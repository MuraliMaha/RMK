//
//  StructuresAndEnums.swift
//  TripArcher
//
//  Created by APPLE on 22/11/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit


struct TravellerDetailStruct {
    var structIndex : String!
    var travellerTitle : String!
    var firstName : String!
    var lastName : String!
    var dateOfBirth : String!
    var passportNo : String!
    var expiryDate : String!
    var filterStr : String!
    
}

//{"CityCode":"KBL","CityName":"Kabul","CountryCode":"AF","CountryName":"Afghanistan"}
struct HotelCityStruct{
    var cityCode : String!
    var cityName : String!
    var countryCode : String!
    var countryName : String!
}

//{"AirportCode":"CJB","CityName":"Coimbatore(CJB)","Country_sK":1.0,"CountryName":"India"}
struct AirportStruct : Equatable {
    var airportCode : String!
    var cityName : String!
    var countrySK : String!
    var countryName : String!
    
    static func == (lhs : AirportStruct,rhs : AirportStruct) -> Bool {
        return lhs.airportCode == rhs.airportCode
    }
}

/*
struct Car: Equatable {
    
    var modelName = String()
    var manufacturer = String()
    
    init(modelName: String, manufacturer: String) {
        self.modelName = modelName
        self.manufacturer = manufacturer
    }
    
    static func == (lhs: Car, rhs: Car) -> Bool {
        return lhs.modelName == rhs.modelName
    }
} */

struct FlightResultAndDetailStruct {

    var wayType : String!
    
    //for going
    
    var flightID : String!
    
    var flightImgName : String!
    var flightImgData : Data?
    var flightName : String!
    var departureTime : String!
    var departureAirportCode : String!
    var duration : String!
    var stopDetails : String!
    var noOfStops : String!
    var arrivalTime : String!
    var arrivalAirportCode : String!
    var amount : String!
    
    var isMultiAirlineAvailable : Bool!
    var detailArrWithFlightDetailStruct = [FlightDetailStruct]()
    
    
    //for returning
//    var returnFlightID : String!
    var returnFlightImgName : String!
    var returnFlightImgData : Data!
    var returnFlightName : String!
    var returnDepartureTime : String!
    var returnDepartureAirportCode : String!
    var returnDuration : String!
    var returnNoofStops : String!
    var returnArrivalTime :String!
    var returnArrivalAirportCode : String!
    
    var isReturnMultiAirlineAvailable : Bool!
    var returnDetailArrWithFlightDetailStruct = [FlightDetailStruct]()
    
}
struct FlightDetailStruct {
    var flightImgName : String!
    var flightImgData : Data!
    var flightNumber : String!
    var departureDate : String!
    var departureTime : String!
    var arrivalDate : String!
    var arrivalTime : String!
    
    var marketing : String!
    var operating : String!
    var duration : String!
    var fromAirportName : String!
    var toAirportName : String!
    
    var departureDateTime : String!
    var arrivalDateTime : String!
    
//    var flightName : String!
    var stop : String!
    var fromCity : String!
    var toCity : String!
}

struct FinalStruct {
    var flightImgName : String!
    var flightImgData : Data?
    var flightName : String!
    var departureTime : String!
    var departureAirportCode : String!
    var duration : String!
    var stop : String!
    var arrivalTime : String!
    var arrivalAirportCode : String!
    
    var TripDetailsArr = [FlightDetailStruct]()
}
extension FinalStruct {
//    var structExtension : String!
    
}

//Not Required
struct RoomStruct1 {
    var roomNo : String!
    var noOfAdult : String!
    var noOfChildren : String!
    var ageArr = [ChildrenAgeStruct2]()
}
//Not Required
struct ChildrenAgeStruct2 {
    var age : String!
}

struct RoomStruct {
    var roomNo : Int!
    var noOfAdult : Int!
    var noOfChildren : Int!
    var ageArr = [ChildrenAgeStruct]()
}
struct ChildrenAgeStruct {
    var age : Int!
}


// Hotel

struct HotelStruct {
    
    var HotelUniqueKey : String!
    var processId : String!
    var RoomcategoryCode : String!
    var APIType : String!
    
    var NoOfRooms : String!
    var NoOfNights : String!
    var CheckInDate : String!
    var CheckOutDate : String!
    var HotelName : String!
    var ThumbNailImage : String!
    var Address : String!
    var StarRating : String!
    var RatingImage : String!
    var DispTotalAmount : String!
    var RoomDetailArr = [RoomDetailStruct]()
    
    var city : String?
    var country : String?
    var hotelImgData : Data?
}

struct RoomDetailStruct {
    var RoomDescription : String!
    var inclusions : String!
    var TotalAmount : String!
    var Cancellationpolicy : String!
    var BaseFareAmount : String!
    var TotalTaxCharges : String!
    var TotalAmountMarkupWithTax : String!
}



struct HoteltlStruct{
    var hotel_name : String!
    var Address : String!
    var city : String!
    var state : String!
    var country : String!
    var zip : String!
    var locality : String!
    var ContactNumber : String!
    var description : String!
    var checkin : String!
    var checkout : String!
    var numberofrooms : String!
    var numberoffloors : String!
    var Rating : String!
    var amenity_text : String!
    var roomtype : String!
    var bedtype : String!
    var noofbeds : String!
    var noofpax : String!
    var latitude : String!
    var longitude : String!
}

struct FacilitytlStruct {
    var amenity_text : String!
}
struct GallerytlStruct{
    var thumb_nail_image_Url : String!
    var wide_angle_Image_Url : String!
}

//HotelFaciltyGalleryContainerStruct
struct HFGContainerStruct {
    var HoteltlArr = [HoteltlStruct]()
    var FaciltytlArr = [FacilitytlStruct]()
    var GallerytlArr = [GallerytlStruct]()
}
