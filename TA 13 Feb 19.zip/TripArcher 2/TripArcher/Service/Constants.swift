//
//  Constants.swift
//  TripArcher
//
//  Created by APPLE on 19/11/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit


struct WebServicesUrl{
    /*
     
     //Local
     
     #define mainurl @"http://192.168.1.3:2217/"
     #define flightserviceurl @"http://192.168.1.3:2217/FlightService.asmx/"
     #define hotelserviceurl @"http://192.168.1.3:2217/hotelService.asmx/"
     #define profileserviceurl @"http://192.168.1.3:2217/Profile.asmx/"
     #define mybookinglist @"http://192.168.1.3:2217/myaccountlistservice.asmx/"
     
     */
    
    /*Live
    
    //#define mainurl @"http://mobileapi.shioktrip.com/"
    //#define flightserviceurl @"http://mobileapi.shioktrip.com/FlightService.asmx/"
    //#define hotelserviceurl @"http://mobileapi.shioktrip.com/hotelService.asmx/"
    //#define profileserviceurl @"http://mobileapi.shioktrip.com/Profile.asmx/"
    //#define mybookinglist @"http://mobileapi.shioktrip.com/myaccountlistservice.asmx/"
    //#define imageURLAirline @"https://www.shioktrip.com/Airline_Images"
    */
    
    
    
    //Test URL
    //Flight
    static let FlightServiceUrl = "http://192.168.1.3:2217/FlightService.asmx"
    static let FlightResult = "FlightResult"
    static let FlightImgURL = "https://www.shioktrip.com/Airline_Images/"
    
    //Hotel
    static let HotelServiceUrl = "http://192.168.1.3:2217/hotelService.asmx"
    static let HotelServiceUrlLive = "http://mobileapi.shioktrip.com/hotelService.asmx"
    
    static let HotelResult = "GetHotelResult"
    static let HotelDetails = "GetHotelDetails"
  
    
}
