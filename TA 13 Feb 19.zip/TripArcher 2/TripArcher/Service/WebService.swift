//
//  WebService.swift
//  TripArcher
//
//  Created by APPLE on 19/11/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

class WebService {
    
    func callAutoAPI(mainURL:String,Suffix:String,parameterDict: [String:String], completion: @escaping ([String:AnyObject]?,Bool) -> ()) {
        
        var ParamsStr = "<ns1:\(Suffix)>"
        
        for (key,value) in parameterDict {
            ParamsStr.append("<ns1:\(key)>\(value)</ns1:\(key)>")
        }
        
        ParamsStr.append("</ns1:\(Suffix)>")
        
        
        let soapMessage =  "<?xml version='1.0' encoding='UTF-8'?><SOAP-ENV:Envelope xmlns:SOAP-ENV='http://schemas.xmlsoap.org/soap/envelope/' xmlns:ns1='http://tempuri.org/'><SOAP-ENV:Body>\(ParamsStr)</SOAP-ENV:Body></SOAP-ENV:Envelope>"
        
        
        let soapLenth = String(soapMessage.count)
        let theUrlString = mainURL
        let theURL = URL(string: theUrlString)
        let mutableR = NSMutableURLRequest(url: theURL!)
        
        mutableR.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        
        mutableR.addValue(soapLenth, forHTTPHeaderField: "Content-Length")
        mutableR.httpMethod = "POST"
        mutableR.httpBody = soapMessage.data(using: String.Encoding.utf8)
        
//        mutableR.timeoutInterval = 35
//        mutableR.allowsCellularAccess = true
        
        let manager = AFHTTPRequestOperation(request: mutableR as URLRequest)
        
        manager.setCompletionBlockWithSuccess({ (operation : AFHTTPRequestOperation, responseObject : Any) -> Void in
            
            let data = NSMutableData(data: responseObject as! Data)
            
            /*
            let data2 = responseObject as! Data
            var str2 = String(data:data2,encoding : .utf8)
          */

            var str = NSString(bytes: data.mutableBytes, length: data.length, encoding:String.Encoding.utf8.rawValue)
//            print("inital str = ",str)
            
            str = (str?.substring(from: 292) as! NSString)
            let rang : NSRange = (str?.range(of: "<"))!
            
            if rang.location == NSNotFound {
                print("NSRangeException - Index out of bounds........Service Failed")
                completion(nil,false)
            }else{
                str = (str?.substring(to: rang.location) as! NSString)
                print("str from WebService class =",str!)
                if let FinalData = str?.data(using: String.Encoding.utf8.rawValue) {
                    if let JsonDict:[String:AnyObject] = try? JSONSerialization.jsonObject(with: FinalData, options: .allowFragments) as! [String:AnyObject] {
                        completion(JsonDict,true)
                    }
                    else {
                        completion(nil,false)
                    }
                }
                else {
                    completion(nil,false)
                }
            }
            

            
        }, failure: { (operation : AFHTTPRequestOperation, error : Error) -> Void in
            
            print("Service call error is :",error, terminator: "")
            
            completion(nil,false)
            
        })
        
        manager.start()
        
    }
    //MARK:- HTTP POST ----------- Flight
    func HTTP_POST_WebServiceMethod_Flight(mainURL:String,suffix : String , parameterDict : [String:String],completion:@escaping (_ Data:Any,_ IsSuccess:Bool) -> ())
    {
        
        //Part 1
        var parameters = ""
        for (key,value) in parameterDict {
            parameters.append(key + "=" + value + "&")
        }
        parameters.remove(at: parameters.index(parameters.endIndex, offsetBy: -1))
        let soapLenth = String(parameters.count)
        
        
        //Part 2
        let theUrlString = mainURL + "/" + suffix
        let theURL = URL(string: theUrlString)
        
        //Part 3
        var mutableR = URLRequest.init(url: theURL!)
        mutableR.httpMethod = "POST"
        mutableR.allHTTPHeaderFields = ["Content-Type":"application/x-www-form-urlencoded","Content-Length":soapLenth]
        mutableR.httpBody = parameters.data(using: String.Encoding.utf8)
        
        mutableR.timeoutInterval = 35
        mutableR.allowsCellularAccess = true
        
        //Part 4
        let manager = AFHTTPRequestOperation(request: mutableR as URLRequest)
        
        manager.setCompletionBlockWithSuccess({ (operation : AFHTTPRequestOperation, responseObject : Any) -> Void in
            
            let responseData = responseObject as! Data
            let stringFromData = String(data: responseData, encoding: .utf8)
            
            //            var strDic = String(describing: stringFromData)
            let strDic = String(stringFromData!.dropFirst(75))
            
            let finalStr = strDic.dropLast(9) as NSString
            //            print(finalStr)
            
            if let FinalData = finalStr.data(using: String.Encoding.utf8.rawValue) {
                if let JsonDict:[String:AnyObject] = try? JSONSerialization.jsonObject(with: FinalData, options: .mutableContainers) as! [String:AnyObject] {
                    completion(JsonDict,true)
                }
                else {
                    completion([],false)
                }
            }
            else {
                completion([],false)
            }
            
        }, failure: { (operation : AFHTTPRequestOperation, error : Error) -> Void in
            
            print(error, terminator: "")
            
            completion([:],false)
            
        })
        
        manager.start()
    }
    
    //MARK:- HTTP POST
    func HTTP_POST_WebServiceMethod_Hotel(mainURL:String,suffix : String , parameterDict : [String:String],completion:@escaping (_ Data:Any,_ IsSuccess:Bool) -> ())
    {
        
        //Part 1
        var parameters = ""
        for (key,value) in parameterDict {
            parameters.append(key + "=" + value + "&")
        }
        parameters.remove(at: parameters.index(parameters.endIndex, offsetBy: -1))
        let soapLenth = String(parameters.count)
        
        
        //Part 2
        let theUrlString = mainURL + "/" + suffix
        let theURL = URL(string: theUrlString)
        
        //Part 3
        var mutableR = URLRequest.init(url: theURL!)
        mutableR.httpMethod = "POST"
        mutableR.allHTTPHeaderFields = ["Content-Type":"application/x-www-form-urlencoded","Content-Length":soapLenth]
        mutableR.httpBody = parameters.data(using: String.Encoding.utf8)
        
        mutableR.timeoutInterval = 35
        mutableR.allowsCellularAccess = true
        
        //Part 4
        let manager = AFHTTPRequestOperation(request: mutableR as URLRequest)
        
        manager.setCompletionBlockWithSuccess({ (operation : AFHTTPRequestOperation, responseObject : Any) -> Void in

            let responseData = responseObject as! Data
            let stringFromData = String(data: responseData, encoding: .utf8)
            
//            var strDic = String(describing: stringFromData)
            let strDic = String(stringFromData!.dropFirst(75))

            let finalStr = strDic.dropLast(9) as NSString
//            print(finalStr)
            
            if finalStr == "" {
                print("the finalStr after dropping is empty")
                let myArr : [String] = ["No data for your search..."]
                completion(myArr,false)
            }else{
                if let FinalData = finalStr.data(using: String.Encoding.utf8.rawValue) {
                    if let JsonArr:[[String:AnyObject]] = try? JSONSerialization.jsonObject(with: FinalData, options: .mutableContainers) as! [[String:AnyObject]] {
                        completion(JsonArr,true)
                    }
                    else {
                        
                        completion([],false)
                    }
                }
                else {
                    completion([],false)
                }
            }
            
        }, failure: { (operation : AFHTTPRequestOperation, error : Error) -> Void in
            
            print(error, terminator: "")
            
            completion([],false)
            
        })
        
        manager.start()
    }
}
