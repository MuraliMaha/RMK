//
//  HomePageVC4.swift
//  TripArcher
//
//  Created by APPLE on 26/12/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

class HomePageVC4: UIViewController {

    @IBOutlet weak var flightView: UIView!
    @IBOutlet weak var hotelView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.flightView.backgroundColor = hexStringToUIColor(hex: "#AFCA1F")
        //        self.flightView.layer.shadowColor = hexStringToUIColor(hex: "#AFCA1F").cgColor
        self.flightView.layer.cornerRadius = 5
        self.flightView.clipsToBounds = true
        self.flightView.layer.masksToBounds = false
        self.flightView.shadowOffset = CGSize(width: 5.0, height: 0)
        self.flightView.shadowRadius = 5;
        self.flightView.shadowOpacity = 0.5;
        
        self.hotelView.backgroundColor = hexStringToUIColor(hex: "#AFCA1F")//2E65B0
        //        self.hotelView.layer.shadowColor = hexStringToUIColor(hex: "#AFCA1F").cgColor
        self.hotelView.layer.cornerRadius = 5
        self.hotelView.clipsToBounds = true
        self.hotelView.layer.masksToBounds = false
        self.hotelView.shadowOffset = CGSize(width: 5.0, height: 0)
        self.hotelView.shadowRadius = 5;
        self.hotelView.shadowOpacity = 0.5;
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    @IBAction func flightBtnTapped(_ sender: UIButton) {
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "SearchFlightVC2SBID") as! SearchFlightVC2
        self.navigationController?.pushViewController(ctrl, animated: true)
    }

}
