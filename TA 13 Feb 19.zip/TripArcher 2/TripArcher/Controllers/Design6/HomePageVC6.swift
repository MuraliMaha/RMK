//
//  HomePageVC6.swift
//  TripArcher
//
//  Created by APPLE on 26/12/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

class HomePageVC6: UIViewController {

    @IBOutlet weak var flightView: UIView!
    @IBOutlet weak var hotelView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.flightView.backgroundColor = hexStringToUIColor(hex: "#AFCA1F")
//        self.flightView.layer.shadowColor = hexStringToUIColor(hex: "#AFCA1F").cgColor
        self.flightView.layer.cornerRadius = self.flightView.frame.size.width / 2
        self.flightView.clipsToBounds = true
        self.flightView.layer.masksToBounds = false
        self.flightView.shadowOffset = CGSize(width: 5.0, height: 0)
        self.flightView.shadowRadius = 5;
        self.flightView.shadowOpacity = 0.5;
        
        self.hotelView.backgroundColor = hexStringToUIColor(hex: "#AFCA1F")
//        self.hotelView.layer.shadowColor = hexStringToUIColor(hex: "#AFCA1F").cgColor
        self.hotelView.layer.cornerRadius = self.hotelView.frame.size.width / 2
        self.hotelView.clipsToBounds = true
        self.hotelView.layer.masksToBounds = false
        self.hotelView.shadowOffset = CGSize(width: 5.0, height: 0)
        self.hotelView.shadowRadius = 5;
        self.hotelView.shadowOpacity = 0.5;
        
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
