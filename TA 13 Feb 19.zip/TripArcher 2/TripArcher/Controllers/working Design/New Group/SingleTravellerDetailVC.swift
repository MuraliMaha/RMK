//
//  SingleTravellerDetailVC.swift
//  TripArcher
//
//  Created by APPLE on 31/12/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

protocol SingleTravellerDetailProtocol {
    func doneBtnTapped(_ structToPass : TravellerDetailStruct , _ controller : SingleTravellerDetailVC )
}
class SingleTravellerDetailVC: UIViewController {

    @IBOutlet weak var passportNoTxtField: UITextField!
    @IBOutlet weak var lastNameTxtField: UITextField!
    @IBOutlet weak var firstNameTxtField: UITextField!
    @IBOutlet weak var dateOfBirthTxtField: UITextField!
    @IBOutlet weak var expiryTxtField: UITextField!
    
    var DelegateVar:SingleTravellerDetailProtocol!
    var travellerTVIndex : Int!
    

    @IBOutlet weak var datePickerBGView: UIView!
    @IBOutlet weak var datePickerContainerView: UIView!
    
    
    var dateString : String!
    var dateFormatter = DateFormatter()
    
    
    var myDatePicker: UIDatePicker!
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        firstNameTxtField.delegate = self
        lastNameTxtField.delegate = self
        dateOfBirthTxtField.delegate = self
        passportNoTxtField.delegate = self
        expiryTxtField.delegate = self
        
        myDatePicker = UIDatePicker()
        
        dateFormatter.dateFormat = "dd-MMM-yyyy"
        dateString = dateFormatter.string(from: Date())
        
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.default
//        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.blue
//        toolBar.backgroundColor = hexStringToUIColor(hex: "#AFCA1F")
        toolBar.barTintColor = hexStringToUIColor(hex: "#AFCA1F")
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action:#selector(donePicker))
        
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.plain, target: self, action:#selector(cancelPicker))
        
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        myDatePicker.datePickerMode = UIDatePickerMode.date
        dateOfBirthTxtField.inputView = myDatePicker
        dateOfBirthTxtField.inputAccessoryView = toolBar
        
        
        expiryTxtField.inputView = myDatePicker
        expiryTxtField.inputAccessoryView = toolBar
        
//        datePickerBGView.isHidden = true
//        dateOfBirthTxtField.inputView = datePickerBGView
        
        
        
        
        /*
        datepicker.datePickerMode = UIDatePickerMode.date
        datetextfield.inputView = datepicker
        datetextfield.inputAccessoryView = toolBar
        */
        
    }
    @objc func donePicker(sender : UIBarButtonItem) {
        
        if dateOfBirthTxtField.isFirstResponder {
//            if dateOfBirthTxtField.text! != dateString! {
//                timetextfield.text = "";
//            }
            dateOfBirthTxtField.text = dateString
            self.dateOfBirthTxtField.resignFirstResponder()
        }
        if expiryTxtField.isFirstResponder{
            expiryTxtField.text = dateString
            self.expiryTxtField.resignFirstResponder()
        }
        
    }
    
    @objc func cancelPicker(sender : UIBarButtonItem ){
        if dateOfBirthTxtField.isFirstResponder {
            self.dateOfBirthTxtField.resignFirstResponder()
        }
        if expiryTxtField.isFirstResponder{
            self.expiryTxtField.resignFirstResponder()
        }
    }

    @IBOutlet weak var mrBtn: UIButton!
    @IBOutlet weak var msBtn: UIButton!
    @IBOutlet weak var mrsBtn: UIButton!
    var selectedTitle : String!
    
    @IBAction func mrBtnTapped(_ sender: UIButton) {
        print("mr btn tapped")
        mrBtn.isSelected = true
        msBtn.isSelected = false
        mrsBtn.isSelected = false
        selectedTitle = "Mr"
    }
    @IBAction func msBtnTapped(_ sender: UIButton) {
        print("ms btn tapped")
        mrBtn.isSelected = false
        msBtn.isSelected = true
        mrsBtn.isSelected = false
        selectedTitle = "Ms"
    }
    @IBAction func mrsBtnTapped(_ sender: UIButton) {
        print("mrs btn tapped")
        mrBtn.isSelected = false
        msBtn.isSelected = false
        mrsBtn.isSelected = true
        selectedTitle = "Mrs"
    }
    
    @IBAction func backBtnTapped(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    
   
    
   
    
    @IBAction func doneBtnTapped(_ sender: UIButton) {
        if !mrBtn.isSelected && !msBtn.isSelected && !mrsBtn.isSelected {
            self.view.ShowBlackTostWithText(message: "Please select Title", Interval: 3)
        }else if (firstNameTxtField.text?.isEmpty)! {
            self.view.ShowBlackTostWithText(message: "Please provide First Name", Interval: 3)
        }else if (lastNameTxtField.text?.isEmpty)! {
            self.view.ShowBlackTostWithText(message: "Please provide Last Name", Interval: 3)
        }else if (dateOfBirthTxtField.text?.isEmpty)! {
            self.view.ShowBlackTostWithText(message: "Please provide Date of Birth", Interval: 3)
        }else if (passportNoTxtField.text?.isEmpty)!{
            self.view.ShowBlackTostWithText(message: "Please provide Passport Number", Interval: 3)
        }else if (expiryTxtField.text?.isEmpty)!{
            self.view.ShowBlackTostWithText(message: "Please provide Expiry Date", Interval: 3)
        }else{
            var structToPass = TravellerDetailStruct()
            structToPass.structIndex = "\(travellerTVIndex!)"
            structToPass.travellerTitle = selectedTitle!
            structToPass.firstName = firstNameTxtField.text!
            structToPass.lastName = lastNameTxtField.text!
            structToPass.dateOfBirth = dateOfBirthTxtField.text!
            structToPass.passportNo = passportNoTxtField.text!
            structToPass.expiryDate = expiryTxtField.text!
            structToPass.filterStr = "filled" // This parameter is for, showing toast if value is not provided in the tableview textfields.One Struct for traveller is created.
            
            DelegateVar.doneBtnTapped(structToPass, self)
        } 
    }
    
    @IBAction func datePickerDoneBtnTapped(_ sender: UIButton) {
        self.view.endEditing(true)
//        self.datePickerBGView.isHidden = true
        print("The Selected Date =",dateString)
        self.dateOfBirthTxtField.text = dateString
    }
}
extension SingleTravellerDetailVC : UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == dateOfBirthTxtField || textField == expiryTxtField{
//            datePickerBGView.isHidden = false
//            myDatePicker.isHidden = false
            dateString = dateFormatter.string(from: Date())
//            datepicker.minimumDate = NSDate() as Date
            let calendar:NSCalendar = NSCalendar.current as NSCalendar
            let components = calendar.components([NSCalendar.Unit.year, NSCalendar.Unit.month, NSCalendar.Unit.day, NSCalendar.Unit.hour, NSCalendar.Unit.minute], from: NSDate() as Date)
            let date = calendar.date(from: components)!
            myDatePicker.setDate(date, animated: true)
            myDatePicker.addTarget(self, action: #selector(handleDatePicker), for: UIControlEvents.valueChanged)
        }
    }
    
    @objc func handleDatePicker(sender: UIDatePicker) {
        dateString = dateFormatter.string(from: sender.date)
    }
}
