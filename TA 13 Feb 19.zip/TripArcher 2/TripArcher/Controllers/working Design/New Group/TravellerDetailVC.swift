//
//  TravellerDetailVC.swift
//  TripArcher
//
//  Created by APPLE on 12/12/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

class TravellerDetailVC: UIViewController {

    var ActualY : CGFloat = 0
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var travellerListTV: UITableView!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var footerView: UIView!
    @IBOutlet weak var bottomView: UIView!
    
    
    @IBOutlet weak var fromCityLbl: UILabel!
    @IBOutlet weak var onewayOrTwowayImgView: UIImageView!
    @IBOutlet weak var toCityLbl: UILabel!
    @IBOutlet weak var dateLbl: UILabel!
    
    var selectedStruct : FlightResultAndDetailStruct!
    var providedInputDict = [String:String]()
    
    var adultCount : Int!
    var childCount : Int!
    var infantCount : Int!
    
    //    var adultIndex = 0
    var childIndex = 0
    var infantIndex = 0
    
    
    var myIndexPath : IndexPath!
    
//    var GrandArr = [String]()
    var GrandArr = [TravellerDetailStruct]()
    var StaticArr = [String]()
//    var detailLabelArr = [String]()
   
    var viewloadedFlag : Bool!
    
    @IBOutlet weak var mobileNoTxtField: UITextField!
    @IBOutlet weak var emailTxtField: UITextField!
    
    var everythingProvidedFlag : Bool = false
   
    @IBOutlet weak var amountLbl: UILabel!
    
    
    var isKeyboardVisible : Bool = false
    var mobileNoTxtFieldFocusFlag : Bool!
    var emailTxtFieldFocusFlag : Bool!
    let keyboardDoneButton = UIButton(type: UIButton.ButtonType.custom)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.viewloadedFlag = true
//        print("viewLoadedFlag = \(self.viewloadedFlag)")
        self.navigationController?.navigationBar.isHidden = false
        
        travellerListTV.delegate = self
        travellerListTV.dataSource = self
        
        adultCount = Int(self.providedInputDict["AdultCount"]!)
        childCount = Int(self.providedInputDict["ChildCount"]!)
        infantCount = Int(self.providedInputDict["InfantCount"]!)
        print("Count = ",(adultCount+childCount+infantCount))
        
        self.fromCityLbl.text = selectedStruct.detailArrWithFlightDetailStruct[0].fromCity
        self.toCityLbl.text = selectedStruct.detailArrWithFlightDetailStruct.last?.toCity
        if selectedStruct.wayType == "one" {
            self.onewayOrTwowayImgView.image = UIImage.init(named: "Oneway100")
            self.dateLbl.text = selectedStruct.detailArrWithFlightDetailStruct.first?.departureDate
        }else{
            self.onewayOrTwowayImgView.image = UIImage.init(named: "Roundtrip100")
            self.dateLbl.text =  selectedStruct.detailArrWithFlightDetailStruct[0].departureDate! + " - " + selectedStruct.returnDetailArrWithFlightDetailStruct[0].departureDate!
        }
        
        self.amountLbl.text = "MYR." + selectedStruct.amount
        mobileNoTxtField.delegate = self
        emailTxtField.delegate = self
        
        
        keyboardDoneButton.setTitle("Done", for: UIControl.State())
        keyboardDoneButton.setTitleColor(UIColor.black, for: UIControl.State())
        keyboardDoneButton.addTarget(self, action: #selector(keyboardDoneBtnTapped(_:)), for: UIControl.Event.touchUpInside)
    }
    @objc func keyboardDoneBtnTapped(_ sender : UIButton){
        
        DispatchQueue.main.async { () -> Void in
            UIView.setAnimationsEnabled(true)
            self.keyboardDoneButton.isHidden = true
            self.mobileNoTxtField.resignFirstResponder()
            
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        self.viewloadedFlag = false
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: .UIKeyboardWillHide, object: nil)
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
        
    }
    //MARK: - Keyboard show
    var keyboardSize : CGRect?
    @objc func keyboardWillShow(_ notification : NSNotification){
        
        keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue
        if !self.isKeyboardVisible{
            self.view.frame.origin.y -= keyboardSize!.height
        }
        self.isKeyboardVisible = true
        
        
        
        if !emailTxtFieldFocusFlag {
            let height , width ,btnHeight,btnWidth : CGFloat
            width = CGFloat(UIScreen.main.bounds.width)
            let aStr = notification.userInfo![UIKeyboardFrameEndUserInfoKey] as? NSValue
            height = (aStr?.cgRectValue.height)!
            
            btnHeight = height/4 // Four Rows
            btnWidth = (width/3) - 2 // Three Columns - 2px to account for lines
            
            DispatchQueue.main.async { () -> Void in
                self.keyboardDoneButton.isHidden = false
                let keyBoardWindow = UIApplication.shared.windows.last
                
                self.keyboardDoneButton.frame = CGRect(x: 0, y: ((keyBoardWindow?.frame.size.height)! - btnHeight)+1, width: btnWidth, height: btnHeight)
                keyBoardWindow?.addSubview(self.keyboardDoneButton)
                keyBoardWindow?.bringSubview(toFront: self.keyboardDoneButton)   
            }
        }
        
    }
    
    @objc func keyboardWillHide(_ notification : NSNotification)
    {
        if keyboardSize != nil{ // this condition is for, when keyboard is visible and tapping on backBtn crashes as self.keyboardSize is nil
            self.view.frame.origin.y += keyboardSize!.height
            self.isKeyboardVisible = false
        }else{
            print("KeyboardSize is nil ")
        }
       
    }
    
  
    @IBAction func backBtnTapped(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func proceedToPayBtnTapped(_ sender: UIButton) {
        
        
        for (idx,aStruct) in GrandArr.enumerated(){
            
            if aStruct.filterStr == nil{
                self.view.ShowBlackTostWithText(message: "Please enter \(aStruct.firstName!) detail", Interval: 3)
                break
            }
            
            if idx == GrandArr.endIndex - 1 {
                print("EveryThing Provided")
                self.everythingProvidedFlag = true
            }
        }
        
        
        if everythingProvidedFlag {
//            if !(self.mobileNoTxtField.text?.isValidMobileNumber())!{
//                self.view.ShowBlackTostWithText(message: "Please enter valid Mobile number", Interval: 3)
//            }
            if !(self.emailTxtField.text?.isValidEmail())!{
                self.view.ShowBlackTostWithText(message: "Please enter valid Email ID", Interval: 3)
            }else{
                print("Proceed to Pay....")
                if mobileNoTxtField.isFirstResponder {
                    mobileNoTxtField.resignFirstResponder()
                }
                if emailTxtField.isFirstResponder {
                    emailTxtField.resignFirstResponder()
                }
                let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "PaymentVCSBID") as! PaymentVC
                self.navigationController?.pushViewController(ctrl, animated: true)
            }
        }
    }
}
extension TravellerDetailVC : UITableViewDataSource , UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (adultCount+childCount+infantCount)
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCellID", for: indexPath) as! MyCellClass
        
        var aTravellerStruct = TravellerDetailStruct()
        if indexPath.row < adultCount {
            
            if self.viewloadedFlag {
                aTravellerStruct.firstName = "Adult \(indexPath.row + 1)"
                self.GrandArr.append(aTravellerStruct)
            }
            cell.nameLbl.text = self.GrandArr[indexPath.row].firstName
            
        }else if indexPath.row < (self.adultCount+self.childCount){
            
            childIndex += 1
            if self.viewloadedFlag {
                aTravellerStruct.firstName = "Child \(childIndex)"
                self.GrandArr.append(aTravellerStruct)
            }
            cell.nameLbl.text = self.GrandArr[indexPath.row].firstName
        }else if indexPath.row < (self.adultCount+self.childCount+self.infantCount){
            infantIndex += 1
            if self.viewloadedFlag {
                aTravellerStruct.firstName = "Infant \(infantIndex)"
                self.GrandArr.append(aTravellerStruct)
            }
            cell.nameLbl.text = self.GrandArr[indexPath.row].firstName
            
        }
        
        if self.viewloadedFlag {
            self.StaticArr.append(self.GrandArr[indexPath.row].firstName)
        }
        if cell.detailLbl.textColor == UIColor.black {
            print("Dont change Text Color - TravellerDetailVC")
        }else{
            cell.detailLbl.textColor = hexStringToUIColor(hex: "#2E65B0")
        }
        
        
        if indexPath.row == (adultCount+childCount+infantCount) - 1{
            cell.cellBottomContraint.constant = 1
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        print("Tapped Cell index = \(indexPath.row)")
        self.myIndexPath = indexPath
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "SingleTravellerDetailVCSBID") as! SingleTravellerDetailVC
        ctrl.DelegateVar = self
        ctrl.travellerTVIndex = indexPath.row
//        self.present(ctrl, animated: true, completion: nil)
        self.navigationController?.pushViewController(ctrl, animated: true)
    }
}
class MyCellClass : UITableViewCell {
    
    @IBOutlet weak var cellBottomContraint: NSLayoutConstraint!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var detailLbl: UILabel!
}

extension TravellerDetailVC : UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == mobileNoTxtField {
            UIView.setAnimationsEnabled(false)
            mobileNoTxtFieldFocusFlag = true
            emailTxtFieldFocusFlag = false
//            NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
        }
        if textField == emailTxtField{
            emailTxtFieldFocusFlag = true
            mobileNoTxtFieldFocusFlag = false
        }
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == mobileNoTxtField {
            DispatchQueue.main.async { () -> Void in
                self.keyboardDoneButton.isHidden = true
            }
            
        }
    }
//    @objc func keyboardWillShow(_ note : Notification) -> Void{
//
//        let height , width ,btnHeight,btnWidth : CGFloat
//        width = CGFloat(UIScreen.main.bounds.width)
//        let aStr = note.userInfo![UIKeyboardFrameEndUserInfoKey] as? NSValue
//        height = (aStr?.cgRectValue.height)!
//
//        btnHeight = height/4 // Four Rows
//        btnWidth = (width/3) - 2 // Three Columns - 2px to account for lines
//
//        DispatchQueue.main.async { () -> Void in
//            self.keyboardDoneButton.isHidden = false
//            let keyBoardWindow = UIApplication.shared.windows.last
//
//            self.keyboardDoneButton.frame = CGRect(x: 0, y: ((keyBoardWindow?.frame.size.height)! - btnHeight)+1, width: btnWidth, height: btnHeight)
//            keyBoardWindow?.addSubview(self.keyboardDoneButton)
//            keyBoardWindow?.bringSubview(toFront: self.keyboardDoneButton)
//
//        }
//    }
    
    /*
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == mobileNoTxtField {
            emailTxtField.isUserInteractionEnabled = false
        }else if textField == emailTxtField {
            mobileNoTxtField.isUserInteractionEnabled = false
        }
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == mobileNoTxtField {
            emailTxtField.isUserInteractionEnabled = true
        }else if textField == emailTxtField {
            mobileNoTxtField.isUserInteractionEnabled = true
        }
    } */
}

extension TravellerDetailVC : SingleTravellerDetailProtocol {
    func doneBtnTapped(_ structToPass: TravellerDetailStruct, _ controller: SingleTravellerDetailVC) {
        print("Details of Traveller = ", structToPass)
        
        let cell = travellerListTV.cellForRow(at: myIndexPath) as! MyCellClass
        self.GrandArr[myIndexPath.row] = structToPass
        cell.nameLbl.text = self.GrandArr[myIndexPath.row].firstName
        cell.detailLbl.text = self.StaticArr[myIndexPath.row]
        cell.detailLbl.textColor = UIColor.black
        
        self.navigationController?.popViewController(animated: true)
        
    }
}

