//
//  FlightResultVCTester.swift
//  TripArcher
//
//  Created by APPLE on 10/01/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class FlightResultVCTester: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

//            {
//                "FlightResult": [
//                {
//                "FlightId": "88",
//                "recid": "88",
//                "sefref": "88",
//                "refno": "",
//                "Number": "sess",
//                "carrier": "UL~UL~MH~UL~UL",
//                "totalAmountAll": 3086,
//                "TotalBasisAmount": "2322",
//                "totalTaxAmountAll": "764",
//                "booingclassall": "O~O~Y~V~V",
//                "farebasisall": "",
//                "TaxSplitupall": "",
//                "breakpointAll": "",
//                "pset": null,
//                "maindt": null,
//                "faretype": "Refundable",
//                "API": "20",
//                "country": "1",
//                "TaxSplitup": "",
//                "TotalDisAmount": 3086,
//                "flightnoall": "194~306~610~319~193",
//                "marketingall": "UL~UL~MH~UL~UL",
//                "ddateall": "2019-01-10~2019-01-11~2019-01-11~2019-01-12~2019-01-12",
//                "adateall": "2019-01-10~2019-01-11~2019-01-11~2019-01-12~2019-01-12",
//                "dtimeall": "153500~010000~212000~085000~133000",
//                "atimeall": "164000~073000~222000~095000~143500",
//                "dairportall": "CJB~CMB~CMB~SIN~SIN~KUL~KUL~CMB~CMB~CJB",
//                "airname": "Coimbatore(CJB),Colombo(CMB),Colombo(CMB),Singapore(SIN),Singapore(SIN),Kuala Lumpur(KUL),Kuala Lumpur(KUL),Colombo(CMB),Colombo(CMB),Coimbatore(CJB)",
//                "stop": "3 Stops",
//                "departuretime": "15 : 35",
//                "arrivaltime": "16 : 40",
//                "aname": "SriLankan Airlines,Malaysia Airlines,SriLankan Airlines,SriLankan Airlines",
//                "aairportall": "0",
//                "TerminalAll": "0~0~0~0~0",
//                "Markupall": 0,
//                "SSessionid": "88",
//                "RSessionid": "88",
//                "IsLCC": "false",
//                "Source": "NML",
//                "APIAmt": "3086",
//                "FileName": "IXCRAJ042_IXCRAJ042_10012019_CJB to SIN_54.xml",
//                "TRI_SplitUp": "0",
//                "LCCtotalAmountAll": 0,
//                "LCCTotalBasisAmount": "0",
//                "LCCtotalTaxAmountAll": "0",
//                "LCCSessionID": "0",
//                "LCCrowID": "0",
//                "SPLfare": "false",
//                "DepartAirportall": "CJB~CMB~SIN~KUL~CMB",
//                "ArrivalAirportall": "CMB~SIN~KUL~CMB~CJB",
//                "OperatingAirlineall": "UL~UL~MH~UL~UL",
//                "Departdatetimetall": "2019-01-10T15:35:00~2019-01-11T01:00:00~2019-01-11T21:20:00~2019-01-12T08:50:00~2019-01-12T13:30:00",
//                "Arrivaldatetimeall": "2019-01-10T16:40:00~2019-01-11T07:30:00~2019-01-11T22:20:00~2019-01-12T09:50:00~2019-01-12T14:35:00",
//                "EquipmentTypeall": "320~32B~738~32B~320",
//                "MarkupAmt": 0,
//                "DiscountAmt": 0,
//                "AdultType": "Adult(s)",
//                "ChildType": null,
//                "InfantType": null,
//                "AdultBsFare": "2322 X 1",
//                "ChildBsFare": "0",
//                "InfantBsFare": "0",
//                "AdultTotBsFare": "2322",
//                "ChildTotBsFare": "0",
//                "InfantTotBsFare": "0",
//                "ProviderCode": null
//                }
//                ],
//                "Flightdetails": [
//                {
//                "FlightId": "88",
//                "Number": "0",
//                "trip": "1",
//                "flightNumber": "194",
//                "departuredate": "Thu, 10 Jan, 15:35",
//                "departuretime": "15 : 35",
//                "arrivaldate": "Thu, 10 Jan, 16:40",
//                "arrivaltime": "16 : 40",
//                "marketing": "UL",
//                "operating": "SriLankan Airlines",
//                "equipmentType": "320",
//                "fromcity": "Coimbatore(CJB)",
//                "tocity": "Colombo(CMB)",
//                "duration": "1h : 05m",
//                "stop": "Non-Stop",
//                "Terminal": "0",
//                "FromAirportName": "Coimbatore Airport(CJB)",
//                "ToAirportName": "Colombo Airport(CMB)",
//                "DepartureDateTime": "2019-01-10T15:35:00",
//                "ArrivalDateTime": "2019-01-10T16:40:00"
//                },
//                {
//                "FlightId": "88",
//                "Number": "1",
//                "trip": "2",
//                "flightNumber": "306",
//                "departuredate": "Fri, 11 Jan, 01:00",
//                "departuretime": "01 : 00",
//                "arrivaldate": "Fri, 11 Jan, 07:30",
//                "arrivaltime": "07 : 30",
//                "marketing": "UL",
//                "operating": "SriLankan Airlines",
//                "equipmentType": "32B",
//                "fromcity": "Colombo(CMB)",
//                "tocity": "Singapore(SIN)",
//                "duration": "4h : 00m",
//                "stop": "Non-Stop",
//                "Terminal": "0",
//                "FromAirportName": "Colombo Airport(CMB)",
//                "ToAirportName": "Singapore Airport(SIN)",
//                "DepartureDateTime": "2019-01-11T01:00:00",
//                "ArrivalDateTime": "2019-01-11T07:30:00"
//                }
//                ],
//                "FlightdetailsReturn": [
//                {
//                "FlightId": "88",
//                "Number": "0",
//                "trip": "1",
//                "flightNumber": "610",
//                "departuredate": "Fri, 11 Jan, 21:20",
//                "departuretime": "21 : 20",
//                "arrivaldate": "Fri, 11 Jan, 22:20",
//                "arrivaltime": "22 : 20",
//                "marketing": "MH",
//                "operating": "Malaysia Airlines",
//                "equipmentType": "738",
//                "fromcity": "Singapore(SIN)",
//                "tocity": "Kuala Lumpur(KUL)",
//                "duration": "1h : 00m",
//                "stop": "Non-Stop",
//                "Terminal": "0",
//                "FromAirportName": "Singapore Airport(SIN)",
//                "ToAirportName": "Kuala Lumpur Airport(KUL)",
//                "DepartureDateTime": "2019-01-11T21:20:00",
//                "ArrivalDateTime": "2019-01-11T22:20:00"
//                },
//                {
//                "FlightId": "88",
//                "Number": "1",
//                "trip": "2",
//                "flightNumber": "319",
//                "departuredate": "Sat, 12 Jan, 08:50",
//                "departuretime": "08 : 50",
//                "arrivaldate": "Sat, 12 Jan, 09:50",
//                "arrivaltime": "09 : 50",
//                "marketing": "UL",
//                "operating": "SriLankan Airlines",
//                "equipmentType": "32B",
//                "fromcity": "Kuala Lumpur(KUL)",
//                "tocity": "Colombo(CMB)",
//                "duration": "3h : 30m",
//                "stop": "Non-Stop",
//                "Terminal": "0",
//                "FromAirportName": "Kuala Lumpur Airport(KUL)",
//                "ToAirportName": "Colombo Airport(CMB)",
//                "DepartureDateTime": "2019-01-12T08:50:00",
//                "ArrivalDateTime": "2019-01-12T09:50:00"
//                },
//                {
//                "FlightId": "88",
//                "Number": "2",
//                "trip": "3",
//                "flightNumber": "193",
//                "departuredate": "Sat, 12 Jan, 13:30",
//                "departuretime": "13 : 30",
//                "arrivaldate": "Sat, 12 Jan, 14:35",
//                "arrivaltime": "14 : 35",
//                "marketing": "UL",
//                "operating": "SriLankan Airlines",
//                "equipmentType": "320",
//                "fromcity": "Colombo(CMB)",
//                "tocity": "Coimbatore(CJB)",
//                "duration": "1h : 05m",
//                "stop": "Non-Stop",
//                "Terminal": "0",
//                "FromAirportName": "Colombo Airport(CMB)",
//                "ToAirportName": "Coimbatore Airport(CJB)",
//                "DepartureDateTime": "2019-01-12T13:30:00",
//                "ArrivalDateTime": "2019-01-12T14:35:00"
//                }
//                
//                ]
//        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
