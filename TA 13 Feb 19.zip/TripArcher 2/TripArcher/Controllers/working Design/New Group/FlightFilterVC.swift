//
//  FlightFilterVC.swift
//  TripArcher
//
//  Created by APPLE on 11/02/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class FlightFilterVC: UIViewController {

    @IBOutlet weak var nonStopBtn: DesignableButton!
    @IBOutlet weak var oneStopBtn: DesignableButton!
    @IBOutlet weak var twoStopBtn: DesignableButton!
    
    @IBOutlet weak var before11AMBtn: UIButton!
    @IBOutlet weak var elevenAMtoFivePMBtn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
    @IBAction func backBtnTapped(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func nonStopBtnTapped(_ sender: DesignableButton) {

        if !sender.isSelected {
            sender.isSelected = true
            
            sender.backgroundColor = hexStringToUIColor(hex: "#AFCA1F") //TripArcher Green Color
            sender.setTitleColor(UIColor.white, for: .selected)
            
//            sender.layer.cornerRadius = 5
//            sender.borderWidth = 2
            sender.borderColor = UIColor.black
            
            sender.shadowOffset = CGSize(width: 0,height: 5)
            sender.shadowOpacity = 1

            
        }else{
            sender.isSelected = false
            
            sender.backgroundColor = hexStringToUIColor(hex: "#FFFFFF")
            sender.setTitleColor(UIColor.darkGray, for: .normal)
            
//            sender.layer.cornerRadius = 5
//            sender.borderWidth = 2
            sender.borderColor = hexStringToUIColor(hex: "#AFCA1F")
            
            sender.shadowOffset = CGSize(width: 0,height: 0)
            sender.shadowOpacity = 0
            
        }
        
    }
    
    @IBAction func oneStopBtnTapped(_ sender: DesignableButton) {
        if !sender.isSelected {
            sender.isSelected = true
            
            sender.backgroundColor = hexStringToUIColor(hex: "#AFCA1F") //TripArcher Green Color
            sender.setTitleColor(UIColor.white, for: .selected)
            
            
            sender.borderColor = UIColor.black
            
            sender.shadowOffset = CGSize(width: 0,height: 5)
            sender.shadowOpacity = 1
            
            
        }else{
            sender.isSelected = false
            
            sender.backgroundColor = hexStringToUIColor(hex: "#FFFFFF")
            sender.setTitleColor(UIColor.darkGray, for: .normal)
            
            
            sender.borderColor = hexStringToUIColor(hex: "#AFCA1F")
            
            sender.shadowOffset = CGSize(width: 0,height: 0)
            sender.shadowOpacity = 0
            
        }
    }
    
    @IBAction func twoStopBtnTapped(_ sender: DesignableButton) {
        if !sender.isSelected {
            sender.isSelected = true
            
            sender.backgroundColor = hexStringToUIColor(hex: "#AFCA1F") //TripArcher Green Color
            sender.setTitleColor(UIColor.white, for: .selected)
            
            
            sender.borderColor = UIColor.black
            
            sender.shadowOffset = CGSize(width: 0,height: 5)
            sender.shadowOpacity = 1
            
            
        }else{
            sender.isSelected = false
            
            sender.backgroundColor = hexStringToUIColor(hex: "#FFFFFF")
            sender.setTitleColor(UIColor.darkGray, for: .normal)
            
            
            sender.borderColor = hexStringToUIColor(hex: "#AFCA1F")
            
            sender.shadowOffset = CGSize(width: 0,height: 0)
            sender.shadowOpacity = 0
            
        }
    }
    
    @IBAction func before11AMBtnTapped(_ sender: UIButton) {
        if !sender.isSelected {
            sender.isSelected = true
        }else{
            sender.isSelected = false
        }
    }
    

}

