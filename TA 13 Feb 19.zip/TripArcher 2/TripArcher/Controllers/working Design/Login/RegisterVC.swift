//
//  RegisterVC.swift
//  TripArcher
//
//  Created by APPLE on 14/01/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class RegisterVC: UIViewController {

    @IBOutlet weak var firstNameTxtField: UITextField!
    @IBOutlet weak var lastNameTxtField: UITextField!
    @IBOutlet weak var dateOfBirthTxtField: UITextField!
    @IBOutlet weak var emailTxtField: UITextField!
    @IBOutlet weak var passwordTxtField: UITextField!
    @IBOutlet weak var confirmPasswordTxtField: UITextField!
    @IBOutlet weak var phoneNumberTxtField: UITextField!
    
    var dateString : String!
    var dateFormatter = DateFormatter()
    var myDatePicker: UIDatePicker!
    
    @IBOutlet weak var checkBoxBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        firstNameTxtField.delegate = self
        lastNameTxtField.delegate = self
        dateOfBirthTxtField.delegate = self
        emailTxtField.delegate = self
        passwordTxtField.delegate = self
        confirmPasswordTxtField.delegate = self
        phoneNumberTxtField.delegate = self
        

        myDatePicker = UIDatePicker()

        dateFormatter.dateFormat = "dd-MMM-yyyy"
        dateString = dateFormatter.string(from: Date())
        
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.default
        //        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.blue
        //        toolBar.backgroundColor = hexStringToUIColor(hex: "#AFCA1F")
        toolBar.barTintColor = hexStringToUIColor(hex: "#AFCA1F")
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action:#selector(donePicker))
        
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.plain, target: self, action:#selector(cancelPicker))
        
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        myDatePicker.datePickerMode = UIDatePickerMode.date
        dateOfBirthTxtField.inputView = myDatePicker
        dateOfBirthTxtField.inputAccessoryView = toolBar
        
    }
    @objc func donePicker(sender : UIBarButtonItem) {
        
        if dateOfBirthTxtField.isFirstResponder {
            dateOfBirthTxtField.text = dateString
            self.dateOfBirthTxtField.resignFirstResponder()
        }
    }
    
    @objc func cancelPicker(sender : UIBarButtonItem ){
        if dateOfBirthTxtField.isFirstResponder {
            self.dateOfBirthTxtField.resignFirstResponder()
        }
    }
    @IBAction func backBtnTapped(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }

    @IBAction func checkBoxBtnTapped(_ sender: UIButton) {
        if !sender.isSelected {
            sender.isSelected = true
        }else{
            sender.isSelected = false
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension RegisterVC : UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == passwordTxtField || textField == confirmPasswordTxtField {
            textField.isSecureTextEntry = true
        }
        if textField == phoneNumberTxtField {
            textField.keyboardType = .phonePad
        }
        if textField == emailTxtField{
            textField.keyboardType = .emailAddress
        }
        if textField == dateOfBirthTxtField{
            
            dateString = dateFormatter.string(from: Date())
            let calendar:NSCalendar = NSCalendar.current as NSCalendar
            let components = calendar.components([NSCalendar.Unit.year, NSCalendar.Unit.month, NSCalendar.Unit.day, NSCalendar.Unit.hour, NSCalendar.Unit.minute], from: NSDate() as Date)
            let date = calendar.date(from: components)!
            myDatePicker.setDate(date, animated: true)
            myDatePicker.addTarget(self, action: #selector(handleDatePicker), for: UIControlEvents.valueChanged)
        }
    }
    @objc func handleDatePicker(sender: UIDatePicker) {
        dateString = dateFormatter.string(from: sender.date)
    }
}
