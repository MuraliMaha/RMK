//
//  SplashScreenVC.swift
//  TripArcher
//
//  Created by APPLE on 14/11/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit
var airportStructArrGlobal = [AirportStruct]()
var hotelCityStructArrGlobal = [HotelCityStruct]()

class SplashScreenVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
//        {"AirportCode":"BOM","CityName":"Mumbai(BOM)","Country_sK":1.0,"CountryName":"India"}
        if let path = Bundle.main.path(forResource: "AirportList", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let jsonResult = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves)
                if let jsonResult = jsonResult as? Dictionary<String, AnyObject>
                {
//                    print("Airports Dict:",jsonResult)
                    let airportArr = jsonResult["airports"] as! [[String:AnyObject]]
                    for aDict in airportArr {
                        var aAirportStructObj = AirportStruct()
                        aAirportStructObj.airportCode = "\(aDict["AirportCode"]!)"
                        aAirportStructObj.cityName = "\(aDict["CityName"]!)"
                        aAirportStructObj.countrySK = "\(aDict["Country_sK"]!)"
                        aAirportStructObj.countryName = "\(aDict["CountryName"]!)"
                        airportStructArrGlobal.append(aAirportStructObj)
                    }
                }
            } catch {
                // handle error
                print("Error from catch - FlightPlacesVC - Airport")
            }
        }
        if let path = Bundle.main.path(forResource: "HotelCityList", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let jsonResult = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves)
                if let jsonResult = jsonResult as? Dictionary<String, AnyObject>
                {
                    //                    print("Airports Dict:",jsonResult)
                    let hotelCityArr = jsonResult["hotels"] as! [[String:AnyObject]]
                    for aDict in hotelCityArr {
                        //{"CityCode":"KBL","CityName":"Kabul","CountryCode":"AF","CountryName":"Afghanistan"}
                        
                        var aHotelCityStructObj = HotelCityStruct()
                        aHotelCityStructObj.cityCode = "\(aDict["CityCode"]!)"
                        aHotelCityStructObj.cityName = "\(aDict["CityName"]!)"
                        aHotelCityStructObj.countryCode = "\(aDict["CountryCode"]!)"
                        aHotelCityStructObj.countryName = "\(aDict["CountryName"]!)"
                        hotelCityStructArrGlobal.append(aHotelCityStructObj)
                        
                    }
                }
            } catch {
                // handle error
                print("Error from catch - FlightPlacesVC - HotelCity = \(error)")
            }
        }
        
        Timer.scheduledTimer(timeInterval: 0.2, target: self, selector: #selector(Call), userInfo: nil, repeats: false)
        
    } // end of view didload

    @objc func Call(){
        
        if !(Reachability()!.isReachable) {
            print("No Internet from Splash..................")
            self.view.ShowBlackTostWithText(message: "Check Your internet Connection", Interval: 3)
            Timer.scheduledTimer(timeInterval: 3, target: self, selector: #selector(Call), userInfo: nil, repeats: false)
        }
        else {
            
//            guard FetchLoginResponce() != nil  else {
//                GoToLogin()
//                return
//            }
            

            
//             let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HomePageVCSBID") as! HomePageVC
//
//            let naviCtrl = self.storyboard?.instantiateViewController(withIdentifier: "navigationCtrlSBID") as! UINavigationController
//            naviCtrl.pushViewController(ctrl, animated: true)
            
            let naviCtrl = self.storyboard?.instantiateViewController(withIdentifier: "navigationCtrlSBID")
            self.present(naviCtrl!, animated: true, completion: nil)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
