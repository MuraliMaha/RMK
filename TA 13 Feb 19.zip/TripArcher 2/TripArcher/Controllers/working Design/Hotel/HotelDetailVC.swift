//
//  HotelDetailVC.swift
//  TripArcher
//
//  Created by APPLE on 28/01/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit
import AACarousel

class HotelDetailVC: UIViewController {

//    var HotelDetailArr = [HotelStruct]()
    var selectedHotelStruct : HotelStruct!
    
    @IBOutlet weak var tvContainerView: UIView!
    @IBOutlet weak var roomTypeTV: UITableView!

    @IBOutlet weak var addressLbl: UILabel!

    @IBOutlet weak var ratingView: EDStarRating!
    
    
    var hoteltlArr = [HoteltlStruct]()
    var facilitytlArr = [FacilitytlStruct]()
    var gallerytlArr = [GallerytlStruct]()
    var HFGContainerArr = [HFGContainerStruct]()
    
    var imagePathArr = [String]()
    
    
    @IBOutlet weak var myCarousalView: AACarousel!
    
    var selectedRoomTypeIndex : Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        roomTypeTV.delegate = self
        roomTypeTV.dataSource = self
        
        self.addressLbl.text = selectedHotelStruct.Address!
        
        self.ratingView.starImage = UIImage.init(named: "starUnfilled")
        self.ratingView.starHighlightedImage = UIImage.init(named: "starFilled")
        self.ratingView.maxRating = 5
        self.ratingView.horizontalMargin = 0
        self.ratingView.displayMode = UInt(EDStarRatingDisplayFull)
        self.ratingView.rating = Float(selectedHotelStruct.StarRating)!
        
        myCarousalView.delegate = self
//        myCarousalView.setCarouselData(paths: pathArray,  describedTitle: titleArray, isAutoScroll: true, timer: 5.0, defaultImage: "defaultImage")
        //optional method
        myCarousalView.setCarouselOpaque(layer: true, describedTitle: true, pageIndicator: false)
        myCarousalView.setCarouselLayout(displayStyle: 0, pageIndicatorPositon: 2, pageIndicatorColor: UIColor.init(red: 175.0, green: 202.0, blue: 31.0, alpha: 0.0), describedTitleColor: UIColor.green, layerColor: UIColor.red)
        
        self.callGetHotelDetailService()
    }
    
   
    
    func callGetHotelDetailService(){
        
        if (Reachability()?.isReachable)! {
            showLoading()
            let DictInput = [
                "HotelID":selectedHotelStruct.HotelUniqueKey!,
                "apiname":selectedHotelStruct.APIType!,
                "prid":selectedHotelStruct.processId!,
                "HotelCity":selectedHotelStruct.city!,
                "HotelCountry":selectedHotelStruct.country!,
                "ReqType":"json"
            ]
            
            WebService().HTTP_POST_WebServiceMethod_Hotel(mainURL: WebServicesUrl.HotelServiceUrl, suffix: WebServicesUrl.HotelDetails, parameterDict: DictInput) { (ResponseArr, ResponseStatus) in
                hideLoading()
                
                if ResponseStatus {
                    print("Service call success ..........")
                    
//                    self.flightResultArr = responce["FlightResult"] as! [[String:AnyObject]]
                    
                    let fullResponseArr = ResponseArr as! [[String:AnyObject]]
                    for aDict in fullResponseArr {
                        var aHFGContainerStruct = HFGContainerStruct()
                        let TempHoteltlArr = aDict["hoteltl"] as! [[String:AnyObject]]
                        let TempFacilitytlArr = aDict["facilitytl"] as! [[String:AnyObject]]
                        let TempGallerytlArr = aDict["gallerytl"] as! [[String:AnyObject]]
                        
                        self.hoteltlArr.removeAll()
                        for aHotelDict in TempHoteltlArr{
                            var aHotelStru = HoteltlStruct()
                            aHotelStru.Address = "\(aHotelDict["Address"]!)"
                            aHotelStru.hotel_name = "\(aHotelDict["hotel_name"]!)"
                            self.hoteltlArr.append(aHotelStru)
                        }
                        
                        self.facilitytlArr.removeAll()
                        for aFacilityDict in TempFacilitytlArr{
                            var aFacilityStru = FacilitytlStruct()
                            aFacilityStru.amenity_text = "\(aFacilityDict["amenity_text"]!)"
                            self.facilitytlArr.append(aFacilityStru)
                            
                        }
                        
                        self.imagePathArr.removeAll()
                        self.gallerytlArr.removeAll()
                        for galDict in TempGallerytlArr{
                            var aGalStr = GallerytlStruct()
                            aGalStr.thumb_nail_image_Url = "\(galDict["thumb_nail_image_Url"]!)"
                            aGalStr.wide_angle_Image_Url = "\(galDict["wide_angle_Image_Url"]!)"
                            self.gallerytlArr.append(aGalStr)
                            self.imagePathArr.append(aGalStr.thumb_nail_image_Url)
                        }
                        
                        
                        aHFGContainerStruct.HoteltlArr = self.hoteltlArr
                        aHFGContainerStruct.FaciltytlArr = self.facilitytlArr
                        aHFGContainerStruct.GallerytlArr = self.gallerytlArr
                        
                        self.HFGContainerArr.append(aHFGContainerStruct)
                    }
                    
                    print("HFG Container Array count: ",self.HFGContainerArr.count)
                    print("self.HFGContainerArr[0].HoteltlArr.count = ",self.HFGContainerArr[0].HoteltlArr.count)
                    print("self.HFGContainerArr[0].FaciltytlArr.count = ",self.HFGContainerArr[0].FaciltytlArr.count)
                    print("self.HFGContainerArr[0].GallerytlArr.count = ",self.HFGContainerArr[0].GallerytlArr.count)
                    
                    self.myCarousalView.setCarouselData(paths: self.imagePathArr, describedTitle: ["MyTitle"], isAutoScroll: true, timer: 5.0, defaultImage: nil)
                    
                }else{
                    print("Service call failure ..........")
                    print("Try after sometimes...internet connetivity Problem....")
                    self.view.ShowBlackTostWithText(message: "Try after sometimes...internet connetivity Problem....", Interval: 2)
                }
            }
            
            
        }else{
            print("No Internet......")
//            self.dataTVContainerView.isHidden = true
//            self.errorLbl.text = "Internet connetivity Problem!!!"
        }
    }
    
    @IBAction func continueBtnTapped(_ sender: UIButton) {
        /*
        if let temp = selectedRoomTypeIndex {
            print("Room Selected...")
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HotelReviewVCSBID") as! HotelReviewVC
            ctrl.theSelectedHotelStruct = self.selectedHotelStruct
            ctrl.selectedRoomIndex = temp
            self.navigationController?.pushViewController(ctrl, animated: true)
        }else{
            print("Pls select Room type....")
            self.view.ShowBlackTostWithText(message: "Please select RoomType", Interval: 3)
        } */
    }
    @IBAction func backBtnTapped(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
}
extension HotelDetailVC : UITableViewDelegate , UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.selectedHotelStruct.RoomDetailArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RoomTypeCellID", for: indexPath) as! RoomTypeCellClass
        cell.roomTypeLbl.text = self.selectedHotelStruct.RoomDetailArr[indexPath.row].RoomDescription
        cell.inclusionLbl.text = self.selectedHotelStruct.RoomDetailArr[indexPath.row].inclusions
        cell.amountLbl.text = self.selectedHotelStruct.RoomDetailArr[indexPath.row].TotalAmountMarkupWithTax
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
            print("Selected Table index = ",indexPath.row)
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HotelReviewVCSBID") as! HotelReviewVC
            ctrl.theSelectedHotelStruct = self.selectedHotelStruct
            ctrl.selectedRoomIndex = indexPath.row
            self.navigationController?.pushViewController(ctrl, animated: true)
        
    }
}
class RoomTypeCellClass: UITableViewCell {
    @IBOutlet weak var roomTypeLbl: UILabel!
    @IBOutlet weak var inclusionLbl: UILabel!
    @IBOutlet weak var amountLbl: UILabel!
}

extension HotelDetailVC : AACarouselDelegate {
    func didSelectCarouselView(_ view: AACarousel, _ index: Int) {
        print("didSelect CarouselView....")
    }
    
    func callBackFirstDisplayView(_ imageView: UIImageView, _ url: [String], _ index: Int) {
        imageView.sd_setImage(with: URL(string: url[index]), completed: nil)
    }
    
    func downloadImages(_ url: String, _ index: Int) {
        let imgView = UIImageView()
        imgView.sd_setImage(with: URL(string: url)!) { (downloadImage, error, cacheType, url) in
            
            if error == nil{
                self.myCarousalView.images[index] = downloadImage!
            }else{
                print("The error is : \(error)")
            }
        }
    }
}
