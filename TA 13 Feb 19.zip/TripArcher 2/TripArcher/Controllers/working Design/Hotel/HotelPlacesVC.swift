//
//  HotelPlacesVC.swift
//  TripArcher
//
//  Created by APPLE on 21/01/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

protocol HotelPlacesDelegate {
    func didSelectCity(selectedHotelCityStruct : HotelCityStruct,controller : HotelPlacesVC)
}

class HotelPlacesVC: UIViewController {
    
    @IBOutlet weak var searchTxtField: UITextField!
    @IBOutlet weak var placesTV: UITableView!
    
    var hotelPlacesStructArr : [HotelCityStruct]!
    var searchResultsArray = [HotelCityStruct]()
    
    var delegateVariable : HotelPlacesDelegate!

    override func viewDidLoad() {
        super.viewDidLoad()

        self.placesTV.dataSource = self
        self.placesTV.delegate = self
        
        self.searchTxtField.delegate = self
        hotelPlacesStructArr = hotelCityStructArrGlobal
        
        self.searchTxtField.becomeFirstResponder()
    }
    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        NotificationCenter.default.addObserver(self, selector: #selector(self.textChangeNotification), name: NSNotification.Name.UITextFieldTextDidChange, object: nil)
    }
    override func viewWillDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self, name: .UITextFieldTextDidChange , object: nil)
    }
    @objc func textChangeNotification(_ notification : Notification){
        print("SearchTextField changed")
        self.placesTV.isHidden = false
        searchRecordsAsPerText(searchStr : searchTxtField.text!)
    }
    func searchRecordsAsPerText(searchStr: String) {
        
        searchResultsArray.removeAll()
        let Filtered = hotelPlacesStructArr.filter({$0.cityName!.localizedCaseInsensitiveContains(searchStr)})
        searchResultsArray = Filtered
        
        if (searchStr == "") {
            placesTV.isHidden = true
        }
        else {
            if searchResultsArray.count == 0 {
                placesTV.isHidden = true
            }
            placesTV.isHidden = false
        }
        //        print(Filtered)
        
        
        placesTV.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
// MARK: - TextFieldDelegate {
extension HotelPlacesVC : UITextFieldDelegate{
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        if !placesTV.isHidden{
            placesTV.isHidden = true
        }
        textField.resignFirstResponder()
        return true
    }
}
// MARK: - }
//MARK: - TableViewDelegate {

//{"CityCode":"KBL","CityName":"Kabul","CountryCode":"AF","CountryName":"Afghanistan"}
extension HotelPlacesVC : UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchResultsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HotelPlacesCellID", for: indexPath) as! HotelPlacesCellClass
        cell.containerView.layer.cornerRadius = 5
        cell.containerView.clipsToBounds = true
        
        cell.cityNameLbl.text = searchResultsArray[indexPath.row].cityName
        cell.countryNameLbl.text = searchResultsArray[indexPath.row].countryName
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let cell : HotelPlacesCellClass!
        
        cell = tableView.cellForRow(at: indexPath) as! HotelPlacesCellClass
        print("Row:\(indexPath.row) selected and its data is \(cell.cityNameLbl.text!)")
        print("Row:\(indexPath.row) selected and its data is \(cell.countryNameLbl.text!)")
        print("Row:\(indexPath.row) selected and its data is :",searchResultsArray[indexPath.row].cityCode)
        print("Row:\(indexPath.row) selected and its data is :",searchResultsArray[indexPath.row].countryName)
        
        self.placesTV.isHidden = true
        self.searchTxtField.text = ""
        searchTxtField.resignFirstResponder()
        
        delegateVariable.didSelectCity(selectedHotelCityStruct: searchResultsArray[indexPath.row], controller: self)
    }
}
//MARK: - }
class HotelPlacesCellClass : UITableViewCell {
    
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var cityNameLbl: UILabel!
    @IBOutlet weak var countryNameLbl: UILabel!
}
