//
//  SearchHotelVC.swift
//  TripArcher
//
//  Created by APPLE on 21/01/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class SearchHotelVC: UIViewController {

    @IBOutlet weak var cityContainerView: UIView!
    @IBOutlet weak var cityTxtField: UITextField!
    @IBOutlet weak var checkinTxtField: DesignableTextField!
    @IBOutlet weak var checkoutTxtField: DesignableTextField!
    
    var selectedOriginStruct : HotelCityStruct!
    
    @IBOutlet weak var myCalenderContainerView: UIView!
    @IBOutlet weak var myCalenderView: FSCalendar!
    
    var selectedCheckinDateStr : String!
    var selectedCheckoutDateStr = "Nothing"
    
    var selectedCheckinDate : Date!
    var selectedCheckoutDate : Date!
    
    var dateFormatter = DateFormatter()
    var calendarFlag : String!
    
    var inputParameterDateFormatter = DateFormatter()
    var selectedCheckinStrToPass : String!
    var selectedCheckoutStrToPass : String!
    
 
    @IBOutlet weak var noOfNightLbl: DesignableLabel!
    var noOfNight : Int!
    
    @IBOutlet weak var roomTxtField: UITextField!
    @IBOutlet weak var guestTxtField: UITextField!
    
    var totalNoOfAdult : Int = 2
    var totalNoOfChildren : Int = 0
//    var totalNoOfRoom : Int = 1
    
    var selectedArr1 = [RoomStruct1]()
 
    var selectedArr = [RoomStruct]()

    override func viewDidLoad() {
        super.viewDidLoad()

        cityTxtField.delegate = self
        checkinTxtField.delegate = self
        checkoutTxtField.delegate = self
        roomTxtField.delegate = self
        guestTxtField.delegate = self
        
        
        myCalenderContainerView.isHidden = true
        checkinTxtField.inputView = myCalenderContainerView
        myCalenderView.dataSource = self
        myCalenderView.delegate = self
        
        dateFormatter.dateFormat = "dd-MMM-yyyy"
        //        dateFormatter.dateFormat = "yyyy-MM-dd"
        self.checkinTxtField.text = dateFormatter.string(from: Date())
        self.selectedCheckinDateStr = dateFormatter.string(from: Date())
        self.selectedCheckinDate = dateFormatter.date(from: self.selectedCheckinDateStr)
        
        self.checkoutTxtField.text = dateFormatter.string(from: Date())
        self.selectedCheckoutDateStr = dateFormatter.string(from: Date())
        self.selectedCheckoutDate = dateFormatter.date(from: self.selectedCheckoutDateStr)
        
        self.noOfNight = 0
        self.noOfNightLbl.text = "\(self.noOfNight!) Night"
//        print("selected departOn :\(self.selectedDepartOnDateStr!)  returnOn : \(self.selectedReturnOnDateStr)")
        
//        self.selectedReturnOnStrToPass = selectedDepartOnStrToPass
        
        
        
        inputParameterDateFormatter.dateFormat = "dd-MM-yyyy"
        self.selectedCheckinStrToPass = inputParameterDateFormatter.string(from: Date())
        self.selectedCheckoutStrToPass = inputParameterDateFormatter.string(from: Date())
        
        
       
 
        self.myCalenderView.calendarHeaderView.backgroundColor = hexStringToUIColor(hex: "#AFCA1F")
        //        self.myCalenderView.layer.masksToBounds = false
        self.myCalenderView.calendarHeaderView.layer.masksToBounds = false
        
        /*
        let aRoomStruct : RoomStruct1 = RoomStruct1.init(roomNo : "1",noOfAdult: "2", noOfChildren: "0", ageArr: [])
        self.selectedArr.append(aRoomStruct) */
        
        var aRoomStruct = RoomStruct()
        aRoomStruct.roomNo = 1
        aRoomStruct.noOfAdult = 2
        aRoomStruct.noOfChildren = 0
        aRoomStruct.ageArr = []
        self.selectedArr.append(aRoomStruct)
    
        self.roomTxtField.text = "\(self.selectedArr[0].roomNo!) Room"
        self.guestTxtField.text = "\(self.selectedArr[0].noOfAdult!) Adults"
    }
   
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = false
    }
    
    @IBAction func backBtnTapped(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func searchHotelBtnTapped(_ sender: UIButton) {
    
        if !(self.cityTxtField.text?.isEmpty)!{
            let DictInput = [
                
                /*
                 "HotelCity": "coimbatore", //selectedOriginStruct.cityName!,
                 "HotelCountry": "IN", //selectedOriginStruct.countryCode!,
                 "CheckIndate":"08-02-2019", //selectedCheckinDate!,
                 "CheckOutdate":"09-02-2019",
                 "Adult":"2",
                 "Child":"0",
                 "NoOfRooms":"1",
                 "AdultPerRoom1":"2",
                 "ChildrenPerRoom1":"0",
                 "ChildAge1":"0",
                 "ChildAge2":"0",
                 "ChildAge3":"0",
                 "AdultPerRoom2":"0",
                 "ChildrenPerRoom2":"0",
                 "ChildAge21":"0",
                 "ChildAge22":"0",
                 "ChildAge23":"0",
                 "AdultPerRoom3":"0",
                 "ChildrenPerRoom3":"0",
                 "ChildAge31":"0",
                 "ChildAge32":"0",
                 "ChildAge33":"0",
                 "AdultPerRoom4":"0",
                 "ChildrenPerRoom4":"0",
                 "ChildAge41":"0",
                 "ChildAge42":"0",
                 "ChildAge43":"0",
                 "nationality": "IN", //selectedOriginStruct.countryCode!,
                 "supplier":"HotelsPro",
                 "ReqType":"json" */
                
                //            i % 2 == 0 ? i % 3 == 0 ? "fizzbuzz" : "fizz" : i % 3 == 0 ? "buzz" : i.ToString();
                
                "HotelCity":selectedOriginStruct.cityName!,
                "HotelCountry":selectedOriginStruct.countryCode!,
                "CheckIndate":selectedCheckinStrToPass!,
                "CheckOutdate":selectedCheckoutStrToPass!,
                "Adult":"\(self.totalNoOfAdult)",
                "Child":"\(self.totalNoOfChildren)",
                "NoOfRooms":"\(self.selectedArr.count)",
                "AdultPerRoom1":(self.selectedArr.count > 0) ? "\(self.selectedArr[0].noOfAdult!)" : "0",
                "ChildrenPerRoom1":(self.selectedArr.count > 0) ? "\(self.selectedArr[0].noOfChildren!)" : "0",
                "ChildAge1":(self.selectedArr.count > 0) ? (self.selectedArr[0].ageArr.count > 0) ? "\(self.selectedArr[0].ageArr[0].age!)" : "0" : "0",
                "ChildAge2":(self.selectedArr.count > 0) ? self.selectedArr[0].ageArr.count > 1 ? "\(self.selectedArr[0].ageArr[1].age!)" : "0" : "0",
                "ChildAge3":(self.selectedArr.count > 0) ? self.selectedArr[0].ageArr.count > 2 ? "\(self.selectedArr[0].ageArr[2].age!)" : "0" : "0",
                "AdultPerRoom2":(self.selectedArr.count > 1) ? "\(self.selectedArr[1].noOfAdult!)" : "0",
                "ChildrenPerRoom2":(self.selectedArr.count > 1) ? "\(self.selectedArr[1].noOfChildren!)" : "0",
                "ChildAge21":(self.selectedArr.count > 1) ? self.selectedArr[1].ageArr.count > 0 ? "\(self.selectedArr[1].ageArr[0].age!)" : "0" : "0",
                "ChildAge22":(self.selectedArr.count > 1) ? self.selectedArr[1].ageArr.count > 1 ? "\(self.selectedArr[1].ageArr[1].age!)" : "0" : "0",
                "ChildAge23":(self.selectedArr.count > 1) ? self.selectedArr[1].ageArr.count > 2 ? "\(self.selectedArr[1].ageArr[2].age!)" : "0" : "0",
                "AdultPerRoom3":(self.selectedArr.count > 2) ? "\(self.selectedArr[2].noOfAdult!)" : "0",
                "ChildrenPerRoom3":(self.selectedArr.count > 2) ? "\(self.selectedArr[2].noOfChildren!)" : "0",
                "ChildAge31":(self.selectedArr.count > 2) ? (self.selectedArr[2].ageArr.count > 0) ? "\(self.selectedArr[2].ageArr[0].age!)" : "0" : "0",
                "ChildAge32":(self.selectedArr.count > 2) ? (self.selectedArr[2].ageArr.count > 1) ? "\(self.selectedArr[2].ageArr[1].age!)" : "0" : "0",
                "ChildAge33":(self.selectedArr.count > 2) ? (self.selectedArr[2].ageArr.count > 2) ? "\(self.selectedArr[2].ageArr[2].age!)" : "0" : "0",
                "AdultPerRoom4":(self.selectedArr.count > 3) ? "\(self.selectedArr[3].noOfAdult!)" : "0",
                "ChildrenPerRoom4":(self.selectedArr.count > 3) ? "\(self.selectedArr[3].noOfChildren!)" : "0",
                "ChildAge41":(self.selectedArr.count > 3) ? (self.selectedArr[3].ageArr.count > 0) ? "\(self.selectedArr[3].ageArr[0].age!)" : "0" : "0",
                "ChildAge42":(self.selectedArr.count > 3) ? (self.selectedArr[3].ageArr.count > 1) ? "\(self.selectedArr[3].ageArr[1].age!)" : "0" : "0",
                "ChildAge43":(self.selectedArr.count > 3) ? (self.selectedArr[3].ageArr.count > 2) ? "\(self.selectedArr[3].ageArr[2].age!)" : "0" : "0",
                "nationality": selectedOriginStruct.countryCode!,
                "supplier":"HotelsPro",
                "ReqType":"json"
            ]
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HotelResultVCSBID") as! HotelResultVC
            ctrl.inputDict = DictInput
            self.navigationController?.pushViewController(ctrl, animated: true)
        }else{
            self.view.ShowBlackTostWithText(message: "Please select city", Interval: 3)
            
        }
        
       
    }
    
    
}
extension SearchHotelVC : UITextFieldDelegate {
  
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.resignFirstResponder()
        
       
        if textField == cityTxtField {
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"HotelPlacesVCSBID") as! HotelPlacesVC
            ctrl.delegateVariable = self
            self.present(ctrl, animated: true, completion: nil)
        }
  
        
        if textField == checkinTxtField || textField == checkoutTxtField{
            self.myCalenderContainerView.isHidden = false
            
            if textField == checkinTxtField{
                self.calendarFlag = "checkinCalender"
            }else{
                self.calendarFlag = "checkoutCalender"
            }
            myCalenderView.reloadData()
        }
        
        if textField == roomTxtField || textField == guestTxtField {
            
            
           /*
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"RoomAndGuestDetailVCSBID") as! RoomAndGuestDetailVC
            ctrl.delegateVariable = self
            ctrl.arrOfRoomStruct = self.selectedArr
            self.present(ctrl, animated: true, completion: nil) */
            
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"RoomAndGuestDetailVC2SBID") as! RoomAndGuestDetailVC2
            ctrl.delegateVariable = self
            ctrl.arrOfRoomStruct = self.selectedArr
            self.present(ctrl, animated: true, completion: nil)
        }
    }
    
}

extension SearchHotelVC : HotelPlacesDelegate {
    
    func didSelectCity(selectedHotelCityStruct: HotelCityStruct, controller: HotelPlacesVC) {
        controller.dismiss(animated: true, completion: nil)
        self.cityTxtField.text = selectedHotelCityStruct.cityName!
        self.selectedOriginStruct = selectedHotelCityStruct
        
    }
}
//MARK: - CalenderViewDelegate {
extension SearchHotelVC:FSCalendarDelegate,FSCalendarDataSource,FSCalendarDelegateAppearance {
    
    func minimumDate(for calendar: FSCalendar) -> Date {
    
        if calendarFlag == "checkinCalender" {
            return Date()
        }else{
            return self.selectedCheckinDate
        }
        
    }
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, titleSelectionColorFor date: Date) -> UIColor? {
        calendar.deselect(date)
        return UIColor.green
    }

    
    func calendar(_ calendar: FSCalendar, willDisplay cell: FSCalendarCell, for date: Date, at monthPosition: FSCalendarMonthPosition) {

        if calendarFlag == "checkoutCalender"{
            calendar.appearance.titleTodayColor = UIColor.brown
        }
    }
    
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        self.view.endEditing(true)
        //        if monthPosition == .previous || monthPosition == .next {
        //          myCalenderView.setCurrentPage(date, animated: true)
        //        }
        
        myCalenderContainerView.isHidden = true
        
        if calendarFlag == "checkinCalender" {
            self.selectedCheckinDateStr = dateFormatter.string(from: date)
            self.selectedCheckinDate = dateFormatter.date(from: self.selectedCheckinDateStr)
            self.checkinTxtField.text = self.selectedCheckinDateStr
            print("selected Checkin :\(self.selectedCheckinDateStr!)  Checkout : \(self.selectedCheckoutDateStr)")
            
            self.selectedCheckinStrToPass = inputParameterDateFormatter.string(from: date)
            
            
            //                if selectedDepartOnDate > selectedReturnOnDate{
            if selectedCheckinDate.compare(selectedCheckoutDate) == .orderedDescending {
                self.selectedCheckoutDateStr = self.selectedCheckinDateStr
                self.selectedCheckoutDate = self.selectedCheckinDate
                self.checkoutTxtField.text = self.selectedCheckoutDateStr
                print("selected Checkin :\(self.selectedCheckinDateStr!)  Checkout : \(self.selectedCheckoutDateStr)")
                self.selectedCheckoutStrToPass = self.selectedCheckinStrToPass
                
                self.noOfNight = 0
                self.noOfNightLbl.text = "\(self.noOfNight!) Night"
            }else{
                print("selected Checkin :\(self.selectedCheckinDateStr!)  Checkout : \(self.selectedCheckoutDateStr)")
                
                let seconds : TimeInterval = self.selectedCheckoutDate.timeIntervalSince(self.selectedCheckinDate)
                self.noOfNight = Int(seconds/86400)
                self.noOfNightLbl.text = "\(self.noOfNight!) Night"
            }
            
        }else{
            self.selectedCheckoutDateStr = dateFormatter.string(from: date)
            self.selectedCheckoutDate = dateFormatter.date(from: self.selectedCheckoutDateStr)
            self.checkoutTxtField.text = self.selectedCheckoutDateStr
            print("selected Checkin :\(self.selectedCheckinDateStr!)  Checkout : \(self.selectedCheckoutDateStr)")
            self.selectedCheckoutStrToPass = inputParameterDateFormatter.string(from: date)
            
            let seconds : TimeInterval = self.selectedCheckoutDate.timeIntervalSince(self.selectedCheckinDate)
            self.noOfNight = Int(seconds/86400)
            self.noOfNightLbl.text = "\(self.noOfNight!) Night"
            
        }
        
    }
    
}
//MARK: - }

extension SearchHotelVC : RoomAndGuestDetailProtocol1 {
    
    func didRoomAndGuestDetailDoneBtnTapped1(selectedArrayOfRoomStruct: [RoomStruct1], controller: RoomAndGuestDetailVC) {
        self.selectedArr1 = selectedArrayOfRoomStruct
        
        self.roomTxtField.text = "\(selectedArrayOfRoomStruct.count) Rooms"
        
        self.totalNoOfAdult = 0
        self.totalNoOfChildren = 0
        for aStruct in selectedArrayOfRoomStruct {
            self.totalNoOfAdult += Int(aStruct.noOfAdult)!
            self.totalNoOfChildren += Int(aStruct.noOfChildren)!
        }
        self.guestTxtField.text = "\(self.totalNoOfAdult) Adults"
        print("Total No Of Children = \(self.totalNoOfChildren)")
        
        
    }
    
    
}
extension SearchHotelVC : RoomAndGuestDetailProtocol {
    func didRoomAndGuestDetailDoneBtnTapped(selectedArrayOfRoomStruct: [RoomStruct], controller: RoomAndGuestDetailVC2) {
        print("From RoomAndGuestDetailProtocol")
        
        self.selectedArr = selectedArrayOfRoomStruct
        self.roomTxtField.text = "\(self.selectedArr.count) Room"
        
        self.totalNoOfAdult = 0
        self.totalNoOfChildren = 0
        for aStruct in self.selectedArr {
            self.totalNoOfAdult += aStruct.noOfAdult
            self.totalNoOfChildren += aStruct.noOfChildren
        }
        
        self.guestTxtField.text = "\(self.totalNoOfAdult) Adults"
        print("Total No Of Children = \(self.totalNoOfChildren)")
    }
    
    
}

