//
//  HotelTravellerDetailVC.swift
//  TripArcher
//
//  Created by APPLE on 04/02/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class HotelTravellerDetailVC: UIViewController {

    var hotelStructToPass : HotelStruct!
    var selectedIndexOfRoom : Int!

    
    @IBOutlet weak var hotelNameLbl: UILabel!
    @IBOutlet weak var hotelAddressLbl: UILabel!
    @IBOutlet weak var checkinLbl: UILabel!
    @IBOutlet weak var checkoutLbl: UILabel!
    @IBOutlet weak var hotelImgView: UIImageView!
    
    @IBOutlet weak var amountLbl: UILabel!

    @IBOutlet weak var checkBoxBtn: UIButton!
    
    @IBOutlet weak var emailTxtField: UITextField!
    @IBOutlet weak var mobileNoTxtField: UITextField!
    
    var isKeyboardVisible : Bool = false
    var mobileNoTxtFieldFocusFlag : Bool!
    var emailTxtFieldFocusFlag : Bool!
    let keyboardDoneButton = UIButton(type: UIButton.ButtonType.custom)
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.hotelNameLbl.text =   hotelStructToPass.HotelName!
        self.hotelAddressLbl.text = hotelStructToPass.Address!
        self.checkinLbl.text = hotelStructToPass.CheckInDate!
        self.checkoutLbl.text = hotelStructToPass.CheckOutDate!
        self.hotelImgView.image = UIImage(data: hotelStructToPass.hotelImgData!)
        
//        self.amountLbl.text = "MYR " + hotelStructToPass.RoomDetailArr[selectedRoomIndex].TotalAmount!
        self.amountLbl.text = "MYR " + hotelStructToPass.RoomDetailArr[selectedIndexOfRoom].TotalAmountMarkupWithTax!
        
        mobileNoTxtField.delegate = self
        emailTxtField.delegate = self
        
        keyboardDoneButton.setTitle("Done", for: UIControl.State())
        keyboardDoneButton.setTitleColor(UIColor.black, for: UIControl.State())
        keyboardDoneButton.addTarget(self, action: #selector(keyboardDoneBtnTapped(_:)), for: UIControl.Event.touchUpInside)
    }
    @objc func keyboardDoneBtnTapped(_ sender : UIButton){
        
        DispatchQueue.main.async { () -> Void in
            UIView.setAnimationsEnabled(true)
            self.keyboardDoneButton.isHidden = true
            self.mobileNoTxtField.resignFirstResponder()       
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: .UIKeyboardWillHide, object: nil)
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
        
    }
    //MARK: - Keyboard show
    var keyboardSize : CGRect?
    @objc func keyboardWillShow(_ notification : NSNotification){
        
        keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue
        if !self.isKeyboardVisible{
            self.view.frame.origin.y -= keyboardSize!.height
        }
        self.isKeyboardVisible = true
        
        
        
        if !emailTxtFieldFocusFlag {
            let height , width ,btnHeight,btnWidth : CGFloat
            width = CGFloat(UIScreen.main.bounds.width)
            let aStr = notification.userInfo![UIKeyboardFrameEndUserInfoKey] as? NSValue
            height = (aStr?.cgRectValue.height)!
            
            btnHeight = height/4 // Four Rows
            btnWidth = (width/3) - 2 // Three Columns - 2px to account for lines
            
            DispatchQueue.main.async { () -> Void in
                self.keyboardDoneButton.isHidden = false
                let keyBoardWindow = UIApplication.shared.windows.last
                
                self.keyboardDoneButton.frame = CGRect(x: 0, y: ((keyBoardWindow?.frame.size.height)! - btnHeight)+1, width: btnWidth, height: btnHeight)
                keyBoardWindow?.addSubview(self.keyboardDoneButton)
                keyBoardWindow?.bringSubview(toFront: self.keyboardDoneButton)
            }
        }
        
    }
    
    @objc func keyboardWillHide(_ notification : NSNotification)
    {
        if keyboardSize != nil{ // this condition is for, when keyboard is visible and tapping on backBtn crashes as self.keyboardSize is nil
            self.view.frame.origin.y += keyboardSize!.height
            self.isKeyboardVisible = false
        }else{
            print("KeyboardSize is nil ")
        }
        
    }
    @IBAction func backBtnTapped(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func checkBoxBtnTapped(_ sender: UIButton) {
        if !sender.isSelected {
            sender.isSelected = true
        }else{
            sender.isSelected = false
        }
    }
    
    @IBAction func payBtnTapped(_ sender: UIButton) {
    
        
        if !(self.emailTxtField.text?.isValidEmail())!{
            self.view.ShowBlackTostWithText(message: "Please enter valid Email ID", Interval: 3)
        }else if !checkBoxBtn.isSelected {
            self.view.ShowBlackTostWithText(message: "Please agree to Continue", Interval: 3)
        }else{
            print("Proceed to Pay....")
            if mobileNoTxtField.isFirstResponder {
                mobileNoTxtField.resignFirstResponder()
            }
            if emailTxtField.isFirstResponder {
                emailTxtField.resignFirstResponder()
            }
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "PaymentVCSBID") as! PaymentVC
            self.navigationController?.pushViewController(ctrl, animated: true)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension HotelTravellerDetailVC : UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == mobileNoTxtField {
            UIView.setAnimationsEnabled(false)
            mobileNoTxtFieldFocusFlag = true
            emailTxtFieldFocusFlag = false
            //            NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: .UIKeyboardWillShow, object: nil)
        }
        if textField == emailTxtField{
            emailTxtFieldFocusFlag = true
            mobileNoTxtFieldFocusFlag = false
        }
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == mobileNoTxtField {
            DispatchQueue.main.async { () -> Void in
                self.keyboardDoneButton.isHidden = true
            }
            
        }
    }
}
