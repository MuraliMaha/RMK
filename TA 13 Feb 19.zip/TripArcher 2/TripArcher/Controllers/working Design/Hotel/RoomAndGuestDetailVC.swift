//
//  RoomAndGuestDetailVC.swift
//  TripArcher
//
//  Created by APPLE on 22/01/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

protocol RoomAndGuestDetailProtocol1 {
    func didRoomAndGuestDetailDoneBtnTapped1(selectedArrayOfRoomStruct : [RoomStruct1],controller : RoomAndGuestDetailVC)
}

class RoomAndGuestDetailVC: UIViewController {

    var delegateVariable : RoomAndGuestDetailProtocol1!
    
    @IBOutlet weak var tvContainerView: UIView!
    @IBOutlet weak var myTV: UITableView!
    @IBOutlet weak var addRoomView: UIView!
    
    var roomNoCount : Int = 0
    var childrenCountInt : Int! = 0
//    var noOfAdult : Int = 0
    
    var arrOfRoomStruct = [RoomStruct1]()
    var arrOfAgeStruct = [ChildrenAgeStruct2]()
    
    @IBOutlet weak var numberOfAdultLbl: UILabel!
    @IBOutlet weak var numberOfChildrenLbl: UILabel!
    
    @IBOutlet weak var guestDetailContainerView: UIView!
//    var selectedRoomNo : String!
    var selectedRowNo : Int! = 0
    @IBOutlet weak var roomNoTitleLbl: UILabel!
    
    var adultCountInt : Int!
    
    
    @IBOutlet weak var adultIncrementBtn: DesignableButton!
    @IBOutlet weak var adultDecrementBtn: DesignableButton!
    
    @IBOutlet weak var childrenIncrementBtn: DesignableButton!
    @IBOutlet weak var childrenDecrementBtn: DesignableButton!
    
    @IBOutlet weak var ageTV: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.guestDetailContainerView.isHidden = true
        
        self.myTV.dataSource = self
        self.myTV.delegate = self
        
        self.roomNoCount = arrOfRoomStruct.count
//        self.childrenCountInt = arrOfRoomStruct[0].noOfChildren
        
        self.ageTV.delegate = self
        self.ageTV.dataSource = self
        
    }
    
    @IBAction func addRoomBtnTapped(_ sender: UIButton) {
        if roomNoCount < 4{
            if roomNoCount == 3 {
              addRoomView.isHidden = true
            }else{
                addRoomView.isHidden = false
            }
            roomNoCount += 1
            let aRoomStruct : RoomStruct1 = RoomStruct1.init(roomNo : "\(roomNoCount)", noOfAdult: "2", noOfChildren: "0", ageArr: [])
            arrOfRoomStruct.append(aRoomStruct)
            myTV.reloadData()
        }
        
    }
    
    @objc func deleteBtnTapped (_sender : UIButton ){
        print("delete btn tapped")
        roomNoCount -= 1
        arrOfRoomStruct.remove(at: _sender.tag)
        updateRoomNoInArrOfRoomStruct()
        if arrOfRoomStruct.count < 4{
            addRoomView.isHidden = false
        }
        myTV.reloadData()
        
    }
    
    func updateRoomNoInArrOfRoomStruct(){
        for i in 0..<arrOfRoomStruct.count {
            arrOfRoomStruct[i].roomNo = "\(i+1)"
        }
    }
    
    @IBAction func adultIncrementBtnTapped(_ sender: UIButton) {
        if self.adultCountInt < 4{
            self.adultCountInt += 1
            self.numberOfAdultLbl.text = "\(self.adultCountInt!)"
        }else{
            self.adultIncrementBtn.titleLabel?.textColor = UIColor.red
        }
        
    }
    
    @IBAction func adultDecrementBtnTapped(_ sender: UIButton) {
        if self.adultCountInt > 1{
            self.adultCountInt -= 1
            self.numberOfAdultLbl.text = "\(self.adultCountInt!)"
        }else{
            self.adultDecrementBtn.titleLabel?.textColor = UIColor.red
        }
    }
   
    
    @IBAction func childrenIncrementBtnTapped(_ sender: UIButton) {
        if self.childrenCountInt < 3{
            self.childrenCountInt += 1
            self.numberOfChildrenLbl.text = "\(self.childrenCountInt!)"
            
            let aAge = ChildrenAgeStruct2.init(age: "3")
            self.arrOfAgeStruct.append(aAge)
            arrOfRoomStruct[selectedRowNo].ageArr = self.arrOfAgeStruct
            arrOfRoomStruct[selectedRowNo].noOfChildren = "\(self.childrenCountInt!)"
            
            self.ageTV.reloadData()
        }else{
            self.childrenIncrementBtn.titleLabel?.textColor = UIColor.gray
        }
    }
    @IBAction func childrenDecrementBtnTapped(_ sender: UIButton) {
        if self.childrenCountInt > 0{
            self.childrenCountInt -= 1
            self.numberOfChildrenLbl.text = "\(self.childrenCountInt!)"
            

            var tempAgeArr = arrOfRoomStruct[selectedRowNo].ageArr
            if tempAgeArr.count != 0 {
                tempAgeArr.removeLast()
            }
            arrOfRoomStruct[selectedRowNo].ageArr = tempAgeArr
            
            self.ageTV.reloadData()
        }else{
            self.childrenDecrementBtn.titleLabel?.textColor = UIColor.red
        }
    }
    
    @IBAction func guestDetailDoneBtnTapped(_ sender: UIButton) {
        
        arrOfRoomStruct[selectedRowNo].noOfAdult = "\(self.adultCountInt!)"
        arrOfRoomStruct[selectedRowNo].noOfChildren = "\(self.childrenCountInt!)"
        myTV.reloadData()
        self.guestDetailContainerView.isHidden = true
    }
    
    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func cancelBtnTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func doneBtnTapped(_ sender: UIButton) {
//        delegateVariable.didSelectAirport(selectedAirportStruct: searchResultsArray[indexPath.row], controller: self)
        delegateVariable.didRoomAndGuestDetailDoneBtnTapped1(selectedArrayOfRoomStruct: arrOfRoomStruct, controller: self)
        self.dismiss(animated: true, completion: nil)
    }
    
    
}
extension RoomAndGuestDetailVC : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView.tag == 1 {
            return arrOfRoomStruct.count
        }else{
//            return Int(self.numberOfChildrenLbl.text!)!
            return Int(arrOfRoomStruct[self.selectedRowNo].noOfChildren)!
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView.tag == 1 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "RoomCellID", for: indexPath) as! RoomCellClass1
            cell.roomNoLbl.text = "Room " + arrOfRoomStruct[indexPath.row].roomNo //"Room \(indexPath.row + 1)"
            cell.noOfAdultLbl.text =  arrOfRoomStruct[indexPath.row].noOfAdult + " Adults"// "\(self.noOfAdult) Adults"
            
            cell.deleteBtn.addTarget(self, action: #selector(self.deleteBtnTapped), for: .touchUpInside)
            cell.deleteBtn.tag = indexPath.row
            
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "ChildrenAgeCellID", for: indexPath) as! ChildrenAgeCellClass1
            return cell
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView.tag == 1 {
            self.guestDetailContainerView.isHidden = false
            self.roomNoTitleLbl.text = "Room " + arrOfRoomStruct[indexPath.row].roomNo
            
            self.numberOfAdultLbl.text = arrOfRoomStruct[indexPath.row].noOfAdult
            self.numberOfChildrenLbl.text = arrOfRoomStruct[indexPath.row].noOfChildren
            
            self.selectedRowNo = indexPath.row
            self.adultCountInt = Int(arrOfRoomStruct[indexPath.row].noOfAdult)
            self.childrenCountInt = Int(arrOfRoomStruct[indexPath.row].noOfChildren)
            
            self.ageTV.reloadData()
            
            self.arrOfAgeStruct.removeAll()
        }else{
            
        }
     
    }
    
}
class RoomCellClass1 : UITableViewCell {
    @IBOutlet weak var roomNoLbl: UILabel!
    @IBOutlet weak var noOfAdultLbl: UILabel!
    @IBOutlet weak var deleteBtn: UIButton!
}
class ChildrenAgeCellClass1 : UITableViewCell {
    
}
