//
//  HotelReviewVC.swift
//  TripArcher
//
//  Created by APPLE on 31/01/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class HotelReviewVC: UIViewController {

    @IBOutlet weak var hotelNameLbl: UILabel!
    @IBOutlet weak var hotelAddressLbl: UILabel!
    @IBOutlet weak var ratingView: EDStarRating!
    @IBOutlet weak var checkinLbl: UILabel!
    @IBOutlet weak var checkoutLbl: UILabel!
    @IBOutlet weak var hotelImgView: UIImageView!
    
    @IBOutlet weak var roomTypeLbl: UILabel!
    @IBOutlet weak var noOfRoomsLbl: UILabel!
    @IBOutlet weak var inclusionLbl: UILabel!
    @IBOutlet weak var cancellationPolicyLbl: UILabel!
    
    @IBOutlet weak var amountLbl: UILabel!
    @IBOutlet weak var baseFareLbl: UILabel!
    @IBOutlet weak var taxLbl: UILabel!
    
    var theSelectedHotelStruct : HotelStruct!
    var selectedRoomIndex : Int!
    
    @IBOutlet weak var checkBoxBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        self.hotelNameLbl.text =   theSelectedHotelStruct.HotelName! // "1.This is line no1 2.This is line no2"
        self.hotelAddressLbl.text = theSelectedHotelStruct.Address! // "1.This is line no1 2.This is line no2 But need to include this" // "theSelectedHotelStruct.Address! theSelectedHotelStruct.Address!theSelectedHotelStruct.Address! theSelectedHotelStruct.Address!theSelectedHotelStruct.Address!theSelectedHotelStruct.Address!theSelectedHotelStruct.Address!theSelectedHotelStruct.Address!theSelectedHotelStruct.Address!theSelectedHotelStruct.Address!theSelectedHotelStruct.Address!theSelectedHotelStruct.Address!theSelectedHotelStruct.Address!theSelectedHotelStruct.Address!theSelectedHotelStruct.Address!"
        self.checkinLbl.text = theSelectedHotelStruct.CheckInDate!
        self.checkoutLbl.text = theSelectedHotelStruct.CheckOutDate!
        
        self.ratingView.starImage = UIImage.init(named: "starUnfilled")
        self.ratingView.starHighlightedImage = UIImage.init(named: "starFilled")
        self.ratingView.maxRating = 5
        self.ratingView.horizontalMargin = 0
        self.ratingView.displayMode = UInt(EDStarRatingDisplayFull)
        self.ratingView.rating = Float(theSelectedHotelStruct.StarRating)!
        self.hotelImgView.image = UIImage(data: theSelectedHotelStruct.hotelImgData!)

        
        
        self.roomTypeLbl.text = theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].RoomDescription
        self.noOfRoomsLbl.text = theSelectedHotelStruct.NoOfRooms! + "Room"
        self.inclusionLbl.text = theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].inclusions!
        self.cancellationPolicyLbl.text = theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].Cancellationpolicy!
        
//        self.amountLbl.text = "MYR " + theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].TotalAmount!
        self.baseFareLbl.text = theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].BaseFareAmount!
        self.taxLbl.text = theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].TotalTaxCharges!
        self.amountLbl.text = "MYR " + theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].TotalAmountMarkupWithTax!
    }
    
    @IBAction func continueBtnTapped(_ sender: UIButton) {
        if !checkBoxBtn.isSelected {
            self.view.ShowBlackTostWithText(message: "Please agree to Continue", Interval: 3)
        }else{
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HotelTravellerDetailVCSBID") as! HotelTravellerDetailVC
            ctrl.hotelStructToPass = self.theSelectedHotelStruct
            ctrl.selectedIndexOfRoom = self.selectedRoomIndex
            self.navigationController?.pushViewController(ctrl, animated: true)
        }
        
    }
    @IBAction func backBtnTapped(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func checkBoxBtnTapped(_ sender: UIButton) {
        if !sender.isSelected {
            sender.isSelected = true
        }else{
            sender.isSelected = false
        }
    }
}
