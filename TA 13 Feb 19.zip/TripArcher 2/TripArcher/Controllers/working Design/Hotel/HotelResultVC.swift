//
//  HotelResultVC.swift
//  TripArcher
//
//  Created by APPLE on 24/01/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit
import EDStarRating
import SDWebImage

class HotelResultVC: UIViewController {

    var inputDict = [String:String]()
    
    @IBOutlet weak var dataTVContainerView: UIView!
    @IBOutlet weak var errorLbl: UILabel!
    
    @IBOutlet weak var myTV: UITableView!
    
    var finalArr = [HotelStruct]()

    
    
    
    @IBOutlet weak var hotelBtn: UIButton!
    @IBOutlet weak var ratingBtn: UIButton!
    @IBOutlet weak var priceBtn: UIButton!
    
    @IBOutlet weak var hotelBtnImgView: UIImageView!
    @IBOutlet weak var ratingBtnImgView: UIImageView!
    @IBOutlet weak var priceBtnImgView: UIImageView!
    
    @IBAction func hotelBtnTapped(_ sender: UIButton) {
      
        
        ratingBtnImgView.image = nil
        priceBtnImgView.image = .none
        
        ratingBtn.isSelected = false
        priceBtn.isSelected = false
        
        if !sender.isSelected {
            hotelBtnImgView.image = UIImage.init(named: "downArrowGreen")
            sender.isSelected = true
           
            self.finalArr.sort { (hotelStruct1, hotelStruct2) -> Bool in
                return hotelStruct1.HotelName > hotelStruct2.HotelName
            }
        }else{
            hotelBtnImgView.image = UIImage.init(named: "upArrowGreen")
            sender.isSelected = false
            self.finalArr.sort { (hotelStruct1, hotelStruct2) -> Bool in
                return hotelStruct1.HotelName < hotelStruct2.HotelName
            }
        }
        myTV.reloadData()
    }
    
    
    @IBAction func ratingBtnTapped(_ sender: UIButton) {
       
        hotelBtnImgView.image = nil
        priceBtnImgView.image = .none
        
        hotelBtn.isSelected = false
        priceBtn.isSelected = false
        
        if !sender.isSelected {
            ratingBtnImgView.image = UIImage.init(named: "downArrowGreen")
            sender.isSelected = true
       
            self.finalArr.sort { (hotelStruct1, hotelStruct2) -> Bool in
                let star0Int :Int = Int(hotelStruct1.StarRating)!
                let star1Int :Int = Int(hotelStruct2.StarRating)!
                return star0Int > star1Int
            }
        }else{
            ratingBtnImgView.image = UIImage.init(named: "upArrowGreen")
            sender.isSelected = false
          
            self.finalArr.sort { (hotelStruct1, hotelStruct2) -> Bool in
                let star0Int :Int = Int(hotelStruct1.StarRating)!
                let star1Int :Int = Int(hotelStruct2.StarRating)!
                return star0Int < star1Int
            }
            
        }
        myTV.reloadData()
    }
    @IBAction func priceBtnTapped(_ sender: UIButton) {
        hotelBtnImgView.image = nil
        ratingBtnImgView.image = .none
        
        hotelBtn.isSelected = false
        ratingBtn.isSelected = false
        
        if !sender.isSelected {
            priceBtnImgView.image = UIImage.init(named: "downArrowGreen")
            sender.isSelected = true
        
            self.finalArr.sort{ (hotelStruct1,hotelStruct2) -> Bool in
                let amount0 : Double = Double(hotelStruct1.DispTotalAmount)!
                let amount1 : Double = Double(hotelStruct2.DispTotalAmount)!
                return amount0 > amount1
            }
            
        }else{
            priceBtnImgView.image = UIImage.init(named: "upArrowGreen")
            sender.isSelected = false
        
            self.finalArr.sort{ (hotelStruct1,hotelStruct2) -> Bool in
                let amount0 : Double = Double(hotelStruct1.DispTotalAmount)!
                let amount1 : Double = Double(hotelStruct2.DispTotalAmount)!
                return amount0 < amount1
            }
        }
        
        myTV.reloadData()
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        self.dataTVContainerView.isHidden = true
        self.errorLbl.isHidden = true
        
        self.navigationController?.navigationBar.isHidden = false
        print("inputDict from HotelResultVC=",self.inputDict)
        
        myTV.dataSource = self
        myTV.delegate = self
        myTV.tableFooterView = UIView.init(frame: CGRect.zero)
        
        
        
        
        callSearchHotelService(messageDict: self.inputDict)
    }
    @IBAction func backBtnTapped(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    func callSearchHotelService(messageDict : [String:String]){
        if (Reachability()?.isReachable)! {
            showLoading()
            
            /*
            WebService().callAutoAPI(mainURL: WebServicesUrl.HotelServiceUrlLive, Suffix: WebServicesUrl.HotelResult, parameterDict: messageDict) { (ResponseDict, ResponseStatus) in
                hideLoading()
                if ResponseStatus {
                    print("Service call success ..........")
                    self.dataTVContainerView.isHidden = false
                    
            
                    
                    
                    
                    
                    
                }else{
                    print("Service call failure ..........")
                    print("Try after sometimes...internet connetivity Problem....")
                    self.view.ShowBlackTostWithText(message: "Try after sometimes...internet connetivity Problem....", Interval: 2)
                    self.dataTVContainerView.isHidden = true
                    self.errorLbl.text = "Oops!!! Try after sometimes..."
                }
            } */
            
            WebService().HTTP_POST_WebServiceMethod_Hotel(mainURL: WebServicesUrl.HotelServiceUrlLive, suffix: WebServicesUrl.HotelResult, parameterDict: messageDict) { (ResponseArr, ResponseStatus) in
                hideLoading()
                if ResponseStatus {
                    print("Service call success ..........")
                    self.dataTVContainerView.isHidden = false
                    self.errorLbl.isHidden = true
                    
                    
                    let fullResponseArr = ResponseArr as! [[String:AnyObject]]
                    for aDict in fullResponseArr {
                        var aStruct = HotelStruct()
                        aStruct.NoOfRooms = "\(aDict["NoOfRooms"]!)"
                        aStruct.NoOfNights = "\(aDict["NoOfNights"]!)"
                        aStruct.CheckInDate = "\(aDict["CheckInDate"]!)"
                        aStruct.CheckOutDate = "\(aDict["CheckOutDate"]!)"
                        aStruct.HotelName = "\(aDict["HotelName"]!)"
                        aStruct.ThumbNailImage = "\(aDict["ThumbNailImage"]!)"
                        aStruct.Address = "\(aDict["Address"]!)"
                        aStruct.StarRating = "\(aDict["StarRating"]!)"
                        aStruct.RatingImage = "\(aDict["RatingImage"]!)"
                        aStruct.DispTotalAmount = "\(aDict["DispTotalAmount"]!)"
                        
                        aStruct.processId = "\(aDict["processId"]!)"
                        aStruct.HotelUniqueKey = "\(aDict["HotelUniqueKey"]!)"
                        aStruct.RoomcategoryCode = "\(aDict["RoomcategoryCode"]!)"
                        aStruct.APIType = "\(aDict["APIType"]!)"
                        
                        let tempArr = aDict["dtHotelRate"] as! [[String : AnyObject]]
                        for aRoomDict in tempArr {
                            var aRoomStruct = RoomDetailStruct()
                            aRoomStruct.RoomDescription =  "\(aRoomDict["RoomDescription"]!)"
                            aRoomStruct.inclusions = "\(aRoomDict["inclusions"]!)"
                            aRoomStruct.TotalAmount = "\(aRoomDict["TotalAmount"]!)"
                            aRoomStruct.Cancellationpolicy = "\(aRoomDict["Cancellationpolicy"]!)"
                            aRoomStruct.BaseFareAmount = "\(aRoomDict["BaseFareAmount"]!)"
                            aRoomStruct.TotalTaxCharges = "\(aRoomDict["TotalTaxCharges"]!)"
                            aRoomStruct.TotalAmountMarkupWithTax = "\(aRoomDict["TotalAmountMarkupWithTax"]!)"
                            aStruct.RoomDetailArr.append(aRoomStruct)
                            
                        }
                        
                        aStruct.city = "\(self.inputDict["HotelCity"]!)"
                        aStruct.country = "\(self.inputDict["HotelCountry"]!)"
                        
                       self.finalArr.append(aStruct)
                    }
                    self.myTV.reloadData()
                    
                    
                }else{
                    
                    let myErrorResponseArr : [String] = ResponseArr as! [String]
                    if myErrorResponseArr.count > 0{
                        self.view.ShowBlackTostWithText(message: myErrorResponseArr[0], Interval: 2)
                    }else{
                        print("Service call failure ..........")
                        print("Try after sometimes.......")
                        self.view.ShowBlackTostWithText(message: "Try after sometimes...Server Problem....", Interval: 2)
                    }
                    self.dataTVContainerView.isHidden = true
                    self.errorLbl.isHidden = false
                    self.errorLbl.text = myErrorResponseArr[0]
                    
                }
                
            }
        }else{
            print("No Internet......")
            self.dataTVContainerView.isHidden = true
            self.errorLbl.isHidden = false
            self.errorLbl.text = "Internet connetivity Problem!!!"
        }
    }

 

}
extension HotelResultVC : UITableViewDelegate , UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.finalArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"HotelCellID",for: indexPath) as! HotelCellClass
        cell.hotelNameLbl.text = finalArr[indexPath.row].HotelName
        cell.hotelAddressLbl.text = finalArr[indexPath.row].Address
        cell.amountLbl.text = finalArr[indexPath.row].DispTotalAmount
        
        cell.RatingView.starImage = UIImage.init(named: "starUnfilled")
        cell.RatingView.starHighlightedImage = UIImage.init(named: "starFilled")
        cell.RatingView.maxRating = 5
//        cell.RatingView.delegate = self
        cell.RatingView.horizontalMargin = 2
//        cell.RatingView.editable = false
        cell.RatingView.displayMode = UInt(EDStarRatingDisplayFull)
        let ratingStr = finalArr[indexPath.row].StarRating!
        
        if !ratingStr.isEmpty{
            cell.RatingView.rating = Float(finalArr[indexPath.row].StarRating)!
        }
        
        
        
        /*
        cell.flightNameLbl.text = self.flightResultAndDetailsArr[indexPath.row].detailArrWithFlightDetailStruct[0].operating
        
        cell.flightImgView.sd_setImage(with: URL(string: flightImgURL), placeholderImage: UIImage(named: "flightGreen"),options: SDWebImageOptions(rawValue: 0), completed: { downloadedImage, error, cacheType, imageURL in
            if error == nil{
                self.flightResultAndDetailsArr[indexPath.row].flightImgData = UIImagePNGRepresentation(downloadedImage!)
            }else{
                print("Error from SBWebImage Block = ",error)
            }
            
        }) */
        
        /*
        cell.hotelImgView.sd_setImage(with: URL(string: finalArr[indexPath.row].ThumbNailImage!), placeholderImage: UIImage(named: "hotelGreen"), options: SDWebImageOptions(rawValue: 0),completed: { downloadedImage, error, cacheType, imageURl in
            if error == nil {
                self.finalArr[indexPath.row].hotelImgData = UIImagePNGRepresentaion(downloadedImage)
            }else{
                print("Error from SBWebImage Block to load hotel Image = ",error)
            }
        }) */

        /*
        cell.hotelImgView.sd_setImage(with: URL(string: finalArr[indexPath.row].ThumbNailImage!), placeholderImage: UIImage(named: "hotelGreen"), options: SDWebImageOptions(rawValue:0), progress: { (<#Int#>, <#Int#>, <#URL?#>) in
            <#code#>
        }, completed: <#T##SDExternalCompletionBlock?##SDExternalCompletionBlock?##(UIImage?, Error?, SDImageCacheType, URL?) -> Void#>) */
        
        
        if self.finalArr[indexPath.row].hotelImgData != nil {
            cell.hotelImgView.image =  UIImage(data: self.finalArr[indexPath.row].hotelImgData!)
        }else{
            /*
            cell.hotelImgView.sd_setImage(with: URL(string: finalArr[indexPath.row].ThumbNailImage!)) { (downloadedImg, error, cacheType, imgURL) in
                if error == nil {
                    self.finalArr[indexPath.row].hotelImgData = UIImagePNGRepresentation(downloadedImg!)
                }else{
                    print("Error from SBWebImage Block to load hotel Image = ",error!)
                }
            } */
            
            
            
            cell.hotelImgView.sd_setImage(with: URL(string: finalArr[indexPath.row].ThumbNailImage!), placeholderImage: UIImage(named: "hotelGreen"),options: SDWebImageOptions(rawValue: 0), completed: { downloadedImg, error, cacheType, imageURL in
                if error == nil{
                    self.finalArr[indexPath.row].hotelImgData = UIImagePNGRepresentation(downloadedImg!)
                }else{
                    print("Error from SBWebImage Block to load hotel Image = ",error!)
                }
                
            })
        }
        
        
        
        
        return cell
    }
    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return UITableViewAutomaticDimension
//    }
//
//    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 100
//    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"HotelDetailVCSBID") as! HotelDetailVC
//        ctrl.HotelDetailArr = finalArr
        ctrl.selectedHotelStruct = self.finalArr[indexPath.row]
        self.navigationController?.pushViewController(ctrl, animated: true)
    }
}
class HotelCellClass: UITableViewCell {
    
    @IBOutlet weak var hotelImgView: UIImageView!
    @IBOutlet weak var hotelNameLbl: UILabel!
    @IBOutlet weak var hotelAddressLbl: UILabel!
    @IBOutlet weak var amountLbl: UILabel!
    @IBOutlet weak var RatingView: EDStarRating!
}
