//
//  RoomAndGuestDetailVC2.swift
//  TripArcher
//
//  Created by APPLE on 24/01/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

protocol RoomAndGuestDetailProtocol {
    func didRoomAndGuestDetailDoneBtnTapped(selectedArrayOfRoomStruct : [RoomStruct],controller : RoomAndGuestDetailVC2)
}

class RoomAndGuestDetailVC2: UIViewController {

    @IBOutlet weak var tvContainerView: UIView!
    @IBOutlet weak var roomTV: UITableView!
    @IBOutlet weak var addRoomView: UIView!
    
    @IBOutlet weak var guestDetailContainerView: UIView!
    @IBOutlet weak var roomNoTitleLbl: UILabel!
    @IBOutlet weak var adultIncrementBtn: DesignableButton!
    @IBOutlet weak var numberOfAdultLbl: UILabel!
    @IBOutlet weak var adultDecrementBtn: DesignableButton!
    @IBOutlet weak var childrenIncrementBtn: DesignableButton!
    @IBOutlet weak var numberOfChildrenLbl: UILabel!
    @IBOutlet weak var childrenDecrementBtn: DesignableButton!
    @IBOutlet weak var ageTV: UITableView!
    
    var delegateVariable : RoomAndGuestDetailProtocol!
    
    var arrOfRoomStruct = [RoomStruct]()
    var selectedRowNo : Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.guestDetailContainerView.isHidden = true
        
        self.roomTV.dataSource = self
        self.roomTV.delegate = self

        self.ageTV.delegate = self
        self.ageTV.dataSource = self
        
//        print("AgeArrCount = ",arrOfRoomStruct[self.selectedRowNo].ageArr.count)
    }
    @IBAction func addRoomBtnTapped(_ sender: UIButton) {
        
        var aRoomStruct = RoomStruct()
        aRoomStruct.noOfAdult = 2
        aRoomStruct.noOfChildren = 0
        aRoomStruct.roomNo = arrOfRoomStruct.count + 1
        aRoomStruct.ageArr = []
        arrOfRoomStruct.append(aRoomStruct)
        roomTV.reloadData()
        
        if arrOfRoomStruct.count == 4{
            addRoomView.isHidden = true
        }else{
            addRoomView.isHidden = false
        }
    }
    @objc func deleteBtnTapped (_sender : UIButton ){
        print("delete btn tapped")
        arrOfRoomStruct.remove(at: _sender.tag)
        updateRoomNoInArrOfRoomStruct()
        if arrOfRoomStruct.count < 4{
            addRoomView.isHidden = false
        }
        roomTV.reloadData()
    }
    
    func updateRoomNoInArrOfRoomStruct(){
        for i in 0..<arrOfRoomStruct.count {
            arrOfRoomStruct[i].roomNo = i + 1
        }
    }
    
    @IBAction func adultIncrementBtnTapped(_ sender: UIButton) {
        if self.arrOfRoomStruct[selectedRowNo].noOfAdult < 4 {
            self.arrOfRoomStruct[selectedRowNo].noOfAdult += 1
            self.numberOfAdultLbl.text = "\(self.arrOfRoomStruct[selectedRowNo].noOfAdult!)"
        }
    }
    
    @IBAction func adultDecrementBtnTapped(_ sender: UIButton) {
        if self.arrOfRoomStruct[selectedRowNo].noOfAdult > 1{
           self.arrOfRoomStruct[selectedRowNo].noOfAdult -= 1
            self.numberOfAdultLbl.text = "\(self.arrOfRoomStruct[selectedRowNo].noOfAdult!)"
        }
    }
    
    @IBAction func childrenIncrementBtnTapped(_ sender: UIButton) {
        if self.arrOfRoomStruct[selectedRowNo].noOfChildren < 3 {
            self.arrOfRoomStruct[selectedRowNo].noOfChildren += 1
            self.numberOfChildrenLbl.text = "\(self.arrOfRoomStruct[selectedRowNo].noOfChildren!)"
            
            var tempAgeArr = self.arrOfRoomStruct[selectedRowNo].ageArr
            var aStruct = ChildrenAgeStruct()
            aStruct.age = 0
            tempAgeArr.append(aStruct)
            self.arrOfRoomStruct[selectedRowNo].ageArr = tempAgeArr
            ageTV.reloadData()
            
            
        }
    }
    @IBAction func childrenDecrementBtnTapped(_ sender: UIButton) {
        if self.arrOfRoomStruct[selectedRowNo].noOfChildren > 0{
            self.arrOfRoomStruct[selectedRowNo].noOfChildren -= 1
            self.numberOfChildrenLbl.text = "\(self.arrOfRoomStruct[selectedRowNo].noOfChildren!)"
            
            var tempAgeArr = self.arrOfRoomStruct[selectedRowNo].ageArr
            if tempAgeArr.count != 0{
                tempAgeArr.removeLast()
            }
            self.arrOfRoomStruct[selectedRowNo].ageArr = tempAgeArr
            ageTV.reloadData()
            
        }
    }
    @IBAction func guestDetailDoneBtnTapped(_ sender: UIButton) {
        arrOfRoomStruct[selectedRowNo].noOfAdult = Int(self.numberOfAdultLbl.text!)
        arrOfRoomStruct[selectedRowNo].noOfChildren = Int(self.numberOfChildrenLbl.text!)
        roomTV.reloadData()
        self.guestDetailContainerView.isHidden = true
    }
    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func cancelBtnTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func doneBtnTapped(_ sender: UIButton) {
        delegateVariable.didRoomAndGuestDetailDoneBtnTapped(selectedArrayOfRoomStruct: arrOfRoomStruct, controller: self)
        self.dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension RoomAndGuestDetailVC2 : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView.tag == 1 {
            return arrOfRoomStruct.count
        }else{
//            return Int(arrOfRoomStruct[self.selectedRowNo].noOfChildren)!
            return arrOfRoomStruct[self.selectedRowNo].noOfChildren
//            return 0
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView.tag == 1 {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "RoomCellID", for: indexPath) as! RoomCellClass
            cell.roomNoLbl.text = "Room \(arrOfRoomStruct[indexPath.row].roomNo!)"
            cell.noOfAdultLbl.text = "\(arrOfRoomStruct[indexPath.row].noOfAdult!) Adults"
            
            if arrOfRoomStruct.count == 1 {
                cell.deleteBtn.isHidden = true
            }else{
                cell.deleteBtn.isHidden = false
            }
            cell.deleteBtn.addTarget(self, action: #selector(self.deleteBtnTapped), for: .touchUpInside)
            cell.deleteBtn.tag = indexPath.row
            
            
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "ChildrenAgeCellID", for: indexPath) as! ChildrenAgeCellClass
            cell.childNoLbl.text = "Child \(indexPath.row + 1)"
            
            if arrOfRoomStruct[selectedRowNo].ageArr[indexPath.row].age == 0{
                cell.ageLbl.text = "infant"
            }else{
                cell.ageLbl.text = "\(arrOfRoomStruct[selectedRowNo].ageArr[indexPath.row].age!) year"
            }
            
            cell.ageIncrementBtn.addTarget(self, action: #selector(self.ageIncrementBtnTapped), for: .touchUpInside)
            cell.ageIncrementBtn.tag = indexPath.row
            
            cell.ageDecrementBtn.addTarget(self, action: #selector(self.ageDecrementBtnTapped), for: .touchUpInside)
            cell.ageDecrementBtn.tag = indexPath.row
            return cell
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        if tableView.tag == 1 {
            self.guestDetailContainerView.isHidden = false
            self.roomNoTitleLbl.text = "Room \(arrOfRoomStruct[indexPath.row].roomNo!)"
            
            self.numberOfAdultLbl.text = "\(arrOfRoomStruct[indexPath.row].noOfAdult!)"
            self.numberOfChildrenLbl.text = "\(arrOfRoomStruct[indexPath.row].noOfChildren!)"
            
            self.selectedRowNo = indexPath.row
            
//            let noOfC = arrOfRoomStruct[indexPath.row].noOfChildren
            
            self.ageTV.reloadData()
        }else{
            
        }
        
    }
    
    @IBAction func closeBtnTapped(_ sender: UIButton) {
        self.guestDetailContainerView.isHidden = true
    }
    
    @objc func ageIncrementBtnTapped (_sender : UIButton ){
        if arrOfRoomStruct[selectedRowNo].ageArr[_sender.tag].age < 12{
            arrOfRoomStruct[selectedRowNo].ageArr[_sender.tag].age += 1
            ageTV.reloadData()
        }
    }
    @objc func ageDecrementBtnTapped (_sender : UIButton ){
        if arrOfRoomStruct[selectedRowNo].ageArr[_sender.tag].age > 0{
            arrOfRoomStruct[selectedRowNo].ageArr[_sender.tag].age -= 1
            ageTV.reloadData()
        }
    }
    
}
class RoomCellClass : UITableViewCell {
    @IBOutlet weak var roomNoLbl: UILabel!
    @IBOutlet weak var noOfAdultLbl: UILabel!
    @IBOutlet weak var deleteBtn: UIButton!
}
class ChildrenAgeCellClass : UITableViewCell {
    
    @IBOutlet weak var childNoLbl: UILabel!
    @IBOutlet weak var ageLbl: UILabel!
    
    @IBOutlet weak var ageIncrementBtn: DesignableButton!
    @IBOutlet weak var ageDecrementBtn: DesignableButton!
}
