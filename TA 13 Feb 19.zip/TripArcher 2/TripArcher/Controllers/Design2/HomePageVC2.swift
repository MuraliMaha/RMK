//
//  HomePageVC2.swift
//  TripArcher
//
//  Created by APPLE on 15/11/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

class HomePageVC2: UIViewController {

    @IBOutlet weak var flightView: UIView!
    @IBOutlet weak var hotelView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        flightView.backgroundColor = hexStringToUIColor(hex: "#AFCA1F")
        self.flightView.layer.cornerRadius = self.flightView.frame.size.width / 2
        self.flightView.clipsToBounds = true
        self.flightView.layer.masksToBounds = false
        self.flightView.shadowOffset = CGSize(width: 5.0, height: 0)
        self.flightView.shadowRadius = 5;
        self.flightView.shadowOpacity = 0.5;
        
    }

    @IBAction func flightBtnTapped(_ sender: UIButton) {
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "SearchFlightVC2SBID") as! SearchFlightVC2
        self.navigationController?.pushViewController(ctrl, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }


}
