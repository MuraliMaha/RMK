//
//  FlightVC.swift
//  TripArcher
//
//  Created by APPLE on 15/11/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

class SearchFlightVC: UIViewController {

    @IBOutlet weak var onewayImg: UIImageView!
    @IBOutlet weak var returnImg: UIImageView!
    
    @IBOutlet weak var onewayBtn: UIButton!
    @IBOutlet weak var returnBtn: UIButton!
    
    @IBOutlet weak var fromTxtField: UITextField!
    @IBOutlet weak var toTxtField: UITextField!
    @IBOutlet weak var departonTxtField: UITextField!
    @IBOutlet weak var returnonTxtField: UITextField!
    @IBOutlet weak var childrenTxtField: UITextField!
    @IBOutlet weak var infantsTxtField: UITextField!
    @IBOutlet weak var classTxtField: UITextField!
    @IBOutlet weak var adultsTxtField: UITextField!
    
    var fromOrTo : String!
    var selectedOriginStruct : AirportStruct!
    var selectedDestinationStruct : AirportStruct!
//    var origin : String!
//    var destination : String!
    
//    var pickerSelectedItem = ""
    var adultSelectedItem = "1"
    var childrenSelectedItem = "0"
    var infantSelectedItem = "0"
    var pickerInputArr = ["1","2","3","4","5","6","7","8","9","10"]
    
    var classSelectedItem = "Economy"
    var classPickerInputArr = ["Economy","Business","First","Premium Economy"]
    
//    fileprivate weak var departureCalendar: FSCalendar!
    
    @IBOutlet var departureCalendarView: FSCalendar!
    var departOrReturn : String!
    var departDate : String!
    var returnDate : String!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.isHidden = false
        fromTxtField.delegate = self
        toTxtField.delegate = self
        departonTxtField.delegate = self
        returnonTxtField.delegate = self
        
        onewayBtn.isSelected = true
        
        
        self.adultsTxtField.text = adultSelectedItem
        self.childrenTxtField.text = childrenSelectedItem
        self.infantsTxtField.text = infantSelectedItem
        self.classTxtField.text = classSelectedItem
        
        PickerViewMake(1)
        PickerViewMake(2)
        PickerViewMake(3)
        PickerViewMake(4)
    
//        let depCalendar = FSCalendar(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height))
//        depCalendar.dataSource = self
//        depCalendar.delegate = self
        
    }
    
    // MARK: - Make Picker based on View Position {
    func PickerViewMake(_ TypeId:Int) {
        
        let PickerViewSelection = UIPickerView.init()
        PickerViewSelection.backgroundColor = UIColor.white
        PickerViewSelection.tag = TypeId
        PickerViewSelection.delegate = self
        PickerViewSelection.dataSource = self
        PickerViewSelection.showsSelectionIndicator = true
        
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.darkGray
        toolBar.sizeToFit()
        
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: #selector(pickerDoneAction(_sender:)))
        doneButton.tag = TypeId
        
        toolBar.setItems([spaceButton,doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        
        if TypeId == 1 {
            adultsTxtField.inputView = PickerViewSelection
            adultsTxtField.inputAccessoryView = toolBar
        }
        else if TypeId == 2 {
            childrenTxtField.inputView = PickerViewSelection
            childrenTxtField.inputAccessoryView = toolBar
        } else if TypeId == 3 {
            infantsTxtField.inputView = PickerViewSelection
            infantsTxtField.inputAccessoryView = toolBar
        }else if TypeId == 4 {
            classTxtField.inputView = PickerViewSelection
            classTxtField.inputAccessoryView = toolBar
        }
        
    }

    @objc func pickerDoneAction(_sender:UIBarButtonItem) {
        self.view.endEditing(true)
        
      if _sender.tag == 1 {
//            if CitySelectTxt.text != CityArr[CitySelectIndex].CityName {
//                CitySelectTxt.text = CityArr[CitySelectIndex].CityName
//                CityPrevSelectIndex = CitySelectIndex
//                getvehicleModelDetails(CityIndex: CityPrevSelectIndex, ModelIndex: ModelSelectIndex)
//            }
        
        self.adultsTxtField.text = adultSelectedItem
        self.adultsTxtField.resignFirstResponder()
        
       
        }
        else if _sender.tag == 2 {
//            if ModelSelectTxt.text != ModelsArr[ModelSelectIndex].CategoryName {
//                ModelSelectTxt.text = ModelsArr[ModelSelectIndex].CategoryName
//                ModelPrevSelectIndex = ModelSelectIndex
//                getvehicleModelDetails(CityIndex: CityPrevSelectIndex, ModelIndex: ModelSelectIndex)
//            }
        self.childrenTxtField.text = childrenSelectedItem
        self.childrenTxtField.resignFirstResponder()
        }
        else if _sender.tag == 3 {
//            if CarSelectTxt.text != CarTypesArr[CarSelectIndex].ModelName {
//                CarSelectTxt.text = CarTypesArr[CarSelectIndex].ModelName
//                self.CallForRateItem(vehicleIndex: CarSelectIndex, CityIndex: CityPrevSelectIndex, ModelIndex: ModelSelectIndex)
//            }
        self.infantsTxtField.text = infantSelectedItem
        self.infantsTxtField.resignFirstResponder()
      }
      else if _sender.tag == 4{
        self.classTxtField.text = classSelectedItem
        self.classTxtField.resignFirstResponder()
        }
        
        
        print("Adult = \(self.adultsTxtField.text!),Children = \(self.childrenTxtField.text!),Infant = \(infantsTxtField.text!)")
        
    }
  
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func onewayBtnTapped(_ sender: UIButton) {
        if !sender.isSelected {
            onewayImg.image = UIImage.init(named: "Circled Dot Filled")
            returnImg.image = UIImage.init(named: "Unchecked Circle")
            onewayBtn.isSelected = true
            returnBtn.isSelected = false
        }
    }
    
    @IBAction func returnBtnTapped(_ sender: UIButton) {
        if !sender.isSelected {
            returnImg.image = UIImage.init(named: "Circled Dot Filled")
            onewayImg.image = UIImage.init(named: "Unchecked Circle")
            returnBtn.isSelected = true
            onewayBtn.isSelected = false
        }
    }
    
    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func searchFlightBtnTapped(_ sender: UIButton) {
        //Donts search for CJB to LAS
        let DictInput = ["Origin":"MAA","Destination":"LAS","DepartureDate":"2018-12-25","Returndate":"2018-12-26","WayType":self.onewayBtn.isSelected ? "one":"two","CabinClass":"Economy","AdultCount":"4","ChildCount":"2","InfantCount":"3","SeniorCount":"0","PreferredCarrier":"1","PromotionalPlanType":"0","SearchSessionid":"0","ModuleId":"14","ParentAccountId":"IXCRAJ042","ChildAccountId":"IXCRAJ042","ApiName":"TBO","NonStop":"","ReqType":"JSON"]
        
        
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "SearchFlightResultVCSBID") as! FlightResultVC
        ctrl.inputDict = DictInput
        self.navigationController?.pushViewController(ctrl, animated: true)
        
    }
}// end of SearchFlightVC
//MARK: - TextFieldDelegate {
extension SearchFlightVC : UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == fromTxtField{
            self.fromOrTo = "from"
        }else if textField == toTxtField {
            self.fromOrTo = "to"
        }
        if textField == fromTxtField || textField == toTxtField {
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"FlightPlacesVCSBID") as! FlightPlacesVC
            ctrl.delegateVariable = self
            self.present(ctrl, animated: true, completion: nil)
        }
        
        
        if textField == departonTxtField{
            self.departOrReturn = "depart"
        }
        if textField == returnonTxtField {
            self.departOrReturn = "return"
        }
        if textField == departonTxtField || textField == returnonTxtField {
            departureCalendarView.bounds = self.view.bounds
            departureCalendarView.center = self.view.center
            departureCalendarView.delegate = self
            departureCalendarView.dataSource = self
            self.view.addSubview(departureCalendarView)
            textField.resignFirstResponder()
        }
        
    }
}
//MARK: - }

//MARK: - FlightPlacesDelegate {
extension SearchFlightVC : FlightPlacesDelegate {
    
    func didSelectAirport(selectedAirportStruct: AirportStruct, controller: FlightPlacesVC) {
        controller.dismiss(animated: true, completion: nil)
        if fromOrTo == "from" {
            self.fromTxtField.text = selectedAirportStruct.cityName!
            self.selectedOriginStruct = selectedAirportStruct
        }else{
            self.toTxtField.text = selectedAirportStruct.cityName!
            self.selectedDestinationStruct = selectedAirportStruct
        }
    }
}
//MARK: - }

//MARK: - PickerViewDelegate {
extension SearchFlightVC:UIPickerViewDelegate,UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView.tag == 4 {
            return classPickerInputArr.count
        }else{
            return pickerInputArr.count
        }
        
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView.tag == 4 {
            return "\(classPickerInputArr[row])"
        }else{
            return "\(pickerInputArr[row])"
        }
        
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if pickerView.tag == 1{
            adultSelectedItem = "\(pickerInputArr[row])"
        }else if pickerView.tag == 2 {
            childrenSelectedItem = "\(pickerInputArr[row])"
        }else if pickerView.tag == 3 {
            infantSelectedItem = "\(pickerInputArr[row])"
        }else if pickerView.tag == 4{
            classSelectedItem = "\(classPickerInputArr[row])"
        }
        
    }
}
//MARK: - }

//MARK: - CalendarViewDelegate
extension SearchFlightVC:FSCalendarDelegate,FSCalendarDataSource,FSCalendarDelegateAppearance {
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        
//        if monthPosition == .previous || monthPosition == .next {
//            departureCalendarView.setCurrentPage(date, animated: true)
//        }
//        else {
//
//            let gregCal:NSCalendar = NSCalendar(calendarIdentifier: NSCalendar.Identifier.gregorian)!
//            let gregTime:NSDateComponents = gregCal.components(([.year, .month, .day, .hour, .minute]), from: date as Date) as NSDateComponents
//
//
//            let Day = gregTime.day
//            let Month = gregTime.month
//
//
//
//
//        }
        
        self.departureCalendarView.removeFromSuperview()
        if departOrReturn == "depart" {
            print("Depart Date :",date)
        }else{
            print("Return Date :",date)
        }
        
    }
    
    func minimumDate(for calendar: FSCalendar) -> Date {
        return Date()
    }
}
