//
//  StructuresAndEnums.swift
//  TripArcher
//
//  Created by APPLE on 22/11/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit


struct TravellerDetailStruct {
    var structIndex : String!
    var travellerTitle : String!
    var firstName : String!
    var lastName : String!
    var dateOfBirth : String!
    var passportNo : String!
    var expiryDate : String!
    var filterStr : String!
    
}

//{"AirportCode":"CJB","CityName":"Coimbatore(CJB)","Country_sK":1.0,"CountryName":"India"}
struct AirportStruct {
    var airportCode : String!
    var cityName : String!
    var countrySK : String!
    var countryName : String!
}

struct FlightResultAndDetailStruct {

    var wayType : String!
    
    //for going
    
    var flightID : String!
    
    var flightImgName : String!
    var flightImgData : Data!
    var flightName : String!
    var departureTime : String!
    var departureAirportCode : String!
    var duration : String!
    var stopDetails : String!
    var noOfStops : String!
    var arrivalTime : String!
    var arrivalAirportCode : String!
    var amount : String!
    
    var isMultiAirlineAvailable : Bool!
    var detailArrWithFlightDetailStruct = [FlightDetailStruct]()
    
    
    //for returning
//    var returnFlightID : String!
    var returnFlightImgName : String!
    var returnFlightImgData : Data!
    var returnFlightName : String!
    var returnDepartureTime : String!
    var returnDepartureAirportCode : String!
    var returnDuration : String!
    var returnNoofStops : String!
    var returnArrivalTime :String!
    var returnArrivalAirportCode : String!
    
    var isReturnMultiAirlineAvailable : Bool!
    var returnDetailArrWithFlightDetailStruct = [FlightDetailStruct]()
    
}
struct FlightDetailStruct {
    var flightImgName : String!
    var flightImgData : Data!
    var flightNumber : String!
    var departureDate : String!
    var departureTime : String!
    var arrivalDate : String!
    var arrivalTime : String!
    
    var marketing : String!
    var operating : String!
    var duration : String!
    var fromAirportName : String!
    var toAirportName : String!
    
    var departureDateTime : String!
    var arrivalDateTime : String!
    
//    var flightName : String!
    var stop : String!
    var fromCity : String!
    var toCity : String!
}

struct FinalStruct {
    var flightImgName : String!
    var flightImgData : Data?
    var flightName : String!
    var departureTime : String!
    var departureAirportCode : String!
    var duration : String!
    var stop : String!
    var arrivalTime : String!
    var arrivalAirportCode : String!
    
    var TripDetailsArr = [FlightDetailStruct]()
}
extension FinalStruct {
//    var structExtension : String!
    
}
