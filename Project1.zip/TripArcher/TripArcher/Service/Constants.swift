//
//  Constants.swift
//  TripArcher
//
//  Created by APPLE on 19/11/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit


struct WebServicesUrl{
    
    //Test URL
    static let MainBaseUrl = "http://192.168.1.3:2217/FlightService.asmx"
    
    static let FlightResult = "FlightResult"
    static let FlightImgURL = "https://www.shioktrip.com/Airline_Images/"
    
}
