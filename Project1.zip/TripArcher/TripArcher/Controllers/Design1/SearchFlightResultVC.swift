//
//  FlightSearchVC.swift
//  TripArcher
//
//  Created by APPLE on 19/11/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

class FlightResultVC: UIViewController {

    @IBOutlet weak var testLbl: UILabel!
    var inputDict = [String:String]()
    
    @IBOutlet weak var onewayView: UIView!
    @IBOutlet weak var dataTV: UITableView!
    
    @IBOutlet weak var bottomView: UIView!
    
    var flightResultArr = [[String:AnyObject]]()
    var flightDetailsArr = [[String:AnyObject]]()
    var flightResultAndDetailsArr = [FlightResultAndDetailStruct]()
    
    var flightDetailsReturnArr = [[String:AnyObject]]()
    
    var way : String!
    
    let dateFormatter = DateFormatter()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        
        self.dataTV.delegate = self
        self.dataTV.dataSource = self
        
        dataTV.tableFooterView = UIView.init(frame: CGRect.zero)
        
        self.way = self.inputDict["WayType"]!
        print("Way Type = ",self.way)
        
        // Do any additional setup after loading the view.
        print("inputDict =",self.inputDict)
        
    }
    override func viewWillAppear(_ animated: Bool) {
        callSearchFlightService(messageDict: self.inputDict)
    }
    
    func callSearchFlightService(messageDict:[String:String]){
        if (Reachability()?.isReachable)! {
//            self.view.StartLoading()
            showLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.FlightResult, parameterDict: messageDict) { (ResponceDict, success) in
                
//                if self.view.isLoading(){
//                    self.view.StopLoading()
//                }
                hideLoading()
                
                
                if success {
                    print("Service call success ..........")
                    //                print("The ResponseDict finally =",ResponceDict!)
                    
                    
                    if let responce = ResponceDict {
                        self.flightResultArr = responce["FlightResult"] as! [[String:AnyObject]]
                        self.flightDetailsArr = responce["Flightdetails"] as! [[String:AnyObject]]
                        if responce.keys.contains("FlightdetailsReturn"){
                            self.flightDetailsReturnArr = responce["FlightdetailsReturn"] as! [[String : AnyObject]]
                        }
                        
                        
                        
                        self.flightResultAndDetailsArr.removeAll()
                        for aResultDict in self.flightResultArr{
                            var aResultAndDetailStruct = FlightResultAndDetailStruct()
                            
                            aResultAndDetailStruct.wayType = self.way
                            
                            //Flight ID
                            aResultAndDetailStruct.flightID = "\(aResultDict["FlightId"]!)"
                            
                            //Flight Name
                            let flightNameArr = "\(aResultDict["aname"]!)".components(separatedBy: ",")
                            aResultAndDetailStruct.flightName = flightNameArr.first
                            
                            
                            
                           
                            
                            //Depature Time
                            aResultAndDetailStruct.departureTime = "\(aResultDict["departuretime"]!)"
                            
                            //Departure Airport Code
                            //IXM~BLR~BLR~MAA
                            var allAirportCodeArr = "\(aResultDict["dairportall"]!)".components(separatedBy: "~")
                            aResultAndDetailStruct.departureAirportCode = allAirportCodeArr[0]
                            
                            //Amount
                            aResultAndDetailStruct.amount = "\(aResultDict["totalAmountAll"]!)"
                            
                            
              
                            //Flight Details
                            for aDetailDict in self.flightDetailsArr {
                                
                                if "\(aDetailDict["FlightId"]!)" == "\(aResultDict["FlightId"]!)"{
                                    var aDetailStruct = FlightDetailStruct()
                                    aDetailStruct.flightNumber = "\(aDetailDict["flightNumber"]!)"
                                    aDetailStruct.departureDate = "\(aDetailDict["departuredate"]!)"
                                    aDetailStruct.departureTime = "\(aDetailDict["departuretime"]!)"
                                    aDetailStruct.arrivalDate = "\(aDetailDict["arrivaldate"]!)"
                                    aDetailStruct.arrivalTime = "\(aDetailDict["arrivaltime"]!)"
                                    
                                    aDetailStruct.marketing = "\(aDetailDict["marketing"]!)"
                                    aDetailStruct.operating = "\(aDetailDict["operating"]!)"
                                    aDetailStruct.duration = "\(aDetailDict["duration"]!)"
                                    aDetailStruct.fromAirportName = "\(aDetailDict["FromAirportName"]!)"
                                    aDetailStruct.toAirportName = "\(aDetailDict["ToAirportName"]!)"
                                    
                                    aDetailStruct.departureDateTime = "\(aDetailDict["DepartureDateTime"]!)"
                                    aDetailStruct.arrivalDateTime = "\(aDetailDict["ArrivalDateTime"]!)"
                                    
                                    aDetailStruct.stop = "\(aDetailDict["stop"]!)"
                                    
                                    aResultAndDetailStruct.detailArrWithFlightDetailStruct.append(aDetailStruct)
                                }
                            }
                            
                            //Flight Name
                            if aResultAndDetailStruct.detailArrWithFlightDetailStruct.count > 1 {
                                //                                    print("Multi Airlines")
                                aResultAndDetailStruct.returnFlightName = "Multi Airlines"
                            }else if aResultAndDetailStruct.detailArrWithFlightDetailStruct.count == 1 {
                                //                                    print("Only single flight")
                                aResultAndDetailStruct.returnFlightName = aResultAndDetailStruct.detailArrWithFlightDetailStruct[0].operating
                            }else{
                                print("0 flight")
                            }
                            
                            
                            
                            /*
                            for aStruct in aResultAndDetailStruct.detailArrWithFlightDetailStruct {
                                let arr = aStruct.duration.components(separatedBy: ":")
                                
                                let h = arr[0].trimmingCharacters(in: .whitespaces).dropLast()
                                let m = arr[1].trimmingCharacters(in: .whitespaces).dropLast()
                                
                                let hSec = Int(h)! * 3600
                                let mSec = Int(m)! * 60
                                let tSec = hSec + mSec
                                
                                grandTSec += tSec
                                
                                

                            }  // 18000 + 300 + 43200 + 3000 + 3600 + 900
                            //40500  2700 */
//                            print("grandTsec = ", grandTSec )
                            
                            var sumOfIndividualFlightDurationInSec = 0
                            var layoverArr = [Int]()
                            var start : String!
                            var end : String!
                            
                            for i in 0..<aResultAndDetailStruct.detailArrWithFlightDetailStruct.count {
                               
                                let arr = aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].duration.components(separatedBy: ":")
                                let hr = arr[0].trimmingCharacters(in: .whitespaces).dropLast()
                                let min = arr[1].trimmingCharacters(in: .whitespaces).dropLast()
                                
                                let hourSec = Int(hr)! * 3600
                                let minSec = Int(min)! * 60
                                let totalSec = hourSec + minSec
                                
                                sumOfIndividualFlightDurationInSec += totalSec
                                
                                
                                if (i%2) == 0 {  // 0 modulo 2 = 0,     1 modulo 2 = 1 ,    2 modulo 2 = 0
                                    if i == 0 {
                                        start = aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].arrivalDateTime
                                    }else{
                                        end = aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].departureDateTime
                                        layoverArr.append(self.calculateSecondsFrom(dateTime1: start, dateTime2: end))
                                        start = aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].arrivalDateTime
                                    }
                                }else {
                                    end = aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].departureDateTime
                                    layoverArr.append(self.calculateSecondsFrom(dateTime1: start, dateTime2: end))
                                    start = aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].arrivalDateTime
                                }
                            }
//                            print("sum Of IndividualFlightDuration InSec = ", sumOfIndividualFlightDurationInSec)
//                            print("Layover Arr = ",layoverArr)
                            
                            let sumofOverlays = layoverArr.reduce(0, {$0 + $1})
//                            print ("Sum of overlays = ",sumofOverlays)
                            

                            let totalDurationInSec = sumOfIndividualFlightDurationInSec + sumofOverlays
//                            print("The Total Duraion in Sec =",totalDurationInSec)
                            
                            let numberOfHo: Int = totalDurationInSec / 3600
                            let numberOfMin: Int = (totalDurationInSec % 3600) / 60
//                            print("The Duration = \(numberOfHo)h \(numberOfMin)m")
                            let durationForForwardFlight = "\(numberOfHo)h \(numberOfMin)m"
                            
                            //Flight Details Return
                            if responce.keys.contains("FlightdetailsReturn"){
                                for aDetailDict in self.flightDetailsReturnArr {
                                    if "\(aDetailDict["FlightId"]!)" == "\(aResultDict["FlightId"]!)"{
                                        var aDetailStruct = FlightDetailStruct()
                                        aDetailStruct.flightNumber = "\(aDetailDict["flightNumber"]!)"
                                        aDetailStruct.departureDate = "\(aDetailDict["departuredate"]!)"
                                        aDetailStruct.departureTime = "\(aDetailDict["departuretime"]!)"
                                        aDetailStruct.arrivalDate = "\(aDetailDict["arrivaldate"]!)"
                                        aDetailStruct.arrivalTime = "\(aDetailDict["arrivaltime"]!)"
                                        
                                        aDetailStruct.marketing = "\(aDetailDict["marketing"]!)"
                                        aDetailStruct.operating = "\(aDetailDict["operating"]!)"
                                        aDetailStruct.duration = "\(aDetailDict["duration"]!)"
                                        aDetailStruct.fromAirportName = "\(aDetailDict["FromAirportName"]!)"
                                        aDetailStruct.toAirportName = "\(aDetailDict["ToAirportName"]!)"
                                        
                                        aDetailStruct.departureDateTime = "\(aDetailDict["DepartureDateTime"]!)"
                                        aDetailStruct.arrivalDateTime = "\(aDetailDict["ArrivalDateTime"]!)"
                                        
                                    aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.append(aDetailStruct)
                                        
                                    }
                                }
                            }
                            var sumOfIndividualFlightDurationInSecReturn = 0
                            var layoverArrReturn = [Int]()
                            var startReturn : String!
                            var endReturn : String!
                            
                            for i in 0..<aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count {
                                
                                let arr = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].duration.components(separatedBy: ":")
                                let hr = arr[0].trimmingCharacters(in: .whitespaces).dropLast()
                                let min = arr[1].trimmingCharacters(in: .whitespaces).dropLast()
                                
                                let hourSec = Int(hr)! * 3600
                                let minSec = Int(min)! * 60
                                let totalSec = hourSec + minSec
                                
                                sumOfIndividualFlightDurationInSecReturn += totalSec
                                
                                
                                if (i%2) == 0 {  // 0 modulo 2 = 0,     1 modulo 2 = 1 ,    2 modulo 2 = 0
                                    if i == 0 {
                                        startReturn = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].arrivalDateTime
                                    }else{
                                        endReturn = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].departureDateTime
                                        layoverArrReturn.append(self.calculateSecondsFrom(dateTime1: startReturn, dateTime2: endReturn))
                                        startReturn = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].arrivalDateTime
                                    }
                                }else {
                                    endReturn = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].departureDateTime
                                    layoverArrReturn.append(self.calculateSecondsFrom(dateTime1: startReturn, dateTime2: endReturn))
                                    startReturn = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].arrivalDateTime
                                }
                            }
//                            print("sum Of IndividualFlightDuration InSec (Return) = ", sumOfIndividualFlightDurationInSecReturn)
//                            print("Return Layover Arr  = ",layoverArrReturn)
                            
                            let sumofOverlaysReturn = layoverArrReturn.reduce(0, {$0 + $1})
//                            print ("Sum of Return overlays = ",sumofOverlaysReturn)
                            
                            
                            let totalDurationInSecReturn = sumOfIndividualFlightDurationInSecReturn + sumofOverlaysReturn
//                            print("The Total Duraion in Sec (Return) =",totalDurationInSecReturn)
                            
                            let numberOfHoReturn: Int = totalDurationInSecReturn / 3600
                            let numberOfMinReturn: Int = (totalDurationInSecReturn % 3600) / 60
//                            print("The Duration = \(numberOfHoReturn)h \(numberOfMinReturn)m")
                            let durationForReturnFlight = "\(numberOfHoReturn)h \(numberOfMinReturn)m"
         
                            
                            if self.way == "one" {
                                
                                //Duration:
                                /*"Departdatetimetall": "2018-12-25T14:15:00~2018-12-26T00:05:00~2018-12-26T08:30:00",
                                 "Arrivaldatetimeall": "2018-12-25T16:30:00~2018-12-26T05:45:00~2018-12-26T10:31:00",*/
                                let allDepartDateTimeArr = "\(aResultDict["Departdatetimetall"]!)".components(separatedBy: "~")
                                let allArrivalDateTimeArr = "\(aResultDict["Arrivaldatetimeall"]!)".components(separatedBy: "~")
                                
                                
                                
                                
                                /* let dur = self.calculateHoursAndMinsFrom(dateTime1: allDepartDateTimeArr.first!, dateTime2: allArrivalDateTimeArr.last!)
                                aResultAndDetailStruct.duration = "\(dur.hours)h \(dur.minutes)m" */
                                
                                aResultAndDetailStruct.duration = durationForForwardFlight
                                
                                //Stop
                                aResultAndDetailStruct.noOfStops = "\(aResultDict["stop"]!)"
                                
                                //Arrival Time
                                //150000~212500 or 044000
                                let allArrivalTime = "\(aResultDict["atimeall"]!)"
                                
                                if allArrivalTime.contains("~"){
                                    let arrivalTime = allArrivalTime.components(separatedBy: "~")
                                    var lastArrivalTime : String = arrivalTime.last!
                                    lastArrivalTime.insert(":", at: lastArrivalTime.index(lastArrivalTime.startIndex, offsetBy: 2))
                                    
                                    let endIndex = lastArrivalTime.index(lastArrivalTime.endIndex, offsetBy: -2)
                                    let arrivalTimeFormatted = String(lastArrivalTime[..<endIndex])
                                    
                                    aResultAndDetailStruct.arrivalTime = arrivalTimeFormatted
                                }else{
                                    aResultAndDetailStruct.arrivalTime = allArrivalTime
                                }
                                
                                //Arrival Airport Code
                                aResultAndDetailStruct.arrivalAirportCode = allAirportCodeArr.last
                                
                            }
                            //two way
                            else{
                                
                                /* For Forward Flights */
                                
                                //Duration:
                                
                                /* let dur = self.calculateHoursAndMinsFrom(dateTime1:(aResultAndDetailStruct.detailArrWithFlightDetailStruct.first?.departureDateTime)! , dateTime2: (aResultAndDetailStruct.detailArrWithFlightDetailStruct.last?.arrivalDateTime)!)
                                aResultAndDetailStruct.duration = "\(dur.hours)h \(dur.minutes)m" */
                                
                                aResultAndDetailStruct.duration = durationForForwardFlight
                                
                                /*
                                let deptDate : Date? = dateFormatter.date(from: (aResultAndDetailStruct.detailArrWithFlightDetailStruct.first?.departureDateTime)!)!
                                let arrivalDate : Date? = dateFormatter.date(from: (aResultAndDetailStruct.detailArrWithFlightDetailStruct.last?.arrivalDateTime)!)!
                                
                                var secondsBetween: TimeInterval? = nil
                                if let aDate = deptDate {
                                    secondsBetween = arrivalDate?.timeIntervalSince(aDate)
                                }
                                let seconds = Int(secondsBetween ?? 0) // Since modulo operator (%) below needs int or long
                                let numberOfHours: Int = seconds / 3600
                                let numberOfMinutes: Int = (seconds % 3600) / 60
                                
                                let duration = "\(numberOfHours)h \(numberOfMinutes)m"
                                aResultAndDetailStruct.duration = duration
                                
                                 print("Diff time : \(aResultAndDetailStruct.detailArrWithFlightDetailStruct.first?.departureDateTime) - \(aResultAndDetailStruct.detailArrWithFlightDetailStruct.last?.arrivalDateTime) \(numberOfHours) \(numberOfMinutes)") */
                                
                                //Stop
//                                print("No of Stops = \(aResultAndDetailStruct.detailArrWithFlightDetailStruct.count - 1)")
                                if (aResultAndDetailStruct.detailArrWithFlightDetailStruct.count - 1) > 1 {
                                    aResultAndDetailStruct.noOfStops = "\(aResultAndDetailStruct.detailArrWithFlightDetailStruct.count - 1) stops"
                                }else{
                                    aResultAndDetailStruct.noOfStops = "\(aResultAndDetailStruct.detailArrWithFlightDetailStruct.count - 1) stop"
                                }
                                
                                
                                //Arrival Time
                                aResultAndDetailStruct.arrivalTime = aResultAndDetailStruct.detailArrWithFlightDetailStruct.last?.arrivalTime
                                
                                //Arrival Airport Code
//                                let lastStruct =
                                let lastAirportCodeStr = aResultAndDetailStruct.detailArrWithFlightDetailStruct.last?.toAirportName //lastStruct?.toAirportName
                                let startInd = lastAirportCodeStr?.index(after: (lastAirportCodeStr?.lastIndex(of: "("))!)
                                let endInd = lastAirportCodeStr?.lastIndex(of: ")")
                                let formattedStr = lastAirportCodeStr![startInd!..<endInd!]
                                //                                print("Result = ",result)
                                aResultAndDetailStruct.arrivalAirportCode = String(formattedStr)
                                
                                
                                
                                /* For Return flights */
                                
                                
                                //Return Flight Name
//                                print ("Number of flights for single return = ",aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count)
//                                print("Stops (Return) = ",aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count - 1)
                                if aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count > 1 {
//                                    print("Multi Airlines")
                                    aResultAndDetailStruct.returnFlightName = "Multi Airlines"
                                }else if aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count == 1 {
//                                    print("Only single flight")
                                    aResultAndDetailStruct.returnFlightName = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[0].operating
                                }else{
                                    print("0 flight")
                                }
                                
                                //Return Depature Time
                                aResultAndDetailStruct.returnDepartureTime = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.first?.departureTime
                                
                                //Return Departure Airport Code
                                let firstAirportCodeStr = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.first?.fromAirportName
                                let startIndReturn = firstAirportCodeStr?.index(after: (firstAirportCodeStr?.lastIndex(of: "(")!)!)
                                let endIndReturn = firstAirportCodeStr?.lastIndex(of: ")")
                                let formattedStrReturn = firstAirportCodeStr![startIndReturn!..<endIndReturn!]
                                aResultAndDetailStruct.returnDepartureAirportCode = String(formattedStrReturn)
                                
                                
                                //Return Duration
                                
                                /*
                                let retDur = self.calculateHoursAndMinsFrom(dateTime1: (aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.first?.departureDateTime)!, dateTime2: (aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.last?.arrivalDateTime)!)
                                
                                aResultAndDetailStruct.returnDuration = "\(retDur.hours)h \(retDur.minutes)m" */
                                
                                aResultAndDetailStruct.returnDuration = durationForReturnFlight
                                
                                
                                //Return stop
                                if (aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count - 1) > 1 {
                                    aResultAndDetailStruct.returnNoofStops = "\(aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count - 1) stops"
                                }else{
                                    aResultAndDetailStruct.returnNoofStops = "\(aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count - 1) stop"
                                }
                               
                                //Return Arrival Time
                                aResultAndDetailStruct.returnArrivalTime = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.last?.arrivalTime
                                
                                //Return Arrival Airport Code
                                let lastAirportCodeStrForReturnArrival = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.last?.toAirportName
                                let startIndexforAirportCode = lastAirportCodeStrForReturnArrival?.index(after: (lastAirportCodeStrForReturnArrival?.lastIndex(of: "("))!)
                                let endIndexforAirportCode = lastAirportCodeStrForReturnArrival?.lastIndex(of: ")")
                                let formattedStrforAirportCode = lastAirportCodeStrForReturnArrival![startIndexforAirportCode!..<endIndexforAirportCode!]
                                //                                print("Result = ",result)
                                aResultAndDetailStruct.returnArrivalAirportCode = String(formattedStrforAirportCode)
//                                aResultAndDetailStruct.arrivalAirportCode = String(formattedStr)
                            }
                            
                            
                            
                           
                            
                            
                            
                            self.flightResultAndDetailsArr.append(aResultAndDetailStruct)
                        }
                        
                        self.dataTV.reloadData()
                        print("flightResultAndDetailsArr count :",self.flightResultAndDetailsArr.count)
//                        print("flightResultAndDetailsArr = ",self.flightResultAndDetailsArr)
                    }
                    else {
                        //                    self.showAlert(Constants.InternalError)
                    }
                }
                else {
                    //                self.showAlert(Constants.InternalError)
                    print("Service call failure ..........")
                }
            }
        }else{
            print("No Internet......")
        }
        

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func calculateHoursAndMinsFrom(dateTime1 : String,dateTime2 : String) -> (hours : String,minutes : String){
        let deptDate : Date? = dateFormatter.date(from: dateTime1)
        let arrivalDate : Date? = dateFormatter.date(from: dateTime2)
        
        var secondsBetween: TimeInterval? = nil
        if let aDate = deptDate {
            secondsBetween = arrivalDate?.timeIntervalSince(aDate)
        }
        let seconds = Int(secondsBetween ?? 0) // Since modulo operator (%) below needs int or long
        let numberOfHours: Int = seconds / 3600
        let numberOfMinutes: Int = (seconds % 3600) / 60
        
//        let duration = "\(numberOfHours)h \(numberOfMinutes)m"
        
        return("\(numberOfHours)","\(numberOfMinutes)")
    }
    
    func calculateSecondsFrom(dateTime1 : String,dateTime2 : String) -> (Int){
        let deptDate : Date? = dateFormatter.date(from: dateTime1)
        let arrivalDate : Date? = dateFormatter.date(from: dateTime2)
        
        var secondsBetween: TimeInterval? = nil
        if let aDate = deptDate {
            secondsBetween = arrivalDate?.timeIntervalSince(aDate)
        }
        let seconds = Int(secondsBetween ?? 0) // Since modulo operator (%) below needs int or long
        return seconds
        
//        let numberOfHours: Int = seconds / 3600
//        let numberOfMinutes: Int = (seconds % 3600) / 60
//        return("\(numberOfHours)","\(numberOfMinutes)")
    }

    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func sortBtnTapped(_ sender: UIButton) {
    }
    
    @IBAction func filterBtnTapped(_ sender: UIButton) {
    }
}
extension FlightResultVC : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.flightResultAndDetailsArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "onewayCellID", for: indexPath) as! OnewayCellClass
        if self.inputDict["WayType"]! == "one"{
            cell.returnFlightLbl.isHidden = true
        }else{
            cell.returnFlightLbl.isHidden = false
        }
//        cell.flightNameLbl.text = self.flightResultAndDetailsArr[indexPath.row].flightName
        cell.flightNameLbl.text = self.flightResultAndDetailsArr[indexPath.row].detailArrWithFlightDetailStruct[0].operating
        cell.depTimeLbl.text = self.flightResultAndDetailsArr[indexPath.row].departureTime
        cell.depAirportCodeLbl.text = self.flightResultAndDetailsArr[indexPath.row].departureAirportCode
        cell.durationLbl.text = self.flightResultAndDetailsArr[indexPath.row].duration
        cell.stopDetailsLbl.text = self.flightResultAndDetailsArr[indexPath.row].noOfStops
        cell.arrivalTimeLbl.text = self.flightResultAndDetailsArr[indexPath.row].arrivalTime
        cell.arrivalAirportCodeLbl.text = self.flightResultAndDetailsArr[indexPath.row].arrivalAirportCode
        cell.amountLbl.text = self.flightResultAndDetailsArr[indexPath.row].amount
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    
        let structToSend : FlightResultAndDetailStruct = self.flightResultAndDetailsArr[indexPath.row]
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "FlightReviewVCSBID") as! FlightReviewVC
        ctrl.selectedStruct = structToSend
        ctrl.providedInputDict = self.inputDict
        self.navigationController?.pushViewController(ctrl, animated: true)
        
        
    }
}
class OnewayCellClass : UITableViewCell {
    
    @IBOutlet weak var flightNameLbl: UILabel!
    @IBOutlet weak var depTimeLbl: UILabel!
    @IBOutlet weak var depAirportCodeLbl: UILabel!
    @IBOutlet weak var durationLbl: UILabel!
    @IBOutlet weak var stopDetailsLbl: UILabel!
    @IBOutlet weak var arrivalTimeLbl: UILabel!
    @IBOutlet weak var arrivalAirportCodeLbl: UILabel!
    @IBOutlet weak var amountLbl: UILabel!
    
    @IBOutlet weak var refundOrNonRefundLbl: UILabel!
    @IBOutlet weak var lineDesignVIew: UIView!
    @IBOutlet weak var returnFlightLbl: UILabel!

}
