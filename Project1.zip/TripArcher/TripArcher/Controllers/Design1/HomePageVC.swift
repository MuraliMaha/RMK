//
//  HomePageVC3.swift
//  TripArcher
//
//  Created by APPLE on 16/11/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

class HomePageVC: UIViewController {

    @IBOutlet weak var logoView: UIView!
    @IBOutlet weak var flightView: UIView!
    @IBOutlet weak var hotelView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.isHidden = true
        
        self.logoView.layer.cornerRadius = self.logoView.frame.size.width / 2
        self.logoView.clipsToBounds = true
     
            
        self.flightView.layer.cornerRadius = self.flightView.frame.size.width / 2
        self.flightView.clipsToBounds = true
        self.flightView.layer.masksToBounds = false
        
        self.hotelView.layer.cornerRadius = self.hotelView.frame.size.width / 2
        self.hotelView.clipsToBounds = true
        hotelView.layer.masksToBounds = false

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func flightBtnTapped(_ sender: UIButton) {
//        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "SearchFlightVCSBID") as! SearchFlightVC
//        self.navigationController?.pushViewController(ctrl, animated: true)
        
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "SearchFlightVC2SBID") as! SearchFlightVC2
        self.navigationController?.pushViewController(ctrl, animated: true)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
