//
//  SearchFlightVC2.swift
//  TripArcher
//
//  Created by APPLE on 05/12/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

class SearchFlightVC2: UIViewController {
    
    var airportStructFull : [AirportStruct]!
    var defaultOriginStruct : AirportStruct!
    var defaultDestinationStruct : AirportStruct!
    var originToPass : String!
    var destinationToPass : String!
    
//    @IBOutlet weak var onewayImg: UIImageView!
//    @IBOutlet weak var returnImg: UIImageView!
    @IBOutlet weak var onewayBtn: UIButton!
    @IBOutlet weak var returnBtn: UIButton!
    
    @IBOutlet weak var fromAirportCodeLbl: UILabel!
    @IBOutlet weak var toAirportCodeLbl: UILabel!
    @IBOutlet weak var fromTxtField: UITextField!
    @IBOutlet weak var toTxtField: UITextField!
    var fromOrTo : String!
    var selectedOriginStruct : AirportStruct!
    var selectedDestinationStruct : AirportStruct!
    
    @IBOutlet weak var departOnDateView: UIView!
    @IBOutlet weak var returnOnDateView: UIView!
    
    var adultSelectedItem = "1",childrenSelectedItem = "0",infantSelectedItem = "0"

    var passengerInputArr = ["0","1","2","3","4","5","6","7","8","9","10"]
    var adultSelectedIndex : Int = 1 ,childrenSelectedIndex = 0 ,infantSelectedIndex = 0

    var adultPreviousIndex : Int = 1,childrenPreviousIndex = 0,infantPreviousIndex = 0

    
    var classSelectedItem = "Economy"
    var classSelectedIndex : Int = 0
    var classPreviousIndex : Int = 0
    var classInputArr = ["Economy","Bussiness","First","Premium Economy"]
    
    
    
    @IBOutlet weak var passengerTxtField: UITextField!
    @IBOutlet weak var classTxtField: UITextField!
    
    var formattedPassengerStr : String!
    
    @IBOutlet weak var passengerPickerView: UIPickerView!
    @IBOutlet weak var passengerOrClassSelectionView: UIView!
    @IBOutlet weak var passengerOrClassSelectionContentView: UIView!
    
    @IBOutlet weak var pickersTopTitleLbl: UILabel!
    
    @IBOutlet weak var classPickerView: UIPickerView!
    @IBOutlet weak var adultTitleLbl: UILabel!
    @IBOutlet weak var childrenTitleLbl: UILabel!
    @IBOutlet weak var infantTitleLbl: UILabel!
    
    @IBAction func passengerSelectionDoneBtnTapped(_ sender: UIButton) {
        self.view.endEditing(true)
        passengerOrClassSelectionView.isHidden = true
        
        if classPickerView.isHidden {
            self.passengerTxtField.resignFirstResponder()
            
            
            self.adultSelectedItem = passengerInputArr[self.adultSelectedIndex]
            self.childrenSelectedItem = passengerInputArr[self.childrenSelectedIndex]
            self.infantSelectedItem = passengerInputArr[self.infantSelectedIndex]
            
            var adultStr : String!
            var childStr : String!
            var infantStr : String!
            
            
            if Int(adultSelectedItem)! > 1 {
                adultStr = "\(adultSelectedItem) Adults,"
            }else{
                adultStr = "\(adultSelectedItem) Adult,"
            }
            
            
            if Int(childrenSelectedItem)! > 1 {
                childStr = "\(childrenSelectedItem) Children,"
            }else{
                childStr = "\(childrenSelectedItem) Child,"
            }
            
            
            if Int(infantSelectedItem)! > 1 {
                infantStr = "\(infantSelectedItem) Infants"
            }else{
                infantStr = "\(infantSelectedItem) Infant"
            }
            passengerTxtField.text = adultStr! + childStr! + infantStr!
            
            self.adultPreviousIndex = self.adultSelectedIndex
            self.childrenPreviousIndex = self.childrenSelectedIndex
            self.infantPreviousIndex = self.infantSelectedIndex
        }else{
            self.classTxtField.resignFirstResponder()
            self.classSelectedItem = classInputArr[self.classSelectedIndex]
            classTxtField.text = self.classSelectedItem
            self.classPreviousIndex = self.classSelectedIndex
        }
    }
    
    @IBAction func passengerSelectionCancelBtnTapped(_ sender: UIButton) {
        self.view.endEditing(true)
        passengerOrClassSelectionView.isHidden = true
        
        if classPickerView.isHidden {
            self.passengerTxtField.resignFirstResponder()
            self.adultSelectedIndex = self.adultPreviousIndex
            self.childrenSelectedIndex = self.childrenPreviousIndex
            self.infantSelectedIndex = self.infantPreviousIndex
        }else{
            self.classTxtField.resignFirstResponder()
            self.classSelectedIndex = self.classPreviousIndex
        }
    }
    
    @IBOutlet weak var departOnTxtField: UITextField!
    @IBOutlet weak var returnOnTxtField: UITextField!
    
    @IBOutlet weak var myCalenderContainerView: UIView!
    @IBOutlet weak var myCalenderView: FSCalendar!
    
    var selectedDepartOnDateStr : String!
    var selectedReturnOnDateStr = "Nothing"
    
    var selectedDepartOnDate : Date!
    var selectedReturnOnDate : Date!
    
    var dateFormatter = DateFormatter()
    var calendarFlag : String!
    
    var inputParameterDateFormatter = DateFormatter()
    var selectedDepartOnStrToPass : String!
    var selectedReturnOnStrToPass : String!
    
    @IBAction func swapBtnTapped(_ sender: UIButton) {
        
        if let _ = selectedOriginStruct,let _ = selectedDestinationStruct{
            let abc = selectedOriginStruct
            selectedOriginStruct = selectedDestinationStruct
            selectedDestinationStruct = abc
            
            fromAirportCodeLbl.text = selectedOriginStruct.airportCode
            fromTxtField.text = selectedOriginStruct.cityName
            
            toAirportCodeLbl.text = selectedDestinationStruct.airportCode
            toTxtField.text = selectedDestinationStruct.cityName
        }else{
            let xyz = defaultOriginStruct
            defaultOriginStruct = defaultDestinationStruct
            defaultDestinationStruct = xyz
            
            fromAirportCodeLbl.text = defaultOriginStruct.airportCode
            fromTxtField.text = defaultOriginStruct.cityName
            
            toAirportCodeLbl.text = defaultDestinationStruct.airportCode
            toTxtField.text = defaultDestinationStruct.cityName
        }
        
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        onewayBtn.isSelected = true
        self.returnOnDateView.isHidden = true
        
        
        fromTxtField.delegate = self
        toTxtField.delegate = self
        
        passengerTxtField.delegate = self
        classTxtField.delegate = self
        
        departOnTxtField.delegate = self
        returnOnTxtField.delegate = self
        
        formattedPassengerStr = adultSelectedItem + " Adult," + childrenSelectedItem + " Child," + infantSelectedItem + " Infant"
        passengerTxtField.text = formattedPassengerStr
        
        passengerOrClassSelectionView.isHidden = true
        passengerTxtField.inputView = passengerOrClassSelectionView
        passengerPickerView.delegate = self
        passengerPickerView.dataSource = self
        passengerPickerView.backgroundColor = UIColor.white
        passengerPickerView.showsSelectionIndicator = true
        passengerPickerView.selectRow(1, inComponent: 0, animated: true)
        
        passengerOrClassSelectionContentView.layer.masksToBounds = false
        
        classTxtField.inputView = passengerOrClassSelectionView
        classPickerView.delegate = self
        classPickerView.dataSource = self
        classPickerView.backgroundColor = UIColor.white
        classPickerView.showsSelectionIndicator = true
        classPickerView.selectRow(0, inComponent: 0, animated: true)
        
        myCalenderContainerView.isHidden = true
        departOnTxtField.inputView = myCalenderContainerView
        myCalenderView.dataSource = self
        myCalenderView.delegate = self
        
        dateFormatter.dateFormat = "dd-MMM-yyyy"
//        dateFormatter.dateFormat = "yyyy-MM-dd"
        self.departOnTxtField.text = dateFormatter.string(from: Date())
        self.selectedDepartOnDateStr = dateFormatter.string(from: Date())
        self.selectedDepartOnDate = dateFormatter.date(from: self.selectedDepartOnDateStr)
        
        inputParameterDateFormatter.dateFormat = "yyyy-MM-dd"
        self.selectedDepartOnStrToPass = inputParameterDateFormatter.string(from: Date())
        self.selectedReturnOnStrToPass = "Nothing"
//        dateFormatter.dateFormat = "yyyy-MM-dd"
//        self.selectedDepartOnStrFinal = dateFormatter.string(from: Date())
        
        
        
        self.myCalenderView.calendarHeaderView.backgroundColor = hexStringToUIColor(hex: "#AFCA1F")
//        self.myCalenderView.layer.masksToBounds = false
        self.myCalenderView.calendarHeaderView.layer.masksToBounds = false
        
//        self.myCalenderView.scrollDirection = .horizontal
        getDefaultValuesForHomePage()

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func getDefaultValuesForHomePage(){
        airportStructFull = airportStructArrGlobal
        
        let temp = airportStructFull.filter { (AirportStruct) -> Bool in
//            $0.cityName == "Mumbai"
            AirportStruct.airportCode == "CJB"
        }
        self.defaultOriginStruct = temp[0]
        
        let temp2 = airportStructFull.filter { (AirportStruct) -> Bool in
            AirportStruct.airportCode == "SIN"
        }
        self.defaultDestinationStruct = temp2[0]
        
        self.fromAirportCodeLbl.text = self.defaultOriginStruct.airportCode
        self.fromTxtField.text = self.defaultOriginStruct.cityName
        
        self.toAirportCodeLbl.text = self.defaultDestinationStruct.airportCode
        self.toTxtField.text = self.defaultDestinationStruct.cityName
        
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = false
    }

    @IBAction func onewayBtnTapped(_ sender: UIButton) {
        if !sender.isSelected {
//            onewayImg.image = UIImage.init(named: "Circled Dot Filled")
//            returnImg.image = UIImage.init(named: "Unchecked Circle")
            onewayBtn.isSelected = true
            returnBtn.isSelected = false
            returnOnDateView.isHidden = true
            
            self.selectedReturnOnDateStr = "Nothing"
            self.selectedReturnOnDate = nil
            print("selected departOn :\(self.selectedDepartOnDateStr!)  returnOn : \(self.selectedReturnOnDateStr)")
            self.selectedReturnOnStrToPass = "Nothing"
            myCalenderView.reloadData()
            
        }
    }
    
    @IBAction func returnBtnTapped(_ sender: UIButton) {
        if !sender.isSelected {
//            returnImg.image = UIImage.init(named: "Circled Dot Filled")
//            onewayImg.image = UIImage.init(named: "Unchecked Circle")
            returnBtn.isSelected = true
            onewayBtn.isSelected = false
            returnOnDateView.isHidden = false
            
            myCalenderView.reloadData()
            
            self.selectedReturnOnDateStr = self.selectedDepartOnDateStr
            self.selectedReturnOnDate = self.selectedDepartOnDate
            self.returnOnTxtField.text = self.selectedReturnOnDateStr
            print("selected departOn :\(self.selectedDepartOnDateStr!)  returnOn : \(self.selectedReturnOnDateStr)")
            
            self.selectedReturnOnStrToPass = selectedDepartOnStrToPass
            
        }
    }

    @IBAction func searchFlightBtnTapped(_ sender: UIButton) {
        
//        guard let _ = self.selectedOriginStruct.airportCode else {
//            print("Please Enter Source")
//            return
//        }
//
//        guard let _ = self.selectedDestinationStruct.airportCode else {
//            print("Please Enter Destination")
//            return
//        }
        
        if let a = self.selectedOriginStruct{
            originToPass = a.airportCode
        }else{
            originToPass = defaultOriginStruct.airportCode
        }
        
        destinationToPass = self.selectedDestinationStruct != nil ? self.selectedDestinationStruct.airportCode : self.defaultDestinationStruct.airportCode
        

        //Donts search for CJB to LAS
//        let DictInput = ["Origin":"MAA","Destination":"LAS","DepartureDate":selectedDepartOnStrToPass!,"Returndate":selectedReturnOnStrToPass!,"WayType":self.onewayBtn.isSelected ? "one":"two","CabinClass":self.classSelectedItem,"AdultCount":self.adultSelectedItem,"ChildCount":self.childrenSelectedItem,"InfantCount":self.infantSelectedItem,"SeniorCount":"0","PreferredCarrier":"1","PromotionalPlanType":"0","SearchSessionid":"0","ModuleId":"14","ParentAccountId":"IXCRAJ042","ChildAccountId":"IXCRAJ042","ApiName":"TBO","NonStop":"","ReqType":"JSON"]
        
        
        
         let DictInput = ["Origin":self.originToPass!,"Destination":self.destinationToPass!,"DepartureDate":selectedDepartOnStrToPass!,"Returndate":selectedReturnOnStrToPass!,"WayType":self.onewayBtn.isSelected ? "one":"two","CabinClass":self.classSelectedItem,"AdultCount":self.adultSelectedItem,"ChildCount":self.childrenSelectedItem,"InfantCount":self.infantSelectedItem,"SeniorCount":"0","PreferredCarrier":"1","PromotionalPlanType":"0","SearchSessionid":"0","ModuleId":"14","ParentAccountId":"IXCRAJ042","ChildAccountId":"IXCRAJ042","ApiName":"TBO","NonStop":"","ReqType":"JSON"]
        
//        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "FlightResultVC2SBID") as! FlightResultVC2
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "FlightResultVCSBID") as! FlightResultVC
        ctrl.inputDict = DictInput
        self.navigationController?.pushViewController(ctrl, animated: true)
        
    }
    
    @IBAction func backBtnTappedBarBtn(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
}
//MARK: - TextFieldDelegate {
extension SearchFlightVC2 : UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.resignFirstResponder()
       
        if textField == fromTxtField{
            self.fromOrTo = "from"
        }else if textField == toTxtField {
            self.fromOrTo = "to"
        }
        if textField == fromTxtField || textField == toTxtField {
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"FlightPlacesVCSBID") as! FlightPlacesVC
            ctrl.delegateVariable = self
            self.present(ctrl, animated: true, completion: nil)
        }
        if textField == passengerTxtField {
            passengerOrClassSelectionView.isHidden = false
            classPickerView.isHidden = true
            pickersTopTitleLbl.text = "Select Passenger"
            adultTitleLbl.isHidden = false
            infantTitleLbl.isHidden = false
            childrenTitleLbl.text = "Children"
            passengerPickerView.reloadAllComponents()
            passengerPickerView.selectRow(adultSelectedIndex, inComponent: 0, animated: true)
            passengerPickerView.selectRow(childrenSelectedIndex, inComponent: 1, animated: true)
            passengerPickerView.selectRow(infantSelectedIndex, inComponent: 2, animated: true)
        }
        if textField == classTxtField {
            passengerOrClassSelectionView.isHidden = false
            classPickerView.isHidden = false
            pickersTopTitleLbl.text = "Select Class"
            adultTitleLbl.isHidden = true
            infantTitleLbl.isHidden = true
            childrenTitleLbl.text = "Class Type"
                
            classPickerView.reloadAllComponents()
            classPickerView.selectRow(classSelectedIndex, inComponent: 0, animated: true)
        }
        if textField == departOnTxtField || textField == returnOnTxtField{
            self.myCalenderContainerView.isHidden = false
            
            if textField == departOnTxtField{
                self.calendarFlag = "departOnCalender"
                
//                calendar.deselect(Date())
//                self.myCalenderView.
            }else{
                self.calendarFlag = "returnOnCalender"
            }
            myCalenderView.reloadData()
        }
    }
}
//MARK: - }

//MARK: - FlightPlacesDelegate {
extension SearchFlightVC2 : FlightPlacesDelegate {
    
    func didSelectAirport(selectedAirportStruct: AirportStruct, controller: FlightPlacesVC) {
        controller.dismiss(animated: true, completion: nil)
        if fromOrTo == "from" {
            self.fromTxtField.text = selectedAirportStruct.cityName!
            self.fromAirportCodeLbl.text = selectedAirportStruct.airportCode!
            self.selectedOriginStruct = selectedAirportStruct
        }else{
            self.toTxtField.text = selectedAirportStruct.cityName!
            self.toAirportCodeLbl.text = selectedAirportStruct.airportCode!
            self.selectedDestinationStruct = selectedAirportStruct
        }
    }
}
//MARK: - }

//MARK: - PickerViewDelegate {
extension SearchFlightVC2:UIPickerViewDelegate,UIPickerViewDataSource {
 
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        if pickerView == passengerPickerView{
            return 3
        }else{
            return 1
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == passengerPickerView{
            return passengerInputArr.count
        }else{
            return classInputArr.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == passengerPickerView{
            return passengerInputArr[row]
        }else{
            return classInputArr[row]
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == passengerPickerView {
            self.adultSelectedIndex = pickerView.selectedRow(inComponent: 0)
            self.childrenSelectedIndex = pickerView.selectedRow(inComponent: 1)
            self.infantSelectedIndex = pickerView.selectedRow(inComponent: 2)
        }else{
            self.classSelectedIndex = pickerView.selectedRow(inComponent: 0)
        }
        
    }
}
//MARK: - }

//MARK: - PickerViewDelegate {
extension SearchFlightVC2:FSCalendarDelegate,FSCalendarDataSource,FSCalendarDelegateAppearance {
    func minimumDate(for calendar: FSCalendar) -> Date {
//        if onewayBtn.isSelected {
//            return Date()
//        }else{
//            return self.selectedDepartOnDate
//        }
        
        if calendarFlag == "departOnCalender" {
            return Date()
        }else{
            return self.selectedDepartOnDate
        }
        
    }
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, titleSelectionColorFor date: Date) -> UIColor? {
        calendar.deselect(date)
        return UIColor.green
    }
    
    
    
//    - (BOOL)calendar:(FSCalendar *)calendar shouldDeselectDate:(NSDate *)date atMonthPosition:(FSCalendarMonthPosition)monthPosition;
    
    func calendar(_ calendar: FSCalendar, willDisplay cell: FSCalendarCell, for date: Date, at monthPosition: FSCalendarMonthPosition) {
//        calendar.appearance.titleTodayColor = UIColor.brown
        if calendarFlag == "returnOnCalender"{
            calendar.appearance.titleTodayColor = UIColor.brown
        }
    }
    
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        self.view.endEditing(true)
        //        if monthPosition == .previous || monthPosition == .next {
        //          myCalenderView.setCurrentPage(date, animated: true)
        //        }
        
        myCalenderContainerView.isHidden = true
        
        if onewayBtn.isSelected {
            print("Depart Date :",date)
            self.selectedDepartOnDateStr = dateFormatter.string(from: date)
            self.selectedDepartOnDate = dateFormatter.date(from: self.selectedDepartOnDateStr)
            self.departOnTxtField.text = self.selectedDepartOnDateStr
            print("selected departOn :\(self.selectedDepartOnDateStr!)  returnOn : \(self.selectedReturnOnDateStr)")
            
            self.selectedDepartOnStrToPass = inputParameterDateFormatter.string(from: date)
//            dateFormatter.dateFormat = "yyyy-MM-dd"
//            self.selectedDepartOnStrFinal = dateFormatter.string(from: date)
            
            myCalenderView.setCurrentPage(date, animated: true)
        }else{
            if calendarFlag == "departOnCalender" {
                self.selectedDepartOnDateStr = dateFormatter.string(from: date)
                self.selectedDepartOnDate = dateFormatter.date(from: self.selectedDepartOnDateStr)
                self.departOnTxtField.text = self.selectedDepartOnDateStr
                print("selected departOn :\(self.selectedDepartOnDateStr!)  returnOn : \(self.selectedReturnOnDateStr)")
                
                self.selectedDepartOnStrToPass = inputParameterDateFormatter.string(from: date)
                
                
//                if selectedDepartOnDate > selectedReturnOnDate{
                if selectedDepartOnDate.compare(selectedReturnOnDate) == .orderedDescending {
                    self.selectedReturnOnDateStr = self.selectedDepartOnDateStr
                    self.selectedReturnOnDate = self.selectedDepartOnDate
                    self.returnOnTxtField.text = self.selectedReturnOnDateStr
                    print("selected departOn :\(self.selectedDepartOnDateStr!)  returnOn : \(self.selectedReturnOnDateStr)")
                    self.selectedReturnOnStrToPass = self.selectedDepartOnStrToPass
                }else{
                    print("selected departOn :\(self.selectedDepartOnDateStr!)  returnOn : \(self.selectedReturnOnDateStr)")
                }
               
            }else{
                self.selectedReturnOnDateStr = dateFormatter.string(from: date)
                self.selectedReturnOnDate = dateFormatter.date(from: self.selectedReturnOnDateStr)
                self.returnOnTxtField.text = self.selectedReturnOnDateStr
                print("selected departOn :\(self.selectedDepartOnDateStr!)  returnOn : \(self.selectedReturnOnDateStr)")
                self.selectedReturnOnStrToPass = inputParameterDateFormatter.string(from: date)
            }
            
        }
        
    }
    
}
//MARK: - }





