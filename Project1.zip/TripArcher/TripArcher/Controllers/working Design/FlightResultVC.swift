//
//  FlightSearchVC.swift
//  TripArcher
//
//  Created by APPLE on 19/11/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit
import SDWebImage

class FlightResultVC: UIViewController {

    @IBOutlet weak var errorLbl: UILabel!
    
    var inputDict = [String:String]()
    @IBOutlet weak var dataTV: UITableView!

    var flightResultArr = [[String:AnyObject]]()
    var flightDetailsArr = [[String:AnyObject]]()
    var flightResultAndDetailsArr = [FlightResultAndDetailStruct]()
    
    var flightDetailsReturnArr = [[String:AnyObject]]()
    
    var way : String!
    let dateFormatter = DateFormatter()
    
    @IBOutlet weak var dataTVContainerView: UIView!
    @IBOutlet weak var bottomView: UIView!
    
//    @IBAction func backBtnTapped(_ sender: UIButton) {
//        self.navigationController?.popViewController(animated: true)
//    }
    
    @IBAction func backBtnTapped(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBOutlet weak var departureBtn: UIButton!
    @IBOutlet weak var flightBtn: UIButton!
    @IBOutlet weak var priceBtn: UIButton!
    
    @IBOutlet weak var departureBtnImgView: UIImageView!
    @IBOutlet weak var flightBtnImgView: UIImageView!
    @IBOutlet weak var priceBtnImgView: UIImageView!
    
    @IBAction func departureBtnTapped(_ sender: UIButton) {
        
        flightBtnImgView.image = .none
        priceBtnImgView.image = nil
        
        flightBtn.isSelected = false
        priceBtn.isSelected = false
        
        if !sender.isSelected { //isSelected : default is NO..Though if u tap on btn,isSelected value will be NO.We have to set.
            departureBtnImgView.image = UIImage.init(named: "downArrowGreen")
            sender.isSelected = true
        }else{
            departureBtnImgView.image = UIImage.init(named: "upArrowGreen")
            sender.isSelected = false
        }
    }
    
    
    @IBAction func flightNameBtnTapped(_ sender: UIButton) {
        departureBtnImgView.image = nil
        priceBtnImgView.image = .none
        
        departureBtn.isSelected = false
        priceBtn.isSelected = false
        
        if !sender.isSelected {
            flightBtnImgView.image = UIImage.init(named: "downArrowGreen")
            sender.isSelected = true
        }else{
            flightBtnImgView.image = UIImage.init(named: "upArrowGreen")
            sender.isSelected = false
        }
    }
    @IBAction func priceBtnTapped(_ sender: UIButton) {
        departureBtnImgView.image = nil
        flightBtnImgView.image = .none
        
        departureBtn.isSelected = false
        flightBtn.isSelected = false
        
        if !sender.isSelected {
            priceBtnImgView.image = UIImage.init(named: "downArrowGreen")
            sender.isSelected = true
        }else{
            priceBtnImgView.image = UIImage.init(named: "upArrowGreen")
            sender.isSelected = false
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.isHidden = false
        
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        
        self.dataTV.delegate = self
        self.dataTV.dataSource = self
        
        dataTV.tableFooterView = UIView.init(frame: CGRect.zero)
        
        self.way = self.inputDict["WayType"]!
        print("Way Type = ",self.way)
        print("inputDict from FlightResultVC=",self.inputDict)
        callSearchFlightService(messageDict: self.inputDict)
    }
    override func viewWillAppear(_ animated: Bool) {
//        callSearchFlightService(messageDict: self.inputDict)
    }
    
    func callSearchFlightService(messageDict:[String:String]){
        if (Reachability()?.isReachable)! {
            //            self.view.StartLoading()
                        showLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.FlightResult, parameterDict: messageDict) { (ResponceDict, success) in
                                hideLoading()
                if success {
                    print("Service call success ..........")
//                    self.dataTV.isHidden = false
                    self.dataTVContainerView.isHidden = false
                    //                print("The ResponseDict finally =",ResponceDict!)
                    
                    
                    if let responce = ResponceDict {
                        self.flightResultArr = responce["FlightResult"] as! [[String:AnyObject]]
                        self.flightDetailsArr = responce["Flightdetails"] as! [[String:AnyObject]]
                        if responce.keys.contains("FlightdetailsReturn"){
                            self.flightDetailsReturnArr = responce["FlightdetailsReturn"] as! [[String : AnyObject]]
                        }
                        
                        self.flightResultAndDetailsArr.removeAll()
                        for aResultDict in self.flightResultArr{
                            var aResultAndDetailStruct = FlightResultAndDetailStruct()
                            
                            aResultAndDetailStruct.wayType = self.way
                            
                            //Flight ID
                            aResultAndDetailStruct.flightID = "\(aResultDict["FlightId"]!)"
                            
                            //Amount
                            aResultAndDetailStruct.amount = "\(aResultDict["totalAmountAll"]!)"
                            
                            //Flight Details
                            for aDetailDict in self.flightDetailsArr {
                                
                                if "\(aDetailDict["FlightId"]!)" == "\(aResultDict["FlightId"]!)"{
                                    var aDetailStruct = FlightDetailStruct()
                                    aDetailStruct.flightNumber = "\(aDetailDict["flightNumber"]!)"
                                    aDetailStruct.departureDate = "\(aDetailDict["departuredate"]!)"
                                    aDetailStruct.departureTime = "\(aDetailDict["departuretime"]!)"
                                    aDetailStruct.arrivalDate = "\(aDetailDict["arrivaldate"]!)"
                                    aDetailStruct.arrivalTime = "\(aDetailDict["arrivaltime"]!)"
                                    
                                    aDetailStruct.marketing = "\(aDetailDict["marketing"]!)"
                                    aDetailStruct.operating = "\(aDetailDict["operating"]!)"
                                    aDetailStruct.duration = "\(aDetailDict["duration"]!)"
                                    aDetailStruct.fromAirportName = "\(aDetailDict["FromAirportName"]!)"
                                    aDetailStruct.toAirportName = "\(aDetailDict["ToAirportName"]!)"
                                    
                                    aDetailStruct.departureDateTime = "\(aDetailDict["DepartureDateTime"]!)"
                                    aDetailStruct.arrivalDateTime = "\(aDetailDict["ArrivalDateTime"]!)"
                                    
                                    aDetailStruct.stop = "\(aDetailDict["stop"]!)"
                                    aDetailStruct.fromCity = "\(aDetailDict["fromcity"]!)"
                                    aDetailStruct.toCity = "\(aDetailDict["tocity"]!)"
                                    
                                    aResultAndDetailStruct.detailArrWithFlightDetailStruct.append(aDetailStruct)
                                }
                            }
                            
                            //Flight Name
                            if aResultAndDetailStruct.detailArrWithFlightDetailStruct.count > 1 {
                                
                                
                                aResultAndDetailStruct.isMultiAirlineAvailable = false
                                let lastStruct = aResultAndDetailStruct.detailArrWithFlightDetailStruct.last
                                
                                
                                for i in 0..<aResultAndDetailStruct.detailArrWithFlightDetailStruct.count {
                                    if i == aResultAndDetailStruct.detailArrWithFlightDetailStruct.count-1 {
                                        print("This is Last Item")
                                    }else{
                                        if aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].marketing != lastStruct?.marketing{
                                            aResultAndDetailStruct.isMultiAirlineAvailable = true
                                            break
                                        }
                                    }
                                }
                                
                                if aResultAndDetailStruct.isMultiAirlineAvailable{
                                    print("Multiple Exists...")
                                    aResultAndDetailStruct.flightName = "Multi Airlines"
                                    aResultAndDetailStruct.flightImgName = "multiairline"
                                }else{
                                    print("Multiple Exists...But All are same")
                                    aResultAndDetailStruct.flightName = aResultAndDetailStruct.detailArrWithFlightDetailStruct.last?.operating
                                    aResultAndDetailStruct.flightImgName = aResultAndDetailStruct.detailArrWithFlightDetailStruct.last?.marketing
                                }
                                
                                
                                
                            }else if aResultAndDetailStruct.detailArrWithFlightDetailStruct.count == 1 {
                                aResultAndDetailStruct.flightName = aResultAndDetailStruct.detailArrWithFlightDetailStruct[0].operating
                                aResultAndDetailStruct.flightImgName = aResultAndDetailStruct.detailArrWithFlightDetailStruct[0].marketing
                            }else{
                                print("0 flight")
                                aResultAndDetailStruct.flightName = "0 Flight"
                                aResultAndDetailStruct.flightImgName = "No Flight"
                            }
                            
                            //Depature Time
                            aResultAndDetailStruct.departureTime = aResultAndDetailStruct.detailArrWithFlightDetailStruct[0].departureTime
                            
                            //Departure Airport Code
                            //IXM~BLR~BLR~MAA
                            var allAirportCodeArr = "\(aResultDict["dairportall"]!)".components(separatedBy: "~")
                            aResultAndDetailStruct.departureAirportCode = allAirportCodeArr[0]
                            
                            //Duration
                            var sumOfIndividualFlightDurationInSec = 0
                            var layoverArr = [Int]()
                            var start : String!
                            var end : String!
                            
                            for i in 0..<aResultAndDetailStruct.detailArrWithFlightDetailStruct.count {
                                
                                let arr = aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].duration.components(separatedBy: ":")
                                let hr = arr[0].trimmingCharacters(in: .whitespaces).dropLast()
                                let min = arr[1].trimmingCharacters(in: .whitespaces).dropLast()
                                
                                let hourSec = Int(hr)! * 3600
                                let minSec = Int(min)! * 60
                                let totalSec = hourSec + minSec
                                
                                sumOfIndividualFlightDurationInSec += totalSec
                                
                                
                                if (i%2) == 0 {  // 0 modulo 2 = 0,     1 modulo 2 = 1 ,    2 modulo 2 = 0
                                    if i == 0 {
                                        start = aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].arrivalDateTime
                                    }else{
                                        end = aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].departureDateTime
                                        layoverArr.append(self.calculateSecondsFrom(dateTime1: start, dateTime2: end))
                                        start = aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].arrivalDateTime
                                    }
                                }else {
                                    end = aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].departureDateTime
                                    layoverArr.append(self.calculateSecondsFrom(dateTime1: start, dateTime2: end))
                                    start = aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].arrivalDateTime
                                }
                            }
                            let sumofOverlays = layoverArr.reduce(0, {$0 + $1})
                            let totalDurationInSec = sumOfIndividualFlightDurationInSec + sumofOverlays
                            
                            let numberOfHo: Int = totalDurationInSec / 3600
                            let numberOfMin: Int = (totalDurationInSec % 3600) / 60
                            
                            let durationForForwardFlight = "\(numberOfHo)h \(numberOfMin)m"
                            aResultAndDetailStruct.duration = durationForForwardFlight
                            
                            //Stops
                            if (aResultAndDetailStruct.detailArrWithFlightDetailStruct.count - 1) > 1 {
                                aResultAndDetailStruct.noOfStops = "\(aResultAndDetailStruct.detailArrWithFlightDetailStruct.count - 1) stops"
                            }else{
                                aResultAndDetailStruct.noOfStops = "\(aResultAndDetailStruct.detailArrWithFlightDetailStruct.count - 1) stop"
                            }
                            
                            // Arrival Time
                            aResultAndDetailStruct.arrivalTime = aResultAndDetailStruct.detailArrWithFlightDetailStruct.last?.arrivalTime
                            
                            // Arrival Airport Code
                            let lastAirportCodeStrForArrival = aResultAndDetailStruct.detailArrWithFlightDetailStruct.last?.toAirportName
                            let startIndexforAirportCode = lastAirportCodeStrForArrival?.index(after: (lastAirportCodeStrForArrival?.lastIndex(of: "("))!)
                            let endIndexforAirportCode = lastAirportCodeStrForArrival?.lastIndex(of: ")")
                            let formattedStrforAirportCode = lastAirportCodeStrForArrival![startIndexforAirportCode!..<endIndexforAirportCode!]
                            //                                print("Result = ",result)
                            aResultAndDetailStruct.arrivalAirportCode = String(formattedStrforAirportCode)
                            
                            // ------ end of oneway ----
                            
                            
                            
                            //Flight Details Return
                            if responce.keys.contains("FlightdetailsReturn"){
                                for aDetailDict in self.flightDetailsReturnArr {
                                    if "\(aDetailDict["FlightId"]!)" == "\(aResultDict["FlightId"]!)"{
                                        var aDetailStruct = FlightDetailStruct()
                                        aDetailStruct.flightNumber = "\(aDetailDict["flightNumber"]!)"
                                        aDetailStruct.departureDate = "\(aDetailDict["departuredate"]!)"
                                        aDetailStruct.departureTime = "\(aDetailDict["departuretime"]!)"
                                        aDetailStruct.arrivalDate = "\(aDetailDict["arrivaldate"]!)"
                                        aDetailStruct.arrivalTime = "\(aDetailDict["arrivaltime"]!)"
                                        
                                        aDetailStruct.marketing = "\(aDetailDict["marketing"]!)"
                                        aDetailStruct.operating = "\(aDetailDict["operating"]!)"
                                        aDetailStruct.duration = "\(aDetailDict["duration"]!)"
                                        aDetailStruct.fromAirportName = "\(aDetailDict["FromAirportName"]!)"
                                        aDetailStruct.toAirportName = "\(aDetailDict["ToAirportName"]!)"
                                        
                                        aDetailStruct.departureDateTime = "\(aDetailDict["DepartureDateTime"]!)"
                                        aDetailStruct.arrivalDateTime = "\(aDetailDict["ArrivalDateTime"]!)"
                                        
                                        aDetailStruct.stop = "\(aDetailDict["stop"]!)"
                                        aDetailStruct.fromCity = "\(aDetailDict["fromcity"]!)"
                                        aDetailStruct.toCity = "\(aDetailDict["tocity"]!)"
                                        
                                        aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.append(aDetailStruct)
                                        
                                    }
                                }
                            }
                            
                            if self.way == "two" {
                                //Return Flight Name
                                if aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count > 1 {
//                                    aResultAndDetailStruct.returnFlightName = "Multi Airlines"
                                    
                                    
                                    
                                    aResultAndDetailStruct.isReturnMultiAirlineAvailable = false
                                    let lastStructRet = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.last
                                    
                                    for i in 0..<aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count {
                                        if i == aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count-1 {
                                            print("Return This is Last Item")
                                        }else{
                                            if aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].marketing != lastStructRet?.marketing{
                                                aResultAndDetailStruct.isReturnMultiAirlineAvailable = true
                                                break
                                            }
                                        }
                                    }
                                    
                                    if aResultAndDetailStruct.isReturnMultiAirlineAvailable{
                                        print("Return Multiple Exists...")
                                        aResultAndDetailStruct.returnFlightName = "Multi Airlines"
                                        aResultAndDetailStruct.returnFlightImgName = "multiairline"
                                    }else{
                                        print("Return Multiple Exists...But All are same")
                                        aResultAndDetailStruct.returnFlightName = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.last?.operating
                                        aResultAndDetailStruct.returnFlightImgName = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.last?.marketing
                                    }
                                    
                                    
                                    
                                    
                                }else if aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count == 1 {
                                    aResultAndDetailStruct.returnFlightName = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[0].operating
                                }else{
                                    aResultAndDetailStruct.returnFlightName = "0 flight"
                                    aResultAndDetailStruct.returnFlightImgName = "No Flight"
                                }
                                
                                
                                
                                
                                
                                
                                //Return Depature Time
                                aResultAndDetailStruct.returnDepartureTime = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.first?.departureTime
                                
                                //Return Departure Airport Code
                                let firstAirportCodeStr = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.first?.fromAirportName
                                let startIndReturn = firstAirportCodeStr?.index(after: (firstAirportCodeStr?.lastIndex(of: "(")!)!)
                                let endIndReturn = firstAirportCodeStr?.lastIndex(of: ")")
                                let formattedStrReturn = firstAirportCodeStr![startIndReturn!..<endIndReturn!]
                                aResultAndDetailStruct.returnDepartureAirportCode = String(formattedStrReturn)
                                
                                //Return Duration
                                var sumOfIndividualFlightDurationInSecReturn = 0
                                var layoverArrReturn = [Int]()
                                var startReturn : String!
                                var endReturn : String!
                                
                                for i in 0..<aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count {
                                    
                                    let arr = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].duration.components(separatedBy: ":")
                                    let hr = arr[0].trimmingCharacters(in: .whitespaces).dropLast()
                                    let min = arr[1].trimmingCharacters(in: .whitespaces).dropLast()
                                    
                                    let hourSec = Int(hr)! * 3600
                                    let minSec = Int(min)! * 60
                                    let totalSec = hourSec + minSec
                                    
                                    sumOfIndividualFlightDurationInSecReturn += totalSec
                                    
                                    
                                    if (i%2) == 0 {  // 0 modulo 2 = 0,     1 modulo 2 = 1 ,    2 modulo 2 = 0
                                        if i == 0 {
                                            startReturn = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].arrivalDateTime
                                        }else{
                                            endReturn = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].departureDateTime
                                            layoverArrReturn.append(self.calculateSecondsFrom(dateTime1: startReturn, dateTime2: endReturn))
                                            startReturn = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].arrivalDateTime
                                        }
                                    }else {
                                        endReturn = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].departureDateTime
                                        layoverArrReturn.append(self.calculateSecondsFrom(dateTime1: startReturn, dateTime2: endReturn))
                                        startReturn = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].arrivalDateTime
                                    }
                                }
                                
                                let sumofOverlaysReturn = layoverArrReturn.reduce(0, {$0 + $1})
                                
                                
                                let totalDurationInSecReturn = sumOfIndividualFlightDurationInSecReturn + sumofOverlaysReturn
                                
                                let numberOfHoReturn: Int = totalDurationInSecReturn / 3600
                                let numberOfMinReturn: Int = (totalDurationInSecReturn % 3600) / 60
                                let durationForReturnFlight = "\(numberOfHoReturn)h \(numberOfMinReturn)m"
                                aResultAndDetailStruct.returnDuration = durationForReturnFlight
                                
                                //Return stop
                                if (aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count - 1) > 1 {
                                    aResultAndDetailStruct.returnNoofStops = "\(aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count - 1) stops"
                                }else{
                                    aResultAndDetailStruct.returnNoofStops = "\(aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count - 1) stop"
                                }
                                
                                //Return Arrival Time
                                aResultAndDetailStruct.returnArrivalTime = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.last?.arrivalTime
                                
                                //Return Arrival Airport Code
                                let lastAirportCodeStrForReturnArrival = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.last?.toAirportName
                                let startIndexforAirportCode = lastAirportCodeStrForReturnArrival?.index(after: (lastAirportCodeStrForReturnArrival?.lastIndex(of: "("))!)
                                let endIndexforAirportCode = lastAirportCodeStrForReturnArrival?.lastIndex(of: ")")
                                let formattedStrforAirportCode = lastAirportCodeStrForReturnArrival![startIndexforAirportCode!..<endIndexforAirportCode!]
                                aResultAndDetailStruct.returnArrivalAirportCode = String(formattedStrforAirportCode)
                            }
                            
                            self.flightResultAndDetailsArr.append(aResultAndDetailStruct)
                        }
                        
                        self.dataTV.reloadData()
                        print("flightResultAndDetailsArr count :",self.flightResultAndDetailsArr.count)
                    }
                    else {
                        //                    self.showAlert(Constants.InternalError)
                    }
                }
                else {
                    //                self.showAlert(Constants.InternalError)
                    print("Service call failure ..........")
                    print("Try after sometimes...internet connetivity Problem....")
                    self.view.ShowBlackTostWithText(message: "Try after sometimes...internet connetivity Problem....", Interval: 2)
//                    self.dataTV.isHidden = true
                    self.dataTVContainerView.isHidden = true
                    self.errorLbl.text = "Oops!!! Try after sometimes..."
                }
            }
        }else{
            print("No Internet......")
//            self.dataTV.isHidden = true
            self.dataTVContainerView.isHidden = true
            self.errorLbl.text = "Internet connetivity Problem..."
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    func calculateHoursAndMinsFrom(dateTime1 : String,dateTime2 : String) -> (hours : String,minutes : String){
        let deptDate : Date? = dateFormatter.date(from: dateTime1)
        let arrivalDate : Date? = dateFormatter.date(from: dateTime2)
        
        var secondsBetween: TimeInterval? = nil
        if let aDate = deptDate {
            secondsBetween = arrivalDate?.timeIntervalSince(aDate)
        }
        let seconds = Int(secondsBetween ?? 0) // Since modulo operator (%) below needs int or long
        let numberOfHours: Int = seconds / 3600
        let numberOfMinutes: Int = (seconds % 3600) / 60
        
//        let duration = "\(numberOfHours)h \(numberOfMinutes)m"
        
        return("\(numberOfHours)","\(numberOfMinutes)")
    }*/
    
    func calculateSecondsFrom(dateTime1 : String,dateTime2 : String) -> (Int){
        let deptDate : Date? = dateFormatter.date(from: dateTime1)
        let arrivalDate : Date? = dateFormatter.date(from: dateTime2)
        
        var secondsBetween: TimeInterval? = nil
        if let aDate = deptDate {
            secondsBetween = arrivalDate?.timeIntervalSince(aDate)
        }
        let seconds = Int(secondsBetween ?? 0) // Since modulo operator (%) below needs int or long
        return seconds
    }
}
extension FlightResultVC : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.flightResultAndDetailsArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "onewayCellID", for: indexPath) as! OnewayCellClass
        if self.inputDict["WayType"]! == "one"{
            cell.returnFlightLbl.isHidden = true
        }else{
            cell.returnFlightLbl.isHidden = false
        }
     
        let flightImgURL = WebServicesUrl.FlightImgURL + self.flightResultAndDetailsArr[indexPath.row].detailArrWithFlightDetailStruct[0].marketing + ".gif"
        /* or
         let flightImgURL = WebServicesUrl.FlightImgURL + self.flightResultAndDetailsArr[indexPath.row].flightImgName */
        
        if self.flightResultAndDetailsArr[indexPath.row].flightImgName == "multiairline" {
            cell.flightImgView.image = UIImage(named: "multiairline")
            cell.flightNameLbl.text = self.flightResultAndDetailsArr[indexPath.row].flightName
            self.flightResultAndDetailsArr[indexPath.row].flightImgData = UIImagePNGRepresentation(UIImage(named: "multiairline")!)
        }else{
//            cell.flightImgView.sd_setImage(with: URL(string: flightImgURL), completed: nil)
            cell.flightNameLbl.text = self.flightResultAndDetailsArr[indexPath.row].detailArrWithFlightDetailStruct[0].operating
            
            cell.flightImgView.sd_setImage(with: URL(string: flightImgURL), placeholderImage: UIImage(named: "flightGreen"),options: SDWebImageOptions(rawValue: 0), completed: { downloadedImage, error, cacheType, imageURL in
                if error == nil{
                    self.flightResultAndDetailsArr[indexPath.row].flightImgData = UIImagePNGRepresentation(downloadedImage!)
                }else{
                    print("Error from SBWebImage Block = ",error)
                }
                
            })
            
            
        }
        
//        cell.flightNameLbl.text = self.flightResultAndDetailsArr[indexPath.row].detailArrWithFlightDetailStruct[0].operating
        /* or
         cell.flightNameLbl.text = self.flightResultAndDetailsArr[indexPath.row].flightName */

        
        cell.depTimeLbl.text = self.flightResultAndDetailsArr[indexPath.row].departureTime
        cell.depAirportCodeLbl.text = self.flightResultAndDetailsArr[indexPath.row].departureAirportCode
        cell.durationLbl.text = self.flightResultAndDetailsArr[indexPath.row].duration
        cell.stopDetailsLbl.text = self.flightResultAndDetailsArr[indexPath.row].noOfStops
        cell.arrivalTimeLbl.text = self.flightResultAndDetailsArr[indexPath.row].arrivalTime
        cell.arrivalAirportCodeLbl.text = self.flightResultAndDetailsArr[indexPath.row].arrivalAirportCode
        cell.amountLbl.text = "Rs." + self.flightResultAndDetailsArr[indexPath.row].amount
        
//        https://www.shioktrip.com/Airline_Images/%@.gif
//        imageView.sd_setImage(with: URL(string: "http://www.domain.com/path/to/image.jpg"), placeholderImage: UIImage(named: "placeholder.png"))
        
        
        
//        cell.flightImgView.sd_setImage(with: URL(string: flightImgURL), placeholderImage: nil, options: <#T##SDWebImageOptions#>, completed: nil)
       
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        var structToSend : FlightResultAndDetailStruct = self.flightResultAndDetailsArr[indexPath.row]
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "FlightReviewVCSBID") as! FlightReviewVC
        ctrl.providedInputDict = self.inputDict
        ctrl.selectedStruct = structToSend
        self.navigationController?.pushViewController(ctrl, animated: true)
        
        /*
        if self.way == "two" {
            let flightImgURLStr = WebServicesUrl.FlightImgURL + structToSend.returnFlightImgName + ".gif"
            print("Image URL :",flightImgURLStr)
            SDWebImageManager.shared().imageDownloader?.downloadImage(with: URL(string: flightImgURLStr), options: .highPriority, progress: nil, completed: { (downloadedImg, downloadedData, error, isFinished) in
                if downloadedImg != nil {
                    structToSend.returnFlightImgData = downloadedData
                    ctrl.selectedStruct = structToSend
                    self.navigationController?.pushViewController(ctrl, animated: true)
                }else{
                    print("No Img downloaded...")
                }
            })
        }else{
            ctrl.selectedStruct = structToSend
            self.navigationController?.pushViewController(ctrl, animated: true)
        } */
        
        
        
        
    }
}
class OnewayCellClass : UITableViewCell {
    
    @IBOutlet weak var flightImgView: UIImageView!
    @IBOutlet weak var flightNameLbl: UILabel!
    @IBOutlet weak var depTimeLbl: UILabel!
    @IBOutlet weak var depAirportCodeLbl: UILabel!
    @IBOutlet weak var durationLbl: UILabel!
    @IBOutlet weak var stopDetailsLbl: UILabel!
    @IBOutlet weak var arrivalTimeLbl: UILabel!
    @IBOutlet weak var arrivalAirportCodeLbl: UILabel!
    @IBOutlet weak var amountLbl: UILabel!
    
    @IBOutlet weak var refundOrNonRefundLbl: UILabel!
    @IBOutlet weak var lineDesignVIew: UIView!
    @IBOutlet weak var returnFlightLbl: UILabel!

}
