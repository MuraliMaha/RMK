//
//  HomePageVC.swift
//  TripArcher
//
//  Created by APPLE on 14/11/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

class HomePageVC3: UIViewController {

    @IBOutlet weak var testView1: UIView!
    @IBOutlet weak var testView2: UIView!
    
    @IBOutlet weak var titleVIew: UIView!
    @IBOutlet weak var titleDetailView: UIView!
    
    @IBOutlet weak var flightView: UIView!
    @IBOutlet weak var hotelView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        titleDetailView.addBottomRoundedEdge(desiredCurve: 2)
        
//        layer.backgroundColor = UIColor.clear.cgColor
        titleVIew.layer.shadowColor = UIColor.black.cgColor
        titleVIew.layer.shadowOffset = CGSize(width: 0, height: 1.0)
        titleVIew.layer.shadowOpacity = 0.2
        titleVIew.layer.shadowRadius = 4.0
        self.titleVIew.layer.masksToBounds = false
        
        // set the cornerRadius of the containerView's layer
//        containerView.layer.cornerRadius = cornerRadius
//        containerView.layer.masksToBounds = true
        

        flightView.backgroundColor = UIColor.white
        flightView.layer.cornerRadius = 5
        flightView.clipsToBounds = true
        
        
        flightView.layer.masksToBounds = false
        flightView.layer.shadowColor = UIColor.black.cgColor
        flightView.layer.shadowOpacity = 1
        flightView.layer.shadowOffset = CGSize.zero //CGSize(width: -1, height: 1)
        flightView.layer.shadowRadius = 5
        
        flightView.layer.shadowPath = UIBezierPath(rect: flightView.bounds).cgPath
        flightView.layer.shouldRasterize = true
        flightView.layer.rasterizationScale = true ? UIScreen.main.scale : 1
        
//        flightView.layer.shadowColor = UIColor.init
        
        
        hotelView.backgroundColor = UIColor.white
        hotelView.layer.cornerRadius = 5
        hotelView.clipsToBounds = true
        
        hotelView.layer.masksToBounds = false
        hotelView.layer.shadowColor = UIColor.black.cgColor
        hotelView.layer.shadowOpacity = 1
        hotelView.layer.shadowOffset =  CGSize.zero //CGSize(width: -1, height: 1)
        hotelView.layer.shadowRadius = 5
        
        hotelView.layer.shadowPath = UIBezierPath(rect: hotelView.bounds).cgPath
        hotelView.layer.shouldRasterize = true
        hotelView.layer.rasterizationScale = true ? UIScreen.main.scale : 1
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func flightBtnTapped(_ sender: UIButton) {
//        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "SearchFlightVCSBID") as! SearchFlightVC
//        self.navigationController?.pushViewController(ctrl, animated: true)
        
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "SearchFlightVC2SBID") as! SearchFlightVC2
        self.navigationController?.pushViewController(ctrl, animated: true)
    }
    
}
