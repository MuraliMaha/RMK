//
//  SearchFlightResultVC2.swift
//  TripArcher
//
//  Created by APPLE on 06/12/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

class FlightResultVC2: UIViewController {

    var inputDict = [String:String]()
    @IBOutlet weak var dataTV: UITableView!
    
    var flightResultArr = [[String:AnyObject]]()
    var flightDetailsArr = [[String:AnyObject]]()
    var flightResultAndDetailsArr = [FlightResultAndDetailStruct]()
    
    var flightDetailsReturnArr = [[String:AnyObject]]()
    
    var way : String!
    let dateFormatter = DateFormatter()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.isHidden = false
        
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        
        self.dataTV.delegate = self
        self.dataTV.dataSource = self
        
        dataTV.tableFooterView = UIView.init(frame: CGRect.zero)
        
        self.way = self.inputDict["WayType"]!
        print("Way Type = ",self.way)
        print("inputDict =",self.inputDict)
        callSearchFlightService(messageDict: self.inputDict)
    }
    override func viewWillAppear(_ animated: Bool) {
//        callSearchFlightService(messageDict: self.inputDict)
    }
    
    func callSearchFlightService(messageDict:[String:String]){
        if (Reachability()?.isReachable)! {
            //            self.view.StartLoading()
            //            showLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.FlightResult, parameterDict: messageDict) { (ResponceDict, success) in
                //                hideLoading()
                if success {
                    print("Service call success ..........")
                    //                print("The ResponseDict finally =",ResponceDict!)
                    
                    
                    if let responce = ResponceDict {
                        self.flightResultArr = responce["FlightResult"] as! [[String:AnyObject]]
                        self.flightDetailsArr = responce["Flightdetails"] as! [[String:AnyObject]]
                        if responce.keys.contains("FlightdetailsReturn"){
                            self.flightDetailsReturnArr = responce["FlightdetailsReturn"] as! [[String : AnyObject]]
                        }
                      
                        self.flightResultAndDetailsArr.removeAll()
                        for aResultDict in self.flightResultArr{
                            var aResultAndDetailStruct = FlightResultAndDetailStruct()
                            
                            aResultAndDetailStruct.wayType = self.way
                            
                            //Flight ID
                            aResultAndDetailStruct.flightID = "\(aResultDict["FlightId"]!)"
                           
                            //Amount
                            aResultAndDetailStruct.amount = "\(aResultDict["totalAmountAll"]!)"

                            //Flight Details
                            for aDetailDict in self.flightDetailsArr {
                                
                                if "\(aDetailDict["FlightId"]!)" == "\(aResultDict["FlightId"]!)"{
                                    var aDetailStruct = FlightDetailStruct()
                                    aDetailStruct.flightNumber = "\(aDetailDict["flightNumber"]!)"
                                    aDetailStruct.departureDate = "\(aDetailDict["departuredate"]!)"
                                    aDetailStruct.departureTime = "\(aDetailDict["departuretime"]!)"
                                    aDetailStruct.arrivalDate = "\(aDetailDict["arrivaldate"]!)"
                                    aDetailStruct.arrivalTime = "\(aDetailDict["arrivaltime"]!)"
                                    
                                    aDetailStruct.marketing = "\(aDetailDict["marketing"]!)"
                                    aDetailStruct.operating = "\(aDetailDict["operating"]!)"
                                    aDetailStruct.duration = "\(aDetailDict["duration"]!)"
                                    aDetailStruct.fromAirportName = "\(aDetailDict["FromAirportName"]!)"
                                    aDetailStruct.toAirportName = "\(aDetailDict["ToAirportName"]!)"
                                    
                                    aDetailStruct.departureDateTime = "\(aDetailDict["DepartureDateTime"]!)"
                                    aDetailStruct.arrivalDateTime = "\(aDetailDict["ArrivalDateTime"]!)"
                                    
                                    aDetailStruct.stop = "\(aDetailDict["stop"]!)"
                                    aDetailStruct.fromCity = "\(aDetailDict["fromcity"]!)"
                                    aDetailStruct.toCity = "\(aDetailDict["tocity"]!)"
                                    
                                    aResultAndDetailStruct.detailArrWithFlightDetailStruct.append(aDetailStruct)
                                }
                            }
                            
                            //Flight Name
                            if aResultAndDetailStruct.detailArrWithFlightDetailStruct.count > 1 {
                                aResultAndDetailStruct.flightName = "Multi Airlines"
                            }else if aResultAndDetailStruct.detailArrWithFlightDetailStruct.count == 1 {
                                aResultAndDetailStruct.flightName = aResultAndDetailStruct.detailArrWithFlightDetailStruct[0].operating
                            }else{
                                print("0 flight")
                                aResultAndDetailStruct.flightName = "0 flight"
                            }
                            
                            //Depature Time
                            aResultAndDetailStruct.departureTime = aResultAndDetailStruct.detailArrWithFlightDetailStruct[0].departureTime
                            
                            //Departure Airport Code
                            //IXM~BLR~BLR~MAA
                            var allAirportCodeArr = "\(aResultDict["dairportall"]!)".components(separatedBy: "~")
                            aResultAndDetailStruct.departureAirportCode = allAirportCodeArr[0]
                            
                            //Duration
                            var sumOfIndividualFlightDurationInSec = 0
                            var layoverArr = [Int]()
                            var start : String!
                            var end : String!
                            
                            for i in 0..<aResultAndDetailStruct.detailArrWithFlightDetailStruct.count {
                                
                                let arr = aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].duration.components(separatedBy: ":")
                                let hr = arr[0].trimmingCharacters(in: .whitespaces).dropLast()
                                let min = arr[1].trimmingCharacters(in: .whitespaces).dropLast()
                                
                                let hourSec = Int(hr)! * 3600
                                let minSec = Int(min)! * 60
                                let totalSec = hourSec + minSec
                                
                                sumOfIndividualFlightDurationInSec += totalSec
                                
                                
                                if (i%2) == 0 {  // 0 modulo 2 = 0,     1 modulo 2 = 1 ,    2 modulo 2 = 0
                                    if i == 0 {
                                        start = aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].arrivalDateTime
                                    }else{
                                        end = aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].departureDateTime
                                        layoverArr.append(self.calculateSecondsFrom(dateTime1: start, dateTime2: end))
                                        start = aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].arrivalDateTime
                                    }
                                }else {
                                    end = aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].departureDateTime
                                    layoverArr.append(self.calculateSecondsFrom(dateTime1: start, dateTime2: end))
                                    start = aResultAndDetailStruct.detailArrWithFlightDetailStruct[i].arrivalDateTime
                                }
                            }
                            let sumofOverlays = layoverArr.reduce(0, {$0 + $1})
                            let totalDurationInSec = sumOfIndividualFlightDurationInSec + sumofOverlays
                        
                            let numberOfHo: Int = totalDurationInSec / 3600
                            let numberOfMin: Int = (totalDurationInSec % 3600) / 60

                            let durationForForwardFlight = "\(numberOfHo)h \(numberOfMin)m"
                            aResultAndDetailStruct.duration = durationForForwardFlight
                            
                            //Stops
                            if (aResultAndDetailStruct.detailArrWithFlightDetailStruct.count - 1) > 1 {
                                aResultAndDetailStruct.noOfStops = "\(aResultAndDetailStruct.detailArrWithFlightDetailStruct.count - 1) stops"
                            }else{
                                aResultAndDetailStruct.noOfStops = "\(aResultAndDetailStruct.detailArrWithFlightDetailStruct.count - 1) stop"
                            }
   
                            // Arrival Time
                           aResultAndDetailStruct.arrivalTime = aResultAndDetailStruct.detailArrWithFlightDetailStruct.last?.arrivalTime
                            
                            // Arrival Airport Code
                            let lastAirportCodeStrForArrival = aResultAndDetailStruct.detailArrWithFlightDetailStruct.last?.toAirportName
                            let startIndexforAirportCode = lastAirportCodeStrForArrival?.index(after: (lastAirportCodeStrForArrival?.lastIndex(of: "("))!)
                            let endIndexforAirportCode = lastAirportCodeStrForArrival?.lastIndex(of: ")")
                            let formattedStrforAirportCode = lastAirportCodeStrForArrival![startIndexforAirportCode!..<endIndexforAirportCode!]
                            //                                print("Result = ",result)
                            aResultAndDetailStruct.arrivalAirportCode = String(formattedStrforAirportCode)

                           // ------ end of oneway ----
                            
                            
                           
                            //Flight Details Return
                            if responce.keys.contains("FlightdetailsReturn"){
                                for aDetailDict in self.flightDetailsReturnArr {
                                    if "\(aDetailDict["FlightId"]!)" == "\(aResultDict["FlightId"]!)"{
                                        var aDetailStruct = FlightDetailStruct()
                                        aDetailStruct.flightNumber = "\(aDetailDict["flightNumber"]!)"
                                        aDetailStruct.departureDate = "\(aDetailDict["departuredate"]!)"
                                        aDetailStruct.departureTime = "\(aDetailDict["departuretime"]!)"
                                        aDetailStruct.arrivalDate = "\(aDetailDict["arrivaldate"]!)"
                                        aDetailStruct.arrivalTime = "\(aDetailDict["arrivaltime"]!)"
                                        
                                        aDetailStruct.marketing = "\(aDetailDict["marketing"]!)"
                                        aDetailStruct.operating = "\(aDetailDict["operating"]!)"
                                        aDetailStruct.duration = "\(aDetailDict["duration"]!)"
                                        aDetailStruct.fromAirportName = "\(aDetailDict["FromAirportName"]!)"
                                        aDetailStruct.toAirportName = "\(aDetailDict["ToAirportName"]!)"
                                        
                                        aDetailStruct.departureDateTime = "\(aDetailDict["DepartureDateTime"]!)"
                                        aDetailStruct.arrivalDateTime = "\(aDetailDict["ArrivalDateTime"]!)"
                                        
                                        aDetailStruct.fromCity = "\(aDetailDict["fromcity"]!)"
                                        aDetailStruct.toCity = "\(aDetailDict["tocity"]!)"
                                        
                                        aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.append(aDetailStruct)
                                        
                                    }
                                }
                            }
                            
                            if self.way == "two" {
                                //Return Flight Name
                                if aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count > 1 {
                                    aResultAndDetailStruct.returnFlightName = "Multi Airlines"
                                }else if aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count == 1 {
                                    aResultAndDetailStruct.returnFlightName = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[0].operating
                                }else{
                                    aResultAndDetailStruct.returnFlightName = "0 flight"
                                }
                                
                                //Return Depature Time
                                aResultAndDetailStruct.returnDepartureTime = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.first?.departureTime
                                
                                //Return Departure Airport Code
                                let firstAirportCodeStr = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.first?.fromAirportName
                                let startIndReturn = firstAirportCodeStr?.index(after: (firstAirportCodeStr?.lastIndex(of: "(")!)!)
                                let endIndReturn = firstAirportCodeStr?.lastIndex(of: ")")
                                let formattedStrReturn = firstAirportCodeStr![startIndReturn!..<endIndReturn!]
                                aResultAndDetailStruct.returnDepartureAirportCode = String(formattedStrReturn)
                                
                                //Return Duration
                                var sumOfIndividualFlightDurationInSecReturn = 0
                                var layoverArrReturn = [Int]()
                                var startReturn : String!
                                var endReturn : String!
                                
                                for i in 0..<aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count {
                                    
                                    let arr = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].duration.components(separatedBy: ":")
                                    let hr = arr[0].trimmingCharacters(in: .whitespaces).dropLast()
                                    let min = arr[1].trimmingCharacters(in: .whitespaces).dropLast()
                                    
                                    let hourSec = Int(hr)! * 3600
                                    let minSec = Int(min)! * 60
                                    let totalSec = hourSec + minSec
                                    
                                    sumOfIndividualFlightDurationInSecReturn += totalSec
                                    
                                    
                                    if (i%2) == 0 {  // 0 modulo 2 = 0,     1 modulo 2 = 1 ,    2 modulo 2 = 0
                                        if i == 0 {
                                            startReturn = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].arrivalDateTime
                                        }else{
                                            endReturn = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].departureDateTime
                                            layoverArrReturn.append(self.calculateSecondsFrom(dateTime1: startReturn, dateTime2: endReturn))
                                            startReturn = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].arrivalDateTime
                                        }
                                    }else {
                                        endReturn = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].departureDateTime
                                        layoverArrReturn.append(self.calculateSecondsFrom(dateTime1: startReturn, dateTime2: endReturn))
                                        startReturn = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct[i].arrivalDateTime
                                    }
                                }
                                
                                let sumofOverlaysReturn = layoverArrReturn.reduce(0, {$0 + $1})
                                
                                
                                let totalDurationInSecReturn = sumOfIndividualFlightDurationInSecReturn + sumofOverlaysReturn
                                
                                let numberOfHoReturn: Int = totalDurationInSecReturn / 3600
                                let numberOfMinReturn: Int = (totalDurationInSecReturn % 3600) / 60
                                let durationForReturnFlight = "\(numberOfHoReturn)h \(numberOfMinReturn)m"
                                aResultAndDetailStruct.returnDuration = durationForReturnFlight
                                
                                //Return stop
                                if (aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count - 1) > 1 {
                                    aResultAndDetailStruct.returnNoofStops = "\(aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count - 1) stops"
                                }else{
                                    aResultAndDetailStruct.returnNoofStops = "\(aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.count - 1) stop"
                                }
                                
                                //Return Arrival Time
                                aResultAndDetailStruct.returnArrivalTime = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.last?.arrivalTime
                                
                                //Return Arrival Airport Code
                                let lastAirportCodeStrForReturnArrival = aResultAndDetailStruct.returnDetailArrWithFlightDetailStruct.last?.toAirportName
                                let startIndexforAirportCode = lastAirportCodeStrForReturnArrival?.index(after: (lastAirportCodeStrForReturnArrival?.lastIndex(of: "("))!)
                                let endIndexforAirportCode = lastAirportCodeStrForReturnArrival?.lastIndex(of: ")")
                                let formattedStrforAirportCode = lastAirportCodeStrForReturnArrival![startIndexforAirportCode!..<endIndexforAirportCode!]
                                aResultAndDetailStruct.returnArrivalAirportCode = String(formattedStrforAirportCode)
                            }
                            
                            self.flightResultAndDetailsArr.append(aResultAndDetailStruct)
                        }
                        
                        self.dataTV.reloadData()
                        print("flightResultAndDetailsArr count :",self.flightResultAndDetailsArr.count)
                    }
                    else {
                        //                    self.showAlert(Constants.InternalError)
                    }
                }
                else {
                    //                self.showAlert(Constants.InternalError)
                    print("Service call failure ..........")
                }
            }
        }else{
            print("No Internet......")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    func calculateHoursAndMinsFrom(dateTime1 : String,dateTime2 : String) -> (hours : String,minutes : String){
        let deptDate : Date? = dateFormatter.date(from: dateTime1)
        let arrivalDate : Date? = dateFormatter.date(from: dateTime2)
        
        var secondsBetween: TimeInterval? = nil
        if let aDate = deptDate {
            secondsBetween = arrivalDate?.timeIntervalSince(aDate)
        }
        let seconds = Int(secondsBetween ?? 0) // Since modulo operator (%) below needs int or long
        let numberOfHours: Int = seconds / 3600
        let numberOfMinutes: Int = (seconds % 3600) / 60
        
        //        let duration = "\(numberOfHours)h \(numberOfMinutes)m"
        
        return("\(numberOfHours)","\(numberOfMinutes)")
    } */
    
    func calculateSecondsFrom(dateTime1 : String,dateTime2 : String) -> (Int){
        let deptDate : Date? = dateFormatter.date(from: dateTime1)
        let arrivalDate : Date? = dateFormatter.date(from: dateTime2)
        
        var secondsBetween: TimeInterval? = nil
        if let aDate = deptDate {
            secondsBetween = arrivalDate?.timeIntervalSince(aDate)
        }
        let seconds = Int(secondsBetween ?? 0) // Since modulo operator (%) below needs int or long
        return seconds
    }
}
extension FlightResultVC2 : UITableViewDelegate,UITableViewDataSource {
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return self.flightResultAndDetailsArr.count
        }
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "CellID", for: indexPath) as! CellClass
            
            cell.flightNameLbl.text = self.flightResultAndDetailsArr[indexPath.row].detailArrWithFlightDetailStruct[0].operating
            cell.depTimeLbl.text = self.flightResultAndDetailsArr[indexPath.row].departureTime
            cell.depAirportCodeLbl.text = self.flightResultAndDetailsArr[indexPath.row].departureAirportCode
            cell.durationLbl.text = self.flightResultAndDetailsArr[indexPath.row].duration
            cell.stopDetailsLbl.text = self.flightResultAndDetailsArr[indexPath.row].noOfStops
            cell.arrivalTimeLbl.text = self.flightResultAndDetailsArr[indexPath.row].arrivalTime!
            cell.arrivalAirportCodeLbl.text = self.flightResultAndDetailsArr[indexPath.row].arrivalAirportCode
            cell.amountLbl.text = self.flightResultAndDetailsArr[indexPath.row].amount
            
            if self.way == "two"{
                cell.doublewayFlightView.isHidden = false
//                cell.singlewayBottomBorder.isHidden = false
                
                cell.doublewayFlightNameLbl.text = self.flightResultAndDetailsArr[indexPath.row].detailArrWithFlightDetailStruct[0].operating
                cell.returnDepTimeLbl.text = self.flightResultAndDetailsArr[indexPath.row].returnDepartureTime
                cell.returnDepAirportCodeLbl.text = self.flightResultAndDetailsArr[indexPath.row].returnDepartureAirportCode
                cell.returnDurationLbl.text = self.flightResultAndDetailsArr[indexPath.row].returnDuration
                cell.returnStopDetailsLbl.text = self.flightResultAndDetailsArr[indexPath.row].returnNoofStops
                cell.returnArrivalTimeLbl.text = self.flightResultAndDetailsArr[indexPath.row].returnArrivalTime
                cell.returnArrivalAirportCodeLbl.text = self.flightResultAndDetailsArr[indexPath.row].returnArrivalAirportCode
            }else{
                cell.doublewayFlightView.isHidden = true
//                cell.singlewayBottomBorder.isHidden = true
            }
            return cell
        }
        
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            tableView.deselectRow(at: indexPath, animated: true)

            /*
            let structToSend : FlightResultAndDetailStruct = self.flightResultAndDetailsArr[indexPath.row]
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "FlightReviewVC2SBID") as! FlightReviewVC2
            ctrl.selectedStruct = structToSend
            self.navigationController?.pushViewController(ctrl, animated: true)
            */
            
        }
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            if self.way == "one" {
//                return 100
                return 98
            }else{
                return 198
            }
        }
    }
    class CellClass : UITableViewCell {
        
        @IBOutlet weak var flightNameLbl: UILabel!
        @IBOutlet weak var depTimeLbl: UILabel!
        @IBOutlet weak var depAirportCodeLbl: UILabel!
        @IBOutlet weak var durationLbl: UILabel!
        @IBOutlet weak var stopDetailsLbl: UILabel!
        @IBOutlet weak var arrivalTimeLbl: UILabel!
        @IBOutlet weak var arrivalAirportCodeLbl: UILabel!
        @IBOutlet weak var amountLbl: UILabel!
        
        @IBOutlet weak var refundOrNonRefundLbl: UILabel!
        @IBOutlet weak var lineDesignVIew: UIView!
        @IBOutlet weak var returnFlightLbl: UILabel!
        
        @IBOutlet weak var returnDepTimeLbl: UILabel!
        @IBOutlet weak var returnDepAirportCodeLbl: UILabel!
        @IBOutlet weak var returnDurationLbl: UILabel!
        @IBOutlet weak var returnStopDetailsLbl: UILabel!
        @IBOutlet weak var returnArrivalTimeLbl: UILabel!
        @IBOutlet weak var returnArrivalAirportCodeLbl: UILabel!
        
        @IBOutlet weak var singlewayBottomBorder: UILabel!
        @IBOutlet weak var doublewayFlightView: UIView!
        @IBOutlet weak var doublewayFlightImg: UIImageView!
        @IBOutlet weak var doublewayFlightNameLbl: UILabel!
}
