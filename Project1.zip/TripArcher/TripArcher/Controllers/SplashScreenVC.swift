//
//  SplashScreenVC.swift
//  TripArcher
//
//  Created by APPLE on 14/11/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit
var airportStructArrGlobal = [AirportStruct]()

class SplashScreenVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        Timer.scheduledTimer(timeInterval: 0.2, target: self, selector: #selector(Call), userInfo: nil, repeats: false)
        if let path = Bundle.main.path(forResource: "AirportList", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let jsonResult = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves)
                if let jsonResult = jsonResult as? Dictionary<String, AnyObject>
                {
//                    print("Airports Dict:",jsonResult)
                    let airportArr = jsonResult["airports"] as! [[String:AnyObject]]
                    for aDict in airportArr {
                        var aAirportStructObj = AirportStruct()
                        aAirportStructObj.airportCode = "\(aDict["AirportCode"]!)"
                        aAirportStructObj.cityName = "\(aDict["CityName"]!)"
                        aAirportStructObj.countrySK = "\(aDict["Country_sK"]!)"
                        aAirportStructObj.countryName = "\(aDict["CountryName"]!)"
                        airportStructArrGlobal.append(aAirportStructObj)
                    }
                }
            } catch {
                // handle error
                print("Error from catch - FlightPlacesVC")
            }
        }
    } // end of view didload

    @objc func Call(){
        
        if !(Reachability()!.isReachable) {
            print("No Internet..................")
        }
        else {
            
//            guard FetchLoginResponce() != nil  else {
//                GoToLogin()
//                return
//            }
            

            
//             let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HomePageVCSBID") as! HomePageVC
//
//            let naviCtrl = self.storyboard?.instantiateViewController(withIdentifier: "navigationCtrlSBID") as! UINavigationController
//            naviCtrl.pushViewController(ctrl, animated: true)
            
            let naviCtrl = self.storyboard?.instantiateViewController(withIdentifier: "navigationCtrlSBID")
            self.present(naviCtrl!, animated: true, completion: nil)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
