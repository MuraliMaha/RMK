//
//  FlightPlacesVC.swift
//  TripArcher
//
//  Created by APPLE on 22/11/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

protocol FlightPlacesDelegate {
    func didSelectAirport(selectedAirportStruct : AirportStruct,controller : FlightPlacesVC)
}
class FlightPlacesVC: UIViewController {

    @IBOutlet weak var searchTxtField: UITextField!
    @IBOutlet weak var placesTV: UITableView!
    
    var airportStructArr : [AirportStruct]!
    var searchResultsArray = [AirportStruct]()
    
    var delegateVariable : FlightPlacesDelegate!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.placesTV.dataSource = self
        self.placesTV.delegate = self
        
        self.searchTxtField.delegate = self
        airportStructArr = airportStructArrGlobal
        
        self.searchTxtField.becomeFirstResponder()
        /*
        if let path = Bundle.main.path(forResource: "AirportList", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let jsonResult = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves)
                if let jsonResult = jsonResult as? Dictionary<String, AnyObject>
//                    , let person = jsonResult["person"] as? [Any]
                {
                    // do stuff
                    print("Airports Dict:",jsonResult)
                    
//                    let Arr = responce["data"] as! [[String:AnyObject]]
                    let airportArr = jsonResult["airports"] as! [[String:AnyObject]]
                    for aDict in airportArr {
                        var aAirportStructObj = AirportStruct()
                        aAirportStructObj.airportCode = "\(aDict["AirportCode"]!)"
                        aAirportStructObj.cityName = "\(aDict["CityName"]!)"
                        aAirportStructObj.countrySK = "\(aDict["Country_sK"]!)"
                        aAirportStructObj.countryName = "\(aDict["CountryName"]!)"
                        self.airportStructArr.append(aAirportStructObj)
                    }
                    
                }
            } catch {
                // handle error
                print("Error from catch - FlightPlacesVC")
            }
        } */
        
        
    
    
    }
    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
        NotificationCenter.default.addObserver(self, selector: #selector(self.textChangeNotification), name: NSNotification.Name.UITextFieldTextDidChange, object: nil)
    }
    @objc func textChangeNotification(_ notification : Notification){
        print("SearchTextField changed")
        self.placesTV.isHidden = false
        searchRecordsAsPerText(searchStr : searchTxtField.text!)
    }
    func searchRecordsAsPerText(searchStr: String) {
        
        searchResultsArray.removeAll()
        let Filtered = airportStructArr.filter({$0.cityName!.localizedCaseInsensitiveContains(searchStr)})
        searchResultsArray = Filtered
        
        if (searchStr == "") {
            placesTV.isHidden = true
        }
        else {
            if searchResultsArray.count == 0 {
                placesTV.isHidden = true
            }
            placesTV.isHidden = false
        }
        //        print(Filtered)
        
        
        placesTV.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
// MARK: - TextFieldDelegate {
extension FlightPlacesVC : UITextFieldDelegate{
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        if !placesTV.isHidden{
            placesTV.isHidden = true
        }
        textField.resignFirstResponder()
        return true
    }
}
// MARK: - }

//MARK: - TableViewDelegate {

//{"AirportCode":"CJB","CityName":"Coimbatore(CJB)","Country_sK":1.0,"CountryName":"India"}
extension FlightPlacesVC : UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchResultsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PlacesCellID", for: indexPath) as! PlacesCellClass
        cell.containerView.layer.cornerRadius = 5
        cell.containerView.clipsToBounds = true

        cell.cityNameLbl.text = searchResultsArray[indexPath.row].cityName
        cell.countryNameLbl.text = searchResultsArray[indexPath.row].countryName
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let cell : PlacesCellClass!
        
        cell = tableView.cellForRow(at: indexPath) as! PlacesCellClass
        print("Row:\(indexPath.row) selected and its data is \(cell.cityNameLbl.text!)")
        print("Row:\(indexPath.row) selected and its data is \(cell.countryNameLbl.text!)")
        print("Row:\(indexPath.row) selected and its data is :",searchResultsArray[indexPath.row].airportCode)
        print("Row:\(indexPath.row) selected and its data is :",searchResultsArray[indexPath.row].countrySK)
        
        self.placesTV.isHidden = true
        self.searchTxtField.text = ""
        searchTxtField.resignFirstResponder()
        
        delegateVariable.didSelectAirport(selectedAirportStruct: searchResultsArray[indexPath.row], controller: self)
        
    }
}
//MARK: - }
class PlacesCellClass : UITableViewCell {
    
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var cityNameLbl: UILabel!
    @IBOutlet weak var countryNameLbl: UILabel!
}
