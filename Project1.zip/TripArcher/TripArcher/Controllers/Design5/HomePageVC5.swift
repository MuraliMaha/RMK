//
//  HomePageVC5.swift
//  TripArcher
//
//  Created by APPLE on 26/12/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

class HomePageVC5: UIViewController {

    @IBOutlet weak var flightView: UIView!
    @IBOutlet weak var hotelView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        flightView.backgroundColor = UIColor.white
        flightView.layer.cornerRadius = 5
        flightView.clipsToBounds = true
        
        
        flightView.layer.masksToBounds = false
        flightView.layer.shadowColor = hexStringToUIColor(hex: "#AFCA1F").cgColor //UIColor.black.cgColor
        flightView.layer.shadowOpacity = 1
        flightView.layer.shadowOffset =  CGSize(width: 0, height: -2) // CGSize.zero  //
        flightView.layer.shadowRadius = 5
        
        flightView.layer.shadowPath = UIBezierPath(rect: flightView.bounds).cgPath
        flightView.layer.shouldRasterize = true
        flightView.layer.rasterizationScale = true ? UIScreen.main.scale : 1
        
        //        flightView.layer.shadowColor = UIColor.init
        
        
        hotelView.backgroundColor = UIColor.white
        hotelView.layer.cornerRadius = 5
        hotelView.clipsToBounds = true
        
        hotelView.layer.masksToBounds = false
        hotelView.layer.shadowColor = hexStringToUIColor(hex: "#AFCA1F").cgColor  // UIColor.black.cgColor
        hotelView.layer.shadowOpacity = 1
        hotelView.layer.shadowOffset =  CGSize(width: 0, height: -2)  //CGSize.zero //CGSize(width: -1, height: 1)
        hotelView.layer.shadowRadius = 5
        
        hotelView.layer.shadowPath = UIBezierPath(rect: hotelView.bounds).cgPath
        hotelView.layer.shouldRasterize = true
        hotelView.layer.rasterizationScale = true ? UIScreen.main.scale : 1 
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
