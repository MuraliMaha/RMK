//
//  WebService.swift
//  BMTC
//
//  Created by SunTelematics on 09/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class WebService {
    
    func callBMTCBookingAPI(Suffix:String, RestMethod: String = "POST",parameterDict: [String:String], securityKey:String, completion: @escaping (_ Data:JSON,_ Responcecode:ResponceCodes,_ IsSuccess:Bool) -> ()) {
        
        let theUrlString = WebServicesUrl.BMTCBookingBase + "/" + Suffix
        let theURL = URL(string: theUrlString)
        
        var mutableR = URLRequest.init(url: theURL!)
        mutableR.httpMethod = RestMethod
        mutableR.allHTTPHeaderFields = ["Content-Type":"application/json","AuthenticationToken":securityKey]
        
        
        if RestMethod == "GET" {
            
            var ParamsStr = ""
            
            for (key,value) in parameterDict {
                
                let param = key + "=" + value
                if ParamsStr == "" {
                    ParamsStr += param
                }
                else {
                    ParamsStr += "&" + param
                }
                
            }
            
            if ParamsStr != "" {
                mutableR.url = URL.init(string: theUrlString + "?" + ParamsStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!
            }
            
        }
        else {
            
            if let jsonObj = try? JSON(parameterDict).rawData() {
                mutableR.httpBody = jsonObj
            }
            else {
                completion([:],ResponceCodes.OtherError,false)
                return
            }
        }
        
        if !(Alamofire.NetworkReachabilityManager()?.isReachable)! {
            completion([:],ResponceCodes.NoInternet,false)
            return
        }
        
        mutableR.timeoutInterval = 35
        mutableR.allowsCellularAccess = true
        
        Alamofire.request(mutableR)
            .responseJSON { (DataResponce) in
                switch DataResponce.result {
                case .success(let value):
                    completion(JSON(value),ResponceCodes.success,true)
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    var responcecode = ResponceCodes.OtherError
                    if ((DataResponce.response?.statusCode) != nil) {
                        responcecode = (DataResponce.response?.statusCode)!.FetchError()
                    }
                    completion([:],responcecode,false)
                    break
                }
        }
        
    }

}
