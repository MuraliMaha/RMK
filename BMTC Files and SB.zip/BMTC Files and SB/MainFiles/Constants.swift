//
//  Constants.swift
//  BMTC
//
//  Created by SunTelematics on 08/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit

struct GOOGLEKeys {
    static let MainKey = "AIzaSyDZEFnAMTGOy9xwjwL1s3v3XTT0TRWRtwI"
}

struct Constants {
    static let NetErrorMsg = "please Check your Internet Connection. Turn on mobile data or use WiFi"
    static let InternalError = "Something went wrong..!"
}
struct WebServicesUrl
{
    
    static let BMTCBookingBase = "https://www.drivee.in/ShuttleApi"
    static let DummySecurity = "FC8AF7E9-CFE1-4C20-B0E4-18A812FBAE41"
    
    static let BMTCLogin = "Registration/Login"
    static let BMTCGetOtp = "Registration/GetOtp"
    static let BMTCRegisterUser = "Registration/New"
    static let BMTCUpdatePassword = "Registration/UpdatePassword"
    
    static let BMTCRouteDetails = "Route/Details"
    static let BMTCRouteTime = "Route/Time"
    
    static let BMTCBookingDetails = "Booking/Details"
    
}
struct StaticCredentials {

    static let VendorId = "1280"
    static let CorporateId = "10800"
    static let AppCustomerType = "2"
    
}
