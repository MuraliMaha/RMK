//
//  Structures_Enums.swift
//  BMTC
//
//  Created by SunTelematics on 09/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit

struct BMTCCredentials {
    var VendorId: String!
    var CorporateId: String!
    var AppCustomerType: String!
}
enum ResponceCodes {
    case success, authError, badRequest, requestTimeOut, internalServerError, serviceUnavailable, notFound, forbidden, OtherError, NoInternet
    
    func GetResponceCode() -> Int {
        var result: Int = 0
        switch self {
        case .success:
            result = 200
        case .authError:
            result = 401
        case .badRequest:
            result = 400
        case .requestTimeOut:
            result = 408
        case .internalServerError:
            result = 500
        case .serviceUnavailable:
            result = 503
        case .notFound:
            result = 404
        case .forbidden:
            result = 403
        case .NoInternet:
            result = 007
        case .OtherError:
            result = 0
        }
        return result
    }
}
