//
//  UtilitiesClass.h
//  DriveFindMyCab
//
//  Created by Raja Bhuma on 30/03/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
@import UIKit;
@import CoreLocation;
@import CoreText;

#pragma mark - LocationParser
#define LocationParserCity @"City"
#define LocationParserCountry @"Country"
#define LocationParserPincode @"Pincode"
#define LocationParserFullAddress @"FullAddress"
#define LocationParserLocation @"Location"

@interface UtilitiesClassSub : NSObject

+(NSDictionary *)GetLocationDetailsFromCLPlaceMark:(CLPlacemark *)placemark;
+(NSString *)RemoveLeadingandTralingSpace:(NSString *)string;
+(UIImage *)ReduceSizeOftheImage:(UIImage *)OriginalImage To:(CGSize)ToSize;
+(NSArray *)getLinesArrayOfStringInLabel:(UITextView *)textView;
+(UIColor *)colorFromHexString:(NSString *)hexString;
+(UIColor *)colorFromHexString:(NSString *)hexString Alpha:(CGFloat)Alpha;

@end
