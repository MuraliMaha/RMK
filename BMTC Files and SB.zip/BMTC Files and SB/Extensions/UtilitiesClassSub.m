//
//  UtilitiesClass.m
//  DriveFindMyCab
//
//   Created by Raja Bhuma on 30/03/17.

//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

#import "UtilitiesClassSub.h"

@implementation UtilitiesClassSub
+(NSDictionary *)GetLocationDetailsFromCLPlaceMark:(CLPlacemark *)placemark {
    
    NSString * CityStr = @"";
    NSString * CountryStr = @"";
    NSString * FullAddressStr = @"";
    NSString * LocationStr = @"";
    NSString * PincodeStr = @"";
    
    NSDictionary * placemarkAddressDict = placemark.addressDictionary;
    
    if ([[placemarkAddressDict allKeys] containsObject:@"City"]) {
        CityStr = [placemarkAddressDict valueForKey:@"City"];
    }
    else if ([[placemarkAddressDict allKeys] containsObject:@"SubAdministrativeArea"])
    {
        CityStr = [placemarkAddressDict valueForKey:@"SubAdministrativeArea"];
    }
    
    if ([[placemarkAddressDict allKeys] containsObject:@"Country"]) {
        CountryStr = [placemarkAddressDict valueForKey:@"Country"];
    }
    
    if ([[placemarkAddressDict allKeys] containsObject:@"ZIP"]) {
        PincodeStr = [placemarkAddressDict valueForKey:@"ZIP"];
    }
    
    if ([[placemarkAddressDict allKeys] containsObject:@"SubLocality"]) {
        LocationStr = [placemarkAddressDict valueForKey:@"SubLocality"];
    }
    else if ([[placemarkAddressDict allKeys] containsObject:@"Thoroughfare"])
    {
        LocationStr = [placemarkAddressDict valueForKey:@"Thoroughfare"];
    }
    else if ([[placemarkAddressDict allKeys] containsObject:@"Street"])
    {
        LocationStr = [placemarkAddressDict valueForKey:@"Street"];
    }
    
    for (NSString * Str in [placemarkAddressDict valueForKey:@"FormattedAddressLines"]) {
        if ([FullAddressStr isEqualToString:@""]) {
            FullAddressStr = Str;
        }
        else {
            FullAddressStr = [NSString stringWithFormat:@"%@, %@",FullAddressStr,Str];
        }
    }
    
    return @{LocationParserFullAddress:FullAddressStr,LocationParserCity:CityStr,LocationParserCountry:CountryStr,LocationParserPincode:PincodeStr,LocationParserLocation:LocationStr};
}
+(NSString *)RemoveLeadingandTralingSpace:(NSString *)string
{
    NSInteger i = 0;
    while ((i < [string length])
           && [[NSCharacterSet whitespaceAndNewlineCharacterSet] characterIsMember:[string characterAtIndex:i]])
    {
        i++;
    }
    NSString * newstr = [string substringFromIndex:i];
    NSInteger j = 0;
    while ((j < [newstr length])
           && [[NSCharacterSet whitespaceAndNewlineCharacterSet] characterIsMember:[newstr characterAtIndex:[newstr length]-(j+1)]])
    {
        j++;
    }
    NSString * newstr2 = [newstr substringToIndex:newstr.length-j];
    return newstr2;
}
+(UIImage *)ReduceSizeOftheImage:(UIImage *)OriginalImage To:(CGSize)ToSize {
    
    CGSize canvasSize = CGSizeMake(ToSize.width, (ToSize.width/OriginalImage.size.width) * OriginalImage.size.height);
    
    UIGraphicsBeginImageContextWithOptions(canvasSize, false, OriginalImage.scale);
    [OriginalImage drawInRect:CGRectMake(0, 0, canvasSize.width, canvasSize.height)];
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return img;
}
+(NSArray *)getLinesArrayOfStringInLabel:(UITextView *)textView
{
    NSString *text = [textView text];
    UIFont   *font = [textView font];
    CGRect    rect = [textView frame];
    
    CTFontRef myFont = CTFontCreateWithName(( CFStringRef)([font fontName]), [font pointSize], NULL);
    NSMutableAttributedString *attStr = [[NSMutableAttributedString alloc] initWithString:text];
    [attStr addAttribute:(NSString *)kCTFontAttributeName value:(__bridge  id)myFont range:NSMakeRange(0, attStr.length)];
    
    CFRelease(myFont);
    
    CTFramesetterRef frameSetter = CTFramesetterCreateWithAttributedString(( CFAttributedStringRef)attStr);
    
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathAddRect(path, NULL, CGRectMake(0,0,rect.size.width,100000));
    
    CTFrameRef frame = CTFramesetterCreateFrame(frameSetter, CFRangeMake(0, 0), path, NULL);
    
    NSArray *lines = ( NSArray *)CTFrameGetLines(frame);
    
    NSMutableArray *linesArray = [[NSMutableArray alloc]init];
    
    for (id line in lines)
    {
        CTLineRef lineRef = (__bridge  CTLineRef )line;
        CFRange lineRange = CTLineGetStringRange(lineRef);
        NSRange range = NSMakeRange(lineRange.location, lineRange.length);
        
        NSString *lineString = [text substringWithRange:range];
        
        CFAttributedStringSetAttribute((CFMutableAttributedStringRef)attStr, lineRange, kCTKernAttributeName, (CFTypeRef)([NSNumber numberWithFloat:0.0]));
        CFAttributedStringSetAttribute((CFMutableAttributedStringRef)attStr, lineRange, kCTKernAttributeName, (CFTypeRef)([NSNumber numberWithInt:0.0]));
        
        //NSLog(@"''''''''''''''''''%@",lineString);
        [linesArray addObject:lineString];
        
    }
    
    CGPathRelease(path);
    CFRelease( frame );
    CFRelease(frameSetter);
    
    
    return (NSArray *)linesArray;
}
+(UIColor *)colorFromHexString:(NSString *)hexString
{
    unsigned rgbValue = 0;
    NSScanner *scanner = [NSScanner scannerWithString:hexString];
    [scanner setScanLocation:1]; // bypass '#' character
    [scanner scanHexInt:&rgbValue];
    return [UIColor colorWithRed:((rgbValue & 0xFF0000) >> 16)/255.0 green:((rgbValue & 0xFF00) >> 8)/255.0 blue:(rgbValue & 0xFF)/255.0 alpha:1.0];
}
+(UIColor *)colorFromHexString:(NSString *)hexString Alpha:(CGFloat)Alpha {
    unsigned rgbValue = 0;
    NSScanner *scanner = [NSScanner scannerWithString:hexString];
    [scanner setScanLocation:1]; // bypass '#' character
    [scanner scanHexInt:&rgbValue];
    return [UIColor colorWithRed:((rgbValue & 0xFF0000) >> 16)/255.0 green:((rgbValue & 0xFF00) >> 8)/255.0 blue:(rgbValue & 0xFF)/255.0 alpha:Alpha];
}

@end
