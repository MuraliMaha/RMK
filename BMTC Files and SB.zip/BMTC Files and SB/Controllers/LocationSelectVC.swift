//
//  LocationSelectVC.swift
//  BMTC
//
//  Created by SunTelematics on 06/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import Alamofire

protocol LocationSelectDelegate {

    func DidCancelPicking(_ controller:LocationSelectVC)
    func DidSelect(_ FavObj:LocationsStruct,_ isfavorite:Bool,_ controller:LocationSelectVC)
    
    
}
class LocationSelectVC: UIViewController {

    var Delegate : LocationSelectDelegate!
    var SearchTable : UITableView!
    var SearchText: UITextField!
    
    var SearchResultsArr = [PlacesStruct]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ViewMakeWithSearch()
        
        SearchText.delegate = self
        SearchTable.estimatedRowHeight = 45
        SearchTable.rowHeight = UITableViewAutomaticDimension
        
        SearchTable.delegate = self
        SearchTable.dataSource = self
        SearchTable.reloadData()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func ViewMakeWithSearch() {
        
        let SearchView = UIView.init()
        SearchView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(SearchView)
        
        SearchTable = UITableView.init()
        SearchTable.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(SearchTable)
        
        
        let SelectPin = UIView.init()
        SelectPin.translatesAutoresizingMaskIntoConstraints = false
        SelectPin.backgroundColor = UIColor.white
  /*
        if isDrop {
            self.view.addSubview(SelectPin)
            
            SelectOnMapButton.translatesAutoresizingMaskIntoConstraints = false
            SelectOnMapButton.tintColor = UIColor.clear
            //            SelectOnMapButton.titleLabel?.textAlignment = .left
            SelectOnMapButton.contentHorizontalAlignment = .left
            
            SelectOnMapButton.setTitleColor(UIColor.black, for: .normal)
            SelectOnMapButton.setTitle("         Select Location On Map", for: .normal)
            SelectOnMapButton.backgroundColor = UIColor.white
            SelectOnMapButton.addTarget(self, action: #selector(SelectOnMapButtonAction(_:)), for: .touchUpInside)
            
            SelectPin.addSubview(SelectOnMapButton)
            
            let MapImg = UIImageView.init()
            MapImg.image = #imageLiteral(resourceName: "placeholder")
            MapImg.translatesAutoresizingMaskIntoConstraints = false
            MapImg.contentMode = .scaleAspectFit
            MapImg.backgroundColor = UIColor.clear
            SelectPin.addSubview(MapImg)
            
            let line = UIView.init()
            line.translatesAutoresizingMaskIntoConstraints = false
            line.backgroundColor = UIColor.init(hex: "AAAAAA", alpha: 0.5)
            SelectPin.addSubview(line)
            
            
            let InfoDict:[String:Any] = ["SelectOnMapButton":SelectOnMapButton,"line":line,"MapImg":MapImg]
            
            NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-6-[SelectOnMapButton]-6-|", options: .alignAllCenterX, metrics: nil, views: InfoDict))
            NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-12-[MapImg(30)]", options: .alignAllLeft, metrics: nil, views: InfoDict))
            NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[line]-0-|", options: .alignAllCenterX, metrics: nil, views: InfoDict))
            NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-6-[SelectOnMapButton]-6-[line(1)]-0-|", options: .alignAllCenterX, metrics: nil, views: InfoDict))
            NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-6-[MapImg(42)]", options: .alignAllCenterY, metrics: nil, views: InfoDict))
            
        }
*/
        let InfoDict:[String:Any] = ["SearchView":SearchView,"SearchTable":SearchTable,"SelectPin":SelectPin,"self":self.view]
        
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[SearchView]-0-|", options: .alignAllCenterX, metrics: nil, views: InfoDict))
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[SearchTable]-0-|", options: .alignAllCenterX, metrics: nil, views: InfoDict))
        
         NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[SearchView(75)]-4-[SearchTable]-4-|", options: .alignAllCenterX, metrics: nil, views: InfoDict))
        
        SearchTable.backgroundColor = UIColor.white
        SearchView.backgroundColor = UIColor.blue
        
        SearchTable.tableFooterView = UIView.init(frame: CGRect.zero)
        
        
        let BackButton = UIButton.init()
        BackButton.setImage(UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackBtn"), to: CGSize.init(width: 24, height: 24)), for: .normal)
        BackButton.tintColor = UIColor.clear
        BackButton.addTarget(self, action: #selector(BackAction), for: .touchUpInside)
        BackButton.backgroundColor = UIColor.clear
        
        BackButton.translatesAutoresizingMaskIntoConstraints = false
        
        SearchView.addSubview(BackButton)
        
        
        let searchTextView = UIView.init()
        searchTextView.translatesAutoresizingMaskIntoConstraints = false
        
        searchTextView.backgroundColor = UIColor.white
        searchTextView.layer.shadowColor = UIColor.white.cgColor
        searchTextView.layer.shadowOffset = CGSize.zero
        searchTextView.layer.shadowRadius = 2
        searchTextView.layer.shadowOpacity = 0.4
        
        searchTextView.layer.cornerRadius = 3
        
        SearchView.addSubview(searchTextView)
        
        let InfoDict2 = ["SearchView":SearchView,"BackButton":BackButton,"searchTextView":searchTextView]
        
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-2-[BackButton]-2-[searchTextView]-8-|", options: [], metrics: nil, views: InfoDict2))
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-31-[BackButton]-4-|", options: [], metrics: nil, views: InfoDict2))
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-31-[searchTextView]-4-|", options: [], metrics: nil, views: InfoDict2))
        
        NSLayoutConstraint(item: BackButton, attribute: .width, relatedBy: .equal, toItem: nil, attribute:.notAnAttribute, multiplier: 1, constant:40).isActive = true
        
        
        
        
        SearchText = UITextField.init()
        SearchText.backgroundColor = UIColor.clear
        SearchText.translatesAutoresizingMaskIntoConstraints = false
        SearchText.placeholder = "Search Location"
        SearchText.font = UIFont.systemFont(ofSize: 15)
        
        SearchText.returnKeyType = .search
        SearchText.autocorrectionType = .no
        //        SearchText.DoneBtn = true
        searchTextView.addSubview(SearchText)
        let InfoDict3 = ["SearchText":SearchText,"searchTextView":searchTextView]
        
        
        
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-4-[SearchText]-4-|", options: [], metrics: nil, views: InfoDict3))
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-8-[SearchText]-8-|", options: [], metrics: nil, views: InfoDict3))
        
        
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        //        toolBar.tintColor = UIColor(red: 76/255, green: 217/255, blue: 100/255, alpha: 1)
        toolBar.tintColor = UIColor.blue
        toolBar.sizeToFit()
        
//        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action:#selector(donePicker))
        
//        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.plain, target: self, action:#selector(cancelPicker))
        
//        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.setItems([cancelButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        toolBar.sizeToFit()
//        SearchText.delegate = self
        SearchText.inputAccessoryView = toolBar
        
        
        
        
        self.perform(#selector(footerview), with: self, afterDelay: 0.2)
    }
    @objc func footerview(){
        let footerview = UIView()
        footerview.frame = CGRect(x: 0, y: 0, width: SearchTable.frame.width, height: 45)
        footerview.backgroundColor = UIColor.clear
        
        let FooterImage     = UIImageView()
        FooterImage.frame   = CGRect(x: 0, y: 15, width: SearchTable.frame.width, height: 15)
        FooterImage.contentMode = .scaleAspectFit
        
        FooterImage.image   = #imageLiteral(resourceName: "pwdgoogle")
        footerview.addSubview(FooterImage)
        SearchTable.tableFooterView = footerview
        
//        fetchFavorites()
        SearchTable.reloadData()
    }
//    @objc func donePicker(sender : UIBarButtonItem){
//        var Struct = LocationsStruct()
//        Struct.Latitude = nil
//        Struct.Longitude = nil
//        Struct.Location = SearchText.text!
//        self.Delegate.DidSelect(Struct, false, self)
//
//    }
    
    @objc func cancelPicker(sender : UIBarButtonItem){
        SearchText.resignFirstResponder()
    }
    @objc func BackAction() {
        Delegate.DidCancelPicking(self)
    }
}


struct PlacesStruct {
    var ID:String!
    var Title:String!
    var lat:Double!
    var lon:Double!
    var isfromService:Bool = false
}
struct LocationsStruct {
    var Latitude: Double!
    var Longitude: Double!
    var Location: String!
}

extension LocationSelectVC : UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let currentString: NSString = NSString.init(string: textField.text!)
        let searchTxt =
            currentString.replacingCharacters(in: range, with: string)
        
        if searchTxt.count == 0 {
            SearchResultsArr.removeAll()
            self.SearchTable.reloadData()
        }
        
        else if searchTxt.count >= 3{
            
//            var UrlStr = "https://maps.googleapis.com/maps/api/place/autocomplete/json?" + "input=\(searchTxt.replacingOccurrences(of: " ", with: "+"))&sensor=true&key=AIzaSyDZEFnAMTGOy9xwjwL1s3v3XTT0TRWRtwI&components=country:IN"

            var UrlStr = "https://maps.googleapis.com/maps/api/place/autocomplete/json?" + "input=\(searchTxt.replacingOccurrences(of: " ", with: "+"))&sensor=true&key=\(GOOGLEKeys.MainKey)&components=country:IN"
            
            UrlStr = UrlStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
            
            let urlRequest  = URLRequest.init(url: URL.init(string: UrlStr)!)
            Alamofire.request(urlRequest)
                .responseJSON { (DataResponce) in
                    
                    print(DataResponce)
                    
                    switch DataResponce.result {
                    case .success(let value):
                        self.SearchResultsArr.removeAll()
                        
                        let val = value as! [String:AnyObject]
                        if let dataarr:[[String:AnyObject]] = val["predictions"] as? [[String:AnyObject]] {
                            if dataarr.count > 0{
                                for dataObj in dataarr {
                                    var structobj = PlacesStruct()
                                    structobj.Title = dataObj["description"] as! String
                                    structobj.ID = dataObj["place_id"] as! String
                                    self.SearchResultsArr.append(structobj)
                                }
                            }
                        }
                        self.SearchTable.reloadData()
                        break
                    case .failure(_):
                        self.SearchResultsArr.removeAll()
                        self.SearchTable.reloadData()
                        break
                    }
            }
        
        }
        
        return true
    }
    
}

extension LocationSelectVC : UITableViewDelegate , UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if SearchResultsArr.count == 0 {
            return 0
        }
        else {
            return SearchResultsArr.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
//        if SearchResultsArr.count == 0 {
//            let cell = FavTBCell()
//            cell.setupCell()
//            cell.Title.text = "\(FavoratesArr[indexPath.row].Location!)"
//            cell.selectionStyle = .none
//            return cell
//        }
//        else {
            let cell = LocSearchTBCell()
            cell.setupCell()
            cell.Title.text = "\(SearchResultsArr[indexPath.row].Title!)"
            cell.selectionStyle = .none
            return cell
//        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        LoadFromSearch(SearchResultsArr[indexPath.row])
    }
    
    //    get lat and lon using placeID in googleplace details API
    func LoadFromSearch(_ Place:PlacesStruct) {
        
        self.view.StartLoading()
        //        AIzaSyAE5UblSko0JCqUC05-bag8gjZFpTAicuA
        
        
        /*
        if Place.isfromService == true{
            var Struct = FavouritesLocationsStruct()
            Struct.Latitude = Place.lat!
            Struct.Longitude = Place.lon!
            Struct.Location = Place.Title!
            self.Delegate.DidSelect(Struct, false, self)
        }else{ */
        
        
        
//            var UrlStr = "https://maps.googleapis.com/maps/api/place/details/json?" + "placeid=\(Place.ID!)&key=AIzaSyDZEFnAMTGOy9xwjwL1s3v3XTT0TRWRtwI"
        var UrlStr = "https://maps.googleapis.com/maps/api/place/details/json?" + "placeid=\(Place.ID!)&key=\(GOOGLEKeys.MainKey)"
        
        
        
        
        
        //        gme-suntelematicsprivate
            UrlStr = UrlStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
            
            let urlRequest  = URLRequest.init(url: URL.init(string: UrlStr)!)
            Alamofire.request(urlRequest)
                .responseJSON { (DataResponce) in
                    
                    self.view.StopLoading()
                    print(DataResponce)
                    switch DataResponce.result {
                    case .success(let value):
                        
                        let val = value as! [String:AnyObject]
                        if let result:[String:AnyObject] = val["result"] as? [String:AnyObject] {
                            if let geometry:[String:AnyObject] = result["geometry"] as? [String:AnyObject] {
                                if let Location:[String:AnyObject] = geometry["location"] as? [String:AnyObject] {
                                    
                                    var Lat:Double = 0
                                    var Lon:Double = 0
                                    
                                    if let latitude = Location["lat"],
                                        (latitude is NSNumber || latitude is String) {
                                        Lat = Double("\(latitude)")!
                                    }
                                    if let longitude = Location["lng"],
                                        (longitude is NSNumber || longitude is String) {
                                        Lon = Double("\(longitude)")!
                                    }
                                    
                                    var Struct = LocationsStruct()
                                    Struct.Latitude = Lat
                                    Struct.Longitude = Lon
                                    Struct.Location = Place.Title!
                                    
                                    self.Delegate.DidSelect(Struct, false, self)
                                    
                                }
                            }
                        }
                        
                        break
                    case .failure(_):
                        self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                        break
                    }
                    
            }
//        }
    }

    

    
    
}
class LocSearchTBCell:UITableViewCell {
    
    var Title:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    func setupCell()
    {
        Title = UILabel.init()
        Title.translatesAutoresizingMaskIntoConstraints = false
        Title.numberOfLines = 6
        Title.textColor = UIColor.black
        Title.backgroundColor = UIColor.clear
        
        self.contentView.addSubview(Title)
        
        
        let InfoDict = ["Title":Title,"self":self.contentView]
        
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-8-[Title]-8-|", options: [], metrics: nil, views: InfoDict))
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-6-[Title]-6-|", options: [], metrics: nil, views: InfoDict))
        
        NSLayoutConstraint.init(item: Title, attribute: .height, relatedBy: .greaterThanOrEqual, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 40).isActive = true
        
    }
    
}
