//
//  PickupVC.swift
//  BMTC
//
//  Created by SunTelematics on 09/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import GoogleMaps

class PickupVC: UIViewController {

    var selectedPickup: LocationsStruct!
    @IBOutlet weak var pickupLocationLabel: UILabel!
    
    @IBOutlet weak var gMapView: GMSMapView!
    let LocationManager = CLLocationManager()
    
    var IsFirstTime = true
    var LoadGeoLocation = true
    var isZoomingAll = false
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.LocationManager.delegate = self
        self.LocationManager.requestWhenInUseAuthorization()
        
        self.gMapView.delegate = self
        
    }

    override func viewWillAppear(_ animated: Bool) {
        LocationManager.requestWhenInUseAuthorization()
        LocationManager.startUpdatingLocation()
        
        UIApplication.shared.statusBarStyle = UIStatusBarStyle.lightContent
        self.navigationController?.navigationBar.isHidden = false
        self.title = "Select Bus Stop"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}//Main end


// MARK : - CLLocation
extension PickupVC : CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse || status == .authorizedAlways {
            LocationManager.startUpdatingLocation()
        }
        else {
            ShowLocationDenied(controller: self)
        }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        if locations.count > 0 {
            
            let Location = locations.last!
            
            if IsFirstTime {
                IsFirstTime = false
                let Camera = GMSCameraPosition.camera(withLatitude: Location.coordinate.latitude, longitude: Location.coordinate.longitude, zoom: 17)
                //              RideLaterMap.camera = Camera
                gMapView.animate(to: Camera)
                self.pickupLocationLabel.superview?.lock()
            }
            
            CLGeocoder().reverseGeocodeLocation(locations.last!, completionHandler: { (Locations, error) in
                
                
                if error == nil {
                    //                    let Dict = UtilitiesClassSub.getLocationDetails(fromCLPlaceMark: Locations?.last!)
                    //                    if "\((Dict?[LocationParserCity]!)!)" != "" {
                    //                        self.CityName = "\((Dict?[LocationParserCity]!)!)"
                    //                    }
                    //                    else {
                    //
                    //                    }
                }
                else {
                    
                }
            })
            
        }
    }
}

//MARK: GMSMap
extension PickupVC : GMSMapViewDelegate {
    func mapView(_ mapView: GMSMapView, idleAt position: GMSCameraPosition) {
        if !isZoomingAll {
            if LoadGeoLocation {
                GeoLocationLoadOnMap(Position: position.target)
            }
        }
        else {
            isZoomingAll = false
        }
        
    }
    func GeoLocationLoadOnMap(Position:CLLocationCoordinate2D) {
        
        GMSGeocoder().reverseGeocodeCoordinate(Position) { (GeocodeResponce, error) in
            
            self.pickupLocationLabel.superview?.unlock()
            if error == nil {
                
                if GeocodeResponce != nil {
                    let address = GeocodeResponce?.results()?[0].lines
                    
                    var AddStr = ""
                    for add in address! {
                        
                        var AddFilterStr = ""
                        
                        if add == "Unnamed Road" {
                            // nothing to add
                        }
                        else {
                            if add.contains("Unnamed Road, ") {
                                AddFilterStr = add.replacingOccurrences(of: "Unnamed Road, ", with: "")
                            }
                            else {
                                AddFilterStr = add
                            }
                        }
                        if AddFilterStr != "" {
                            AddStr.append(AddFilterStr + ", ")
                        }
                    }
                    
                    if AddStr.isEmpty {
                        self.pickupLocationLabel.text = "No Address available"
                        self.selectedPickup = nil
                    }
                    else {
                        let addStr = AddStr.substring(to: AddStr.index(AddStr.endIndex, offsetBy: -2))
                        self.pickupLocationLabel.text = addStr
                        
                        self.selectedPickup = LocationsStruct()
                        self.selectedPickup.Location = addStr
                        self.selectedPickup.Latitude = Double("\(Position.latitude)")
                        self.selectedPickup.Longitude = Double("\(Position.longitude)")
                    }
                }
                else {
                    self.pickupLocationLabel.text = "Invalid Location"
                    self.selectedPickup = nil
                }
                
            }//if error == nil
            else {
                self.pickupLocationLabel.text = "Invalid Location"
                self.selectedPickup = nil
            }
            
        }
        
    }
    
}
