//
//  LocationSelectVC.swift
//  BMTC
//
//  Created by SunTelematics on 06/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit

class LeavingFromVC: UIViewController {

    
    @IBOutlet weak var searchLocationLabel: UILabel!
    @IBOutlet weak var busStopTV: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.isHidden = false
        UIApplication.shared.statusBarStyle = UIStatusBarStyle.lightContent
        self.title = "Leaving From"
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor : UIColor.white]
        self.navigationController?.navigationBar.barTintColor = UIColor.init(red: 4.0/255.0, green: 51.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        
//        self.searchLocationLabel.layer.cornerRadius = 5
        
        
        
        // Do any additional setup after loading the view.
        
        searchLocationLabel.isUserInteractionEnabled = true
        let tapPick = UITapGestureRecognizer.init(target: self, action: #selector(searchLocationLabelTapped))
        tapPick.numberOfTapsRequired = 1
        searchLocationLabel.addGestureRecognizer(tapPick)
        
    }

    @objc func searchLocationLabelTapped () {
        print("searchLocationLabel Tapped")
        
        let searchController = LocationSelectVC()
        searchController.Delegate = self
        self.present(searchController, animated: true, completion: nil)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func currentLocationBtnTapped(_ sender: UIButton) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension LeavingFromVC : LocationSelectDelegate {
    func DidSelect(_ FavObj: LocationsStruct, _ isfavorite: Bool, _ controller: LocationSelectVC) {
        controller.dismiss(animated: true, completion: nil)
        
        self.searchLocationLabel.text = FavObj.Location
        
    }
    
    func DidCancelPicking(_ controller: LocationSelectVC) {
        print("Cancel Tapped")
        controller.dismiss(animated: true, completion: nil)
    }
    
}
extension LeavingFromVC : UITableViewDelegate , UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BusStopsCellID", for: indexPath) as! BusStopsCellClass
        return cell
    }

}
class BusStopsCellClass : UITableViewCell {
    
    
}
