//
//  ViewController.swift
//  BMTC
//
//  Created by SunTelematics on 04/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit

class SplashScreenVC: UIViewController {

    var session : AppSessionInfo!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.backBarButtonItem?.title = " "
        self.navigationItem.leftBarButtonItem = UIBarButtonItem.init(title: " ", style: .done, target: nil, action: nil)
        
        self.perform(#selector(PerformAction), with: self, afterDelay: 0.4)
        
    }

    @objc func PerformAction () {
        session = AppSession.shared.getPocofySessionInfo()
        
        if session.isLoggedIn() {
            if (Reachability()?.isReachable)! {
                FetchLoginResponce()
            }
            else {
                Message.shared.Alert(Title: "NetworkAlert", Message: "Internet connection seems to be down. Please check and try again", TitleAlign: .left, MessageAlign: .left, Actions: [Message.AlertActionWithSelector(Title: "Close", Selector: #selector(DieTheApplication), Controller: self),Message.AlertActionWithSelector(Title: "Settings", Selector: #selector(GoToSettings), Controller: self)], Controller: self)
            } 
        }
        else {
            // Not Loggedin
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
            self.navigationController?.viewControllers = [ctrl]
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @objc func GoToSettings() {
        UIApplication.shared.openURL(URL.init(string: UIApplicationOpenSettingsURLString)!)
    }
    
    @objc func DieTheApplication() {
        exit(0)
    }
    @objc func retry(){
        FetchLoginResponce()
    }
    func GoToLogin() {
        let Login = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        self.navigationController?.viewControllers = [Login]
    }
    func FetchLoginResponce() {
    
        
        self.view.StartLoading()
        
        let Dict = ["UserName":session.getPhoneNo(),
                    "Password":session.getPassword(),
                    "Version":session.getVersion(),
                    "DeviceToken":session.getDeviceToken(),
                    "DeviceIMEINO":session.getIMEI(),
                    "DeviceType":session.getDeviceType(),
                    "VendorId":session.getVendorId(),
                    "CorporateId":session.getCorporateId(),
                    "AppType":session.getAppType()
        ]
        
        print("SplashVC-LogininInput = ",Dict)
        
        WebService().callBMTCBookingAPI(Suffix: WebServicesUrl.BMTCLogin, parameterDict: Dict, securityKey: WebServicesUrl.DummySecurity) { (responce, responcecode, success) in
            print("Splash - LoginResponse",responce,responcecode)
            self.view.StopLoading()
            
            if success {
                
                if responce["Status"].stringValue.toBool()! {
                    
                    self.session.setPhoneNo(phoneno: responce["MobileNo"].string ?? "NA")
                    self.session.setPassword(password: "\(Dict["Password"]!)")
                    self.session.setName(name: responce["Name"].string ?? "NA")
                    self.session.setCustomerId(customerid: responce["CustomerId"].string ?? "NA")
                    self.session.setEmail(email: responce["Email"].string ?? "NA")
                    self.session.setAuthKey(authkey: responce["AuthKey"].string ?? "NA")
                    self.session.setVendorId(vendorid: responce["VendorId"].string ?? "NA")
                    self.session.setCorporateId(corporateid: responce["CorporateId"].string ?? "NA")
                    self.session.setAppType(apptype: responce["AppType"].string ?? "NA")
                    
                    AppSession.shared.setPocofySessionInfo(AppSessionInfo: self.session)
                    
                    let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "ShuttleBookingVC") as! ShuttleBookingVC
                    self.navigationController?.viewControllers = [ctrl]
                    
                    
                }else{
                    Message.shared.Alert(Title: "Alert", Message: responce["Response"].stringValue, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                }
                
            }
            else {
                print("SplashScreenVC-LoginResponse failure =",responcecode.GetResponceCode())
                if responcecode == .authError{
                    self.GoToLogin()
                }else{
                    Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal , MessageAlign: .normal, Actions: [Message.AlertActionWithSelector(Title: "Close", Selector: #selector(self.DieTheApplication), Controller: self),Message.AlertActionWithSelector(Title: "Retry", Selector: #selector(self.retry), Controller: self)], Controller: self)
                }
            }
        }
        
    }

}

