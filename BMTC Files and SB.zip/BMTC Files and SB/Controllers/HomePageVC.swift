//
//  HomePageVC.swift
//  BMTC
//
//  Created by SunTelematics on 04/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import GoogleMaps
import Alamofire

class HomePageVC: UIViewController {

    @IBOutlet weak var gMapView: GMSMapView!
    
    @IBOutlet weak var pickupDropSelectionView: UIView!
    @IBOutlet weak var pickupSelectionLabel: UILabel!
    @IBOutlet weak var dropSelectionLabel: UILabel!
    
    let LocationManager = CLLocationManager()
    var IsFirstTime = true
    var LoadGeoLocation = true
    var isZoomingAll = false
    var PickUpLocation:LocationsStruct!
    
    
    
    @IBAction func logoutTapped(_ sender: UIButton) {
        let session = AppSession.shared.getPocofySessionInfo()
        session.reset()
        
        AppSession.shared.setPocofySessionInfo(AppSessionInfo: session)
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        self.navigationController?.viewControllers = [ctrl]
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        self.LocationManager.delegate = self
        self.LocationManager.requestWhenInUseAuthorization()
        
        
        
//        self.pickupDropSelectionView.layer.masksToBounds = false
//        self.pickupDropSelectionView.layer.shadowColor = UIColor.black.cgColor
//        self.pickupDropSelectionView.layer.shadowOpacity = 0.35
//        self.pickupDropSelectionView.layer.shadowOffset = CGSize.zero
//        self.pickupDropSelectionView.layer.shadowRadius = 2.5
//
//        self.pickupDropSelectionView.layer.shadowPath = UIBezierPath(rect: self.pickupDropSelectionView.bounds).cgPath
        
        self.InitializeLocationSelectionMarkers()
        
        UIApplication.shared.statusBarStyle = UIStatusBarStyle.lightContent
        
        
    }

    override func viewWillAppear(_ animated: Bool) {
        LocationManager.requestWhenInUseAuthorization()
        LocationManager.startUpdatingLocation()
        
        self.navigationController?.navigationBar.isHidden = false
        
//        self.title = "BMTC"
//        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "menu"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(MenuAction))
//        BackBtnItem.tintColor = UIColor.white
//        self.navigationItem.leftBarButtonItem = BackBtnItem
//        self.navigationController?.navigationItem.leftBarButtonItem = BackBtnItem
        
        
    }
  
    func InitializeLocationSelectionMarkers() {
        
        pickupSelectionLabel.isUserInteractionEnabled = true
        let tapPick = UITapGestureRecognizer.init(target: self, action: #selector(pickUpViewTapped))
        tapPick.numberOfTapsRequired = 1
        pickupSelectionLabel.addGestureRecognizer(tapPick)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func pickUpViewTapped () {
        print("pickUpView  Tapped")
        
//        let searchController = LocationSelectVC()
//        searchController.Delegate = self
//        self.present(searchController, animated: true, completion: nil)
        
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "PickupVC") as! PickupVC
//        ctrl.selectedPickup = self.PickUpLocation
        self.navigationController?.pushViewController(ctrl, animated: true)
        
        
    }

} // Main End





// MARK : - CLLocation
extension HomePageVC : CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse || status == .authorizedAlways {
            LocationManager.startUpdatingLocation()
        }
        else {
            ShowLocationDenied(controller: self)
        }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        if locations.count > 0 {
            
            let Location = locations.last!
            
            if IsFirstTime {
                IsFirstTime = false
                let Camera = GMSCameraPosition.camera(withLatitude: Location.coordinate.latitude, longitude: Location.coordinate.longitude, zoom: 17)
                //              RideLaterMap.camera = Camera
                gMapView.animate(to: Camera)
                self.pickupSelectionLabel.superview?.lock()
            }
            
            CLGeocoder().reverseGeocodeLocation(locations.last!, completionHandler: { (Locations, error) in
                
                
                if error == nil {
//                    let Dict = UtilitiesClassSub.getLocationDetails(fromCLPlaceMark: Locations?.last!)
//                    if "\((Dict?[LocationParserCity]!)!)" != "" {
//                        self.CityName = "\((Dict?[LocationParserCity]!)!)"
//                    }
//                    else {
//
//                    }
                }
                else {
                    
                }
            })
            
        }
    }
}

//MARK: GMSMap
extension HomePageVC : GMSMapViewDelegate {
    func mapView(_ mapView: GMSMapView, idleAt position: GMSCameraPosition) {
        if !isZoomingAll {
            if LoadGeoLocation {
                GeoLocationLoadOnMap(Position: position.target)
            }
        }
        else {
            isZoomingAll = false
        }
        
    }
    func GeoLocationLoadOnMap(Position:CLLocationCoordinate2D) {
        
        GMSGeocoder().reverseGeocodeCoordinate(Position) { (GeocodeResponce, error) in
            
            self.pickupSelectionLabel.superview?.unlock()
            if error == nil {
                
                if GeocodeResponce != nil {
                    let address = GeocodeResponce?.results()?[0].lines
                    
                    var AddStr = ""
                    for add in address! {
                        
                        var AddFilterStr = ""
                        
                        if add == "Unnamed Road" {
                            // nothing to add
                        }
                        else {
                            if add.contains("Unnamed Road, ") {
                                AddFilterStr = add.replacingOccurrences(of: "Unnamed Road, ", with: "")
                            }
                            else {
                                AddFilterStr = add
                            }
                        }
                        if AddFilterStr != "" {
                            AddStr.append(AddFilterStr + ", ")
                        }
                    }
                    
                    if AddStr.isEmpty {
                        self.pickupSelectionLabel.text = "No Address available"
                        self.PickUpLocation = nil
                    }
                    else {
                        let addStr = AddStr.substring(to: AddStr.index(AddStr.endIndex, offsetBy: -2))
                        self.pickupSelectionLabel.text = addStr
                        
                        self.PickUpLocation = LocationsStruct()
                        self.PickUpLocation.Location = addStr
                        self.PickUpLocation.Latitude = Double("\(Position.latitude)")
                        self.PickUpLocation.Longitude = Double("\(Position.longitude)")
                    }
                }
                else {
                    self.pickupSelectionLabel.text = "Invalid Location"
                    self.PickUpLocation = nil
                }
                
            }//if error == nil
            else {
                self.pickupSelectionLabel.text = "Invalid Location"
                self.PickUpLocation = nil
            }
            
        }
        
    }

}
