//
//  SeatingLayoutConstants.swift
//  SeatingLayout
//
//  Created by Raja Bhuma on 21/12/17.
//  Copyright © 2017 Check. All rights reserved.
//

import UIKit

public struct SeatingLayoutConstants {
    static let EmptySeat = "E"
    static let BookedByLadies = "L"
    static let Booked = "B"
    static let CurrentBooking = "S"
    static let EmptySpace = "_"
}

enum BookingType {
    case emptySpace, notBooked, booked, bookedbyLadies, reservedForLadies, currentBooking
    
    static func setBookingType(typeString: String, leftType: String, rightType: String) -> BookingType {
        
        if typeString == SeatingLayoutConstants.Booked {
            return .booked
        }
        
        if typeString == SeatingLayoutConstants.BookedByLadies {
            return .bookedbyLadies
        }
        
        if typeString == SeatingLayoutConstants.EmptySeat {
            
            if leftType == SeatingLayoutConstants.BookedByLadies || rightType == SeatingLayoutConstants.BookedByLadies {
                return .reservedForLadies
            }
            else {
                return .notBooked
            }
        }
        
        return .emptySpace
    }
    
    func getType() -> String {
        switch self {
        case .booked:
            return SeatingLayoutConstants.Booked
        case .bookedbyLadies:
            return SeatingLayoutConstants.BookedByLadies
        case .currentBooking:
            return SeatingLayoutConstants.CurrentBooking
        case .emptySpace:
            return SeatingLayoutConstants.EmptySpace
        case .notBooked:
            return SeatingLayoutConstants.EmptySeat
        case .reservedForLadies:
            return SeatingLayoutConstants.EmptySeat
        }
    }
}
