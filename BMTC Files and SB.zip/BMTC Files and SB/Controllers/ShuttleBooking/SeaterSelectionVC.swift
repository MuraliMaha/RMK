//
//  SeaterSelectionVC.swift
//  BMTC
//
//  Created by Raja Bhuma on 11/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit

class SeaterSelectionVC: UIViewController {

    @IBOutlet var SeatingCV: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()

        print(LayoutVisualFormat,"\n\n",LayoutVisualFormat.split(separator: "\n"))
        Implement()
        SeatingCV.tableFooterView = UIView.init(frame: .zero)
        
        SeatingCV.superview?.layer.borderWidth = 1
        SeatingCV.superview?.layer.borderColor = UIColor.lightGray.cgColor
        
        
        self.navigationItem.title = "Seating Confirmation"
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    var LayoutVisualFormat = """
                            L__EE
                            EE_BE
                            EE_EE
                            BE_EL
                            EE_EE
                            EE_EE
                            LE_BE
                            EE_EL
                            BE_EE
                            EE_EE
                            EE_EE
                            LB_EE
                            """
    
    var Seats = [[BookingType]]()
    
    func Implement() {
        var seatsArr = [[BookingType]]()
        for Seat in LayoutVisualFormat.split(separator: "\n") {
            
            let SeatBatch = String(Seat)
            
            let BatchArr = Givecharecters(chars: SeatBatch)
            
            var MainSeaterArr = [BookingType]()
            
            for (index,Char) in BatchArr.enumerated() {
                
                if index == 0 { // EE_EE
                    
                    let rightObj = BatchArr[index+1]
                    
                    MainSeaterArr.append(BookingType.setBookingType(typeString: Char, leftType: SeatingLayoutConstants.EmptySpace, rightType: rightObj))
                }
                else if index == BatchArr.count - 1 {
                    let leftObj = BatchArr[index-1]
                    
                    MainSeaterArr.append(BookingType.setBookingType(typeString: Char, leftType: leftObj, rightType: SeatingLayoutConstants.EmptySpace))
                }
                else {
                    let leftObj = BatchArr[index-1]
                    let rightObj = BatchArr[index+1]
                    MainSeaterArr.append(BookingType.setBookingType(typeString: Char, leftType: leftObj, rightType: rightObj))
                }
            }
            
            seatsArr.append(MainSeaterArr)
        }
        
        Seats = seatsArr
    }
    
    func Givecharecters(chars: String) -> [String] {
        var charArr = [String]()
        
        for str in chars {
            charArr.append(String.init(str))
        }
        
        return charArr
    }
}


extension SeaterSelectionVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Seats.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SeatingTVCell", for: indexPath) as! SeatingTVCell
        cell.nController = self
        cell.index = indexPath.row
        cell.SetUI(seats: Seats[indexPath.row])
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return (250 - 16) / CGFloat(Seats[indexPath.row].count)
    }
    
}



class SeatingCollection: UICollectionViewCell {
    
    @IBOutlet var SeatingImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
}

class SeatingTVCell: UITableViewCell, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout  {
    
    @IBOutlet var SeatingCV: UICollectionView!
    
    var nController: SeaterSelectionVC!
    var index = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    var SeatsinRow = [BookingType]()
    
    func SetUI(seats: [BookingType]) {
        SeatingCV.delegate = self
        SeatingCV.dataSource = self
        SeatsinRow = seats
        SeatingCV.reloadData()
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return SeatsinRow.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SeatingCollection", for: indexPath) as! SeatingCollection
        cell.SeatingImage.isHidden = false
        switch SeatsinRow[indexPath.row] {
        case .booked:
            cell.SeatingImage.image = #imageLiteral(resourceName: "BookedForMen")
            break
        case .bookedbyLadies:
            cell.SeatingImage.image = #imageLiteral(resourceName: "BookedforWomen")
            break
        case .currentBooking:
            cell.SeatingImage.image = #imageLiteral(resourceName: "BookingSeat")
            break
        case .emptySpace:
            cell.SeatingImage.isHidden = true
            break
        case .notBooked:
            cell.SeatingImage.image = #imageLiteral(resourceName: "EmptySeat")
            break
        case .reservedForLadies:
            cell.SeatingImage.image = #imageLiteral(resourceName: "ReservedForLadies")
            break
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let height = CGFloat(250-16) / CGFloat(SeatsinRow.count)
        return CGSize.init(width: height, height: height)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if SeatsinRow[indexPath.row] == .booked || SeatsinRow[indexPath.row] == .bookedbyLadies || SeatsinRow[indexPath.row] == .emptySpace {
            return
        }
        
        if SeatsinRow[indexPath.row] == .currentBooking {
            
            if indexPath.row == 0 {
                
                let rightObj = SeatsinRow[indexPath.row+1].getType()
                
                nController.Seats[index][indexPath.row] = BookingType.setBookingType(typeString: SeatingLayoutConstants.EmptySeat, leftType: SeatingLayoutConstants.EmptySpace, rightType: rightObj)
                
            }
            else if indexPath.row == SeatsinRow.count - 1 {
                
                let leftObj = SeatsinRow[indexPath.row-1].getType()
                
                nController.Seats[index][indexPath.row] = BookingType.setBookingType(typeString: SeatingLayoutConstants.EmptySeat, leftType: leftObj, rightType: SeatingLayoutConstants.EmptySpace)
                
            }
            else {
                
                let leftObj = SeatsinRow[indexPath.row-1].getType()
                let rightObj = SeatsinRow[indexPath.row+1].getType()
                
                nController.Seats[index][indexPath.row] = BookingType.setBookingType(typeString: SeatingLayoutConstants.EmptySeat, leftType: leftObj, rightType: rightObj)
                
            }
            
        }
        else {
            nController.Seats[index][indexPath.row] = BookingType.currentBooking
        }
        
        nController.SeatingCV.reloadRows(at: [IndexPath.init(row: index, section: 0)], with: .none)
    }
}
