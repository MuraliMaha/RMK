//
//  ShuttleBookingVC.swift
//  BMTC
//
//  Created by Raja Bhuma on 10/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import GooglePlaces
import GooglePlacePicker

class ShuttleBookingVC: UIViewController {

    @IBOutlet var FromLocationView: UIView!
    @IBOutlet var FromLocationText: UITextField!

    @IBOutlet var ToLocationView: UIView!
    @IBOutlet var ToLocationText: UITextField!
    
    @IBOutlet var DatePickingView: UIView!
    @IBOutlet var DatePickingTxt: UITextField!

    @IBOutlet var ShuttleCustomTable: UITableView!

    @IBOutlet var FindMyShuttleBtnView: UIView!

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationController?.navigationBar.isHidden = false

        ShuttleCustomTable.tableFooterView = UIView.init(frame: CGRect.zero)
        
        
        self.navigationItem.backBarButtonItem?.title = " "
        
        AddDatePicker()
        
        self.DatePickingTxt.attributedText = DateConversion()
    }
    
    func DateConversion(date: Date = Date()) -> NSAttributedString {
        let dateformat = DateFormatter()
        dateformat.dateFormat = "yyyy-MM-dd"
        let dateStr = dateformat.string(from: date)
        
        let attStr = NSAttributedString.init(string: dateStr, attributes: [NSAttributedStringKey.underlineColor : UIColor.black, NSAttributedStringKey.underlineStyle: NSUnderlineStyle.styleSingle.rawValue])
        
        return attStr
    }
    
    var DatePicker: UIDatePicker!
    
    func AddDatePicker() {
        
        DatePicker = UIDatePicker()
        DatePicker.minimumDate = Date()
        DatePicker.date = Date()
        
        DatePicker.datePickerMode = .date
        
        DatePicker.backgroundColor = UIColor.white
        
        let toolbar = UIToolbar()
        toolbar.tintColor = UIColor.white
        toolbar.barStyle = UIBarStyle.default
        toolbar.barTintColor = UIColor.darkGray
        toolbar.isTranslucent = false
        toolbar.sizeToFit()
        
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: #selector(DonePressed))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)

        toolbar.setItems([ spaceButton, doneButton], animated: false)
        toolbar.isUserInteractionEnabled = true
        
        
        self.DatePickingTxt.inputView = DatePicker
        self.DatePickingTxt.inputAccessoryView = toolbar

    }
    
    @objc func DonePressed() {
        self.view.endEditing(true)
        self.DatePickingTxt.attributedText = DateConversion(date: DatePicker.date)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    var fromLocationDetails: (title: String, address: String, lat: String, lng: String)?
    var toLocationDetails: (title: String, address: String, lat: String, lng: String)?

    
    var FromRouteDetails = [RouteDetails]()
    
    var fromSelectedIndex: Int!
    
    var TORouteDetails = [RouteDetails]()

    var toSelectedIndex: Int!
    
    
    func GetRouteDetails(isFrom: Bool) {
        
        let session = AppSession.shared.getPocofySessionInfo()

        if isFrom {
            
            let routeDetailsRequest = ["CustId":session.getCustomerId(),
                                      "AreaId":"0",
                                      "AreaLat":(fromLocationDetails?.lat)!,
                                      "AreaLon":(fromLocationDetails?.lng)!,
                                      "ShiftType":"1"]
            WebService().callBMTCBookingAPI(Suffix: WebServicesUrl.BMTCRouteDetails, parameterDict: routeDetailsRequest, securityKey: session.getAuthKey(), completion: { (response, statusCode, success) in
                if success {
                    print(response)
                    
                    self.FromRouteDetails.removeAll()
                    
                    if response["Status"].stringValue.toBool()! {
                        if let routeDetails = response["RouteDetails"].array {
                            for routeObj in routeDetails {
                                var route = RouteDetails()
                                route.AreaId = routeObj["AreaId"].stringValue
                                route.AreaName = routeObj["AreaName"].stringValue
                                route.Lat = Double(routeObj["Lat"].stringValue)!
                                route.Lon = Double(routeObj["Lon"].stringValue)!
                                route.Distance = routeObj["Distance"].stringValue
                                route.ETA = routeObj["ETA"].stringValue
                                self.FromRouteDetails.append(route)
                            }
                        }
                        else {
                            print("error")
                        }
                    }
                    else {
                        print("error")
                    }
                    
                    self.ShuttleCustomTable.reloadData()
                }
                else {
                    print("error")
                    if statusCode == .NoInternet {
                        
                    }
                    else {
                        
                    }
                }
            })
            
        }
        else {
            let routeDetailsRequest = ["CustId":session.getCustomerId(),
                                       "AreaId":FromRouteDetails[fromSelectedIndex!].AreaId,
                                       "AreaLat":(toLocationDetails?.lat)!,
                                       "AreaLon":(toLocationDetails?.lng)!,
                                       "ShiftType":"2"]
            
            WebService().callBMTCBookingAPI(Suffix: WebServicesUrl.BMTCRouteDetails, parameterDict: routeDetailsRequest, securityKey: session.getAuthKey(), completion: { (response, statusCode, success) in
                if success {
                    print(response)
                    self.TORouteDetails.removeAll()
                    
                    if response["Status"].stringValue.toBool()! {
                        if let routeDetails = response["RouteDetails"].array {
                            for routeObj in routeDetails {
                                var route = RouteDetails()
                                route.AreaId = routeObj["AreaId"].stringValue
                                route.AreaName = routeObj["AreaName"].stringValue
                                route.Lat = Double(routeObj["Lat"].stringValue)!
                                route.Lon = Double(routeObj["Lon"].stringValue)!
                                route.Distance = routeObj["Distance"].stringValue
                                route.ETA = routeObj["ETA"].stringValue
                                self.TORouteDetails.append(route)
                            }
                        }
                        else {
                            print("error")
                        }
                    }
                    else {
                        print("error")
                    }
                    
                    self.ShuttleCustomTable.reloadData()
                }
                else {
                    print("error")
                    if statusCode == .NoInternet {
                        
                    }
                    else {
                        
                    }
                }
            })
        }
        
       
    }
    
    
    
    @IBAction func FindMyShuttleBtnPressed(_ sender: UIButton) {
        
        self.view.endEditing(true)
        
        if (FromLocationText.text?.isEmpty)! {
         
            return
        }
        
        if (ToLocationText.text?.isEmpty)! {
            
            return
        }
        
        if fromSelectedIndex == nil {
            
            return
        }
        
        if toSelectedIndex == nil {
            
            return
        }
        
        let session = AppSession.shared.getPocofySessionInfo()

        let TimingParameters = ["CustId":session.getCustomerId(),
                                "StartTime":(self.DatePickingTxt.attributedText?.string)!,
                                "StartAreaId":FromRouteDetails[fromSelectedIndex!].AreaId,
                                "EndAreaId":TORouteDetails[toSelectedIndex!].AreaId]

        self.view.StartLoading()
        WebService().callBMTCBookingAPI(Suffix: WebServicesUrl.BMTCRouteTime, parameterDict: TimingParameters, securityKey: session.getAuthKey()) { (jsonData, statusCode, success) in
            
            self.view.StopLoading()

            if success {
                print(jsonData)
                
                if jsonData["Status"].stringValue.toBool()! {
                    
                    var routeTimingsArr = [RouteTimingModel]()
                    
                    if let routes = jsonData["Timings"].array {
                        for route in routes {
                            var timing = RouteTimingModel()
                            timing.ShiftTime = route["ShiftTime"].stringValue
                            timing.AvailableSeats = route["AvailableSeats"].stringValue
                            timing.PickUpTime = route["PickUpTime"].stringValue
                            timing.SeatingPattern = route["SeatingPattern"].stringValue
                            timing.RouteName = route["RouteName"].stringValue
                            timing.SeatSelectionStatus = route["SeatSelectionStatus"].stringValue
                            timing.Id = route["Id"].stringValue
                            routeTimingsArr.append(timing)
                        }
                    }
                    
                    if routeTimingsArr.count > 0 {
                        // call next
                        
                        let controller = self.storyboard?.instantiateViewController(withIdentifier: "RouteConfirmationVC") as! RouteConfirmationVC
                        controller.routeTimingsArr = routeTimingsArr
                        controller.FromRouteDetails = self.FromRouteDetails[self.fromSelectedIndex!]
                        controller.ToRouteDetails = self.TORouteDetails[self.toSelectedIndex!]
                        controller.fromLocationDetails = self.fromLocationDetails!
                        controller.toLocationDetails = self.toLocationDetails!
                        self.navigationController?.pushViewController(controller, animated: true)
                        
                    }
                    else {
                        print("error")
                    }
                    
                }
                else {
                    print("error")
                }
            }
            else {
                print("error")
                if statusCode == .NoInternet {
                    
                }
                else {
                    
                }
            }
        }
    }
    
}


extension ShuttleBookingVC: UITextFieldDelegate, PlacesAutoCompletionDelegate, GMSAutocompleteViewControllerDelegate {
    
    func DidSelectLocation(title: String, address: String, lat: Double, lon: Double, controller: LocationAutoCompletionVC) {
        controller.dismiss(animated: true, completion: nil)
        print(title,address,lat,lon, separator: ",", terminator: "#\n")
    }
    
    func DidCancel(controller: LocationAutoCompletionVC) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        if textField == self.FromLocationText {
            
            let AutoPicker = GMSAutocompleteViewController()
            AutoPicker.delegate = self
            AutoPicker.view.tag = 200
            self.present(AutoPicker, animated: true, completion: nil)
        }
        
        if textField == self.ToLocationText {
            
            if fromSelectedIndex == nil {
                Message.shared.Alert(Title: "Alert", Message: "Please select from Stop", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return false
            }
            
            let AutoPicker = GMSAutocompleteViewController()
            AutoPicker.delegate = self
            AutoPicker.view.tag = 400
            self.present(AutoPicker, animated: true, completion: nil)
            
        }
        
        if textField == self.DatePickingTxt {
            return true
        }
        
//        let controller = self.storyboard?.instantiateViewController(withIdentifier: "LocationAutoCompletionVC") as! LocationAutoCompletionVC
//        controller.autoCompleteDelegate = self
//        self.present(controller, animated: true, completion: nil)
        
        return false
    }
    
    func viewController(_ viewController: GMSAutocompleteViewController, didAutocompleteWith place: GMSPlace) {
        dismiss(animated: true, completion: nil)
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
        
        if viewController.view.tag == 200 {
            fromLocationDetails = (title: place.name, address: place.formattedAddress!, lat: "\(place.coordinate.latitude)", lng: "\(place.coordinate.longitude)")
            
            fromSelectedIndex = nil
            FromRouteDetails.removeAll()
            TORouteDetails.removeAll()
            ToLocationText.text = ""
            toLocationDetails = nil
            toSelectedIndex = nil
            self.FromLocationText.text = (fromLocationDetails?.title)!
            GetRouteDetails(isFrom: true)
        }
        else {
            TORouteDetails.removeAll()
            toSelectedIndex = nil
            toLocationDetails = (title: place.name, address: place.formattedAddress!, lat: "\(place.coordinate.latitude)", lng: "\(place.coordinate.longitude)")
            self.ToLocationText.text = (toLocationDetails?.title)!
            GetRouteDetails(isFrom: false)
        }
    }
    
    func viewController(_ viewController: GMSAutocompleteViewController, didFailAutocompleteWithError error: Error) {
        // TODO: handle the error.
        print("Error: ", error.localizedDescription)
    }
    
    // User canceled the operation.
    func wasCancelled(_ viewController: GMSAutocompleteViewController) {
        dismiss(animated: true, completion: nil)
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }
    
    // Turn the network activity indicator on and off again.
    func didRequestAutocompletePredictions(_ viewController: GMSAutocompleteViewController) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
    }
    
    func didUpdateAutocompletePredictions(_ viewController: GMSAutocompleteViewController) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
    }
}

extension ShuttleBookingVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        switch section {
        case 0:
            return FromLocationView
        case 1:
            return ToLocationView
        case 2:
            return DatePickingView
        default:
            return nil
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        switch section {
        case 0:
            return 50
        case 1:
            return 50
        case 2:
            return 80
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        switch section {
        case 0:
            return nil
        case 1:
            return nil
        case 2:
            return FindMyShuttleBtnView
        default:
            return nil
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        switch section {
        case 0:
            return 0
        case 1:
            return 0
        case 2:
            return 45
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            
            if FromRouteDetails.count > 0 {
                return FromRouteDetails.count + 1
            }
            return 0
        case 1:
            if TORouteDetails.count > 0 {
                return TORouteDetails.count + 1
            }
            return 0
        case 2:
            return 0
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.section {
        case 0:
            
            if indexPath.row == 0 {
                let cell = UITableViewCell()
                cell.textLabel?.text = "Choose a pick-up spot"
                cell.textLabel?.font = UIFont.systemFont(ofSize: 14)
                return cell
            }
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "BusStopSelectionCell", for: indexPath) as! BusStopSelectionCell
            
            cell.busStopName.text = FromRouteDetails[indexPath.row - 1].AreaName
            cell.duration.text = FromRouteDetails[indexPath.row - 1].ETA

            cell.navigationimage.superview?.isHidden = false

            if let selectedindex = fromSelectedIndex {
                if selectedindex == indexPath.row - 1 {
                    cell.navigationimage.image = #imageLiteral(resourceName: "ic_navigation_selected")
                    cell.checkmarkimage.image = #imageLiteral(resourceName: "ic_checkmark_fill")
                }
                else {
                    cell.navigationimage.image = #imageLiteral(resourceName: "ic_navigation_unselected")
                    cell.checkmarkimage.image = #imageLiteral(resourceName: "ic_checkmark_empty")
                }
            }
            else {
                cell.navigationimage.image = #imageLiteral(resourceName: "ic_navigation_unselected")
                cell.checkmarkimage.image = #imageLiteral(resourceName: "ic_checkmark_empty")
            }
            
//            cell.checkmarkBtn.tag = indexPath.row - 1
//            cell.checkmarkBtn.addTarget(self, action: #selector(FromCheckMarkSelection(sender:)), for: .touchUpInside)
            
            cell.selectionStyle = .none

            return cell
            
        case 1:
            
            if indexPath.row == 0 {
                let cell = UITableViewCell()
                cell.textLabel?.text = "Choose a drop spot"
                cell.textLabel?.font = UIFont.systemFont(ofSize: 14)
                return cell
            }
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "BusStopSelectionCell", for: indexPath) as! BusStopSelectionCell
            
            cell.busStopName.text = TORouteDetails[indexPath.row - 1].AreaName
            cell.duration.text = TORouteDetails[indexPath.row - 1].ETA
            
            cell.navigationimage.superview?.isHidden = true
            
            if let selectedindex = toSelectedIndex {
                if selectedindex == indexPath.row - 1 {
                    cell.navigationimage.image = #imageLiteral(resourceName: "ic_navigation_selected")
                    cell.checkmarkimage.image = #imageLiteral(resourceName: "ic_checkmark_fill")
                }
                else {
                    cell.navigationimage.image = #imageLiteral(resourceName: "ic_navigation_unselected")
                    cell.checkmarkimage.image = #imageLiteral(resourceName: "ic_checkmark_empty")
                }
            }
            else {
                cell.navigationimage.image = #imageLiteral(resourceName: "ic_navigation_unselected")
                cell.checkmarkimage.image = #imageLiteral(resourceName: "ic_checkmark_empty")
            }
//            cell.checkmarkBtn.tag = indexPath.row - 1
//            cell.checkmarkBtn.addTarget(self, action: #selector(ToCheckMarkSelection(sender:)), for: .touchUpInside)
            
            cell.selectionStyle = .none
            
            return cell
            
        default:
            return UITableViewCell()
        }
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.section == 0 {
            
            if indexPath.row == 0 {
                return
            }
            
            fromSelectedIndex = indexPath.row - 1
            toSelectedIndex = nil
            TORouteDetails.removeAll()
            toLocationDetails = nil
            ToLocationText.text = ""
            self.ShuttleCustomTable.reloadData()
        }
        else {
            if indexPath.row == 0 {
                return
            }
            toSelectedIndex = indexPath.row - 1
            self.ShuttleCustomTable.reloadData()
        }
    }
}

class BusStopSelectionCell: UITableViewCell {
    
    @IBOutlet var busStopName: UILabel!
    @IBOutlet var duration: UILabel!
    @IBOutlet var navigationimage: UIImageView!
    @IBOutlet var checkmarkimage: UIImageView!
    @IBOutlet var checkmarkBtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}


struct RouteDetails {
    var AreaId = ""
    var AreaName = ""
    var Lat = 0.0
    var Lon = 0.0
    var Distance = ""
    var ETA = ""
}
