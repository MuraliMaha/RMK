//
//  RouteConfirmationVC.swift
//  BMTC
//
//  Created by Raja Bhuma on 11/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit

class RouteConfirmationVC: UIViewController {

    @IBOutlet var RouteSelectionCV: UICollectionView!
    
    
    @IBOutlet var FromLocationTxt: UITextField!
    @IBOutlet var ToLocationTxt: UITextField!

    @IBOutlet var FromRouteName: UILabel!
    @IBOutlet var ToRouteName: UILabel!
    
    @IBOutlet var FromRouteTime: UILabel!

    
    var routeTimingsArr = [RouteTimingModel]()
    
    var fromLocationDetails: (title: String, address: String, lat: String, lng: String)?
    var toLocationDetails: (title: String, address: String, lat: String, lng: String)?
    
    var FromRouteDetails: RouteDetails!
    var ToRouteDetails: RouteDetails!

    var selectedRouteTiming = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.FromLocationTxt.text = (fromLocationDetails?.title)!
        self.ToLocationTxt.text = (toLocationDetails?.title)!

        self.FromRouteName.text = FromRouteDetails.AreaName
        self.ToRouteName.text = ToRouteDetails.AreaName

        self.FromRouteTime.text = FromRouteDetails.ETA
        
        if let flowLayout = self.RouteSelectionCV.collectionViewLayout as? UICollectionViewFlowLayout {
            flowLayout.estimatedItemSize = CGSize.init(width: 90, height: 85)
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBOutlet var PassengerDetailsView: UIView!

    @IBOutlet var BookForMeBtn: UIButton!
    @IBOutlet var BookForOthersBtn: UIButton!

    @IBAction func BookForMe_OtherBtnActions(sender: UIButton) {
        if sender == BookForMeBtn {
            if BookForMeBtn.isSelected {
                
            }
            else {
                
            }
        }
        else {
            if BookForMeBtn.isSelected {
                
            }
            else {
                
            }
        }
        
    }
    
}

extension RouteConfirmationVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.routeTimingsArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "RouteSelectionCell", for: indexPath) as! RouteSelectionCell
        cell.RouteName.text = self.routeTimingsArr[indexPath.row].RouteName
        cell.StartTime.text = self.routeTimingsArr[indexPath.row].PickUpTime
        cell.SeatsRemaining.text = self.routeTimingsArr[indexPath.row].AvailableSeats
        
        if selectedRouteTiming == indexPath.row {
            cell.RouteName.textColor = UIColor.NavigationColor
            cell.StartTime.textColor = UIColor.NavigationColor
            cell.SeatsRemaining.textColor = UIColor.NavigationColor
        }
        else {
            cell.RouteName.textColor = UIColor.black
            cell.StartTime.textColor = UIColor.black
            cell.SeatsRemaining.textColor = UIColor.black
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedRouteTiming = indexPath.row
        collectionView.reloadData()
    }
    
}


class RouteSelectionCell: UICollectionViewCell {
    
    @IBOutlet var RouteName: UILabel!
    @IBOutlet var StartTime: UILabel!
    @IBOutlet var SeatsRemaining: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }
}



struct RouteTimingModel {
    var ShiftTime: String = ""
    var AvailableSeats: String = ""
    var PickUpTime: String = ""
    var SeatingPattern: String = ""
    var RouteName: String = ""
    var SeatSelectionStatus: String = ""
    var Id: String = ""
}
