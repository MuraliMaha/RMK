//
//  LocationAutoCompletionVC.swift
//  BMTC
//
//  Created by Raja Bhuma on 10/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

protocol PlacesAutoCompletionDelegate {
    func DidSelectLocation(title: String, address: String, lat: Double, lon: Double, controller: LocationAutoCompletionVC)
    func DidCancel(controller: LocationAutoCompletionVC)
}

class LocationAutoCompletionVC: UIViewController {

    @IBOutlet var LocationSearchTV: UITableView!
    @IBOutlet var LocationSearchTxt: UITextField!

    var autoCompleteDelegate: PlacesAutoCompletionDelegate!
    
    var DataSource: [(title: String, address: String, placeId: String)] = [(title: String, address: String, placeId: String)]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LocationSearchTV.rowHeight = 48
        LocationSearchTV.tableFooterView?.frame.size.height = 40
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        LocationSearchTxt.becomeFirstResponder()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func CancelAction() {
        if dataTask != nil {
            dataTask.cancel()
        }
        ChangeLocadingStatus(false)
        autoCompleteDelegate.DidCancel(controller: self)
    }
    
    @IBAction func DidChangeText(textField: UITextField) {
        print(textField.text!)
        
        if (textField.text?.count)! > 2 {
            SearchLocation(text: textField.text!)
        }
        else {
            DataSource.removeAll()
            LocationSearchTV.reloadData()
        }
    }

    
    var dataTask: DataRequest!
    
    var isLoading = false
    
    func SearchLocation(text: String) {
        
        if !(Alamofire.NetworkReachabilityManager()?.isReachable)! {
            print("No Internet")
            dataTask.cancel()
            self.ChangeLocadingStatus(false)
            return
        }
        
        if isLoading {
            dataTask.cancel()
            self.ChangeLocadingStatus(false)
        }
        
        self.ChangeLocadingStatus(true)

        let input = "input=" + text.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        
        let key = "key=" + "AIzaSyDZEFnAMTGOy9xwjwL1s3v3XTT0TRWRtwI"
        
        let requestStr = "https://maps.googleapis.com/maps/api/place/autocomplete/json?" + input + "&" + key
        
        let request = URLRequest.init(url: URL.init(string: requestStr)!)
        dataTask = Alamofire.request(request)
        dataTask.responseJSON { (response) in
            
            self.ChangeLocadingStatus(false)
            
            switch response.result {
            case .success(let value):
                
                self.DataSource.removeAll()
                
                let placeData = JSON(value)
                
                if placeData["status"].stringValue == "OK" {
                    if let predictions = placeData["predictions"].array {
                        for prediction in predictions {
                            let placeId = prediction["place_id"].stringValue
                            let title = prediction["structured_formatting"]["main_text"].stringValue
                            let address = prediction["structured_formatting"]["secondary_text"].stringValue
                            self.DataSource.append((title: title, address: address, placeId: placeId))
                        }
                    }
                    else {
                        print("search error")
                    }
                }
                else {
                    print("search error")
                }
                
                self.LocationSearchTV.reloadData()
                
                break
            case .failure(let error):
                print(error.localizedDescription)
                break
            }
        }
        
    }
    
    func ChangeLocadingStatus(_ status: Bool) {
        isLoading = status
        if status {
            UIApplication.shared.isNetworkActivityIndicatorVisible = true
        }
        else {
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
        }
    }
    
    func DidSelectPlace(place: (title: String, address: String, placeId: String)) {
        
        if !(Alamofire.NetworkReachabilityManager()?.isReachable)! {
            print("No Internet")
            dataTask.cancel()
            self.ChangeLocadingStatus(false)
            return
        }
        
        if isLoading {
            dataTask.cancel()
            self.ChangeLocadingStatus(false)
        }
        
        self.view.StartLoading()
        
        let placeID = "placeid=" + place.placeId
        
        let key = "key=" + "AIzaSyDZEFnAMTGOy9xwjwL1s3v3XTT0TRWRtwI"
        
        let requestStr = "https://maps.googleapis.com/maps/api/place/details/json?" + (placeID + "&" + key).addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        
        let request = URLRequest.init(url: URL.init(string: requestStr)!)
        dataTask = Alamofire.request(request)
        dataTask.responseJSON { (response) in
            
            self.view.StopLoading()
            
            switch response.result {
            case .success(let value):
                
                let placeData = JSON(value)
                
                if placeData["status"].stringValue == "OK" {
                    
                    let location = placeData["result"]["geometry"]["location"]
                    
                    let lat = location["lat"].doubleValue
                    let lng = location["lng"].doubleValue
                    
                    self.autoCompleteDelegate.DidSelectLocation(title: place.title, address: place.address, lat: lat, lon: lng, controller: self)
                }
                else {
                    print("search error")
                }
                
                break
            case .failure(let error):
                print(error.localizedDescription)
                break
            }
        }
    }
    
}

extension LocationAutoCompletionVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return DataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "LocationSearchCell", for: indexPath) as! LocationSearchCell
        cell.LocationTitle.text = DataSource[indexPath.row].title
        cell.LocationDesc.text = DataSource[indexPath.row].address
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        DidSelectPlace(place: DataSource[indexPath.row])
    }
}

class LocationSearchCell: UITableViewCell {
    
    @IBOutlet var LocationTitle: UILabel!
    @IBOutlet var LocationDesc: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
