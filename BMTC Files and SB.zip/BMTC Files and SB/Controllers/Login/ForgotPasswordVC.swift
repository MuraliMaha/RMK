//
//  ForgotPasswordVC.swift
//  BMTC
//
//  Created by SunTelematics on 10/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit

class ForgotPasswordVC: UIViewController {

    @IBOutlet weak var mobileNoLabel: UILabel!
    @IBOutlet weak var mobileNoTextField: UITextField!
    @IBOutlet weak var mobileNoBorder: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        mobileNoTextField.delegate = self
        
        
        UIApplication.shared.statusBarStyle = UIStatusBarStyle.lightContent
        self.title = "Forgot Password"
        
//        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
//        BackBtnItem.tintColor = UIColor.white
//        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
//        self.navigationItem.leftBarButtonItem = BackBtnItem
        
        
        
        CheckForLabels()
        // Do any additional setup after loading the view.
    }

    @objc func BackAction() {
        self.navigationController?.popViewController(animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func submitBtnTapped(_ sender: UIButton) {
        
        self.view.endEditing(true)
        
        if mobileNoTextField.text! == "" {
            Message.shared.Alert(Title: "Alert", Message: "Please Enter Mobile Number to send OTP", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            return
        }
        
        if !(mobileNoTextField.text?.isValidMobileNumber())! {
            Message.shared.Alert(Title: "Alert", Message: "Please enter valid mobile number", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            return
        }
        
        self.view.StartLoading()
 
        let RegisterDict = [
            "OtpType":"3", //1 for resgistration , 3 for ForgotPassword
            "Email":"0",
            "Mobileno":self.mobileNoTextField.text!,
            "VendorId":StaticCredentials.VendorId,
            "CorporateId": StaticCredentials.CorporateId,
            "AppType":StaticCredentials.AppCustomerType
        ]
       
        WebService().callBMTCBookingAPI(Suffix: WebServicesUrl.BMTCGetOtp, RestMethod: "GET", parameterDict: RegisterDict, securityKey: WebServicesUrl.DummySecurity) { (responce, responceCode, success) in
            
            self.view.StopLoading()
            
            if success {
                
                if responce["Status"].stringValue.toBool()! {
                    
                    print("Response = ",responce["OTP"].stringValue)
                    
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: responce["Response"].stringValue, Interval: 3)
                    let Otp = self.storyboard?.instantiateViewController(withIdentifier: "OtpVerifyVC") as! OtpVerifyVC
                    Otp.RequestDict = ["Mobileno":self.mobileNoTextField.text!,"OTP":responce["OTP"].stringValue,"OTPDuration":responce["OTPDuration"].stringValue,"CustomerId":responce["EmpId"].stringValue]
                    Otp.IsRegistration = false
                    Otp.isEmailLogin = responce["Response"].stringValue
                    self.navigationController?.pushViewController(Otp, animated: true)
                    
                }else{
                    Message.shared.Alert(Title: "Alert", Message: responce["Response"].stringValue, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                }
            }
            else {
                if responceCode == .NoInternet {
                    Message.shared.Alert(Title: "Alert", Message: "Check the Internet connection and try again", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                }
                else {
                    Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                }
            }
            
            
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension ForgotPasswordVC : UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        mobileNoLabel.isHidden = false
        mobileNoLabel.textColor = UIColor(hexString: "2656A0")
//        mobileNoTextField.BottomLine = UIColor(hexString: "2656A0")!
        mobileNoBorder.backgroundColor = UIColor(hexString: "2656A0")
        mobileNoTextField.placeholder = ""
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
       CheckForLabels()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    func CheckForLabels() {
        
        if !(mobileNoTextField.text?.isEmpty)! {
            mobileNoLabel.isHidden = false
        }
        else {
            mobileNoLabel.isHidden = true
//            mobileNoTextField.BottomLine = UIColor.gray
             mobileNoBorder.backgroundColor = UIColor.gray
            
            mobileNoTextField.placeholder = "Mobile Number"
        }
    }
}
