//
//  LoginVC.swift
//  BMTC
//
//  Created by SunTelematics on 04/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {

    @IBOutlet weak var mobileNoLbl: UILabel!
    @IBOutlet weak var pwdLbl: UILabel!
    
    @IBOutlet weak var mobileNoTextField: UITextField!
    @IBOutlet weak var pwdTextField: UITextField!
    
    @IBOutlet weak var mobileNoBorderLabel: UILabel!
    @IBOutlet weak var pwdBorderLabel: UILabel!
    
    @IBOutlet weak var loginBtn: UIButton!
    
    var session : AppSessionInfo!
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        mobileNoTextField.BottomLine = UIColor.green
        mobileNoTextField.delegate = self
        pwdTextField.delegate = self
        
        self.navigationItem.backBarButtonItem?.title = " "
        self.navigationItem.leftBarButtonItem = UIBarButtonItem.init(title: " ", style: .done, target: nil, action: nil)
        
        
        let mobileNoTextFieldPaddingView = UIView(frame: CGRect(x: 0, y: 0, width:5, height: self.mobileNoTextField.frame.height))
        mobileNoTextField.leftView = mobileNoTextFieldPaddingView
        mobileNoTextField.leftViewMode = UITextFieldViewMode.always
        
        let pwdTextFieldPaddingView = UIView(frame: CGRect(x: 0, y: 0, width:5, height: self.pwdTextField.frame.height))
        pwdTextField.leftView = pwdTextFieldPaddingView
        pwdTextField.leftViewMode = UITextFieldViewMode.always
        
        CheckForLabels()
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
//        self.navigationController?.navigationBar.isHidden = true
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        UIApplication.shared.statusBarStyle = UIStatusBarStyle.default
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    @IBAction func loginBtnTapped(_ sender: UIButton) {
        
        mobileNoTextField.resignFirstResponder()
        pwdTextField.resignFirstResponder()
        
        if (mobileNoTextField.text?.isEmpty)! && (pwdTextField.text?.isEmpty)! {
            self.view.ShowBlackTostWithText(message: "Please enter Mobile number and Password to Login", Interval: 3)
        }
            
        else if (mobileNoTextField.text?.isEmpty)! {
            self.view.ShowBlackTostWithText(message: "Please enter Mobile number", Interval: 3)
        }
            
        else if (pwdTextField.text?.isEmpty)! {
            self.view.ShowBlackTostWithText(message: "Please enter Password", Interval: 3)
        }
            
        else if !(mobileNoTextField.text?.isValidMobileNumber())! {
            self.view.ShowBlackTostWithText(message: "Please enter valid Mobile number", Interval: 3)
        }
            
        else if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
//            let Cred = FetchDriveCredentials()!
            session = AppSessionInfo()
            
//            let version = "\(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString")!)"
            
            let Dict = ["UserName":self.mobileNoTextField.text!,
                        "Password":self.pwdTextField.text!,
                        "Version":session.getVersion(),
                        "DeviceToken":session.getDeviceToken(),
                        "DeviceIMEINO":session.getIMEI(),
                        "DeviceType":session.getDeviceType(),
                        "VendorId":StaticCredentials.VendorId,
                        "CorporateId":StaticCredentials.CorporateId,
                        "AppType":StaticCredentials.AppCustomerType
                        ]
            
            print("LoginVC-LogininInput = ",Dict)
            
            WebService().callBMTCBookingAPI(Suffix: WebServicesUrl.BMTCLogin, parameterDict: Dict, securityKey: WebServicesUrl.DummySecurity) { (responce, responcecode, success) in
                print("LoginVC - Response",responce,responcecode)
                self.view.StopLoading()
                
                if success {
//                    let Table = (value as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
//                    if "\(Table[0]["Status"]!)".toBool()! {
//                        SaveDriveRequest(request: Dict)
//                        SaveDriveResponce(DriveResponce: Table[0])
//
//                        let NavMain = self.storyboard?.instantiateViewController(withIdentifier: "LGSideMenu")
//                        self.present(NavMain!, animated: true, completion: nil)
//                    }
//                    else {
//                        print("LoginVC Status false =",value)
//                        self.view.ShowBlackTostWithText(message: "\(Table[0]["Response"]!)", Interval: 3)
//                    }

                    
                    if responce["Status"].stringValue.toBool()! {
                        
                        self.session.setPhoneNo(phoneno: responce["MobileNo"].string ?? "NA")
                        self.session.setPassword(password: "\(Dict["Password"]!)")
                        self.session.setName(name: responce["Name"].string ?? "NA")
                        self.session.setCustomerId(customerid: responce["CustomerId"].string ?? "NA")
                        self.session.setEmail(email: responce["Email"].string ?? "NA")
                        self.session.setAuthKey(authkey: responce["AuthKey"].string ?? "NA")
                        self.session.setVendorId(vendorid: responce["VendorId"].string ?? "NA")
                        self.session.setCorporateId(corporateid: responce["CorporateId"].string ?? "NA")
                        self.session.setAppType(apptype: responce["AppType"].string ?? "NA")
                        self.session.setGender(gender: responce["Gender"].string ?? "NA")
                        
                        AppSession.shared.setPocofySessionInfo(AppSessionInfo: self.session)
                        
                        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "ShuttleBookingVC") as! ShuttleBookingVC
                        self.navigationController?.viewControllers = [ctrl]
                        
                        
                    }else{
                        Message.shared.Alert(Title: "Alert", Message: responce["Response"].stringValue, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                    
                }
                else {
                    print("LoginVC failure =",responcecode.GetResponceCode())
                    self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                }
            }
        }
        else {
            self.view.ShowBlackTostWithText(message: "No Internet connection available", Interval: 3)
        }
    }
    
    @IBAction func registerBtnTapped(_ sender: UIButton) {
//        self.navigationController?.navigationBar.isHidden = false
//        self.navigationController?.setNavigationBarHidden(false, animated: true)
        let REGISTER = self.storyboard?.instantiateViewController(withIdentifier: "RegistrationVC") as! RegistrationVC
        self.navigationController?.pushViewController(REGISTER, animated: true)
    }
    
    @IBAction func forgotPasswordTApped(_ sender: UIButton) {
//        self.navigationController?.setNavigationBarHidden(false, animated: true)
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "ForgotPasswordVC") as! ForgotPasswordVC
        self.navigationController?.pushViewController(ctrl, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension LoginVC : UITextFieldDelegate {

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == mobileNoTextField {
            mobileNoLbl.isHidden = false
            mobileNoLbl.textColor = UIColor(hexString: "2656A0")
//            mobileNoTextField.BottomLine = UIColor(hexString: "2656A0")!
            mobileNoBorderLabel.backgroundColor = UIColor(hexString: "0505CF")
            mobileNoTextField.placeholder = ""
        }
        else if textField == pwdTextField {
            pwdLbl.isHidden = false
            pwdLbl.textColor = UIColor(hexString: "2656A0")
//            pwdTextField.BottomLine = UIColor(hexString: "2656A0")!
            pwdBorderLabel.backgroundColor = UIColor(hexString: "0505CF")
            pwdTextField.placeholder = ""
        }
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        CheckForLabels()
    }
    func CheckForLabels() {
        
        if !(mobileNoTextField.text?.isEmpty)! {
            mobileNoLbl.isHidden = false
        }
        else {
            mobileNoLbl.isHidden = true
//            mobileNoTextField.BottomLine = UIColor.gray
            mobileNoBorderLabel.backgroundColor = UIColor.gray
            mobileNoTextField.placeholder = "Mobile Number"
        }
        
        if !(pwdTextField.text?.isEmpty)! {
            pwdLbl.isHidden = false
        }
        else {
            pwdLbl.isHidden = true
//            pwdTextField.BottomLine = UIColor.gray
            pwdBorderLabel.backgroundColor = UIColor.gray
            pwdTextField.placeholder = "Password"
        }
        
    }
}
