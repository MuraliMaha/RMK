//
//  AppSessionInfo.swift
//  BMTC
//
//  Created by Raja Bhuma on 09/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import Foundation

class AppSessionInfo: NSObject, NSCoding {
    
    static var shared = AppSessionInfo()
    
    static let PhoneNoKey = "PhoneNoKey"
    static let PasswordKey = "PasswordKey"
    static let VendorIdKey = "VendorIdKey"
    static let CorporateIdKey = "CorporateIdKey"
    static let AppTypeKey = "AppTypeKey"
    
    static let CustomerIdKey = "CustomerIdKey"
    static let NameKey = "NameKey"
    static let AuthKey = "AuthKey"
    static let EmailKey = "EmailKey"
    static let GenderKey = "GenderKey"
    
    
    private var phoneno: String
    private var password: String
    private var vendorid: String
    private var corporateid: String
    private var apptype: String
    
    private var customerid: String
    private var name: String
    private var authkey: String
    private var email: String
    private var gender : String
    
    
    // MARK: - Getters
    
    func getPhoneNo() -> String {
        return phoneno
    }
    
    func getPassword() -> String {
        return password
    }
    
    func getVendorId() -> String {
        return vendorid
    }
    
    func getCorporateId() -> String {
        return corporateid
    }
    
    func getAppType() -> String {
        return apptype
    }
    
    
    func getCustomerId() -> String {
        return customerid
    }
    
    func getName() -> String {
        return name
    }
    
    func getAuthKey() -> String {
        return authkey
    }
    
    func getEmail() -> String {
        return email
    }
    func getGender() -> String {
        return gender
    }
    
    // MARK: - Setters
    
    func setPhoneNo(phoneno: String) {
        self.phoneno = phoneno
    }
    
    func setPassword(password: String) {
        self.password = password
    }
    
    func setVendorId(vendorid: String) {
        self.vendorid = vendorid
    }
    
    func setCorporateId(corporateid: String) {
        self.corporateid = corporateid
    }
    
    func setAppType(apptype: String) {
        self.apptype = apptype
    }
    
    
    
    func setCustomerId(customerid: String) {
        self.customerid = customerid
    }
    
    func setName(name: String) {
        self.name = name
    }
    
    func setAuthKey(authkey: String) {
        self.authkey = authkey
    }
    
    func setEmail(email: String) {
        self.email = email
    }
    func setGender(gender:String){
        self.gender = gender
    }
    
    
    public override init() {
        phoneno = ""
        password = ""
        vendorid = ""
        corporateid = ""
        apptype = ""
        
        customerid = ""
        name = ""
        authkey = ""
        email = ""
        gender = ""
    }
    
    public func reset() {
        phoneno = ""
        password = ""
        vendorid = ""
        corporateid = ""
        apptype = ""
        
        customerid = ""
        name = ""
        authkey = ""
        email = ""
        gender = ""
    }
    
    public init(phoneno: String,
                password: String,
                vendorid: String,
                corporateid: String,
                apptype: String,
                customerid: String,
                name: String,
                authkey: String,
                email: String,
                gender:String) {
        
        self.phoneno = phoneno
        self.password = password
        self.vendorid = vendorid
        self.corporateid = corporateid
        self.apptype = apptype
        
        self.customerid = customerid
        self.name = name
        self.authkey = authkey
        self.email = email
        self.gender = gender
    }
    
    required convenience init?(coder aDecoder: NSCoder) {
        let PhoneNo = AppSessionInfo.readString(coder: aDecoder, key: AppSessionInfo.PhoneNoKey, defaultValue: "")
        let Password = AppSessionInfo.readString(coder: aDecoder, key: AppSessionInfo.PasswordKey, defaultValue: "")
        let VendorId = AppSessionInfo.readString(coder: aDecoder, key: AppSessionInfo.VendorIdKey, defaultValue: "")
        let CorporateId = AppSessionInfo.readString(coder: aDecoder, key: AppSessionInfo.CorporateIdKey, defaultValue: "")
        let AppType = AppSessionInfo.readString(coder: aDecoder, key: AppSessionInfo.AppTypeKey, defaultValue: "")
        
        let CustomerId = AppSessionInfo.readString(coder: aDecoder, key: AppSessionInfo.CustomerIdKey, defaultValue: "")
        let Name = AppSessionInfo.readString(coder: aDecoder, key: AppSessionInfo.NameKey, defaultValue: "")
        let AuthToken = AppSessionInfo.readString(coder: aDecoder, key: AppSessionInfo.AuthKey, defaultValue: "")
        let Email = AppSessionInfo.readString(coder: aDecoder, key: AppSessionInfo.EmailKey, defaultValue: "")
        let Gender = AppSessionInfo.readString(coder: aDecoder, key: AppSessionInfo.GenderKey, defaultValue: "")
        
        self.init(phoneno: PhoneNo, password: Password, vendorid: VendorId, corporateid: CorporateId, apptype: AppType, customerid: CustomerId, name: Name, authkey: AuthToken, email: Email,gender:Gender)
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(self.phoneno, forKey: AppSessionInfo.PhoneNoKey)
        aCoder.encode(self.password, forKey: AppSessionInfo.PasswordKey)
        aCoder.encode(self.vendorid, forKey: AppSessionInfo.VendorIdKey)
        aCoder.encode(self.corporateid, forKey: AppSessionInfo.CorporateIdKey)
        aCoder.encode(self.apptype, forKey: AppSessionInfo.AppTypeKey)
        
        aCoder.encode(self.customerid, forKey: AppSessionInfo.CustomerIdKey)
        aCoder.encode(self.name, forKey: AppSessionInfo.NameKey)
        aCoder.encode(self.authkey, forKey: AppSessionInfo.AuthKey)
        aCoder.encode(self.email, forKey: AppSessionInfo.EmailKey)
        aCoder.encode(self.gender, forKey: AppSessionInfo.GenderKey)
    }
    
    
    static func readString(coder aDecoder: NSCoder, key: String, defaultValue: String) -> String {
        if aDecoder.containsValue(forKey: key) {
            return aDecoder.decodeObject(forKey: key) as! String
        }
        return defaultValue
    }
    
    func isLoggedIn() -> Bool {
        if self.authkey == "" || self.authkey == " " || self.authkey == "NA" {
            return false
        }
        return true
    }
    
    
    func getDeviceToken() -> String{
        return "123"
    }
    
    func getIMEI() -> String {
        return UIDevice.current.identifierForVendor!.uuidString
    }
    func getDeviceType() -> String {
        return UIDevice.current.systemName
    }
    func getVersion() -> String {
        return "\(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString")!)"
    }
}

