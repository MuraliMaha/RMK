//
//  RegistrationVC.swift
//  BMTC
//
//  Created by SunTelematics on 04/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit

class RegistrationVC: UIViewController {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var mobileLabel: UILabel!
    @IBOutlet weak var pwdLabel: UILabel!
    @IBOutlet weak var confirmPwdLabel: UILabel!
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var genderTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var mobileTextField: UITextField!
    @IBOutlet weak var pwdTextField: UITextField!
    @IBOutlet weak var confirmPwTextField: UITextField!
    
    @IBOutlet weak var nameBorder: UILabel!
    @IBOutlet weak var genderBorder: UILabel!
    @IBOutlet weak var emailBorder: UILabel!
    @IBOutlet weak var mobileBorder: UILabel!
    @IBOutlet weak var pwdBorder: UILabel!
    @IBOutlet weak var confirmPwdBorder: UILabel!
    
    var genderArr = [String]()
    var genderSelectedIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        nameTextField.delegate = self
        genderTextField.delegate = self
        emailTextField.delegate = self
        mobileTextField.delegate = self
        pwdTextField.delegate = self
        confirmPwTextField.delegate = self
        
        genderArr = ["Male","Female"]

        UIApplication.shared.statusBarStyle = UIStatusBarStyle.lightContent
        self.title = "Sign Up to BMTC"

        let namePaddingView = UIView(frame: CGRect(x: 0, y: 0, width:5, height: self.nameTextField.frame.height))
        nameTextField.leftView = namePaddingView
        nameTextField.leftViewMode = UITextFieldViewMode.always
        
        let genderPaddingView = UIView(frame: CGRect(x: 0, y: 0, width:5, height: self.genderTextField.frame.height))
        genderTextField.leftView = genderPaddingView
        genderTextField.leftViewMode = UITextFieldViewMode.always
        
        let emailPaddingView = UIView(frame: CGRect(x: 0, y: 0, width:5, height: self.emailTextField.frame.height))
        emailTextField.leftView = emailPaddingView
        emailTextField.leftViewMode = UITextFieldViewMode.always
        
        let mobilePaddingView = UIView(frame: CGRect(x: 0, y: 0, width:5, height: self.mobileTextField.frame.height))
        mobileTextField.leftView = mobilePaddingView
        mobileTextField.leftViewMode = UITextFieldViewMode.always
        
        let passwordPaddingView = UIView(frame: CGRect(x: 0, y: 0, width:5, height: self.pwdTextField.frame.height))
        pwdTextField.leftView = passwordPaddingView
        pwdTextField.leftViewMode = UITextFieldViewMode.always
        
        let confirmPwdPaddingView = UIView(frame: CGRect(x: 0, y: 0, width:5, height: self.confirmPwTextField.frame.height))
        confirmPwTextField.leftView = confirmPwdPaddingView
        confirmPwTextField.leftViewMode = UITextFieldViewMode.always
        
//        nameTextField.placeholder = "Please enter Name"
//        emailTextField.placeholder = "Please enter Email Id"
//        mobileTextField.placeholder = "Please enter  Mobile Number"
//        pwdTextField.placeholder = "Please enter Password"
//        confirmPwTextField.placeholder = "Please confirm Password"
        
        CheckForLabels()
        createGenderPicker()
    }
    func createGenderPicker(){
        
        let genderPicker = UIPickerView()
        
        genderPicker.dataSource = self
        genderPicker.delegate = self
        
        let Toolbar = UIToolbar()
        Toolbar.barStyle = .default
        Toolbar.isTranslucent = true
        Toolbar.tintColor = UIColor.blue
        Toolbar.sizeToFit()
        let DoneItem = UIBarButtonItem.init(title: "SELECT", style: .done, target: self, action: #selector(genderSelectAction))
        let FlexiItem = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let TitleItem = UIBarButtonItem.init(title: "Please select Gender", style: .done, target: nil, action: nil)
        let FlexiItem2 = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let CancelItem = UIBarButtonItem.init(title: "CANCEL", style: .done, target: self, action: #selector(genderCancelAction))
        Toolbar.setItems([CancelItem,FlexiItem,TitleItem,FlexiItem2,DoneItem], animated: true)
        Toolbar.isUserInteractionEnabled = true
        
        genderTextField.inputView = genderPicker;
        genderTextField.inputAccessoryView = Toolbar;
    }
    @objc func genderSelectAction() {
        genderTextField.text = genderArr[genderSelectedIndex]
        genderTextField.resignFirstResponder()
        
    }
    
    @objc func genderCancelAction() {
        genderTextField.resignFirstResponder()
    }
    @objc func BackAction() {
        self.navigationController?.popViewController(animated: true)
    }
//    override func viewWillAppear(_ animated: Bool) {
//        super.viewWillAppear(animated)
//        NotificationCenter.default.addObserver(self, selector: #selector(keyboardShow(_:)), name: .UIKeyboardWillShow, object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(keyboardHide(_:)), name: .UIKeyboardWillHide, object: nil)
//        
//    }
//    override func viewWillDisappear(_ animated: Bool) {
//        super.viewWillDisappear(animated)
//        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
//        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
//    }
//    //MARK: - Keyboard show
//    @objc func keyboardShow(_ notification : NSNotification){
//        
//        let info = notification.userInfo
//        let keyboardframe = (info![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size
//        var frame = CGRect.init()
//        
//        var subView = UIView()
//        if nameTextField.isFirstResponder {
//            frame = nameTextField.frame
//            subView = nameTextField
//        }
//        else if genderTextField.isFirstResponder {
//            frame = genderTextField.frame
//            subView = genderTextField
//        }
//        else if emailTextField.isFirstResponder {
//            frame = emailTextField.frame
//            subView = emailTextField
//        }
//        else if mobileTextField.isFirstResponder {
//            frame = mobileTextField.frame
//            subView = mobileTextField
//        }
//        else if pwdTextField.isFirstResponder {
//            frame = pwdTextField.frame
//            subView = pwdTextField
//        }
//        else if confirmPwTextField.isFirstResponder {
//            frame = confirmPwTextField.frame
//            subView = confirmPwTextField
//        }
//        
//        //        frame.origin.y += 64                               // 94 = 30(nameTextfield origin from its superview) + 64(status bar + nav bar)
//        frame.origin.y += (subView.superview?.frame.origin.y)! //174 = 94 + (64+16)
//        
//        var actualFrame = self.view.frame                   // (0.0, 0.0, 375.0, 667.0)
//        actualFrame.size.height -= keyboardframe.height     //  451 = 667 -216
//        actualFrame.size.height -= (frame.size.height)      // 411 = 451 - 40
//        
//        if !actualFrame.contains(frame.origin){
//            let yfinal = frame.origin.y - actualFrame.size.height
//            UIView.animate(withDuration: 0.3, animations: { () -> Void in
//                self.view.frame.origin.y -= yfinal
//            })
//        }
//        
//    }
//    // MARK: - keyboard hide
//    @objc func keyboardHide(_ notification : NSNotification)
//    {
//        UIView.animate(withDuration: 0.3, animations: { () -> Void in
//            self.view.frame.origin.y = 0
//        })
//    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func RegisterBtnPressed(_ sender:UIButton) {
        
        self.view.endEditing(true)
        
        if (Reachability()?.isReachable)! {
            if (nameTextField.text!.isEmpty) && (emailTextField.text!.isEmpty) && (mobileTextField.text!.isEmpty) && (pwdTextField.text!.isEmpty) && (confirmPwTextField.text!.isEmpty)  {
                
                Message.shared.Alert(Title: "Alert", Message: "All Fields are required to regsiter", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            if (nameTextField.text!.isEmpty) {
                Message.shared.Alert(Title: "Alert", Message: "Please enter Your Name", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            
            if !(nameTextField.text?.isValidInput())!{
                Message.shared.Alert(Title: "Alert", Message: "Invalid Username. \n Username should be in between 4 to 15 Characters", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                
                return
            }
            if (emailTextField.text!.isEmpty){
                Message.shared.Alert(Title: "Alert", Message: "Please enter Your Email", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            
            if !(emailTextField.text?.isValidEmail())! {
                Message.shared.Alert(Title: "Alert", Message: "Please enter a Valid Email", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            if (mobileTextField.text!.isEmpty){
                Message.shared.Alert(Title: "Alert", Message: "Please enter a Your Mobile Number", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            if !(mobileTextField.text?.isValidMobileNumber())! {
                Message.shared.Alert(Title: "Alert", Message: "Please enter valid Mobile Number", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            if (pwdTextField.text!.isEmpty){
                Message.shared.Alert(Title: "Alert", Message: "Please enter your Password", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            if (pwdTextField.text!.count<5){
                Message.shared.Alert(Title: "Alert", Message: "Password should be minimum 5 characters", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            
            if (confirmPwTextField.text!.isEmpty){
                Message.shared.Alert(Title: "Alert", Message: "Please Re-enter your Password", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            
            if pwdTextField.text! == confirmPwTextField.text! {
//                let props = ["email": "\(emailTextField.text!)",
//                    "mobile":"\(mobileTextField.text!)"] as [String : Any]
//                CleverTap.sharedInstance()?.recordEvent("Register Event", withProps: props)
                RegisterAndGotoOtpPage()
            }else{
                Message.shared.Alert(Title: "Alert", Message: "Password and Confirm Password should be same", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            }
        }
        else {
            Message.shared.Alert(Title: "Alert", Message: "Check the Internet connection and try again", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
        }
    }
    
    func RegisterAndGotoOtpPage() {
        
        self.view.StartLoading()

        
        
        let RegisterDict = [
            "OtpType":"1", //1 for resgistration , 3 for ForgotPassword
            "Email":emailTextField.text!,
            "Mobileno":mobileTextField.text!,
            "VendorId":StaticCredentials.VendorId,
            "CorporateId": StaticCredentials.CorporateId,
            "AppType":StaticCredentials.AppCustomerType
        ]
        
        print("OTP Request input = ",RegisterDict)
        
        WebService().callBMTCBookingAPI(Suffix: WebServicesUrl.BMTCGetOtp, RestMethod: "GET", parameterDict: RegisterDict, securityKey: WebServicesUrl.DummySecurity) { (responce, responceCode, success) in
            
            self.view.StopLoading()
            
            if success {
                
                if responce["Status"].stringValue.toBool()! {
                    
                    print("Response = ",responce["OTP"].stringValue)
                    
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: responce["Response"].stringValue, Interval: 3)
                    let Otp = self.storyboard?.instantiateViewController(withIdentifier: "OtpVerifyVC") as! OtpVerifyVC
                    Otp.RequestDict = ["Email":self.emailTextField.text!,"Name":self.nameTextField.text!,"Mobileno":self.mobileTextField.text!,"Password":self.pwdTextField.text!,"OTP":responce["OTP"].stringValue,"OTPDuration":responce["OTPDuration"].stringValue,"Gender":self.genderTextField.text!,"CustomerId":responce["EmpId"].stringValue]
                    Otp.IsRegistration = true
                    Otp.isEmailLogin = responce["Response"].stringValue
                    self.navigationController?.pushViewController(Otp, animated: true)
                    
                }else{
                    Message.shared.Alert(Title: "Alert", Message: responce["Response"].stringValue, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                }
            }
            else {
                if responceCode == .NoInternet {
                    Message.shared.Alert(Title: "Alert", Message: "Check the Internet connection and try again", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                }
                else {
                    Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                }
            }
        
    
        }
        
    }
        /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
        



    

extension RegistrationVC : UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == nameTextField {
            nameLabel.isHidden = false
            nameLabel.textColor = UIColor(hexString: "2656A0")
//            nameTextField.BottomLine = UIColor(hexString: "2656A0")!
            nameBorder.backgroundColor = UIColor(hexString: "2656A0")
            nameTextField.placeholder = ""
            
        }
        else if textField == genderTextField {
            genderLabel.isHidden = false
            genderLabel.textColor = UIColor(hexString: "2656A0")
//            genderTextField.BottomLine = UIColor(hexString: "2656A0")!
             genderBorder.backgroundColor = UIColor(hexString: "2656A0")
            genderTextField.placeholder = ""
        }
        else if textField == emailTextField {
            emailLabel.isHidden = false
            emailLabel.textColor = UIColor(hexString: "2656A0")
//            emailTextField.BottomLine = UIColor(hexString: "2656A0")!
            emailBorder.backgroundColor = UIColor(hexString: "2656A0")
            emailTextField.placeholder = ""
        }
        else if textField == mobileTextField {
            mobileLabel.isHidden = false
            mobileLabel.textColor = UIColor(hexString: "2656A0")
//            mobileTextField.BottomLine = UIColor(hexString: "2656A0")!
            mobileBorder.backgroundColor = UIColor(hexString: "2656A0")
            mobileTextField.placeholder = ""
        }
        else if textField == pwdTextField {
            pwdLabel.isHidden = false
            pwdLabel.textColor = UIColor(hexString: "2656A0")
//            pwdTextField.BottomLine = UIColor(hexString: "2656A0")!
            pwdBorder.backgroundColor = UIColor(hexString: "2656A0")
            pwdTextField.placeholder = ""
        }
        else if textField == confirmPwTextField {
            confirmPwdLabel.isHidden = false
            confirmPwdLabel.textColor = UIColor(hexString: "2656A0")
//            confirmPwTextField.BottomLine = UIColor(hexString: "2656A0")!
            confirmPwdBorder.backgroundColor = UIColor(hexString: "2656A0")
            confirmPwTextField.placeholder = ""
        }
        
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        CheckForLabels()
    }
    
    func CheckForLabels() {
        
        if !(nameTextField.text?.isEmpty)! {
            nameLabel.isHidden = false
        }
        else {
            nameLabel.isHidden = true
//            nameTextField.BottomLine = UIColor.gray
            nameBorder.backgroundColor = UIColor.gray
            nameTextField.placeholder = "Name"
        }
        if !(genderTextField.text?.isEmpty)! {
            genderLabel.isHidden = false
        }
        else {
            genderLabel.isHidden = true
//            genderTextField.BottomLine = UIColor.gray
            genderBorder.backgroundColor = UIColor.gray
            genderTextField.placeholder = "Gender"
        }
        if !(emailTextField.text?.isEmpty)! {
            emailLabel.isHidden = false
        }
        else {
            emailLabel.isHidden = true
//            emailTextField.BottomLine = UIColor.gray
            emailBorder.backgroundColor = UIColor.gray
            emailTextField.placeholder = "Email"
        }
        
        if !(mobileTextField.text?.isEmpty)! {
            mobileLabel.isHidden = false
        }
        else {
            mobileLabel.isHidden = true
//            mobileTextField.BottomLine = UIColor.gray
            mobileBorder.backgroundColor = UIColor.gray
            mobileTextField.placeholder = "Mobile Number"
        }
        
        if !(pwdTextField.text?.isEmpty)! {
            pwdLabel.isHidden = false
        }
        else {
            pwdLabel.isHidden = true
//            pwdTextField.BottomLine = UIColor.gray
            pwdBorder.backgroundColor = UIColor.gray
            pwdTextField.placeholder = "Password"
        }
        
        if !(confirmPwTextField.text?.isEmpty)! {
            confirmPwdLabel.isHidden = false
        }
        else {
            confirmPwdLabel.isHidden = true
//            confirmPwTextField.BottomLine = UIColor.gray
            confirmPwdBorder.backgroundColor = UIColor.gray
            confirmPwTextField.placeholder = "Confirm Password"
        }
    }
}
extension RegistrationVC : UIPickerViewDelegate,UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return genderArr.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return genderArr[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        genderSelectedIndex = row
    }
}
