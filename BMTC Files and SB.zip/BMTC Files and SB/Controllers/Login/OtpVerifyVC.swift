//
//  OtpVerifyVC.swift
//  BMTC
//
//  Created by SunTelematics on 09/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit

class OtpVerifyVC: UIViewController {
    
    var RequestDict = [String:String]()
    var IsRegistration = true
    var isEmailLogin : String!
    
    @IBOutlet weak var OTPHeader: UILabel!
    @IBOutlet weak var otpLabel: UILabel!
    @IBOutlet weak var OTPTextField: UITextField!
    @IBOutlet weak var countDowntextLabel: UILabel!
    
    var resendotpButton: UIBarButtonItem!
    var countTimer = 180
    var OtpStr : String!
    var MobileNumber: String!
    var CountDownTimer = Timer()
    
    var session : AppSessionInfo!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        session = AppSessionInfo()
        
        OTPTextField.delegate = self
        
        OTPHeader.text = isEmailLogin
        self.title = "OTP"
        
        if IsRegistration {
            if let Duration = RequestDict["OTPDuration"], Duration != "" {
                countTimer =  Int(Duration)!
            }
        }
        else {
            
        }
        
//        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
//        BackBtnItem.tintColor = UIColor.white
//        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
//        self.navigationItem.leftBarButtonItem = BackBtnItem
        
        resendotpButton = UIBarButtonItem.init(title: "RESEND", style: .done, target: self, action: #selector(ResendOtpPressed(_:)))
        resendotpButton.tintColor = UIColor.white
        self.navigationItem.rightBarButtonItem = resendotpButton
        
        self.OtpStr = "\(RequestDict["OTP"]!)"
        
        CountDownTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(update), userInfo: nil, repeats: true)
        
        CheckForLabels()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        CountDownTimer.invalidate()
    }
    @objc func BackAction() {
        self.navigationController?.popViewController(animated: true)
    }
    @objc func update() {
        if(countTimer > 0) {
            countTimer -= 1
            countDowntextLabel.text =  "OTP Expires in " + "\(FromTimeInterval(interval:TimeInterval(countTimer)))" + " Seconds"
        }
        else {
            CountDownTimer.invalidate()
        }
    }
    func FromTimeInterval(interval: TimeInterval) -> String {
        let interval = Int(interval)
        let seconds = interval % 60
        let minutes = (interval / 60) % 60
        let hours = (interval / 3600)
        var form = "\(hours):\(minutes):\(seconds)"
        
        if hours == 0{
            form = "\(minutes):\(seconds)"
        }
        if minutes == 0{
            form = "\(seconds)"
        }
        if seconds == 0 &&  minutes == 0 && hours == 0 {
            form = "OTP Time expired Please Click on Resend to send OTP again"
        }
        
        return String(format: form)
    }
    @IBAction func ResendOtpPressed(_ sender:UIBarButtonItem) {
        
        Message.shared.Alert(Title: "Alert", Message: isEmailLogin, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
        
        
        if IsRegistration {
            
            self.view.StartLoading()
            
            let RegisterDict = [
                "OtpType":"1", //1 for resgistration , 3 for ForgotPassword
                "Email":RequestDict["Email"]!,
                "Mobileno":RequestDict["Mobileno"]!,
                "VendorId":StaticCredentials.VendorId,
                "CorporateId": StaticCredentials.CorporateId,
                "AppType":StaticCredentials.AppCustomerType
            ]
            
            WebService().callBMTCBookingAPI(Suffix: WebServicesUrl.BMTCGetOtp, RestMethod: "GET", parameterDict: RegisterDict, securityKey: WebServicesUrl.DummySecurity) { (responce, responceCode, success) in
                
                self.view.StopLoading()
                
                if success {
                    if responce["Status"].stringValue.toBool()! {
                        self.countTimer = 0
                        self.OtpStr = responce["Otp"].string
                        self.RequestDict["Otp"] = self.OtpStr
                        self.countTimer = Int(responce["OTPDuration"].string!)!
                        self.CountDownTimer.invalidate()
                        self.CountDownTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.update), userInfo: nil, repeats: true)
                    }else{
                        Message.shared.Alert(Title: "Alert", Message: responce["Response"].stringValue, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
                    
                    
                    
                    
                else {
                    if responceCode == .NoInternet {
                        Message.shared.Alert(Title: "Alert", Message: "Check the Internet connection and try again", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                    else {
                        Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
            }
        }
            // else block for Forgot Password
        else {
            self.view.StartLoading()
            
            let RegisterDict = [
                "OtpType":"3", //1 for resgistration , 3 for ForgotPassword
                "Email":"0",
                "Mobileno":RequestDict["Mobileno"]!,
                "VendorId":StaticCredentials.VendorId,
                "CorporateId": StaticCredentials.CorporateId,
                "AppType":StaticCredentials.AppCustomerType
            ]
            WebService().callBMTCBookingAPI(Suffix: WebServicesUrl.BMTCGetOtp,RestMethod:"GET",parameterDict: RegisterDict, securityKey: WebServicesUrl.DummySecurity) { (responce, responceCode, success) in
                
                self.view.StopLoading()
                
                if success {
                    if responce["Status"].stringValue.toBool()! {
                        self.countTimer = 0
                        self.OtpStr = responce["Otp"].string
                        self.RequestDict["Otp"] = self.OtpStr
                        self.countTimer = Int(responce["OTPDuration"].string!)!
                        self.CountDownTimer.invalidate()
                        self.CountDownTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.update), userInfo: nil, repeats: true)
                    }else{
                        Message.shared.Alert(Title: "Alert", Message: responce["Response"].stringValue, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
                else {
                    if responceCode == .NoInternet {
                        Message.shared.Alert(Title: "Alert", Message: "Check the Internet connection and try again", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                    else {
                        Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
            }
        }
        
    }
    
    @IBAction func verifyBtnTapped(_ sender: UIButton) {
        if OTPTextField.text! == "" {
            Message.shared.Alert(Title: "Alert", Message: "Please Enter OTP to Verify", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            return
        }
        
        if OTPTextField.text! != self.OtpStr {
            Message.shared.Alert(Title: "Alert", Message: "Please Enter Valid OTP", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            return
        }
        
        
        if IsRegistration {
            
            self.view.StartLoading()
            
            //            let version = "\(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString")!)"
            //            let Uuid = UIDevice.current.identifierForVendor!.uuidString
            let RegisterDict = [
                "UserName":RequestDict["Name"]!,
                "Password":RequestDict["Password"]!,
                "EmailId":RequestDict["Email"]!,
                "MobileNo":RequestDict["Mobileno"]!,
                "Version":session.getVersion(),
                "DeviceToken":session.getDeviceToken(),
                "DeviceIMEINO":session.getIMEI(),
                "DeviceType":session.getDeviceType(),
                "VendorId":StaticCredentials.VendorId,
                "CorporateId":StaticCredentials.CorporateId,
                "AppType":StaticCredentials.AppCustomerType,
                "Gender":RequestDict["Gender"]!]
            
            WebService().callBMTCBookingAPI(Suffix: WebServicesUrl.BMTCRegisterUser, parameterDict: RegisterDict, securityKey: WebServicesUrl.DummySecurity, completion: { (Table, responceCode, success) in
                self.view.StopLoading()
                if success {
                    
                    if Table["Status"].stringValue.toBool()! {
                        
                        let session = AppSessionInfo()
                        session.setPhoneNo(phoneno: Table["MobileNo"].string ?? "NA")
                        session.setPassword(password: "\(RegisterDict["Password"]!)")
                        session.setName(name: Table["Name"].string ?? "NA")
                        session.setCustomerId(customerid: Table["CustomerId"].string ?? "NA")
                        session.setEmail(email: Table["Email"].string ?? "NA")
                        session.setAuthKey(authkey: Table["AuthKey"].string ?? "NA")
                        session.setVendorId(vendorid: Table["VendorId"].string ?? "NA")
                        session.setCorporateId(corporateid: Table["CorporateId"].string ?? "NA")
                        session.setAppType(apptype: Table["AppType"].string ?? "NA")
                        session.setGender(gender: Table["Gender"].string ?? "NA")
                        
                        AppSession.shared.setPocofySessionInfo(AppSessionInfo: session)
                        
                        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HomePageVC") as! HomePageVC
                        self.navigationController?.pushViewController(ctrl, animated: true)
                    }
                    else {
                        Message.shared.Alert(Title: "Alert", Message: Table["Response"].stringValue, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                    
                }
                else {
                    if responceCode == .NoInternet {
                        Message.shared.Alert(Title: "Alert", Message: "Check the Internet connection and try again", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                    else {
                        Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
            })
            
        }
        else {
            let updatepass = self.storyboard?.instantiateViewController(withIdentifier: "UpdatePassVC") as! UpdatePassVC
            updatepass.customerId = RequestDict["CustomerId"]!
            updatepass.mobile = RequestDict["Mobileno"]!
            self.navigationController?.pushViewController(updatepass, animated: true)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

extension OtpVerifyVC : UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        otpLabel.isHidden = false
        otpLabel.textColor = UIColor(hexString: "2656A0")
        OTPTextField.placeholder = ""
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        CheckForLabels()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    func CheckForLabels() {
        
        if !(OTPTextField.text?.isEmpty)! {
            otpLabel.isHidden = false
        }
        else {
            otpLabel.isHidden = true
            OTPTextField.placeholder = "Enter OTP"
        }
        
        
        
    }
}

