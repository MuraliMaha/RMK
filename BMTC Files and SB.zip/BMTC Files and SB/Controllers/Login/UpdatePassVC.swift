//
//  UpdatePassVC.swift
//  BMTC
//
//  Created by SunTelematics on 11/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit

class UpdatePassVC: UIViewController {

    @IBOutlet weak var newPwdLabel: UILabel!
    @IBOutlet weak var newPwdTextField: UITextField!
    
    @IBOutlet weak var confirmPwdLabel: UILabel!
    @IBOutlet weak var confirmPwdTextField: UITextField!
    
    @IBOutlet weak var newPwdBorder: UILabel!
    @IBOutlet weak var confirmPwdBorder: UILabel!
    
    var customerId : String!
    var mobile : String!
    
    var session : AppSessionInfo!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        newPwdTextField.delegate = self
        confirmPwdTextField.delegate = self
        
//        self.navigationController?.navigationBar.isHidden = false
        UIApplication.shared.statusBarStyle = UIStatusBarStyle.lightContent
        self.title = "Update Password"
        
//        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
//        BackBtnItem.tintColor = UIColor.white
//        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
//        self.navigationItem.leftBarButtonItem = BackBtnItem
        
        CheckForLabels()
        
    }

    @objc func BackAction() {
        self.navigationController?.popViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func updateBtnTapped(_ sender: UIButton) {
        if newPwdTextField.text! == "" && confirmPwdTextField.text! == "" {
            Message.shared.Alert(Title: "Alert", Message: "Please Enter new and confirm password to update", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            return
        }
        if newPwdTextField.text! == ""{
            Message.shared.Alert(Title: "Alert", Message: "Please Enter new password to update", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            return
        }
        if (newPwdTextField.text!.count<5){
            Message.shared.Alert(Title: "Alert", Message: "Password should be minimum 5 characters", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            return
        }
        if confirmPwdTextField.text! == ""{
            Message.shared.Alert(Title: "Alert", Message: "Please confirm your password to update", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            
            return
        }
        if newPwdTextField.text! == confirmPwdTextField.text! {
            
            self.view.StartLoading()
            
            
            
            let ChangeDict = [
                                "Password":self.newPwdTextField.text!,
                                "CustId":self.customerId!
                            ]
            
            WebService().callBMTCBookingAPI(Suffix: WebServicesUrl.BMTCUpdatePassword, parameterDict: ChangeDict, securityKey: WebServicesUrl.DummySecurity, completion: { (responce, responceCode, success) in
                self.view.StopLoading()

                if  success {
                    if responce["Status"].stringValue.toBool()! {
                         UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: responce["Response"].string, Interval: 4)
                        
                        DispatchQueue.main.async {
                            self.view.StartLoading()
                            
                            self.session = AppSessionInfo()
                            
                            let Dict = ["UserName":self.mobile!,
                                        "Password":self.newPwdTextField.text!,
                                        "Version":self.session.getVersion(),
                                        "DeviceToken":self.session.getDeviceToken(),
                                        "DeviceIMEINO":self.session.getIMEI(),
                                        "DeviceType":self.session.getDeviceType(),
                                        "VendorId":StaticCredentials.VendorId,
                                        "CorporateId":StaticCredentials.CorporateId,
                                        "AppType":StaticCredentials.AppCustomerType
                            ]
                            WebService().callBMTCBookingAPI(Suffix: WebServicesUrl.BMTCLogin, parameterDict: Dict, securityKey: WebServicesUrl.DummySecurity) { (responce, responcecode, success) in
                                
                                self.view.StopLoading()
                                
                                if success {
                                    
                                    if responce["Status"].stringValue.toBool()! {
                                        
                                        self.session.setPhoneNo(phoneno: responce["MobileNo"].string ?? "NA")
                                        self.session.setPassword(password: "\(Dict["Password"]!)")
                                        self.session.setName(name: responce["Name"].string ?? "NA")
                                        self.session.setCustomerId(customerid: responce["CustomerId"].string ?? "NA")
                                        self.session.setEmail(email: responce["Email"].string ?? "NA")
                                        self.session.setAuthKey(authkey: responce["AuthKey"].string ?? "NA")
                                        self.session.setVendorId(vendorid: responce["VendorId"].string ?? "NA")
                                        self.session.setCorporateId(corporateid: responce["CorporateId"].string ?? "NA")
                                        self.session.setAppType(apptype: responce["AppType"].string ?? "NA")
                                        self.session.setGender(gender: responce["Gender"].string ?? "NA")
                                        
                                        AppSession.shared.setPocofySessionInfo(AppSessionInfo: self.session)
                                        
                                        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HomePageVC") as! HomePageVC
                                        self.navigationController?.viewControllers = [ctrl]
                                        
                                        
                                    }else{
                                        Message.shared.Alert(Title: "Alert", Message: responce["Response"].stringValue, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                                    }
                                    
                                }
                                else {
                                    print("LoginVC failure =",responcecode.GetResponceCode())
                                    self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                                }
                            }
                        }

                    }else{
                        Message.shared.Alert(Title: "Alert", Message: responce["Response"].stringValue, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
                    
                else {
                    if responceCode == .NoInternet {
                        Message.shared.Alert(Title: "Alert", Message: "Check the Internet connection and try again", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                    else {
                        Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
            })
        }
        else{
            Message.shared.Alert(Title: "Alert", Message: "New password and confirm password should be same", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension UpdatePassVC : UITextFieldDelegate {

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        
        if textField == newPwdTextField {
            newPwdLabel.isHidden = false
            newPwdLabel.textColor = UIColor(hexString: "2656A0")
//            newPwdTextField.BottomLine = UIColor(hexString: "2656A0")!
            newPwdBorder.backgroundColor = UIColor(hexString: "2656A0")
            
            newPwdTextField.placeholder = ""
        }
        else if textField == confirmPwdTextField {
            confirmPwdLabel.isHidden = false
            confirmPwdLabel.textColor = UIColor(hexString: "2656A0")
//            confirmPwdTextField.BottomLine = UIColor(hexString: "2656A0")!
            confirmPwdBorder.backgroundColor = UIColor(hexString: "2656A0")
            confirmPwdTextField.placeholder = ""
        }
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        CheckForLabels()
    }
    func CheckForLabels() {
        
        if !(newPwdTextField.text?.isEmpty)! {
            newPwdLabel.isHidden = false
        }
        else {
            newPwdLabel.isHidden = true
//            newPwdTextField.BottomLine = UIColor.gray
            newPwdBorder.backgroundColor = UIColor.gray
            newPwdTextField.placeholder = "New Password"
        }
        
        if !(confirmPwdTextField.text?.isEmpty)! {
            confirmPwdLabel.isHidden = false
        }
        else {
            confirmPwdLabel.isHidden = true
//            confirmPwdTextField.BottomLine = UIColor.gray
            confirmPwdBorder.backgroundColor = UIColor.gray
            confirmPwdTextField.placeholder = "Confirm Password"
        }
        
    }
}
