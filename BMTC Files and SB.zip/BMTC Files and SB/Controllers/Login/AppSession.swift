//
//  AppSession.swift
//  BMTC
//
//  Created by Raja Bhuma on 09/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import Foundation

class AppSession {
    static let shared = AppSession()
    static let documentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let sessionInfoArchiveURL = documentsDirectory.appendingPathComponent("AppSessionInfo")
    private init() { }
    
    func getPocofySessionInfo() -> AppSessionInfo {
        var sessionInfo = NSKeyedUnarchiver.unarchiveObject(withFile: AppSession.sessionInfoArchiveURL.path) as? AppSessionInfo
        if sessionInfo != nil {
            return sessionInfo!
        }
        sessionInfo = AppSessionInfo()
        return sessionInfo!
    }
    
    func setPocofySessionInfo(AppSessionInfo: AppSessionInfo) {
        let saved = NSKeyedArchiver.archiveRootObject(AppSessionInfo, toFile: AppSession.sessionInfoArchiveURL.path)
        if !saved {
            debugPrint("Could not save the session info successfully.")
        }
        else {
            debugPrint("SessionInfo saved successfully!")
        }
    }
}
