//
//  UtilitiesClass.swift
//  BMTC
//
//  Created by SunTelematics on 08/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit

class UtilitiesClass: NSObject {
    
}

func ShowLocationDenied(controller:UIViewController) {
    let Location = LocationAccessView.init(nibName: "LocationAccessView", bundle: Bundle.main)
    
    let transition = CATransition()
    transition.duration = 0.45
    transition.type = kCATransitionFade;
    transition.subtype = kCATransitionFromTop;
    
    Location.view.layer.add(transition, forKey: kCATransition)
    
    controller.present(Location, animated: true, completion: nil)
}
