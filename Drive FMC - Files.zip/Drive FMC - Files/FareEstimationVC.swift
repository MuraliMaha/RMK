//
//  FareEstimationVC.swift
//  DriveFindMyCab
//
//  Created by Amarnath B on 22/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit

class FareEstimationVC: UIViewController {

    @IBOutlet var PickupAddressLbl: UILabel!
    @IBOutlet var DropAddressLbl: UILabel!

    @IBOutlet var FareLbl: UILabel!
    @IBOutlet var AppTravelTime: UILabel!

    @IBOutlet var ShadeLbl: UIView!

    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!
    
    
    var PickupDetails: FavouritesLocationsStruct!
    var DropLocDetails: FavouritesLocationsStruct!

    var VehicleCat: String!
    var VehicleModelName: String!
    var CityName: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        LoginRequest = FetchDriveRequest()
        DriveBookingResponce = FetchDriveResponce()
        
        self.PickupAddressLbl.text = PickupDetails.Location!
        self.DropAddressLbl.text = DropLocDetails.Location!
        
        self.perform(#selector(LoadData), with: nil, afterDelay: 0.15)
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.black
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
        self.navigationItem.leftBarButtonItem = BackBtnItem
    }
    
    func BackAction() {
        self.navigationController?.popViewController(animated: true)
    }
    
    func LoadViewWithData(MinBalance:String, TotalTime:String) {
        DispatchQueue.main.async {
            self.FareLbl.text = MinBalance
            self.AppTravelTime.text = "Approximate travel time " + TotalTime
        }
    }
    
    func LoadData() {
        
        DispatchQueue.main.async {
            
            self.ShadeLbl.layer.cornerRadius = 3
            self.ShadeLbl.layer.masksToBounds = false
            self.ShadeLbl.layer.shadowColor = UIColor.black.cgColor
            self.ShadeLbl.layer.shadowOpacity = 0.4
            self.ShadeLbl.layer.shadowOffset = CGSize.zero
            self.ShadeLbl.layer.shadowRadius = 2
            self.ShadeLbl.layer.shadowPath = UIBezierPath(rect: self.ShadeLbl.bounds).cgPath
            
        }
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            
            var dropLon = 0.0
            var dropLat = 0.0
            if DropLocDetails.Latitude != nil{
                dropLat = DropLocDetails.Latitude!
                dropLon = DropLocDetails.Longitude!
            }
            let RequestDict = ["PickUpLat":"\(PickupDetails.Latitude!)",
                "PickUpLon":"\(PickupDetails.Longitude!)",
                "DropLat":"\(dropLat)",
                "DropLon":"\(dropLon)",
                "VehicleCategory":"\(VehicleCat!)",
                "VehicleModel":"\(VehicleModelName!)",
                "TypeofTrip":"Meter Tariff",
                "City":"\(CityName!)",
                "EmpId":"\(DriveBookingResponce.EmpId!)",
                "BookingType":"Current",
                "VendorId":"\(LoginRequest.LoginCreds.VendorId!)",
                "CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)",
                "AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)",
                "Status":"1"]
            print(RequestDict)
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveEstimateRideForBooking, parameterDict: RequestDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (ResponceData, responceCode, success) in
                
                if success {
                    
                    if let Table = ((ResponceData as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                        
                        if "\(Table["Status"]!)" == "true" {
                            self.LoadViewWithData(MinBalance: "\(Table["TotalFare"]!)", TotalTime: "\(Table["TotalTime"]!)")
                        }
                        else {
//                            self.view.ShowBlackTostWithText(message: "\(Table["Response"]!)", Interval: 2)
                        }
                    }
                    else {
                        self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                    }
                    
                }
                else {
                    self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                }
                
                self.view.StopLoading()
            })
        }
        else {
            self.view.ShowBlackTostWithText(message: Constants.NetErrorMsg, Interval: 3)
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
