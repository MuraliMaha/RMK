//
//  TripFeedbackVC.swift
//  DriveFindMyCab
//
//  Created by Divya on 02/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit


class TripFBCell:UITableViewCell {
    @IBOutlet var Title:UILabel!
    @IBOutlet var CheckBox:UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

}

class TripFeedbackVC:UIViewController, UITextFieldDelegate {

    
    @IBOutlet var RatingView:HCSStarRatingView!
    @IBOutlet var TripDateLbl:UILabel!
    @IBOutlet var ShiftTypeLbl:UILabel!
    @IBOutlet var RatingStatusLbl:UILabel!
    @IBOutlet var RatingCommentsTB:UITableView!
    @IBOutlet var CommentTXt:UITextField!
    @IBOutlet var ReasonsView:UIView!
    
    var TripID:String!
    var TripDate:String!
    var TripShift:String!
    
    var LoginResponce:LoginResponce!
    var LoginDetails:LoginDetails!
    
    var TripFeedbackReasonArr = [[String:String]]()
    var TripRatingStatusArr : [String] = {
        let RatingStatus = ["Very bad","Bad","OK","Good","Great"]
        return RatingStatus
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        LoginDetails = FetchLoginDetails()
        LoginResponce = FetchLoginResponce()
        
        TripFeedbackReasonArr = [["Title":"Unsafe Driving","Status":"0"],["Title":"Quality of cab","Status":"0"],["Title":"On time Arrival","Status":"0"],["Title":"Drivers behaviour","Status":"0"],["Title":"Other","Status":"0"]]
        
        ReasonsView.isHidden = true;
        TripDateLbl.text = TripDate!
        ShiftTypeLbl.text = TripShift!
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    @IBAction func DidSelectRating(_ sender:HCSStarRatingView) {
        
        let Index = Int(String.init(format: "%.0f", sender.value))
        
        RatingStatusLbl.text = TripRatingStatusArr[Index!-1];
        
        if (Index! > 3) {
            self.ReasonsView.isHidden = true
            self.view.bringSubview(toFront: self.RatingView)
            self.CommentTXt.text = "";
        }
        else {
            self.ReasonsView.isHidden = false;
            TripFeedbackReasonArr = [["Title":"Unsafe Driving","Status":"0"],["Title":"Quality of cab","Status":"0"],["Title":"On time Arrival","Status":"0"],["Title":"Drivers behaviour","Status":"0"],["Title":"Other","Status":"0"]]
        }
        
        RatingCommentsTB.reloadData()
    }
    
    @IBAction func SubmitBtnAction(_ sender:UIButton) {
        
        var SelectedFeedbacks = ""
        var CommentsStr = ""

        if (self.RatingView.value <= 3) {
            
            for dict in TripFeedbackReasonArr {
                
                if dict["Status"]! == "1" {
                    if SelectedFeedbacks == "" {
                        SelectedFeedbacks.append(dict["Title"]!)
                    }
                    else {
                        SelectedFeedbacks.append("," + dict["Title"]!)
                    }
                }
            }
            CommentsStr = CommentTXt.text!
            
            if SelectedFeedbacks == "" {
                SelectedFeedbacks = "NA"
            }
            
            if CommentsStr == "" {
                CommentsStr = "NA"
            }
            
            
            if SelectedFeedbacks == "NA" {
                
                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Please select reason", Interval: 3)

                return
            }
            
            if CommentsStr == "NA" {
                
                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Please enter feedback", Interval: 3)
                
                return
            }
            
            
        }
        else {
            SelectedFeedbacks = "NA"
            CommentsStr = "NA"
        }
        
        let CMD = "$DriveFeedback|\(LoginDetails.UserID!)|\(TripID!)|\(String.init(format: "%.0f", RatingView.value))|\(SelectedFeedbacks)|\(CommentsStr)|#"
        
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            let RequestDict = ["RatingCmd":CMD]
            WebService().callAutoAPI(Suffix: WebServicesUrl.EMSRateYourTrip, parameterDict: RequestDict, completion: { (dataDict, success) in
                
                self.view.StopLoading()
                
                if success {
                    
                    
                    self.LoginResponce.ShowRateTrip = "false"
                    SaveLoginResponceWithStruct(Struct: self.LoginResponce!)
                    
                    if let dict = dataDict {
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message:"\(dict["Response"]!)", Interval: 3)
                    }else{
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Trip Feedback Updated", Interval: 3)
                    }
                    
                    Timer.scheduledTimer(timeInterval: 3.2, target: self, selector: #selector(self.moveToHomePage), userInfo: nil, repeats: false)
                    
                    
                
                }
                else {
                    UtilitiesClass.Alert(Title: "Alert!", Message: Constants.InternalError as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                }
            })
            
        }
        else {
            UtilitiesClass.Alert(Title: "Alert!", Message: Constants.NetErrorMsg as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
        }
        
    }
    
    func moveToHomePage(){
        let NavMain = self.storyboard?.instantiateViewController(withIdentifier: "LGSideMenu")
        self.present(NavMain!, animated: true, completion: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardHide(_:)), name: .UIKeyboardWillHide, object: nil)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    //MARK: - Keyboard show
    
    func keyboardShow(_ notification : NSNotification){
        
        let info = notification.userInfo
        let keyboardframe = (info![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size
        var frame = CGRect.init()
        frame = CommentTXt.frame
        
        frame.origin.y += ReasonsView.frame.origin.y
        
        var actualframe = self.view.superview?.frame
        actualframe?.size.height -= keyboardframe.height
        actualframe?.size.height -= (frame.size.height)
        
        if !(actualframe?.contains((frame.origin)))! {
            let yfinal = (frame.origin.y) - (actualframe?.size.height)!
            
            UIView.animate(withDuration: 0.3, animations: { () -> Void in
                self.view.frame.origin.y -= yfinal
            })
            
        }
    }
    // MARK: - keyboard hide
    
    func keyboardHide(_ notification : NSNotification)
    {
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.view.frame.origin.y = 0
        })
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    
}



extension TripFeedbackVC:UITableViewDelegate,UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return TripFeedbackReasonArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TripFBCell", for: indexPath) as! TripFBCell
        cell.Title.text = TripFeedbackReasonArr[indexPath.row]["Title"]!
        
        if TripFeedbackReasonArr[indexPath.row]["Status"]! == "1" {
            cell.CheckBox.isSelected = true
        }
        else {
            cell.CheckBox.isSelected = false
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let cell = tableView.cellForRow(at: indexPath) as! TripFBCell
        cell.CheckBox.isSelected = !cell.CheckBox.isSelected;
        
        TripFeedbackReasonArr[indexPath.row]["Status"] = cell.CheckBox.isSelected ? "1" : "0"
    }
}

