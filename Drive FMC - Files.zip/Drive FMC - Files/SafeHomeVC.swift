//
//  SafeHomeVC.swift
//  DriveFindMyCab
//
//  Created by Admin on 01/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit
import GoogleMaps
import Messages
import MessageUI
class SafeHomeVC: UIViewController,MFMessageComposeViewControllerDelegate {

    @IBOutlet var SafeHomeBtn:UIButton!
    @IBOutlet var AddressLbl:UILabel!
    @IBOutlet var SafeHomeImg:UIImageView!
    @IBOutlet var SuccessGreenLbl:UILabel!

    var LocationManager = CLLocationManager()
    var IsFirstUpdate = false
    
    var TripID:String!
    
    var LoginResponce:LoginResponce!
    var LoginDetails:LoginDetails!
    
    var NoLatLon = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        self.LoginDetails = FetchLoginDetails()
        self.LoginResponce = FetchLoginResponce()
        // Do any additional setup after loading the view.
        
        SafeHomeBtn.layer.borderColor = UIColor.white.cgColor
        SafeHomeBtn.layer.borderWidth = 1
        
        LocationManager.delegate = self
        LocationManager.requestWhenInUseAuthorization()
        
        if self.TripID != nil {
            getLatiLon()
            self.SuccessGreenLbl.text = "Please click below to update your safe home"
            self.SuccessGreenLbl.textColor = UtilitiesClassSub.color(fromHexString: "#FF0000")
        }
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.white
        self.navigationItem.leftBarButtonItem = BackBtnItem
    }
    
    func BackAction() {
        self.navigationController?.popViewController(animated: true)
    }

    override func viewWillAppear(_ animated: Bool) {
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func SafeHomeBtnPressed(_ sender:UIButton) {
        
        if (Reachability()?.isReachable)! {
            
            if self.TripID != nil {
                UtilitiesClass.Alert(Title: "Safe Home", Message: "Are you sure you have reached home safely", Actions: [UtilitiesClass.AlertActionWithSelector(Title: "NO", Selector: #selector(EmergencyNOBtnAction), Controller: self),UtilitiesClass.AlertActionWithSelector(Title: "REACHED", Selector: #selector(CallSendSafeHome), Controller: self)], Controller: self)

            }
            else {
                CallSendSafeHome()
            }
            
        }
        else {
            self.view.ShowWhiteTostWithText(message: "No Active Internet connection", Interval: 3)
        }
    }
    
    func EmergencyNOBtnAction() {
        
        var Numbers = [String]()
        
        guard FetchEmergencyContacts() != nil  else {
            return
        }
        
        if (FetchEmergencyContacts()?.count)! > 0 {
            Numbers = [String]()
            
            for number in FetchEmergencyContacts()! {
                Numbers.append(number.Number!)
            }
            
            LocationManager.delegate = self
            LocationManager.requestWhenInUseAuthorization()
            LocationManager.startUpdatingLocation()
            
        }
        
        if Numbers.count == 0 {
            return
        }
        
        GMSGeocoder().reverseGeocodeCoordinate((LocationManager.location?.coordinate)!) { (ReverseGeoCodeResponce, error) in
            if error == nil {
                let address = ReverseGeoCodeResponce?.results()?[0].lines
                
                var AddAddress = ""
                for addstr in address! {
                    AddAddress.append(addstr + ", ")
                }
                
                let addStr = AddAddress.substring(to: AddAddress.index(AddAddress.endIndex, offsetBy: -2))
                
                if (MFMessageComposeViewController.canSendText()) {
                    
                    UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Sending Message to emerg", Interval: 3)

                    let controller = MFMessageComposeViewController()
                    controller.body = "\(self.LoginResponce.Name!)" + " is in an emergency situation and needs help immediately.\nLocation: "
                        + addStr + "\nhttp://maps.google.com/?q="
                        + "\((self.LocationManager.location?.coordinate)!.latitude)" + ","
                        + "\((self.LocationManager.location?.coordinate)!.longitude)"
                    controller.recipients = Numbers
                    controller.messageComposeDelegate = self
                    self.present(controller, animated: true, completion: nil)
                }
            }
            else {
                print((error?.localizedDescription)!)
                if (MFMessageComposeViewController.canSendText()) {
                    let controller = MFMessageComposeViewController()
                    controller.body = "\(self.LoginResponce.Name!)" + " is in an emergency situation and needs help immediately."
                    controller.recipients = Numbers
                    controller.messageComposeDelegate = self
                    self.present(controller, animated: true, completion: nil)
                }
            }
        }
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    func CallSendSafeHome() {
        UIApplication.shared.keyWindow?.StartLoading()
        
        GMSGeocoder().reverseGeocodeCoordinate((LocationManager.location?.coordinate)!) { (ReverseGeoCodeResponce, error) in
            if error == nil {
                let address = ReverseGeoCodeResponce?.results()?[0].lines
                
                
                var AddAddress = ""
                for addstr in address! {
                    AddAddress.append(addstr + ", ")
                }
                
                let addStr = AddAddress.substring(to: AddAddress.index(AddAddress.endIndex, offsetBy: -2))
                
                WebService().callAutoAPI(Suffix: WebServicesUrl.EMSEmpSafeHomeReach, parameterDict: ["EMSEmpSafeHomeReachCMD":"$SUNFMCSAFEREACH|\(self.LoginDetails.UserID!)|\(self.TripID != nil ? self.TripID! : "0")|\((self.LocationManager.location?.coordinate.latitude)!)|\((self.LocationManager.location?.coordinate.longitude)!)|\(addStr)|\(self.LoginDetails.DeviceIMEI!)|#"], completion: { (ResponceDict, success) in
                    UIApplication.shared.keyWindow?.StopLoading()
                    if success {
                        print(ResponceDict!)
                        let Arr = ResponceDict?["data"] as! [[String:AnyObject]]
                        let ResponceData = Arr[0]
                        
                        
                        if "\(ResponceData["Response"]!)" == "Success"
                        {
                            self.SuccessGreenLbl.text = "\(ResponceData["ToastMessage"]!)"
                            self.SuccessGreenLbl.textColor = UtilitiesClassSub.color(fromHexString: "#7ED321")
                        }
                        else {
//                            self.SuccessGreenLbl.text = "\(ResponceData["ToastMessage"]!)"
//                            self.SuccessGreenLbl.textColor = UtilitiesClassSub.color(fromHexString: "#FF0000")
                        }
                        
                        self.view.ShowWhiteTostWithText(message: "\(ResponceData["ToastMessage"]!)", Interval: 3)
                        
                        self.ChangeToWhite()
                    }
                    else {
                        self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 3)
                    }
                })
            }
            else {
                UIApplication.shared.keyWindow?.StopLoading()
                self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 3)
            }
        }
    }
    
    func getLatiLon() {
        if (Reachability()?.isReachable)! {
            
            UIApplication.shared.keyWindow?.StartLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.SafeHomeDetails, parameterDict: ["WebUserid":"\(LoginDetails.UserID!)","TripCode":"\(TripID!)","EmpId":"\(LoginResponce.ID!)"], completion: { (ResponceDict, success) in
                UIApplication.shared.keyWindow?.StopLoading()
                if success {
                    print(ResponceDict!)
                    
                    let Arr = ResponceDict?["data"] as! [[String:AnyObject]]
                    let ResponceData = Arr[0]
                    
                    
                    if "\(ResponceData["Response"]!)" == "Success"
                    {
                        var Lat:Double = 0
                        var Lon:Double = 0
                        
                        if let latitude = ResponceData["Lat"],
                            (latitude is NSNumber || latitude is String) {
                            Lat = Double("\(latitude)")!
                        }
                        if let longitude = ResponceData["Lon"],
                            (longitude is NSNumber || longitude is String) {
                            Lon = Double("\(longitude)")!
                        }
                        
                        if Lat == 0 || Lon == 0 {
                            self.NoLatLon = true
                        }
                        else {
                            self.NoLatLon = false
                            
                            self.DropLat = Lat
                            self.DropLon = Lon
                        }
                    }
                    else {
                        self.NoLatLon = false
                    }
               
                }
                else {
                    self.NoLatLon = true
                }
                
                self.LoadSafeHomeBtnImageColor()
                
            })
        }
        else {
            self.view.ShowWhiteTostWithText(message: "No Active Internet connection", Interval: 3)
        }
    }
    
    var DropLat = 0.0
    var DropLon = 0.0
    func LoadSafeHomeBtnImageColor() {
        if NoLatLon {
            changeToRed()
        }
        else {
           let Distance = getDistanceFromLatLonInKm(lat1: (LocationManager.location?.coordinate.latitude)!, lon1: (LocationManager.location?.coordinate.longitude)!, lat2: DropLat, lon2: DropLon)
            if Distance > 0.1 {
                changeToRed()
                self.SuccessGreenLbl.text = "Current Location is not your home. If you want to change your home location update in Address change tab."
                self.view.ShowWhiteTostWithText(message: "You are not in your home place!!!", Interval: 3)
            }
            else {
                ChangeToGreen()
                self.SuccessGreenLbl.text = "Please click below to update your safe home"
            }
            self.SuccessGreenLbl.textColor = UtilitiesClassSub.color(fromHexString: "#FF0000")
        }
    }
    
    func changeToRed() {
        SafeHomeImg.image = UIImage.init(named: "CenterHomeRed")
        SafeHomeBtn.layer.borderColor = UtilitiesClassSub.color(fromHexString: "#FF0000").cgColor
    }
    
    func ChangeToGreen() {
        SafeHomeImg.image = UIImage.init(named: "CenterHomeGreen")
        SafeHomeBtn.layer.borderColor = UtilitiesClassSub.color(fromHexString: "#7ED321").cgColor
    }
    
    func ChangeToWhite() {
        SafeHomeImg.image = UIImage.init(named: "CenterHome")
        SafeHomeBtn.layer.borderColor = UtilitiesClassSub.color(fromHexString: "#FFFFFF").cgColor
    }
    
    func LoadAddress(Lat:Double,Lon:Double) {
        
        fetchAddressFromLatLon(Lati: Lat, Long: Lon, { (Address, error) in
            if error == nil {
                
                var AddressFilter = ""
                
                for AddObj in Address! {
                    AddressFilter.append("\(AddObj)" + ("\(AddObj)".isEmpty ? "" : ", "))
                }
                
                var FilterAdd = ""
                if AddressFilter != "" && AddressFilter.characters.count > 2 {
                    FilterAdd = AddressFilter.substring(to: AddressFilter.index(AddressFilter.endIndex, offsetBy: -2))
                }
                else {
                    FilterAdd = AddressFilter
                }
                
                
                self.AddressLbl.text = FilterAdd
            }
            else {
                print(error!)
                self.AddressLbl.text = "No Location"
            }
        })
    }

}

extension SafeHomeVC:CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print("Lati:\((locations.last?.coordinate.latitude)!) Long:\((locations.last?.coordinate.longitude)!)")
        if !IsFirstUpdate {
            IsFirstUpdate = true
            LocationManager.stopUpdatingLocation()
            
            let Location:CLLocation = locations.last!
            
            LoadAddress(Lat: Location.coordinate.latitude, Lon: Location.coordinate.longitude)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse || status == .authorizedAlways {
            LocationManager.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("LocationError:===:", error.localizedDescription)
    }
}
