//
//  LeaveRequestVC.swift
//  DriveFindMyCab
//
//  Created by Admin on 01/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit

class LeaveRequestVC: UIViewController {

    
    @IBOutlet weak var FromDateTxt: UITextField!
    @IBOutlet weak var ToDateTxt: UITextField!
    @IBOutlet weak var LeaveTypeTxt: UITextField!
    @IBOutlet weak var ReasonTxt: UITextField!
    
    
    @IBOutlet weak var FromDateLbl: UILabel!
    @IBOutlet weak var ToDateLbl: UILabel!
    @IBOutlet weak var LeaveTypeLbl: UILabel!
    @IBOutlet weak var ReasonLbl: UILabel!
    
//    @IBOutlet weak var scrollViewMain: UIScrollView!
    
    
    var FromDateStr : String!
    var ToDateStr : String!
    
    var FromDatepicker = UIDatePicker()
    var ToDatepicker = UIDatePicker()
    
    var LeaveTypePicker = UIPickerView()
    
    var DateFormat : DateFormatter = {
        let fomat = DateFormatter()
        fomat.dateFormat = "dd-MMM-yyyy"
        return fomat
    }()
    
    var LeaveTypesArr = [String]()
    
    var LeaveTypePickedItem = ""
    
    var LoginResponce:LoginResponce!
    var LoginDetails:LoginDetails!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        LoginDetails = FetchLoginDetails()
        LoginResponce = FetchLoginResponce()
        
        let Toolbar = UIToolbar()
        Toolbar.barStyle = .default
        Toolbar.isTranslucent = true
        Toolbar.tintColor = UIColor.blue
        Toolbar.sizeToFit()
        
        FromDatepicker.datePickerMode = .date;
        
        ToDatepicker.datePickerMode = .date;
        
        FromDateStr = DateFormat.string(from: Date())
        ToDateStr = DateFormat.string(from: Date())
        
        LeaveTypePicker.delegate = self;
        LeaveTypePicker.dataSource = self;
        
        let DoneItem = UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(PickDoneAction(_:)))
        let FlexiItem = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let CancelItem = UIBarButtonItem.init(title: "Cancel", style: .done, target: self, action: #selector(PickCancelAction(_:)))

        
        Toolbar.setItems([CancelItem,FlexiItem,DoneItem], animated: true)
        Toolbar.isUserInteractionEnabled = true
        
        FromDateTxt.inputView = FromDatepicker
        FromDateTxt.inputAccessoryView = Toolbar
        
        ToDateTxt.inputView = ToDatepicker;
        ToDateTxt.inputAccessoryView = Toolbar;
        
        LeaveTypeTxt.inputView = LeaveTypePicker;
        LeaveTypeTxt.inputAccessoryView = Toolbar;
        
        FromDateLbl.isHidden = true
        ToDateLbl.isHidden = true
        LeaveTypeLbl.isHidden = true
        ReasonLbl.isHidden = true
        
        
        FetchLeaveTypes()
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.white
        self.navigationItem.leftBarButtonItem = BackBtnItem
    }
    
    func BackAction() {
        self.navigationController?.popViewController(animated: true)
    }
    
    func FetchLeaveTypes() {
        
        if (Reachability()?.isReachable)! {
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.LeaveTypesFetch, parameterDict: ["EmpCode":"\(LoginDetails.UserID!)"], completion: { (responceDict, success) in
                
                if success {
                    
                    if let Dict = responceDict {
                        let Arr = Dict["data"] as! [[String:AnyObject]]
                        
                        if Arr.count != 0 {
                            for DataDict in Arr {
                                self.LeaveTypesArr.append("\(DataDict["Leavename"]!)")
                            }
                        }

                    }
                    else {
                        self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)

                        print("Error")
                    }
                    
                }
                else {
                    self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)

                    print("Error")
                }
            })
            
        }
        else {
            self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)

            print("Net Error")
        }
    }
    
    // MARK: - Pick Actions {
    
    func PickDoneAction(_ sender:UIBarButtonItem) {
        
        if (FromDateTxt.isFirstResponder) {
            FromDateTxt.text = FromDateStr;
            ToDateTxt.text = "";
        }
        else if (ToDateTxt.isFirstResponder) {
            ToDateTxt.text = ToDateStr;
        }
        else if (LeaveTypeTxt.isFirstResponder) {
            LeaveTypeTxt.text = LeaveTypePickedItem;
        }
        self.view.endEditing(true)
    }
    
    func PickCancelAction(_ sender:UIBarButtonItem) {
        self.view.endEditing(true)
    }

    
    // MARK: - }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func RequestLeaveBtnAction(_ sender:UIButton) {
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.view.frame.origin.y = +64
        })
        
        self.view.endEditing(true)
        
        if self.CheckBeforeRequest() {
            
            
            if (Reachability()?.isReachable)! {
                
                UtilitiesClass.Alert(Title: "Request Leave", Message: "Are you sure" as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "CANCEL"),UtilitiesClass.AlertActionWithSelector(Title: "YES", Selector: #selector(CheckAndSend), Controller: self)], Controller: self)
                
            }
            else {
                UtilitiesClass.Alert(Title: "OOPS..", Message: Constants.NetErrorMsg as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            }
        }
        else {
            
            let charset = NSCharacterSet.init(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
            
            let reasonStr:NSString = self.ReasonTxt.text! as NSString
            
            var errorString = ""
            
            if (self.FromDateTxt.text?.isEmpty)! {
                errorString  = "Please select From Date"
            } else if (self.ToDateTxt.text?.isEmpty)! {
                errorString  = "Please select To Date"
            } else if (self.LeaveTypeTxt.text?.isEmpty)! {
                errorString  = "Please Leave Type"
            }
            else if reasonStr.rangeOfCharacter(from: charset as CharacterSet).location == NSNotFound {
                errorString = "Please enter valid reason"
            }
            
            UtilitiesClass.Alert(Title: "OOPS..", Message: errorString as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            
        }
        
    }
    
    func OkAction() {
        self.navigationController?.popViewController(animated: true)
    }
    func CheckAndSend() {
        
        self.view.StartLoading()
        
        let RequestDict = ["LoginId":"\(LoginDetails.UserID!)","DateOfLeave":"\(FromDateTxt.text!)","ToDate":"\(ToDateTxt.text!)","LeaveReason":"\(ReasonTxt.text!)","LeaveType":"\(LeaveTypeTxt.text!)"]
        
        WebService().callAutoAPI(Suffix: WebServicesUrl.EmployeeLeaveRequest, parameterDict:RequestDict , completion: { (responceDict, success) in
            
            self.view.StopLoading()
            
            if success {
                
                UtilitiesClass.Alert(Title: "Your Request has been registered", Message: "", Actions: [UtilitiesClass.AlertActionWithSelector(Title: "OK", Selector: #selector(self.OkAction), Controller: self)], Controller: self)
                
            }
            else {
                UtilitiesClass.Alert(Title: "OOPS..", Message: Constants.InternalError as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            }
        })
    }
    
    func CheckBeforeRequest() -> Bool {
        
        let charset = NSCharacterSet.init(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
        
        let reasonStr:NSString = self.ReasonTxt.text! as NSString
        
        if (FromDateTxt.text?.isEmpty)! || (ToDateTxt.text?.isEmpty)! || (LeaveTypeTxt.text?.isEmpty)! || reasonStr.rangeOfCharacter(from: charset as CharacterSet).location == NSNotFound
        {
            return false
        }
        else {
            return true
        }
    }
    
    func ChangeLabels() {
        
        if  FromDateTxt.text! == "" {
            FromDateLbl.isHidden = true
        }
        else {
            FromDateLbl.isHidden = false

        }
        
        if  ToDateTxt.text! == "" {
            ToDateLbl.isHidden = true

        }
        else {
            ToDateLbl.isHidden = false

        }
        
        if  LeaveTypeTxt.text! == "" {
            LeaveTypeLbl.isHidden = true

        }
        else {
            LeaveTypeLbl.isHidden = false

        }
        
        if  ReasonTxt.text! == "" {
            ReasonLbl.isHidden = true
        }
        else {
            ReasonLbl.isHidden = false
        }
    }
}

extension LeaveRequestVC:UITextFieldDelegate {
    
    func FromDateChanged(_ fromdate:UIDatePicker) {
        FromDateStr = DateFormat.string(from: fromdate.date)
    }
    
    func ToDateChanged(_ Todate:UIDatePicker) {
        ToDateStr = DateFormat.string(from: Todate.date)
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if (textField == FromDateTxt) {
            
            if FromDateTxt.text == "" {
                FromDatepicker.date = Date();
            }
            else {
                FromDatepicker.date = DateFormat.date(from: FromDateTxt.text!)!
            }
            
            FromDatepicker.minimumDate = Date();
            FromDatepicker.addTarget(self, action: #selector(FromDateChanged(_:)), for: .valueChanged)
            
            FromDateLbl.isHidden = false
        }
        
        if (textField == ToDateTxt) {
            
            if self.FromDateTxt.text! == "" {
                
                self.view.endEditing(true)
                
                UtilitiesClass.Alert(Title: "OOPS..", Message: "Select From date" as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                
            }
            else {
                
                let DateFrom = DateFormat.date(from: FromDateTxt.text!)!
                
                ToDateStr = DateFormat.string(from: DateFrom)
                
                if ToDateTxt.text! == "" {
                    ToDatepicker.date = DateFrom
                    ToDatepicker.minimumDate = DateFrom
                }
                else {
                    ToDatepicker.minimumDate = DateFrom
                    ToDatepicker.date = DateFormat.date(from: ToDateTxt.text!)!
                }
                
                ToDateLbl.isHidden = false
            }
            
            ToDatepicker.addTarget(self, action: #selector(ToDateChanged(_:)), for: .valueChanged)
            

        }
        
        if (textField == LeaveTypeTxt)
        {
            LeaveTypePicker.reloadAllComponents()
            
            if LeaveTypesArr.count != 0 {
                LeaveTypePickedItem = LeaveTypesArr[0]
            }
            
            LeaveTypeLbl.isHidden = false
        }
        
        if textField == ReasonTxt {
            UIView.animate(withDuration: 0.3, animations: { () -> Void in
                self.view.frame.origin.y = -50
//                self.scrollViewMain.setContentOffset(CGPoint.init(x: 0, y: 50), animated: true)
            })
            
            ReasonLbl.isHidden = false

        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        if textField == ReasonTxt {
            UIView.animate(withDuration: 0.3, animations: { () -> Void in
                self.view.frame.origin.y = +64
//                self.scrollViewMain.setContentOffset(CGPoint.init(x: 0, y: 0), animated: true)
            })
        }
        
        ChangeLabels()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    
}
extension LeaveRequestVC:UIPickerViewDelegate,UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return LeaveTypesArr.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return LeaveTypesArr[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        LeaveTypePickedItem = "\(LeaveTypesArr[row])"
    }
}
