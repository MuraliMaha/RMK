//
//  TextFieldSubClass.swift
//  DriveFindMyCab
//
//  Created by SunTelematics on 20/07/18.
//  Copyright © 2018 Suntelematics. All rights reserved.
//

import UIKit

class MyTextFieldWithoutCursor : UITextField {
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
//    override init(frame: CGRect) {
//        super.init(frame: .)
//    }
    
    
    
    override func caretRect(for position: UITextPosition) -> CGRect {
        return .zero
    }
}
