//
//  PlanMyTripListVC.swift
//  DriveFindMyCab
//
//  Created by SunTelematics on 24/05/18.
//  Copyright © 2018 Suntelematics. All rights reserved.
//

import UIKit

class PlanMyTripListVC: UIViewController {

    @IBOutlet weak var planMyTripTableView: UITableView!
    
    @IBOutlet weak var noTripFoundLbl: UILabel!
    
    var planMyTripListArr = [[String:AnyObject]]()
    
    var loginResponse:LoginResponce!
    var loginDetail:LoginDetails!
    
    
    var myDateFormat : DateFormatter = {
        let fomat = DateFormatter()
        fomat.dateFormat = "yyyy-MM-dd"
//        fomat.dateFormat = "dd-MMM-yyyy"
        return fomat
    }()
    
    var currentDate : String!
    
    @IBOutlet var confirmationView: UIView!
    var tappedBtnCellTag:Int!
    
    var staticArr = [[String:AnyObject]]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        planMyTripTableView.delegate = self
        planMyTripTableView.dataSource = self
        
        loginDetail = FetchLoginDetails()
        loginResponse = FetchLoginResponce()
        
        //        shiftChangeRequestTableView.tableFooterView = UIView.init(frame: CGRect.zero)
        
        self.currentDate = myDateFormat.string(from: Date())
        
        let RightItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "ic_add"), to: CGSize.init(width: 30, height: 30)), style: .done, target: self, action: #selector(RightBarItem))
        RightItem.tintColor = UIColor.white
        self.navigationItem.rightBarButtonItem = RightItem
        
        createStaticData()
    }
    
    
    func createStaticData(){
        staticArr = [
        [
                "Date":"2018-07-17",
                "SHIFTTIME": "19:00",
                "SHIFTTYPE": "Logout",
                "ID": 843538,
                "Status": "PENDING"
            ],
        [
            "Date": "2018-07-17",
            "SHIFTTIME": "9:30",
            "SHIFTTYPE": "Login",
            "ID": 843537,
            "Status": "PENDING"
            ],
        [
            "Date": "2018-07-18",
            "SHIFTTIME": "18:00",
            "SHIFTTYPE": "Logout",
            "ID": 843540,
            "Status": "PENDING"
            ],
        [
            "Date": "2018-07-18",
            "SHIFTTIME": "8:30",
            "SHIFTTYPE": "Login",
            "ID": 843539,
            "Status": "PENDING"
            ],
        [
            "Date": "2018-07-19",
            "SHIFTTIME": "18:00",
            "SHIFTTYPE": "Logout",
            "ID": 843542,
            "Status": "APPROVED"
            ],
        [
            "Date": "2018-07-19",
            "SHIFTTIME": "8:30",
            "SHIFTTYPE": "Login",
            "ID": 843541,
            "Status": "APPROVED"
            ]
            ] as [[String : AnyObject]]
    }
    
    func RightBarItem() {
        
        if (Reachability()?.isReachable)!{
            let request = self.storyboard?.instantiateViewController(withIdentifier: "PlanMyTripVCSBID") as! PlanMyTripVC
            request.selectedDateStr = self.currentDate
            request.mode = "0"
            
            self.navigationController?.pushViewController(request, animated: true)
        } else {
            self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        Timer.scheduledTimer(timeInterval: 0.2, target: self, selector: #selector(CallServiceToFetchShiftRequestList), userInfo: nil, repeats: false)
    }
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func CallServiceToFetchShiftRequestList () {
        if (Reachability()?.isReachable)! {
            UIApplication.shared.keyWindow?.StartLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.DriveShiftChangeList, parameterDict: ["EmpId":"\(loginResponse.Employeeid!)"], completion: { (responceDict, success) in
                UIApplication.shared.keyWindow?.StopLoading()
              
                self.planMyTripListArr.removeAll()
                if success {
                    if let Dict = responceDict {
                        let Arr = Dict["data"] as! [[String:AnyObject]]
                        if Arr.count > 0 {
                            self.planMyTripListArr = Arr
                            self.planMyTripTableView.isHidden = false
                        }
                        else {
//                            print("Error")
//                            self.view.ShowWhiteTostWithText(message: "No Requests found", Interval: 2)
                            self.planMyTripTableView.isHidden = true
                        }
                        self.planMyTripTableView.reloadData()
                    }
                    else {
                        self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                        
                        print("Error")
                    }
                }
                else {
                    self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                    
                    print("Error")
                }
                
                
                /*
                //code for static data
                let Arr = self.staticArr
                if Arr.count > 0 {
                    self.planMyTripListArr = Arr
                    self.planMyTripTableView.isHidden = false
                }else{
                    self.planMyTripTableView.isHidden = true
                }
                self.planMyTripTableView.reloadData()
                
                */
                
                
                
            })
            
        }
        else {
            self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
            
            print("Net Error")
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension PlanMyTripListVC : UITableViewDelegate , UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return planMyTripListArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "PlanMyTripCellID", for: indexPath) as! ShiftChangeListCellClass
        
        
      /*
        cell.shiftDateLbl.text = "\(planMyTripListArr[indexPath.row]["Date"]!)"
//        cell.shiftTimeLbl.text = "\(planMyTripListArr[indexPath.row]["Shifttime"]!)"
        
        var loginLogoutTimingsArr = planMyTripListArr[indexPath.row]["ShiftTimings"]?.components(separatedBy:"|")
        
        if ((loginLogoutTimingsArr?.count)! % 2) == 0 {
            
            var loginTimingsArr = loginLogoutTimingsArr![0].components(separatedBy:",")
            var logoutTimingsArr = loginLogoutTimingsArr![1].components(separatedBy:",")
            
            cell.loginTimeLbl.text = loginTimingsArr[1]
            cell.logoutTimeLbl.text = logoutTimingsArr[1]
        }else{
            cell.loginTimeLbl.text = ""
            cell.logoutTimeLbl.text = ""
        }
        
        cell.statusLbl.text = "\(planMyTripListArr[indexPath.row]["Status"]!)"
 */
        
        cell.shiftDateLbl.text = "\(planMyTripListArr[indexPath.row]["DATE"]!)"
        cell.shiftTypeLbl.text = "\(planMyTripListArr[indexPath.row]["SHIFTTYPE"]!)"
        cell.shiftTimeLbl.text = "\(planMyTripListArr[indexPath.row]["SHIFTTIME"]!)"
        cell.statusLbl.text = "\(planMyTripListArr[indexPath.row]["Status"]!)"
        
        /*
        let date = NSDate()
        let gregCal:NSCalendar = NSCalendar(calendarIdentifier: NSCalendar.Identifier.gregorian)!
        let gregTime:NSDateComponents = gregCal.components(([.year, .month, .day, .hour, .minute]), from: date as Date) as NSDateComponents
        
        let SelectedDateStr = datetextfield.text!
        let selectedDate = dateFormatter.date(from: SelectedDateStr)
        
        let selectedGregTime = gregCal.components(([.year, .month, .day, .hour, .minute]), from: selectedDate!)
        
        if selectedGregTime.year == gregTime.year && selectedGregTime.month == gregTime.month && selectedGregTime.day == gregTime.day {
            timepicker.minimumDate = date as Date
        } */
        
        let todaysDate = NSDate()
        let gregCal : NSCalendar = NSCalendar(calendarIdentifier: NSCalendar.Identifier.gregorian)!
        let gregCalComponents : NSDateComponents = gregCal.components(([.year,.month,.day]), from: todaysDate as Date) as NSDateComponents
        
        let selectedDateStr = cell.shiftDateLbl.text!
        let selectedDate = self.myDateFormat.date(from: selectedDateStr)
        
        let selectedDateGregComponents = gregCal.components(([.year,.month,.day]), from: selectedDate!)
        
        if selectedDateGregComponents.year == gregCalComponents.year && selectedDateGregComponents.month == gregCalComponents.month && selectedDateGregComponents.day == gregCalComponents.day {
            cell.editBtn.isHidden = false
        }else{
            if (selectedDate?.compare(todaysDate as Date) == .orderedDescending ){
                cell.editBtn.isHidden = false
            }else{
                cell.editBtn.isHidden = true
            }
            
        }
        
//        if (selectedDate?.compare(todaysDate as Date) == .orderedAscending){
//            if (selectedDate?.compare(todaysDate as Date) != .orderedSame){
//                cell.editBtn.isHidden = true
//            }
//            else{
//                cell.editBtn.isHidden = false
//            }
//        }else{
//            cell.editBtn.isHidden = false
//        }
        
        
        
        
        cell.editBtn.addTarget(self, action: #selector(self.editButtonTapped), for: .touchUpInside)
        cell.editBtn.tag = indexPath.row
        
        cell.deleteBtn.addTarget(self, action: #selector(self.deleteButtonTapped), for: .touchUpInside)
        cell.deleteBtn.tag = indexPath.row
        
        cell.selectionStyle = .none
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 154
    }
    func editButtonTapped(_sender : UIButton ){
//        selectedStructInActiveVC = activeVehicleArray[_sender.tag]
        let controller = self.storyboard?.instantiateViewController(withIdentifier: "PlanMyTripVCSBID") as! PlanMyTripVC
//        controller.selectedStruct = selectedStructInActiveVC
        controller.mode = "1"
        controller.selectedDateStr = "\(planMyTripListArr[_sender.tag]["DATE"]!)"
        controller.selectedShiftType = "\(planMyTripListArr[_sender.tag]["SHIFTTYPE"]!)"
        controller.selectedShiftTime = "\(planMyTripListArr[_sender.tag]["SHIFTTIME"]!)"
        self.navigationController?.pushViewController(controller, animated: true)
        
    }
    func deleteButtonTapped(_sender : UIButton ){
        
//        let controller = self.storyboard?.instantiateViewController(withIdentifier: "PlanMyTripVCSBID") as! PlanMyTripVC
//        controller.selectedDateStr = "\(planMyTripListArr[_sender.tag]["Date"]!)"
//        controller.mode = "1"
//        self.navigationController?.pushViewController(controller, animated: false)
        print("delete button tapped....")
        self.tappedBtnCellTag = _sender.tag
        showConfirmation()
//        UtilitiesClass.Alert(Title: "Delete Trip Request", Message: "Are you sure?", Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "CANCEL"),UtilitiesClass.AlertActionWithSelector(Title: "OK", Selector: #selector(deleteOkAction(_:)), Controller: self)], Controller: self)
    }
    
    
//    func deleteOkAction(_ sender:UIButton) {
//        callDeleteService(requestId: "\(planMyTripListArr[sender.tag]["Id"]!)")
//    }
    
    //MARK: - ConfirmationView
    func showConfirmation(){
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        
        BackView.center = (window?.center)!
        
        window?.addSubview(BackView)
        confirmationView.center = BackView.center
        
        BackView.addSubview(confirmationView!)
        
        let GuardianTap = UITapGestureRecognizer.init(target: self, action: #selector(TapEditGuardianView(_:)))
        GuardianTap.numberOfTapsRequired = 1
        BackView.addGestureRecognizer(GuardianTap)
        
        confirmationView.alpha = 0
        
        
        UIView.animate(withDuration: 0.5) {
            self.confirmationView.alpha = 1
        }
        
    }
    func TapEditGuardianView(_ responder:UITapGestureRecognizer) {
        
        
        let Point = responder.location(in: confirmationView.superview!)
        let Frame = confirmationView.frame
        
        if !Frame.contains(Point) {
            
            UIView.animate(withDuration: 0.3, animations: {
                self.confirmationView.alpha = 0
            }) { (yes) in
                if yes {
                    self.confirmationView.alpha = 1
                    self.confirmationView.superview?.removeFromSuperview()
                }
            }
        }
        
    }
    
    
    
    @IBAction func confirmationCancelTapped(_ sender: UIButton) {
        closeConfirmationView()
    }
    
    
    @IBAction func confirmationOKTapped(_ sender: UIButton) {
        closeConfirmationView()
//        callDeleteService(requestId: "\(planMyTripListArr[self.tappedBtnCellTag]["Id"]!)")
        callDeleteService(requestId: "\(planMyTripListArr[self.tappedBtnCellTag]["ID"]!)", date: "\(planMyTripListArr[self.tappedBtnCellTag]["DATE"]!)")
    }
    
    func closeConfirmationView() {
        UIView.animate(withDuration: 0.3, animations: {
            self.confirmationView.alpha = 0
        }) { (yes) in
            if yes {
                self.confirmationView.alpha = 1
                self.confirmationView.superview?.removeFromSuperview()
            }
        }
    }
    
    func callDeleteService(requestId : String,date : String){
        if (Reachability()?.isReachable)! {
            UIApplication.shared.keyWindow?.StartLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.DriveCancelRequest, parameterDict: ["CancelType":"3","RequestId" : requestId,"DateTime": date,"EmpCode":"\(loginResponse.Empcode!)"], completion: { (responceDict, success) in
                UIApplication.shared.keyWindow?.StopLoading()
                if success {
                    
                    if let Dict = responceDict {
                        let Arr = Dict["data"] as! [[String:AnyObject]]
                        //                        if Arr.count > 0 {
                        //                            self.planMyTripListArr = Arr
                        //                            self.planMyTripTableView.isHidden = false
                        //                        }
                        //                        else {
                        //                            print("Error")
                        //                            self.view.ShowWhiteTostWithText(message: "No Requests found", Interval: 2)
                        //                            self.planMyTripTableView.isHidden = true
                        //                        }
                        
                        
                        
                        if Arr.count > 0 {
                            self.view.ShowWhiteTostWithText(message:"\(Arr[0]["Response"]!)", Interval: 2)
                            self.CallServiceToFetchShiftRequestList()
                            
                        }
                        
                        //                        self.planMyTripTableView.reloadData()
                    }
                    else {
                        self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                        
                        print("Error")
                    }
                }
                else {
                    self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                    
                    print("Error")
                }
            })
            
        }
        else {
            self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
            
            print("Net Error")
        }
    }
    
    /*
    func callDeleteService(requestId : String){
        if (Reachability()?.isReachable)! {
            UIApplication.shared.keyWindow?.StartLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.DriveCancelRequest, parameterDict: ["CancelType":"3","RequestId" : requestId,"DateTime": self.currentDate,"EmpCode":"\(loginDetail.UserID!)"], completion: { (responceDict, success) in
                UIApplication.shared.keyWindow?.StopLoading()
                if success {
                    
                    if let Dict = responceDict {
                        let Arr = Dict["data"] as! [[String:AnyObject]]
//                        if Arr.count > 0 {
//                            self.planMyTripListArr = Arr
//                            self.planMyTripTableView.isHidden = false
//                        }
//                        else {
//                            print("Error")
//                            self.view.ShowWhiteTostWithText(message: "No Requests found", Interval: 2)
//                            self.planMyTripTableView.isHidden = true
//                        }
                        
                        
                        
                        if Arr.count > 0 {
                            self.view.ShowWhiteTostWithText(message:"\(Arr[0]["Response"]!)", Interval: 2)
                            self.CallServiceToFetchShiftRequestList()
                            
                        }
                        
//                        self.planMyTripTableView.reloadData()
                    }
                    else {
                        self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                        
                        print("Error")
                    }
                }
                else {
                    self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                    
                    print("Error")
                }
            })
            
        }
        else {
            self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
            
            print("Net Error")
        }
    }
    */
}
class ShiftChangeListCellClass : UITableViewCell {
    
    @IBOutlet weak var shiftDateLbl: UILabel!
    @IBOutlet weak var editBtn: UIButton!
    /*
    @IBOutlet weak var loginTimeLbl: UILabel!
    @IBOutlet weak var logoutTimeLbl: UILabel!
    */
    @IBOutlet weak var shiftTypeLbl: UILabel!
    @IBOutlet weak var shiftTimeLbl: UILabel!
    
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var deleteBtn: UIButton!

    
}
