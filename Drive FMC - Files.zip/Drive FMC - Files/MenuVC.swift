//
//  MenuVC.swift
//  DriveFindMyCab
//
//  Created by Admin on 01/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit

class MenuVC: UIViewController {

    
    let MenusArray : [[String:String]] = {
       let Arr = [["Title":"Home","Image":"home_slide","Identifier":"NOID"],
                  ["Title":"My Rides","Image":"drive_menu","Identifier":"MyRidesVC"],
                  ["Title":"Set Alarm","Image":"alarm_slide","Identifier":"SetAlarmVC"],
                  ["Title":"Cab Request","Image":"taxi_slide","Identifier":"AdhocRequestListVC"],
                  ["Title":"Leave Request","Image":"edit","Identifier":"LeaveRequestListVC"],
//                  ["Title":"Shift Request","Image":"alarm_slide","Identifier":"ShiftRequestListVCSBID"],
                  ["Title":"Plan My Trip","Image":"alarm_slide","Identifier":"PlanMyTripListVCSBID"],
                  ["Title":"My Location","Image":"myloc_slide","Identifier":"MyLocationVC"],
                  ["Title":"Profile","Image":"user_slide","Identifier":"ProfileVC"],
                  ["Title":"Help Desk","Image":"helpdesk_slide","Identifier":"NOID"],
                  ["Title":"Logout","Image":"logout_slide","Identifier":"NOID"]]
        return Arr
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func BackMenuAction(_ sender:UIButton) {
        sideMenuController?.hideLeftView(animated: true, completionHandler: nil)
    }
}

extension MenuVC: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return MenusArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuCell", for: indexPath) as! MenuCell
        
        cell.MenuImage.image = UIImage.init(named: MenusArray[indexPath.row]["Image"]!)
        cell.MenuName.text = MenusArray[indexPath.row]["Title"]!
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
        tableView.deselectRow(at: indexPath, animated: true)
        
        if indexPath.row == 0 {
            
            sideMenuController?.hideLeftView(animated: true, completionHandler: nil)
            
        }
        else if indexPath.row == MenusArray.count-1 || indexPath.row == MenusArray.count-2 {
            
            sideMenuController?.hideLeftView(animated: true, completionHandler: nil)
            
            if indexPath.row == MenusArray.count-1 {
                NotificationCenter.default.post(name: NotificationStruct.LogOutNotif, object: nil)
            }
            else {
                NotificationCenter.default.post(name: NotificationStruct.HelpDeskNotif, object: nil)
            }
        }
        else {
            
            let controller = self.storyboard?.instantiateViewController(withIdentifier: MenusArray[indexPath.row]["Identifier"]!)
            let navigationController = sideMenuController?.rootViewController as! UINavigationController
            navigationController.pushViewController(controller!, animated: true)
            
            sideMenuController?.hideLeftView(animated: true, completionHandler: nil)
        }
    }
    
}

class MenuCell: UITableViewCell {
    @IBOutlet var MenuImage:UIImageView!
    @IBOutlet var MenuName:UILabel!
}
