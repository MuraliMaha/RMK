//
//  TripTrackVC.swift
//  DriveFindMyCab
//
//  Created by Admin on 01/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit
import GoogleMaps
import GooglePlaces
import QRCodeReader
import AVFoundation

class TripTrackVC: UIViewController {
    
//    @IBOutlet weak var ViewForFloatingBtn: UIView!
    @IBOutlet var TrackMapView: GMSMapView!
    
    @IBOutlet var NoTripView: UIView!
    @IBOutlet var NoTripViewLbl: UILabel!
    @IBOutlet var VehicleClickedView: UIView!
    
    @IBOutlet var VehicleNumberLbl: UILabel!
    @IBOutlet var ShiftTypeLbl: UILabel!
    
    @IBOutlet var CallDriver: UILabel!
    
    var DistanceMarker: DistanceCreateMarker!
    
    
    
    var LoginResponce:LoginResponce!
    var LoginDetails:LoginDetails!
    
    var DriveBookingResponce:DriveLoginResponce!
    
    var TripTrackTimer = Timer()
    
    var MinutesTimer = Timer()
    
    var CurrentLocation = CLLocation()
    var LocationManager = CLLocationManager()
    
    var IsFirstUpdate = true
    
    var FloatButton = VCFloatingActionButton()
    
    lazy var reader: QRCodeReaderViewController = {
        let builder = QRCodeReaderViewControllerBuilder {
            $0.reader = QRCodeReader(metadataObjectTypes: [AVMetadataObjectTypeQRCode], captureDevicePosition: .back)
            $0.showTorchButton = true
        }
        
        return QRCodeReaderViewController(builder: builder)
    }()
    
    var currentAddress : String!
    
    var companyName = "Murali"
    var gender = "male"
    @IBAction func CallDriverAction() {
//        if LoginResponce.CompanyName == "HPE"{
        if companyName == "HPE" {
//            callMyOperator()
        }else{
            if ((NSString.init(string:CallDriver.text!)).rangeOfCharacter(from: CharacterSet.decimalDigits.inverted)).location == NSNotFound {
                UIApplication.shared.openURL(URL.init(string: "tel://\(CallDriver.text!)")!)
            }
            else {
                UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Invalid Helpdesk Number", Interval: 3)
            }
        }
    }
    
    /*
    func callMyOperator(){
//        if LoginResponce.gender == "male"{
        if self.gender == "male"{
            callMyOperatorURLWith(number: "\(CallDriver.text!)")
        }else{
            callMyOperatorURLWith(number: LoginResponce.HelpDeskno!)
        }
    }
    
    func callMyOperatorURLWith(number :String){
        print("Number (driver/calldesk) to call ....",number)
        
        let requestDict = ["token":"a22fbf393c5c7dc74e02ad89e5c0d074","customer_number" :number,"customer_cc": "91","support_user_id":"5b5728a25ad4b722"]
        
        WebService().HTTP_POST_WebServiceMethod(parameterDict: requestDict) { (FullResponse, ResponseStatus) in
            if ResponseStatus{
                let fullResponseDict = FullResponse as! [String:AnyObject]
                print("fullResponse =",fullResponseDict)
            }else{
                print("ResponseStatus is false")
            }
        }
        
    } */
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        DispatchQueue.main.async {
            self.LoginDetails = FetchLoginDetails()
            self.LoginResponce = FetchLoginResponce()
            
            self.DriveBookingResponce = FetchDriveResponce()
            
            self.GetTrackVehicle()
//            self.GetTrackVehicleAbhi()
        }
        
        // Do any additional setup after loading the view.
        TrackMapView.isMyLocationEnabled = true;
        TrackMapView.mapType = .normal;
        TrackMapView.settings.compassButton = true;
        
        
        
        
        switch UIScreen.main.nativeBounds.height {
        case 960:
             print(".iPhone4_4S")
            FloatButton = VCFloatingActionButton.init(frame: CGRect.init(x: UIScreen.main.bounds.size.width - 50 - 16, y: VehicleClickedView.frame.minY - 50 - 150, width: 50, height: 50), normalImage: UIImage.init(named: "plus")!, andPressedImage: UIImage.init(named: "cross")!, withScrollview: nil)
        case 1136:
            print("iPhones_5_5s_5c_SE")
            FloatButton = VCFloatingActionButton.init(frame: CGRect.init(x: UIScreen.main.bounds.size.width - 50 - 16, y: VehicleClickedView.frame.minY - 50 - 100, width: 50, height: 50), normalImage: UIImage.init(named: "plus")!, andPressedImage: UIImage.init(named: "cross")!, withScrollview: nil)
            
        case 1334:
            print ("iPhones_6_6s_7_8")
            FloatButton = VCFloatingActionButton.init(frame: CGRect.init(x: UIScreen.main.bounds.size.width - 50 - 16, y: VehicleClickedView.frame.minY - 50 - 2, width: 50, height: 50), normalImage: UIImage.init(named: "plus")!, andPressedImage: UIImage.init(named: "cross")!, withScrollview: nil)
            
        case 1920, 2208:
            print ("iPhones_6Plus_6sPlus_7Plus_8Plus")
            FloatButton = VCFloatingActionButton.init(frame: CGRect.init(x: UIScreen.main.bounds.size.width - 50 - 16, y: 500, width: 50, height: 50), normalImage: UIImage.init(named: "plus")!, andPressedImage: UIImage.init(named: "cross")!, withScrollview: nil)
        case 2436:
            print ("iPhoneX")
            FloatButton = VCFloatingActionButton.init(frame: CGRect.init(x: UIScreen.main.bounds.size.width - 50 - 16, y: 540, width: 50, height: 50), normalImage: UIImage.init(named: "plus")!, andPressedImage: UIImage.init(named: "cross")!, withScrollview: nil)
        default:
            print("unknown")
            FloatButton = VCFloatingActionButton.init(frame: CGRect.init(x: UIScreen.main.bounds.size.width - 50 - 16, y: VehicleClickedView.frame.minY - 50 - 2, width: 50, height: 50), normalImage: UIImage.init(named: "plus")!, andPressedImage: UIImage.init(named: "cross")!, withScrollview: nil)
        }
        
        
//        FloatButton = VCFloatingActionButton.init(frame: CGRect.init(x: UIScreen.main.bounds.size.width - 50 - 16, y: VehicleClickedView.frame.minY - 50 - 150, width: 50, height: 50), normalImage: UIImage.init(named: "plus")!, andPressedImage: UIImage.init(named: "cross")!, withScrollview: nil)

//UIScreen.main.bounds.size.height - (80 + 50 + 30)

//        FloatButton = VCFloatingActionButton.init(frame: CGRect.init(x: self.ViewForFloatingBtn.frame.origin.x, y:self.ViewForFloatingBtn.frame.origin.y , width: 50, height: 50), normalImage: UIImage.init(named: "plus")!, andPressedImage: UIImage.init(named: "cross")!, withScrollview: nil)

//        FloatButton = VCFloatingActionButton.init(frame: CGRect.init(x: self.ViewForFloatingBtn.frame.origin.x,y: self.ViewForFloatingBtn.frame.origin.y, width: 50, height: 50), normalImage: UIImage.init(named: "plus")!, andPressedImage: UIImage.init(named: "cross")!, withScrollview: nil)
        
        FloatButton.imageArray = ["UserNotif","QRCodemobile"];
        FloatButton.labelArray = ["Employee Authentication","QR Authentication"];
//        FloatButton.bgView.backgroundColor = UIColor.lightGray
        
        FloatButton.hideWhileScrolling = true;
        FloatButton.delegate = self;
        self.view.addSubview(FloatButton)
//        self.ViewForFloatingBtn.addSubview(FloatButton)
        
        FloatButton.isHidden = true
        
        LocationManager.delegate = self
        LocationManager.requestWhenInUseAuthorization()
        
        DeallocClickedView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        TripTrackTimer = Timer.scheduledTimer(timeInterval: 10, target: self, selector: #selector(GetTrackVehicle), userInfo: nil, repeats: true)
//        TripTrackTimer = Timer.scheduledTimer(timeInterval: 10, target: self, selector: #selector(GetTrackVehicleAbhi), userInfo: nil, repeats: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        TripTrackTimer.invalidate()
        MinutesTimer.invalidate()
        LocationManager.stopUpdatingLocation()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func ChangeText() {
        
        if VehicleDetailsObj != nil {
            NoTripViewLbl.text = "Please click on Vehicle icon to show details"
        }
        else {
            NoTripViewLbl.text = "Currently No Trips has been scheduled"
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    @IBAction func GoToMyLocation(_ sender:UIButton) {
        let Camera = GMSCameraPosition.camera(withTarget: (LocationManager.location?.coordinate)!, zoom: 15)
        TrackMapView.animate(to: Camera)
    }
    
    var VehicleDetailsObj: VehicleMarker?
    
    func SendDetails(TripID:String,ShiftType:String,Data:String) {
        let FbObj = self.storyboard?.instantiateViewController(withIdentifier: "TripFeedbackVC") as! TripFeedbackVC
        FbObj.TripID = TripID
        FbObj.TripDate = Data
        FbObj.TripShift = ShiftType
        self.present(FbObj, animated: true, completion: nil)
    }
    
    /*
     CmdDict = ["cmd": "$SUNEMPVEHLOC|corporate1146|5BDE3458-5A35-4431-BC91-87D558AEB85C|#"]
     
     {"Status":"true","EmpId":"corporate1146","VehicleDetails":[{"Vehicleno":"KA99Z123","Lat":"12.94","Lon":"77.6258","Speed":"0","Direction":"0.0","DriverDetails":"DRIVER MICRO/7349642682","ShiftType":"Drop","TripCode":"CoOT_D7349642682_130718143449","Status":"-1","DriverDeviceToken":"85273f7f-8d20-4e05-9fd8-69755836dc9d","LoginOtp":"146","LogoutOtp":"1234"}]}
     
     
     if Status is -1 then the state is yet to start
     if Status is 1 then the state is boarded
     
    */
    
    
    func GetTrackVehicle() {
        
        if (Reachability()?.isReachable)! {
            
            UIApplication.shared.isNetworkActivityIndicatorVisible = true
            
            let CmdDict = ["cmd":"$SUNEMPVEHLOC|\(LoginDetails.UserID!)|\(LoginDetails.DeviceIMEI!)|#"]
            print("CmdDict =",CmdDict)
            WebService().callAutoAPI(Suffix: WebServicesUrl.GetLocationofShuttleServiceIOS, parameterDict: CmdDict, completion: { (dataDict, success) in
                
                UIApplication.shared.isNetworkActivityIndicatorVisible = false
                
                if success {
                    // handel of data
                    if let Dict = dataDict {
                        
                        if !("\(Dict["Status"]!)".toBool()!) {
                            print(Dict)
                            
                            self.DeallocClickedView()
                            
                            self.VehicleDetailsObj?.map = nil
                            self.VehicleDetailsObj = nil
                            
                            if "\(Dict["VehicleDetails"]!)" == "NOData" {
                                if "\(Dict["RatingStatus"]!)".toBool()! {
                                    
                                    let TripId = "\(Dict["DailyTripMasterId"]!)"
                                    let tripDate = "\(Dict["TripDate"]!)"
                                    let ShiftType = "\(Dict["ShiftType"]!)"
                                    
                                    self.SendDetails(TripID: TripId, ShiftType: ShiftType, Data: tripDate)
                                }
                            }
                            
                        }
                        else {
                            
                            if Dict.keys.contains("VehicleDetails") {
                                
                                if (Dict["VehicleDetails"]!) is [[String:AnyObject]] {
                                    if (Dict["VehicleDetails"] as! [[String:AnyObject]]).count > 0 {
                                        
                                        let VihicleDict = (Dict["VehicleDetails"] as! [[String:AnyObject]])[0]
                                        
                                        
                                        var Coordinates = CLLocationCoordinate2D()
                                        
                                        print(VihicleDict)
                                        
                                        if self.VehicleDetailsObj != nil {
                                            if self.VehicleDetailsObj?.Vehicle.Vehicleno! == "\(VihicleDict["Vehicleno"]!)" {
                                                var VehicleStruct = self.VehicleDetailsObj?.Vehicle!
                                                VehicleStruct?.Direction = Double(UtilitiesClassSub.removeLeadingandTralingSpace("\(VihicleDict["Direction"]!)")!)!
                                                
                                                VehicleStruct?.DriverDetails = "\(VihicleDict["DriverDetails"]!)"
                                                VehicleStruct?.DriverDeviceToken = "\(VihicleDict["DriverDeviceToken"]!)"
                                                
                                                VehicleStruct?.Lat = Double("\(VihicleDict["Lat"]!)")!
                                                VehicleStruct?.Lon = Double("\(VihicleDict["Lon"]!)")!
                                                
                                                VehicleStruct?.ShiftType = "\(VihicleDict["ShiftType"]!)"
                                                
                                                VehicleStruct?.Speed = Double("\(VihicleDict["Speed"]!)")!
                                                
                                                
                                                VehicleStruct?.Status = "\(VihicleDict["Status"]!)"
                                                VehicleStruct?.TripCode = "\(VihicleDict["TripCode"]!)"
                                                VehicleStruct?.Vehicleno = "\(VihicleDict["Vehicleno"]!)"
                                                
                                                self.VehicleDetailsObj?.Vehicle = VehicleStruct!
                                                self.VehicleDetailsObj?.position = CLLocationCoordinate2DMake((VehicleStruct?.Lat!)!,(VehicleStruct?.Lon!)!)
                                                self.VehicleDetailsObj?.rotation = (VehicleStruct?.Direction!)! - 90
                                                
                                                Coordinates = CLLocationCoordinate2D.init(latitude: (VehicleStruct?.Lat!)!, longitude: (VehicleStruct?.Lon!)!)
                                                
                                                print("Status =======",(self.VehicleDetailsObj?.Vehicle.Status)!)
                                                if (self.VehicleDetailsObj?.Vehicle.Status)! != "-1" {
                                                    if self.MinutesTimer.isValid {
                                                        self.MinutesTimer.invalidate()
                                                        self.DistanceMarker?.map = nil
                                                        self.DistanceMarker = nil
                                                    }
                                                }
                                            }
                                            else {
                                                
                                                self.VehicleDetailsObj?.map = nil
                                                self.VehicleDetailsObj = nil
                                                
                                                var VehicleStruct = VehicleDetails()
                                                VehicleStruct.Direction = Double(UtilitiesClassSub.removeLeadingandTralingSpace("\(VihicleDict["Direction"]!)")!)!
                                                
                                                VehicleStruct.DriverDetails = "\(VihicleDict["DriverDetails"]!)"
                                                VehicleStruct.DriverDeviceToken = "\(VihicleDict["DriverDeviceToken"]!)"
                                                
                                                VehicleStruct.Lat = Double("\(VihicleDict["Lat"]!)")!
                                                VehicleStruct.Lon = Double("\(VihicleDict["Lon"]!)")!
                                                
                                                VehicleStruct.ShiftType = "\(VihicleDict["ShiftType"]!)"
                                                
                                                VehicleStruct.Speed = Double("\(VihicleDict["Speed"]!)")!
                                                
                                                
                                                VehicleStruct.Status = "\(VihicleDict["Status"]!)"
                                                VehicleStruct.TripCode = "\(VihicleDict["TripCode"]!)"
                                                VehicleStruct.Vehicleno = "\(VihicleDict["Vehicleno"]!)"
                                                
                                                self.VehicleDetailsObj = VehicleMarker.init(Vehicle: VehicleStruct)
                                                self.VehicleDetailsObj?.map = self.TrackMapView
                                                
                                                Coordinates = CLLocationCoordinate2D.init(latitude: VehicleStruct.Lat!, longitude: VehicleStruct.Lon!)
                                                
                                                print("Status =======",(self.VehicleDetailsObj?.Vehicle.Status)!)
                                                if self.VehicleDetailsObj?.Vehicle.Status != "-1" {
                                                    if self.MinutesTimer.isValid {
                                                        self.MinutesTimer.invalidate()
                                                        self.DistanceMarker?.map = nil
                                                        self.DistanceMarker = nil
                                                    }
                                                }
                                            }
                                        }
                                        else {
                                            
                                            var VehicleStruct = VehicleDetails()
                                            VehicleStruct.Direction = Double(UtilitiesClassSub.removeLeadingandTralingSpace("\(VihicleDict["Direction"]!)")!)!
                                            
                                            VehicleStruct.DriverDetails = "\(VihicleDict["DriverDetails"]!)"
                                            VehicleStruct.DriverDeviceToken = "\(VihicleDict["DriverDeviceToken"]!)"
                                            
                                            VehicleStruct.Lat = Double("\(VihicleDict["Lat"]!)")!
                                            VehicleStruct.Lon = Double("\(VihicleDict["Lon"]!)")!
                                            
                                            VehicleStruct.ShiftType = "\(VihicleDict["ShiftType"]!)"
                                            
                                            VehicleStruct.Speed = Double("\(VihicleDict["Speed"]!)")!
                                            
                                            
                                            VehicleStruct.Status = "\(VihicleDict["Status"]!)"
                                            VehicleStruct.TripCode = "\(VihicleDict["TripCode"]!)"
                                            VehicleStruct.Vehicleno = "\(VihicleDict["Vehicleno"]!)"
                                            
                                            self.VehicleDetailsObj = VehicleMarker.init(Vehicle: VehicleStruct)
                                            self.VehicleDetailsObj?.map = self.TrackMapView
                                            
                                            Coordinates = CLLocationCoordinate2D.init(latitude: VehicleStruct.Lat!, longitude: VehicleStruct.Lon!)
                                            
                                            print("Status =======",(self.VehicleDetailsObj?.Vehicle.Status)!)
                                            if (self.VehicleDetailsObj?.Vehicle.Status)! != "-1" {
                                                if self.MinutesTimer.isValid {
                                                    self.MinutesTimer.invalidate()
                                                    self.DistanceMarker?.map = nil
                                                    self.DistanceMarker = nil
                                                }
                                            }
                                        }
                                        
                                        
                                        let Camera = GMSCameraPosition.camera(withTarget: Coordinates, zoom: 15)
                                        self.TrackMapView.animate(to: Camera)
                                        
                                    }
                                    else {
                                        print("Not a vehicle")
                                    }
                                }
                                else {
                                    print("Not a vehicle")
                                    
                                }
                                
                            }
                            else {
                                print("Not a vehicle")
                            }
                        }
                        
                    }
                    else {
                        self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                    }
                }
                else {
                    self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                }
                
                self.ChangeText()
            })
            
        }
        else {
            self.view.ShowBlackTostWithText(message: "Internet Connection Not Found!", Interval: 2)
        }
        
    }
    
    
    
    /*
     CmdDict = ["cmd": "$SUNEMPVEHLOC|corporate1155|5BDE3458-5A35-4431-BC91-87D558AEB85C|#"]
    ["Status": false, "RatingStatus": false, "ShiftType": , "DailyTripMasterId": 0, "CallMaskStatus": , "TripDate": N/A, "CallMaskURL": https://ibs.ideacellular.com/CapsApi/api/CAPSData/, "VehicleDetails": NOData] */
    
    /*
    func GetTrackVehicleAbhi(){
        if (Reachability()?.isReachable)! {
            
            UIApplication.shared.isNetworkActivityIndicatorVisible = true
            
            let CmdDict = ["cmd":"$SUNEMPVEHLOC|\(LoginDetails.UserID!)|\(LoginDetails.DeviceIMEI!)|#"]
            print("CmdDict =",CmdDict)
            WebService().callAutoAPI(Suffix: WebServicesUrl.ShuttleServiceLocation, parameterDict: CmdDict, completion: { (dataDict, success) in
                
                UIApplication.shared.isNetworkActivityIndicatorVisible = false
                
                if success {
                    // handel of data
                    if let Dict = dataDict {
                        
                        if !("\(Dict["Status"]!)".toBool()!) {
                            print(Dict)
                            
                            self.DeallocClickedView()
                            
                            self.VehicleDetailsObj?.map = nil
                            self.VehicleDetailsObj = nil
                            
                            if "\(Dict["VehicleDetails"]!)" == "NOData" {
                                if "\(Dict["RatingStatus"]!)".toBool()! {
                                    
                                    let TripId = "\(Dict["DailyTripMasterId"]!)"
                                    let tripDate = "\(Dict["TripDate"]!)"
                                    let ShiftType = "\(Dict["ShiftType"]!)"
                                    
                                    self.SendDetails(TripID: TripId, ShiftType: ShiftType, Data: tripDate)
                                }
                            }
                            
                        }
                        else {
                            
                            if Dict.keys.contains("VehicleDetails") {
                                
                                if (Dict["VehicleDetails"]!) is [[String:AnyObject]] {
                                    if (Dict["VehicleDetails"] as! [[String:AnyObject]]).count > 0 {
                                        
                                        let VihicleDict = (Dict["VehicleDetails"] as! [[String:AnyObject]])[0]
                                        
                                        
                                        var Coordinates = CLLocationCoordinate2D()
                                        
                                        print(VihicleDict)
                                        
                                        if self.VehicleDetailsObj != nil {
                                            if self.VehicleDetailsObj?.Vehicle.Vehicleno! == "\(VihicleDict["Vehicleno"]!)" {
                                                var VehicleStruct = self.VehicleDetailsObj?.Vehicle!
                                                VehicleStruct?.Direction = Double(UtilitiesClassSub.removeLeadingandTralingSpace("\(VihicleDict["Direction"]!)")!)!
                                                
                                                VehicleStruct?.DriverDetails = "\(VihicleDict["DriverDetails"]!)"
                                                VehicleStruct?.DriverDeviceToken = "\(VihicleDict["DriverDeviceToken"]!)"
                                                
                                                VehicleStruct?.Lat = Double("\(VihicleDict["Lat"]!)")!
                                                VehicleStruct?.Lon = Double("\(VihicleDict["Lon"]!)")!
                                                
                                                VehicleStruct?.ShiftType = "\(VihicleDict["ShiftType"]!)"
                                                
                                                VehicleStruct?.Speed = Double("\(VihicleDict["Speed"]!)")!
                                                
                                                
                                                VehicleStruct?.Status = "\(VihicleDict["Status"]!)"
                                                VehicleStruct?.TripCode = "\(VihicleDict["TripCode"]!)"
                                                VehicleStruct?.Vehicleno = "\(VihicleDict["Vehicleno"]!)"
                                                
                                                self.VehicleDetailsObj?.Vehicle = VehicleStruct!
                                                self.VehicleDetailsObj?.position = CLLocationCoordinate2DMake((VehicleStruct?.Lat!)!,(VehicleStruct?.Lon!)!)
                                                self.VehicleDetailsObj?.rotation = (VehicleStruct?.Direction!)! - 90
                                                
                                                Coordinates = CLLocationCoordinate2D.init(latitude: (VehicleStruct?.Lat!)!, longitude: (VehicleStruct?.Lon!)!)
                                                
                                                print("Status =======",(self.VehicleDetailsObj?.Vehicle.Status)!)
                                                if (self.VehicleDetailsObj?.Vehicle.Status)! != "-1" {
                                                    if self.MinutesTimer.isValid {
                                                        self.MinutesTimer.invalidate()
                                                        self.DistanceMarker?.map = nil
                                                        self.DistanceMarker = nil
                                                    }
                                                }
                                            }
                                            else {
                                                
                                                self.VehicleDetailsObj?.map = nil
                                                self.VehicleDetailsObj = nil
                                                
                                                var VehicleStruct = VehicleDetails()
                                                VehicleStruct.Direction = Double(UtilitiesClassSub.removeLeadingandTralingSpace("\(VihicleDict["Direction"]!)")!)!
                                                
                                                VehicleStruct.DriverDetails = "\(VihicleDict["DriverDetails"]!)"
                                                VehicleStruct.DriverDeviceToken = "\(VihicleDict["DriverDeviceToken"]!)"
                                                
                                                VehicleStruct.Lat = Double("\(VihicleDict["Lat"]!)")!
                                                VehicleStruct.Lon = Double("\(VihicleDict["Lon"]!)")!
                                                
                                                VehicleStruct.ShiftType = "\(VihicleDict["ShiftType"]!)"
                                                
                                                VehicleStruct.Speed = Double("\(VihicleDict["Speed"]!)")!
                                                
                                                
                                                VehicleStruct.Status = "\(VihicleDict["Status"]!)"
                                                VehicleStruct.TripCode = "\(VihicleDict["TripCode"]!)"
                                                VehicleStruct.Vehicleno = "\(VihicleDict["Vehicleno"]!)"
                                                
                                                self.VehicleDetailsObj = VehicleMarker.init(Vehicle: VehicleStruct)
                                                self.VehicleDetailsObj?.map = self.TrackMapView
                                                
                                                Coordinates = CLLocationCoordinate2D.init(latitude: VehicleStruct.Lat!, longitude: VehicleStruct.Lon!)
                                                
                                                print("Status =======",(self.VehicleDetailsObj?.Vehicle.Status)!)
                                                if self.VehicleDetailsObj?.Vehicle.Status != "-1" {
                                                    if self.MinutesTimer.isValid {
                                                        self.MinutesTimer.invalidate()
                                                        self.DistanceMarker?.map = nil
                                                        self.DistanceMarker = nil
                                                    }
                                                }
                                            }
                                        }
                                        else {
                                            
                                            var VehicleStruct = VehicleDetails()
                                            VehicleStruct.Direction = Double(UtilitiesClassSub.removeLeadingandTralingSpace("\(VihicleDict["Direction"]!)")!)!
                                            
                                            VehicleStruct.DriverDetails = "\(VihicleDict["DriverDetails"]!)"
                                            VehicleStruct.DriverDeviceToken = "\(VihicleDict["DriverDeviceToken"]!)"
                                            
                                            VehicleStruct.Lat = Double("\(VihicleDict["Lat"]!)")!
                                            VehicleStruct.Lon = Double("\(VihicleDict["Lon"]!)")!
                                            
                                            VehicleStruct.ShiftType = "\(VihicleDict["ShiftType"]!)"
                                            
                                            VehicleStruct.Speed = Double("\(VihicleDict["Speed"]!)")!
                                            
                                            
                                            VehicleStruct.Status = "\(VihicleDict["Status"]!)"
                                            VehicleStruct.TripCode = "\(VihicleDict["TripCode"]!)"
                                            VehicleStruct.Vehicleno = "\(VihicleDict["Vehicleno"]!)"
                                            
                                            self.VehicleDetailsObj = VehicleMarker.init(Vehicle: VehicleStruct)
                                            self.VehicleDetailsObj?.map = self.TrackMapView
                                            
                                            Coordinates = CLLocationCoordinate2D.init(latitude: VehicleStruct.Lat!, longitude: VehicleStruct.Lon!)
                                            
                                            print("Status =======",(self.VehicleDetailsObj?.Vehicle.Status)!)
                                            if (self.VehicleDetailsObj?.Vehicle.Status)! != "-1" {
                                                if self.MinutesTimer.isValid {
                                                    self.MinutesTimer.invalidate()
                                                    self.DistanceMarker?.map = nil
                                                    self.DistanceMarker = nil
                                                }
                                            }
                                        }
                                        
                                        
                                        let Camera = GMSCameraPosition.camera(withTarget: Coordinates, zoom: 15)
                                        self.TrackMapView.animate(to: Camera)
                                        
                                    }
                                    else {
                                        print("Not a vehicle")
                                    }
                                }
                                else {
                                    print("Not a vehicle")
                                    
                                }
                                
                            }
                            else {
                                print("Not a vehicle")
                            }
                        }
                        
                    }
                    else {
                        self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                    }
                }
                else {
                    self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                }
                
                self.ChangeText()
            })
            
        }
        else {
            self.view.ShowBlackTostWithText(message: "Internet Connection Not Found!", Interval: 2)
        }
    } */

    


}

extension TripTrackVC: GMSMapViewDelegate,CLLocationManagerDelegate {
    
    func mapView(_ mapView: GMSMapView, didTap marker: GMSMarker) -> Bool {
        
        LoadClickedView()
        return true
    }
    
    func DeallocClickedView() {
        NoTripView.isHidden = false
        VehicleClickedView.isHidden = true
        FloatButton.isHidden = true
        MinutesTimer.invalidate()
    }
    
    func LoadClickedView() {
        
        if VehicleClickedView.isHidden {
            NoTripView.isHidden = true
            VehicleClickedView.isHidden = false
            FloatButton.isHidden = false
            VehicleNumberLbl.text = VehicleDetailsObj?.Vehicle.Vehicleno!
            ShiftTypeLbl.text = VehicleDetailsObj?.Vehicle.ShiftType!
            
            let PhoNO = (VehicleDetailsObj?.Vehicle.DriverDetails.contains("/"))! ? (VehicleDetailsObj?.Vehicle.DriverDetails.components(separatedBy: CharacterSet.init(charactersIn: "/")).last)! : "NA"
            CallDriver.text = PhoNO
            
            if VehicleDetailsObj?.Vehicle.Status == "-1" {
                CallFloatTimer()
                MinutesTimer = Timer.scheduledTimer(timeInterval: 6, target: self, selector: #selector(CallFloatTimer), userInfo: nil, repeats: true)
            }else{
//                if MinutesTimer.isValid {
//                    MinutesTimer.invalidate()
//                }else{
//                    print("MinutesTimer is invalid...")
//
//                }
                
            }
            
        }
        
    }
    
    
    func CallFloatTimer() {
        
        let PostDict = ["Lat":"\((VehicleDetailsObj?.Vehicle.Lat!)!)",
            "Lon":"\((VehicleDetailsObj?.Vehicle.Lon!)!)",
            "EndLat":"\((CurrentLocation.coordinate.latitude))",
            "EndLon":"\((CurrentLocation.coordinate.longitude))"]
        
        WebService().callAutoAllAPI(Baseurl: WebServicesUrl.SunBaseUrl, Suffix: "", parameterDict: PostDict) { (ReceivedStr, success) in
            
            if success {
                
                let StrMain = "\(ReceivedStr!)"
                
                if StrMain.contains("|") {
                    let Seperater = StrMain.components(separatedBy: "|")[1]
                    
                    let Mints = Float(Seperater)!/60
                    
                    if Mints > 1 {
                        
                        //                        self.ReachMinsLbl.text = String.init(format: "%.0f", Mints) + " mins"
                        self.ShowLocation(drawTxt: String.init(format: "%.0f", Mints) + " mins")
                    }
                    else {
                        self.ShowLocation(drawTxt: String.init(format: "%.0f", Mints) + " min")
                    }
                }
                else {
                    self.ShowLocation(drawTxt: "NA")
                }
                
            }
            else {
                print("Error")
                self.ShowLocation(drawTxt: "NA")
            }
        }
    }
    
    
    func ShowLocation(drawTxt: String) {
        
        let font = UIFont.init(name: "Helvetica", size: 10)
        let Size = (drawTxt as NSString).size(attributes: [NSFontAttributeName: font!,
                                                           NSForegroundColorAttributeName: UIColor.black])
        let image = UIImage.init(named: "TimerPin")!.ReduceImageSize(CGSize.init(width: 80, height: 80))
        
        let rect = CGRect(x: (0.235 * (image.size.width)) - (Size.width/2), y:(0.24 * (image.size.height)) - (Size.height/2), width: Size.width, height: Size.height)
        
        let RenderedImage = image.addText(drawTxt as NSString, atRect: rect, textColor: UIColor.black, textFont: font)
        
        if DistanceMarker != nil {
            DistanceMarker.position = CurrentLocation.coordinate
            DistanceMarker.icon = RenderedImage
        }
        else {
            DistanceMarker = DistanceCreateMarker.init(positionShow: CurrentLocation.coordinate)
            DistanceMarker.icon = RenderedImage
            DistanceMarker.map = self.TrackMapView
        }
    }
    
    class DistanceCreateMarker: GMSMarker {
        init(positionShow:CLLocationCoordinate2D) {
            super.init()
            position = positionShow
            groundAnchor = CGPoint(x: 0, y: 1-0.265)
            appearAnimation = GMSMarkerAnimation.pop
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        CurrentLocation = locations.last!
        print("Lati:\(CurrentLocation.coordinate.latitude) Long:\(CurrentLocation.coordinate.longitude)")
        if IsFirstUpdate {
            IsFirstUpdate = false
            let Camera = GMSCameraPosition.camera(withTarget: (LocationManager.location?.coordinate)!, zoom: 17)
            TrackMapView.animate(to: Camera)
        }
//        CLGeocoder().reverseGeocodeLocation((self.CurrentLocation), completionHandler: {(placemarks, error) -> Void in
//
//            if error != nil {
//                print("Reverse geocoder failed with error" + (error?.localizedDescription)!)
//                return
//            }
//
//            if (placemarks?.count)! > 0 {
//                let pm : CLPlacemark = (placemarks?[0])! as CLPlacemark
//                print("**********@@@@@@@@@@@@@@********")
//                print("\(String(describing: pm.locality))")
//                if (pm.locality) != nil{
//                    self.currentAddress = pm.locality!
//                }else{
//
//                    self.currentAddress = ""
//                }
//            }
//            else {
//                self.currentAddress = ""
//            }
//        })




        GMSGeocoder().reverseGeocodeCoordinate(self.CurrentLocation.coordinate)
        { (ReverseGeoCodeResponce, error) in
            if error == nil {
                //Here address is coming as nil...Need to check
                let address = ReverseGeoCodeResponce?.results()?[0].lines
                
                
                var AddAddress = ""
                for addstr in address! {
                    AddAddress.append(addstr + ", ")
                }
                
                let addStr = AddAddress.substring(to: AddAddress.index(AddAddress.endIndex, offsetBy: -2))
                
                self.currentAddress = addStr
            }
            else {
                UIApplication.shared.keyWindow?.StopLoading()
                self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 3)
            }
        }





    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse || status == .authorizedAlways {
            LocationManager.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("LocationError:===:", error.localizedDescription)
    }
}



// MARK: - FloatTableViewCell and TableViewDelegate {

extension TripTrackVC:floatMenuDelegate {
    func didSelectMenuOption(at row: Int) {
        if row == 0 {
//            UtilitiesClass.Alert(Title: "Employee Authentication", Message: "Do you want to send Notification to Driver", Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "NO"),UtilitiesClass.AlertActionWithSelector(Title: "YES", Selector: #selector(SendNotifToDriver), Controller: self)], Controller: self)
            
            UtilitiesClass.Alert(Title: "Employee Authentication", Message: "Do you want to send Notification to Driver", Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "NO"),UtilitiesClass.AlertActionWithSelector(Title: "YES", Selector: #selector(SendNotifToDriverNew), Controller: self)], Controller: self)
        }
        else {
            QRSetUp()
        }
    }
    func SendNotifToDriverNew(){
        
        let SoapDict = ["EmpCode":"\(self.LoginDetails.EmpCode!)","EmpId":"\(self.LoginResponce.ID!)","TripCode":"\((VehicleDetailsObj?.Vehicle.TripCode!)!)"]
        
        print("Input =",SoapDict)
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.EmpAuthenticationNotification, parameterDict: SoapDict, completion: { (dataDict, success) in
                
                self.view.StopLoading()
                
                if success {
                    // handel of data
                    if let Dict = dataDict {
                        let Arr = Dict["data"] as! [[String:AnyObject]]
                        let ResponceData = Arr[0]

                            if "\(ResponceData["status"]!)" == "true"{
                                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: ResponceData["Response"] as! String, Interval: 2)
                            } else {
                                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Please try again", Interval: 2)
                        }
                    }
                    else {
                        UtilitiesClass.Alert(Title: "Alert!", Message: Constants.InternalError as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
                else {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Something went wrong", Interval: 2)
                }
            })
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "No Active internet connection available", Interval: 3)
        }
    }
    //not used now
    /*
    func SendNotifToDriver() {
        
        let CMD = "$SUNONESIGNALFMC|\((VehicleDetailsObj?.Vehicle.TripCode!)!)|\(self.LoginResponce.ID!)|\(self.LoginResponce.Name!)|#"
        print(CMD)
        let ProjectID = "ae8a5ac3-1445-4d2b-934e-f8eb9d7f86a8"
        let APIToken = "OGFlYmQ1ZmEtNGM3Ny00OWYwLTk0NWQtYzgyZDQ0ZDY0ZmEz"
        let NotificationTime = " "
        let TimetoLive = "10"
        
        let SoapDict = ["Title":"DriveFMC","Message":"\(CMD)","DeviceToken":"\((VehicleDetailsObj?.Vehicle.DriverDeviceToken!)!)","ProjectId":"\(ProjectID)","APIToken":"\(APIToken)","NotificationTime":"\(NotificationTime)","TimetoLive":"\(TimetoLive)"]
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            WebService().callNotifAPI(Suffix: "PushNotificationsWithTTL", parameterDict: SoapDict, completion: { (ResponceDict, success) in
                
                self.view.StopLoading()
                
                if success {
                    
                    if Int("\((ResponceDict?["recipients"]!)!)")! >= 1 {
                        
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Code Verified", Interval: 2)
                        
                    }
                    else {
                        
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Please try again", Interval: 2)
                        
                    }
                }
                else {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Something went wrong", Interval: 2)
                }
            })
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "No Active internet connection available", Interval: 3)
        }
    } */
    func QRSetUp() {
        do {
            if try QRCodeReader.supportsMetadataObjectTypes() {
                reader.modalPresentationStyle = .formSheet
                reader.delegate               = self
                
                reader.completionBlock = { (result: QRCodeReaderResult?) in
                    if let result = result {
                        print("Completion with result: \(result.value) of type \(result.metadataType)")
                    }
                }
                
                present(reader, animated: true, completion: nil)
            }
        } catch let error as NSError {
            switch error.code {
            case -11852:
                let alert = UIAlertController(title: "Error", message: "This app is not authorized to use Back Camera.", preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "Setting", style: .default, handler: { (_) in
                    DispatchQueue.main.async {
                        if let settingsURL = URL(string: UIApplicationOpenSettingsURLString) {
                            UIApplication.shared.openURL(settingsURL)
                        }
                    }
                }))
                alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
                present(alert, animated: true, completion: nil)
                
                
                
            case -11814:
                let alert = UIAlertController(title: "Error", message: "Reader not supported by the current device", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                
                present(alert, animated: true, completion: nil)
            default:()
            }
        }
    }
}

extension TripTrackVC:QRCodeReaderViewControllerDelegate {
    
    func reader(_ reader: QRCodeReaderViewController, didScanResult result: QRCodeReaderResult) {
        reader.stopScanning()
        
//        dismiss(animated: true) { [weak self] in
//
//            var QRArr: [String]?
//
//            if result.value.contains("|") {
//                QRArr = result.value.components(separatedBy: "|")
//
//                if let tripcode = QRArr?[1], let Devicetoken = QRArr?[2] {
//                    let CMD = "$SUNONESIGNALFMC|\(tripcode)|\((self?.LoginResponce.ID!)!)|\((self?.LoginResponce.Name!)!)|#"
//                    print(CMD)
//                    let ProjectID = "ae8a5ac3-1445-4d2b-934e-f8eb9d7f86a8"
//                    let APIToken = "OGFlYmQ1ZmEtNGM3Ny00OWYwLTk0NWQtYzgyZDQ0ZDY0ZmEz"
//                    let NotificationTime = " "
//                    let TimetoLive = "10"
//
//                    let SoapDict = ["Title":"DriveFMC","Message":"\(CMD)","DeviceToken":"\(Devicetoken)","ProjectId":"\(ProjectID)","APIToken":"\(APIToken)","NotificationTime":"\(NotificationTime)","TimetoLive":"\(TimetoLive)"]
//
//                    if (Reachability()?.isReachable)! {
//
//                        self?.view.StartLoading()
//
//                        WebService().callNotifAPI(Suffix: "PushNotificationsWithTTL", parameterDict: SoapDict, completion: { (ResponceDict, success) in
//
//                            self?.view.StopLoading()
//
//                            if success {
//
//                                if Int("\((ResponceDict?["recipients"]!)!)")! >= 1 {
//
//                                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Code Verified", Interval: 2)
//
//                                }
//                                else {
//
//                                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Please try again", Interval: 2)
//
//                                }
//                            }
//                            else {
//                                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Something went wrong", Interval: 2)
//                            }
//                        })
//                    }
//                    else {
//                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "No Active internet connection available", Interval: 3)
//                    }
//
//                }
//
//            }
//            else {
//                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Invalid QR code", Interval: 2)
//            }
//
//        }
//
        
        
        dismiss(animated: true) {
            [weak self] in
        
            var QRArr: [String]?
            if result.value.contains("|") {
                QRArr = result.value.components(separatedBy: "|")
                
                print("Lati:\(self?.CurrentLocation.coordinate.latitude) Long:\(self?.CurrentLocation.coordinate.longitude)")
                
                
                
                let currentDate = Date()
                print("currentDate...\(currentDate)")
                let dateFormatter = DateFormatter()
                dateFormatter.timeZone = NSTimeZone.system
//                dateFormatter.dateFormat = "yyyy-MM-dd"
                dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                let todayDateandTime: String = dateFormatter.string(from: currentDate)
                let lat = "\(self!.CurrentLocation.coordinate.latitude)"
                let lon = "\(self!.CurrentLocation.coordinate.longitude)"
                
                if let tripcode = QRArr?[1] {
                    let CMD = "$SUNLOGIN|\(tripcode)|\((self?.LoginDetails.EmpCode!)!)|\(lat)|\(lon)|\(self!.currentAddress!)|\(todayDateandTime)|#"
                    print(CMD)
                    
                    let SoapDict = ["cmd" : CMD]
                    if (Reachability()?.isReachable)! {
                        self?.view.StartLoading()
                        

//                        WebService().callDriveBookingAPI(Suffix: "UpdateEmployeeStatus", parameterDict: SoapDict, securityKey:(self?.DriveBookingResponce.AuthenticationToken)! , completion: { (responceDict, responseCode, success) in
//
//                            self?.view.StopLoading()
//
//                            if success{
//                                if let dataArr = ((responceDict as! [String:AnyObject])["data"] as? [[String:AnyObject]]) {
//                                    if dataArr.count > 0 && "\(dataArr[0]["Status"]!)".toBool()! {
//                                       UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Code Verified", Interval: 2)
//                                    }else{
//                                        UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "\(dataArr[0]["Response"]!)", Interval: 2)
//                                    }
//                                }else{
//                                    UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
//                                }
//
//                            }else{
//                                 UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Something went wrong", Interval: 2)
//                            }
//                        })


                        WebService().callAutoAPI(Suffix: "UpdateEmployeeStatus", parameterDict: SoapDict, completion: { (responceDict, success) in
                            self?.view.StopLoading()
                            
                            if success{
                                
                                if let Dict = responceDict {
                                    let dataArr = Dict["data"] as! [[String:AnyObject]]
                                    if dataArr.count > 0 && "\(dataArr[0]["Status"]!)".toBool()! {
                                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Code Verified", Interval: 2)
                                    }else{
                                        UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "\(dataArr[0]["Response"]!)", Interval: 2)
                                    }
                                }
                                else{
                                    UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                                }
                            }else{
                                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Something went wrong", Interval: 2)
                            }
                        })
                        
//                        self?.SendNotifToDriverWithoutToast()
                        
                    }else{
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "No Active internet connection available", Interval: 3)
                    }
                    
                }
            }else {
                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Invalid QR code", Interval: 2)
            }
        }
        
        
        
        
    }
    
    func reader(_ reader: QRCodeReaderViewController, didSwitchCamera newCaptureDevice: AVCaptureDeviceInput) {
        if let cameraName = newCaptureDevice.device.localizedName {
            print("Switching capturing to: \(cameraName)")
        }
    }
    
    func readerDidCancel(_ reader: QRCodeReaderViewController) {
        reader.stopScanning()
        
        dismiss(animated: true, completion: nil)
    }
    func SendNotifToDriverWithoutToast() {
        
        let SoapDict = ["EmpCode":"\(self.LoginDetails.EmpCode!)","EmpId":"\(self.LoginResponce.ID!)","TripCode":"\((VehicleDetailsObj?.Vehicle.TripCode!)!)"]
        
        print("Input =",SoapDict)
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.EmpAuthenticationNotification, parameterDict: SoapDict, completion: { (dataDict, success) in
                
                self.view.StopLoading()
                
                if success {
                    // handel of data
                    if let Dict = dataDict {
                        let Arr = Dict["data"] as! [[String:AnyObject]]
                        let ResponceData = Arr[0]
                        
                        if "\(ResponceData["status"]!)" == "true"{
//                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: ResponceData["Response"] as! String, Interval: 2)
                            print("EmpAuthenticationNotification service successs.....")
                        } else {
//                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Please try again", Interval: 2)
                            print("EmpAuthenticationNotification service response status fail.....")
                        }
                    }
                    else {
                        UtilitiesClass.Alert(Title: "Alert!", Message: Constants.InternalError as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
                else {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Something went wrong", Interval: 2)
                }
            })
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "No Active internet connection available", Interval: 3)
        }
    }
}
// MARK: - }


// MARK: - Vehicle Struct {

struct VehicleDetails {
    var Direction:Double!
    var DriverDetails:String!
    var DriverDeviceToken:String!
    var Lat:Double!
    var Lon:Double!
    var ShiftType:String!
    var Speed:Double!
    var Status:String!
    var TripCode:String!
    var Vehicleno:String!
}


class VehicleMarker: GMSMarker {
    var Vehicle: VehicleDetails!
    var MarkerTag: Int!
    init(Vehicle: VehicleDetails) {
        super.init()
        self.Vehicle = Vehicle
        position = CLLocationCoordinate2DMake(Vehicle.Lat!,Vehicle.Lon!)
        icon = UIImage.init(named: "vehicleicon")
        groundAnchor = CGPoint(x: 0.5, y: 1)
        appearAnimation = GMSMarkerAnimation.pop
        title = Vehicle.Vehicleno!
        rotation = Vehicle.Direction! - 90
    }
}

// MARK: -





