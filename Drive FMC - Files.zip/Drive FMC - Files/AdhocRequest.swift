//
//  AdhocRequest.swift
//  DriveFindMyCab
//
//  Created by Divya on 22/02/17.
//  Copyright © 2017 Divya. All rights reserved.
//

import UIKit
import CoreLocation
import GoogleMaps

class AdhocRequest: UIViewController, UITextFieldDelegate,LocationSelectDelegate,CLLocationManagerDelegate {
    
    @IBOutlet weak var pickupDropdownBtn: UIButton!
    @IBOutlet weak var dropDropdownBtn: UIButton!
    @IBOutlet weak var droptextfield: UITextField!
    @IBOutlet weak var pickuptextfield: UITextField!
    @IBOutlet weak var datetextfield: UITextField!
    @IBOutlet weak var timetextfield: UITextField!
    @IBOutlet weak var reasontextfield: UITextField!
    @IBOutlet weak var pickupbutton: UIButton!
    @IBOutlet weak var dropbutton: UIButton!
    @IBOutlet weak var pickupimg: UIImageView!
    @IBOutlet weak var dropimg: UIImageView!
    
    @IBOutlet weak var dropLbl: UILabel!
    @IBOutlet weak var pickupLbl: UILabel!
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var timeLbl: UILabel!
    @IBOutlet weak var reasonLbl: UILabel!
    
    @IBOutlet weak var scrollViewMain: UIScrollView!
    
    
    var timeString : String!
    var dateString : String!
    var type : String!
    
    var startDate,endDate,currTime,currDate,another:NSDate!
    var dateFormatter = DateFormatter()
    var timeFormatter = DateFormatter()
    
    var datepicker: UIDatePicker!
    var timepicker: UIDatePicker!
    var dateComponents : NSDateComponents!
    
    
    
    /*
    var PickLatOne : Double!
    var PickLongOne : Double!
    var PickPlaceOne : String!
    
    var DropLatOne : Double!
    var DropLongOne : Double!
    var DropPlaceOne : String!
    
    var PickLatTwo : Double!
    var PickLongTwo : Double!
    var PickPlaceTwo : String!
    
    var DropLatTwo : Double!
    var DropLongTwo : Double!
    var DropPlaceTwo : String! */
    
    
    var EmpAddressOneLat : Double!
    var EmpAddressOneLng : Double!
    var EmpAddressOnePickPlace : String!
    
    var EmpAddressTwoLat : Double!
    var EmpAddressTwoLng : Double!
    var EmpAddressTwoPickPlace : String!
    
  
    @IBOutlet weak var pickupLocationsContainer: UIView!
    @IBOutlet weak var pickupLocationsTV: UITableView!
    var pickupLocationsArray = [PickupOrDropLocationsStruct]()
    var pickupLocationSelectedItem = PickupOrDropLocationsStruct()
    
    var dropLocationsArray = [PickupOrDropLocationsStruct]()
    var dropLocationSelectedItem = PickupOrDropLocationsStruct()
    @IBOutlet weak var dropLocationsContainer: UIView!
    @IBOutlet weak var dropLocationsTV: UITableView!
    
//    var pickupLocationFlag : Bool!
   
    
    var LocationManager = CLLocationManager()
    
    var LoginResponce:LoginResponce!
    var LoginDetails:LoginDetails!
    
    var showSearchCtrlFlag : Bool!
    var facilityStrArrFull = [String]()
    var facilityStrArr = [String]()
    var empAddressStrArr = [String]()
    
    @IBOutlet weak var pickupAddress2Btn: UIButton!
    @IBOutlet weak var pickupAddress1Btn: UIButton!
    @IBOutlet weak var pickupAddressView: UIView!
    
    @IBAction func pickupAddress1BtnTapped(_ sender: UIButton) {
        /*
        pickupAddressView.isHidden = true
        if let text = sender.titleLabel?.text{
            print("pickupAddress1BtnTapped",text)
            self.pickuptextfield.text = text
        }*/
        
    }
    
    @IBAction func pickupAddress2BtnTapped(_ sender: UIButton) {
        /*
        pickupAddressView.isHidden = true
        if let text = sender.titleLabel?.text{
            print("pickupAddress2BtnTapped",text)
            self.pickuptextfield.text = text
        }*/
    }
    
    @IBAction func pickupDropdownBtnTapped(_ sender: UIButton) {

        if self.pickupLocationsContainer.isHidden {
            self.pickupLocationsContainer.isHidden = false
            self.pickupLocationsTV.reloadData()
        }else{
            self.pickupLocationsContainer.isHidden = true
        }
        
    }
    
    
    @IBOutlet weak var dropAddress2Btn: UIButton!
    @IBOutlet weak var dropAddress1Btn: UIButton!
    @IBOutlet weak var dropAddressView: UIView!
    
    @IBAction func dropDropdownBtnTapped(_ sender: UIButton) {

        if self.dropLocationsContainer.isHidden {
            self.dropLocationsContainer.isHidden = false
            self.dropLocationsTV.reloadData()
        }else{
            self.dropLocationsContainer.isHidden = true
        }
            
       
    }
    @IBAction func dropAddress1BtnTapped(_ sender: UIButton) {
        /*
        dropAddressView.isHidden = true
        if let text = sender.titleLabel?.text{
            print("dropAddress1BtnTapped",text)
            self.droptextfield.text = text
        } */

        
    }
    
    @IBAction func dropAddress2BtnTapped(_ sender: UIButton) {
        /*
         dropAddressView.isHidden = true
        if let text = sender.titleLabel?.text{
            print("dropAddress2BtnTapped",text)
            self.droptextfield.text = text
        }*/
    }
    
    
    
    
    var shiftTimePicker = UIPickerView()
//    var dropShiftTimePicker = UIPickerView()
    
    var shiftTimeArr = [String]()
//    var dropShiftTimeArr = [String]()
    
    var shiftTimeSelectedItem = ""
//    var dropShiftTimeSelectedItem = ""
    
    var pickupShiftTimeArr = [String]()
    var dropShiftTimeArr = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        shiftTimePicker.delegate = self;
        shiftTimePicker.dataSource = self;

        self.pickupLocationsContainer.isHidden = true
        self.pickupLocationsTV.dataSource = self
        self.pickupLocationsTV.delegate = self
        
        pickupLocationsTV.tableFooterView = UIView.init(frame: CGRect.zero)
        
        self.dropLocationsContainer.isHidden = true
        self.dropLocationsTV.dataSource = self
        self.dropLocationsTV.delegate = self
        
        dropLocationsTV.tableFooterView = UIView.init(frame: CGRect.zero)
        
        
        LoginDetails = FetchLoginDetails()
        LoginResponce = FetchLoginResponce()
        
//        if Pickulocationstatus == 1 means , 0 means non-pwcsdc user
        if LoginResponce.Pickuplocationstatus == "1" {
            
            //    dont check pwc condition in adhoc page sasi sir told login method check pickuplocationstatus if staus=1 then dropdown or  else normal free text
            
            pickupDropdownBtn.isHidden = false
            dropDropdownBtn.isHidden = false
            self.showSearchCtrlFlag = false
            
           
        }else{
            pickupDropdownBtn.isHidden = true
            dropDropdownBtn.isHidden = true
            self.showSearchCtrlFlag = true
        }
        
//        dropbutton.isSelected = true
        pickupbutton.isSelected = true
        
        datepicker = UIDatePicker()
        timepicker = UIDatePicker()
        
        
        dateFormatter.dateFormat = "dd-MMM-yyyy"
        timeFormatter.dateFormat = "HH:mm"
        
        
        dateString = dateFormatter.string(from: Date())
        timeString = timeFormatter.string(from: Date())
        
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.blue
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action:#selector(donePicker))
        
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.plain, target: self, action:#selector(cancelPicker))
        
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        datepicker.datePickerMode = UIDatePickerMode.date
        datetextfield.inputView = datepicker
        datetextfield.inputAccessoryView = toolBar
        

        if LoginResponce.Pickuplocationstatus == "1" {
            timetextfield.inputView = shiftTimePicker
            timetextfield.inputAccessoryView = toolBar
        }else{
            timepicker.datePickerMode = UIDatePickerMode.time
            timetextfield.inputView = timepicker
            timetextfield.inputAccessoryView = toolBar
        }

        // Do any additional setup after loading the view.
        dropLbl.isHidden = true
        pickupLbl.isHidden = true
        dateLbl.isHidden = true
        timeLbl.isHidden = true
        reasonLbl.isHidden = true
        
        LocationManager.delegate = self
        LocationManager.requestWhenInUseAuthorization()
        
   
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.white
        self.navigationItem.leftBarButtonItem = BackBtnItem
        
        callGetAdhocTripRequestDetailsService()
    }
    
    func callGetAdhocTripRequestDetailsService() {
        let inputDict = ["LoginId":"\(self.LoginResponce.Employeeid!)"]
        if (Reachability()?.isReachable)! {
            self.view.StartLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.AdhocTripRequestDetails, parameterDict: inputDict){(ResponceDict, success) in
                self.view.StopLoading()
                if success {
                    print(ResponceDict!)
                    if let responce = ResponceDict, responce["Success"] as! Bool {
                        let Arr = responce["data"] as! [[String:AnyObject]]
                        if Arr.count != 0 {
                            if Arr[0]["EmpAddress"] != nil {
                                if "\(Arr[0]["FacilityAddress"])" == "N/A" || "\(Arr[0]["FacilityAddress"])" == "NA" {
                                    self.showSearchCtrlFlag = true
                                    self.pickuptextfield.isUserInteractionEnabled = true
                                    self.droptextfield.isUserInteractionEnabled = true
                                }else{
                                    self.showSearchCtrlFlag = false
                                    self.pickuptextfield.isUserInteractionEnabled = false
                                    self.droptextfield.isUserInteractionEnabled = false
                                    
                                    
                                    self.pickupLocationsArray.removeAll()
                                    let empAddress = "\(Arr[0]["EmpAddress"]!)"
                                    self.empAddressStrArr = empAddress.components(separatedBy: "|")
                                    var EmpAdd1 = PickupOrDropLocationsStruct()
                                    EmpAdd1.Latitude = Double(self.empAddressStrArr[0])
                                    EmpAdd1.Longitude = Double(self.empAddressStrArr[1])
                                    EmpAdd1.Location = self.empAddressStrArr[2]
                                    self.pickupLocationsArray.append(EmpAdd1)
                                    
                                    var EmpAdd2 = PickupOrDropLocationsStruct()
                                    EmpAdd2.Latitude = Double(self.empAddressStrArr[3])
                                    EmpAdd2.Longitude = Double(self.empAddressStrArr[4])
                                    EmpAdd2.Location = self.empAddressStrArr[5]
                                    self.pickupLocationsArray.append(EmpAdd2)
                                    
                                    self.pickuptextfield.text = self.pickupLocationsArray[0].Location
                                    self.pickupLocationSelectedItem = self.pickupLocationsArray[0]
                                    
                                   
                                    self.facilityStrArrFull = "\(Arr[0]["FacilityAddress"]!)".components(separatedBy: ";")
                                    
                                    
                                    // FacilityAddress = "12.9716|77.5946|HPKTP";
                                    self.dropLocationsArray.removeAll()
                                    for aFacility in self.facilityStrArrFull{
                                        var aDropLocation = PickupOrDropLocationsStruct()
                                        self.facilityStrArr = aFacility.components(separatedBy: "|")
                                        aDropLocation.Latitude = Double(self.facilityStrArr[0])
                                        aDropLocation.Longitude = Double(self.facilityStrArr[1])
                                        aDropLocation.Location = self.facilityStrArr[2]
                                        self.dropLocationsArray.append(aDropLocation)
                                    }
                                    
                                    self.dropLocationSelectedItem = self.dropLocationsArray[0]
                                    self.droptextfield.text = self.dropLocationsArray[0].Location
                                }
                                self.pickupShiftTimeArr = "\(Arr[0]["PickUpShiftTime"]!)".components(separatedBy: "|")
                                self.dropShiftTimeArr = "\(Arr[0]["DropOffShiftTime"]!)".components(separatedBy: "|")
                            }
                        }
                    }
                }else{
                    
                }
            }
        }else{
            self.view.ShowWhiteTostWithText(message: Constants.InternetErrorMsg, Interval: 2)
        }
       
    }
    /*
    func callGetAdhocTripRequestDetailsService(){
        
         let inputDict = ["LoginId":"\(self.LoginDetails.UserID!)"]
        
        self.view.StartLoading()
        
        WebService().callAutoAPI(Suffix: WebServicesUrl.AdhocTripRequestDetails, parameterDict: inputDict) { (ResponceDict, success) in
            
            self.view.StopLoading()
            
            if success {
                print(ResponceDict!)
                
                
                if let responce = ResponceDict, responce["Success"] as! Bool {
                    
                    /*
                     UtilitiesClass.Alert(Title: "Your Request has been registered", Message: "", Actions: [UtilitiesClass.AlertActionWithSelector(Title: "OK", Selector: #selector(self.OkAction), Controller: self)], Controller: self) */
                    let Arr = responce["data"] as! [[String:AnyObject]]
                    if Arr.count != 0 {
                        if Arr[0]["EmpAddress"] != nil {
                            
                            
                            if "\(Arr[0]["FacilityAddress"])" == "N/A" || "\(Arr[0]["FacilityAddress"])" == "NA" {
                                self.showSearchCtrlFlag = true
                                self.pickuptextfield.isUserInteractionEnabled = true
                                self.droptextfield.isUserInteractionEnabled = true
                            }else{
                                self.showSearchCtrlFlag = false
                                self.pickuptextfield.isUserInteractionEnabled = false
                                self.droptextfield.isUserInteractionEnabled = false
                                
                                
                                self.pickupLocationsArray.removeAll()
                                
//                                self.empAddressStrArr = self.LoginResponce.EmpAddress.components(separatedBy: "|")
                                self.empAddressStrArr = "\(Arr[0]["EmpAddress"])".components(separatedBy: "|")
                                var EmpAdd1 = PickupOrDropLocationsStruct()
                                EmpAdd1.Latitude = Double(self.empAddressStrArr[0])
                                EmpAdd1.Longitude = Double(self.empAddressStrArr[1])
                                EmpAdd1.Location = self.empAddressStrArr[2]
                                self.pickupLocationsArray.append(EmpAdd1)
                                
                                var EmpAdd2 = PickupOrDropLocationsStruct()
                                EmpAdd2.Latitude = Double(self.empAddressStrArr[3])
                                EmpAdd2.Longitude = Double(self.empAddressStrArr[4])
                                EmpAdd2.Location = self.empAddressStrArr[5]
                                self.pickupLocationsArray.append(EmpAdd2)
                                
                                self.pickuptextfield.text = self.pickupLocationsArray[0].Location
                                self.pickupLocationSelectedItem = self.pickupLocationsArray[0]
                                
//                                facilityStrArrFull = LoginResponce.FacilityAddress.components(separatedBy: ";")
                                self.facilityStrArrFull = "\(Arr[0]["FacilityAddress"])".components(separatedBy: ";")=
                                //            FacilityAddress = "12.9716|77.5946|HPKTP";
                                self.dropLocationsArray.removeAll()
                                for aFacility in self.facilityStrArrFull{
                                    var aDropLocation = PickupOrDropLocationsStruct()
                                    self.facilityStrArr = aFacility.components(separatedBy: "|")
                                    aDropLocation.Latitude = Double(self.facilityStrArr[0])
                                    aDropLocation.Longitude = Double(self.facilityStrArr[1])
                                    aDropLocation.Location = self.facilityStrArr[2]
                                    self.dropLocationsArray.append(aDropLocation)
                                }
                                
                                self.dropLocationSelectedItem = self.dropLocationsArray[0]
                                self.droptextfield.text = self.dropLocationsArray[0].Location
                                
                            }
                            
                            self.pickupShiftTimeArr = "\(Arr[0]["PickUpShiftTime"])".components(separatedBy: "|")
                            self.dropShiftTimeArr = "\(]Arr[0]["DropOffShiftTime"])".components(separatedBy: "|")
                            
                        }else{
                            print("else Response = Success:true,data:[{EmpAddress:null,FacilityAddress:null,PickUpShiftTime:NA,DropOffShiftTime:NA}]} ")
                        }
                       
                    }
                    
                    
                }
                else {
                    self.showAlert(Constants.InternalError)
                }
                
                
                
                
            }
            else {
                self.showAlert(Constants.InternalError)
            }
        }
        
    } */
 
 
    func BackAction() {
        self.navigationController?.popViewController(animated: true)
    }
    
   

    // MARK: - Location Manager Delegate START {
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse || status == .authorizedAlways {
            LocationManager.startUpdatingLocation()
        }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        manager.stopUpdatingLocation()
    }
    // MARK: - END }
    
    
    
    func DidselectLocation(_ Lat: Double!, _ Lag: Double!, _ Title: String!, _ controller: PlacesSearchResultsTVC) {
        controller.dismiss(animated: true, completion: nil)
        if type == "Pickup" {
            pickuptextfield.text = Title!
           /*
            PickLatOne = Lat!
            PickLongOne = Lag!
            PickPlaceOne = Title! */
            
            EmpAddressOneLat = Lat!
            EmpAddressOneLng = Lag!
            EmpAddressOnePickPlace = Title!
        }
        else {
            droptextfield.text = Title!
            /*
            DropLatOne = Lat!
            DropLongOne = Lag!
            DropPlaceOne = Title! */
            
            EmpAddressTwoLat = Lat!
            EmpAddressTwoLng = Lag!
            EmpAddressTwoPickPlace = Title!
        }
        UpdateLabels()
    }
    
    func CheckSend() {
        /*
        let DictStr = ["LoginId":"\(self.LoginDetails.UserID!)","PickUpTime":"\(self.datetextfield.text! + " " + self.timetextfield.text!)","PickUpLocation":"\(self.PickPlaceOne!)","DropLocation":"\(self.DropPlaceOne!)","ReasonForCab":"\(self.reasonLbl.text!)","PickUpLat":"\(self.PickLatOne!)","PickUpLon":"\(self.PickLongOne!)","DropLat":"\(self.DropLatOne!)","DropLon":"\(self.DropLongOne!)","ShiftType":"\(self.pickupbutton.isSelected ? "Pickup" : "Drop")"] */
        /*
        let DictStr = ["LoginId":"\(self.LoginDetails.UserID!)","PickUpTime":"\(self.datetextfield.text! + " " + self.timetextfield.text!)","PickUpLocation":"\(self.EmpAddressOnePickPlace!)","DropLocation":"\(self.EmpAddressTwoPickPlace!)","ReasonForCab":"\(self.reasonLbl.text!)","PickUpLat":"\(self.EmpAddressOneLat!)","PickUpLon":"\(self.EmpAddressOneLng!)","DropLat":"\(self.EmpAddressTwoLat!)","DropLon":"\(self.EmpAddressTwoLng!)","ShiftType":"\(self.pickupbutton.isSelected ? "Pickup" : "Drop")"] */
        
        let DictStr = ["LoginId":"\(self.LoginDetails.UserID!)","PickUpTime":"\(self.datetextfield.text! + " " + self.timetextfield.text!)","PickUpLocation":"\(self.pickupLocationSelectedItem.Location!)","DropLocation":"\(self.dropLocationSelectedItem.Location!)","ReasonForCab":"\(self.reasonLbl.text!)","PickUpLat":"\(self.pickupLocationSelectedItem.Latitude!)","PickUpLon":"\(self.pickupLocationSelectedItem.Longitude!)","DropLat":"\(self.dropLocationSelectedItem.Latitude!)","DropLon":"\(self.dropLocationSelectedItem.Longitude!)","ShiftType":"\(self.pickupbutton.isSelected ? "Pickup" : "Drop")"]
        
        
        self.SendDataToService(messageDict: DictStr)
    }
    @IBAction func RequestBtnAction(_ sender:UIButton) {
        
        if self.CheckBeforeRequest() {
            
            if (Reachability()?.isReachable)! {
                UtilitiesClass.Alert(Title: "Ad-hoc Vehicle Request", Message: "Are you sure" as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "CANCEL"),UtilitiesClass.AlertActionWithSelector(Title: "YES", Selector: #selector(CheckSend), Controller: self)], Controller: self)
            }
            else {
                self.showAlert(Constants.NetErrorMsg)
            }
        }
        else {
            
            let charset = NSCharacterSet.init(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
            
            let reasonStr:NSString = self.reasontextfield.text! as NSString
            
            var errorString = ""
            if (self.pickuptextfield.text?.isEmpty)! {
                errorString  = "Please select Pickup point"
            } else if (self.droptextfield.text?.isEmpty)! {
                errorString  = "Please select Drop point"
            } else if (self.datetextfield.text?.isEmpty)! {
                errorString  = "Please select date"
            }else if (self.timetextfield.text?.isEmpty)! {
                errorString  = "Please select time"
            }
            else if reasonStr.rangeOfCharacter(from: charset as CharacterSet).location == NSNotFound {
                errorString = "Please enter valid reason"
            }
            self.showAlert(errorString)
        }
        
    }
    func OkAction() {
        self.navigationController?.popViewController(animated: true)
    }
    func SendDataToService(messageDict:[String:String]) {
        
        self.view.StartLoading()

        WebService().callAutoAPI(Suffix: WebServicesUrl.AdhocRequest, parameterDict: messageDict) { (ResponceDict, success) in
            
            self.view.StopLoading()
            
            if success {
                print(ResponceDict!)
                
                
                if let responce = ResponceDict, responce["Success"] as! Bool {
                    
                    /*
                    UtilitiesClass.Alert(Title: "Your Request has been registered", Message: "", Actions: [UtilitiesClass.AlertActionWithSelector(Title: "OK", Selector: #selector(self.OkAction), Controller: self)], Controller: self) */
                    let Arr = responce["data"] as! [[String:AnyObject]]
                    if Arr.count != 0 {
                        
                        UtilitiesClass.Alert(Title: "Information", Message: "\(Arr[0]["StatusMessage"]!)" as NSString, Actions: [UtilitiesClass.AlertActionWithSelector(Title: "OK", Selector: #selector(self.OkAction), Controller: self)], Controller: self)
                    }
                    
                    
                }
                else {
                    self.showAlert(Constants.InternalError)
                }
                
                
                
                
            }
            else {
                self.showAlert(Constants.InternalError)
            }
        }
    }
    
    
    func showAlert(_ Message:String!){
        UtilitiesClass.Alert(Title: "OOPS..", Message: Message as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
    }
    
    func donePicker(sender : UIBarButtonItem) {
        
        if datetextfield.isFirstResponder {
            if datetextfield.text! != dateString! {
                timetextfield.text = "";
            }
            datetextfield.text = dateString
            self.datetextfield.resignFirstResponder()
        }
        
        if timetextfield.isFirstResponder {
            if LoginResponce.Pickuplocationstatus == "1" {
                self.timetextfield.text = shiftTimeSelectedItem
                self.timetextfield.resignFirstResponder()
            }else{
                timetextfield.text = timeString
                self.timetextfield.resignFirstResponder()
            }
            
        }
        UpdateLabels()
    }
    
    func cancelPicker(sender : UIBarButtonItem ){
        self.datetextfield.resignFirstResponder()
        self.timetextfield.resignFirstResponder()
    }
    
    @IBAction func pickupAction(_ sender: UIButton) {
        
        if !sender.isSelected {
            pickupimg.image = UIImage.init(named: "Circled Dot Filled")
            dropimg.image = UIImage.init(named: "Unchecked Circle")
            pickupbutton.isSelected = true
            dropbutton.isSelected = false
            
            if !(timetextfield.text?.isEmpty)!{
                timetextfield.text = pickupShiftTimeArr[0]
                shiftTimeSelectedItem = pickupShiftTimeArr[0]
            }
       
            if LoginResponce.FacilityAddress != "N/A" {
                if LoginResponce.FacilityAddress != "NA"{
                    self.pickuptextfield.text = dropLocationSelectedItem.Location
                    self.droptextfield.text = pickupLocationSelectedItem.Location
                    
                    let aStruct : PickupOrDropLocationsStruct!
                    aStruct = pickupLocationSelectedItem
                    pickupLocationSelectedItem = dropLocationSelectedItem
                    dropLocationSelectedItem = aStruct
                }
            }
        }
    }
    
    @IBAction func dropAction(_ sender: UIButton) {
        
        if !sender.isSelected {
            pickupimg.image = UIImage.init(named: "Unchecked Circle")
            dropimg.image = UIImage.init(named: "Circled Dot Filled")
            pickupbutton.isSelected = false
            dropbutton.isSelected = true
            
            if !(timetextfield.text?.isEmpty)!{
                timetextfield.text = dropShiftTimeArr[0]
                shiftTimeSelectedItem = dropShiftTimeArr[0]
            }
 
            
            if LoginResponce.FacilityAddress != "N/A" {
                if LoginResponce.FacilityAddress != "NA" {
                    self.pickuptextfield.text = dropLocationSelectedItem.Location
                    self.droptextfield.text = pickupLocationSelectedItem.Location
                    
                    let aStruct : PickupOrDropLocationsStruct!
                    aStruct = pickupLocationSelectedItem
                    pickupLocationSelectedItem = dropLocationSelectedItem
                    dropLocationSelectedItem = aStruct
                    
                }
            }
            
            
            
            if self.LoginResponce.Pickuplocationstatus == "1" {
                
            }else{
                
               
            }
            
            
            
           /*
            if LoginResponce.FacilityAddress != "N/A" {
                if LoginResponce.FacilityAddress != "NA" {
                    
                    
                    if self.LoginResponce.Pickuplocationstatus != "1" {
                        /*
                        self.PickLatOne = Double(facilityStrArr[0])
                        self.PickLongOne = Double(facilityStrArr[1])
                        self.PickPlaceOne = facilityStrArr[2]
                        self.pickuptextfield.text = facilityStrArr[2] */
                        
                        self.EmpAddressOneLat = Double(facilityStrArr[0])
                        self.EmpAddressOneLng = Double(facilityStrArr[1])
                        self.EmpAddressOnePickPlace = facilityStrArr[2]
                        self.pickuptextfield.text = facilityStrArr[2]
                        
                    }else{
                        self.EmpAddressOneLat = Double(empAddressStrArr[3])
                        self.EmpAddressOneLng = Double(empAddressStrArr[4])
                        self.EmpAddressOnePickPlace = empAddressStrArr[5]
                        self.pickuptextfield.text = empAddressStrArr[5]
                    }
                    
                    self.EmpAddressTwoLat = Double(empAddressStrArr[0])
                    self.EmpAddressTwoLng = Double(empAddressStrArr[1])
                    self.EmpAddressTwoPickPlace = empAddressStrArr[2]
                    self.droptextfield.text = empAddressStrArr[2]
                    

                    
                }
            } */
        }
    }
    
    func animateViewMoving (up:Bool, moveValue :CGFloat){
        let movementDuration:TimeInterval = 0.3
        let movement:CGFloat = ( up ? -moveValue : moveValue)
        UIView.beginAnimations( "animateView", context: nil)
        UIView.setAnimationBeginsFromCurrentState(true)
        UIView.setAnimationDuration(movementDuration )
        self.view.frame = self.view.frame.offsetBy(dx: 0,  dy: movement)
        UIView.commitAnimations()
    }
    
    func searchResultsController(_ typeStr:String!) -> UISearchController {
        
        type = typeStr
        
        var PlacesSearch:PlacesSearchResultsTVC!
        PlacesSearch = PlacesSearchResultsTVC()
        PlacesSearch.PlaceDelegate = self
        let search = UISearchController.init(searchResultsController: PlacesSearch)
        search.searchResultsUpdater = PlacesSearch
        self.definesPresentationContext = true
        return search
    }
    
//    balu,pickup location and drop location enga iruntha varuthu?
//    puthu service la iruntha?
//    its comming from login method if we select pick from employee home to facility if we select drop facility to home facility means company location so based on icon selection change pickup drop location
    
//    balu phone lock aaki iruka?
//    illa ke murali its on only
    
//    phona restart pannu balu
    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == pickuptextfield {
            if showSearchCtrlFlag {
                self.present(searchResultsController("Pickup"), animated: true, completion: nil)
            }
            
        }
        
        if textField == droptextfield {
            if showSearchCtrlFlag {
               self.present(searchResultsController("Drop"), animated: true, completion: nil)
            }
            
        }
        
        if textField == datetextfield {
            dateString = dateFormatter.string(from: Date())
            datepicker.minimumDate = NSDate() as Date
            let calendar:NSCalendar = NSCalendar.current as NSCalendar
            let components = calendar.components([NSCalendar.Unit.year, NSCalendar.Unit.month, NSCalendar.Unit.day, NSCalendar.Unit.hour, NSCalendar.Unit.minute], from: NSDate() as Date)
            let date = calendar.date(from: components)!
            datepicker.setDate(date, animated: true)
            datepicker.addTarget(self, action: #selector(handleDatePicker), for: UIControlEvents.valueChanged)
        }
        
        if textField == timetextfield {
            
           
            if LoginResponce.Pickuplocationstatus == "1"{
                
                //create picker view to populate shifttiming
                
                if pickupbutton.isSelected{
                    if pickupShiftTimeArr.count != 0 {
                        shiftTimeSelectedItem = pickupShiftTimeArr[0]
                    }
                }else{
                    if dropShiftTimeArr.count != 0 {
                        shiftTimeSelectedItem = dropShiftTimeArr[0]
                    }
                }
                shiftTimePicker.reloadAllComponents()
                
               
                
                timetextfield.isHidden = false
                
                
            }
            else{
                timeString = timeFormatter.string(from: Date())
                
                let date = NSDate()
                let gregCal:NSCalendar = NSCalendar(calendarIdentifier: NSCalendar.Identifier.gregorian)!
                let gregTime:NSDateComponents = gregCal.components(([.year, .month, .day, .hour, .minute]), from: date as Date) as NSDateComponents
                
                if (datetextfield.text?.isEmpty)! {
                    gregTime.setValue(0, forComponent: .hour)
                    gregTime.setValue(0, forComponent: .minute)
                    timepicker.minimumDate = gregCal.date(from: gregTime as DateComponents)!
                    timepicker.date = date as Date
                }
                else {
                    
                    /*
                     if (timetextfield.text?.isEmpty)! {
                     timepicker.minimumDate = gregCal.date(from: gregTime as DateComponents)!
                     timepicker.date = date as Date
                     }
                     else {
                     let SelectedDateStr = datetextfield.text!
                     let selectedDate = dateFormatter.date(from: SelectedDateStr)
                     
                     let selectedGregTime = gregCal.components(([.year, .month, .day, .hour, .minute]), from: selectedDate!)
                     
                     if selectedGregTime.year == gregTime.year && selectedGregTime.month == gregTime.month && selectedGregTime.day == gregTime.day {
                     timepicker.minimumDate = date as Date
                     }
                     else {
                     gregTime.setValue(0, forComponent: .hour)
                     gregTime.setValue(0, forComponent: .minute)
                     timepicker.minimumDate = gregCal.date(from: gregTime as DateComponents)!
                     }
                     
                     timepicker.date = selectedDate!
                     } */
                    
                    
                    
                    
                    let SelectedDateStr = datetextfield.text!
                    let selectedDate = dateFormatter.date(from: SelectedDateStr)
                    
                    let selectedGregTime = gregCal.components(([.year, .month, .day, .hour, .minute]), from: selectedDate!)
                    
                    if selectedGregTime.year == gregTime.year && selectedGregTime.month == gregTime.month && selectedGregTime.day == gregTime.day {
                        timepicker.minimumDate = date as Date
                    }
                    else {
                        gregTime.setValue(0, forComponent: .hour)
                        gregTime.setValue(0, forComponent: .minute)
                        timepicker.minimumDate = gregCal.date(from: gregTime as DateComponents)!
                    }
                    if (timetextfield.text?.isEmpty)! {
                        timepicker.date = date as Date
                    }else{
                        timepicker.date = selectedDate!
                    }
                    
                }
                
                timepicker.addTarget(self, action: #selector(startTimeDiveChanged), for: UIControlEvents.valueChanged)
            }
        }
        
        if textField == reasontextfield {
            
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardHide(_:)), name: .UIKeyboardWillHide, object: nil)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    //MARK: - Keyboard show
    
    func keyboardShow(_ notification : NSNotification){
        
        if datetextfield.isFirstResponder || timetextfield.isFirstResponder || reasontextfield.isFirstResponder {
            let info = notification.userInfo
            let keyboardframe = (info![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size
            var phoneframe = CGRect.init()
            if datetextfield.isFirstResponder {
                phoneframe = datetextfield.frame
            }
            else if timetextfield.isFirstResponder {
                phoneframe = timetextfield.frame
            }
            else if reasontextfield.isFirstResponder {
                phoneframe = reasontextfield.frame
            }
            
            var actualframe = self.view.frame
            actualframe.size.height -= keyboardframe.height
            actualframe.size.height -= (phoneframe.size.height)
            
            if !actualframe.contains((phoneframe.origin)) {
                let yfinal = (phoneframe.origin.y) - actualframe.size.height
                
                UIView.animate(withDuration: 0.3, animations: { () -> Void in
                    
                    self.scrollViewMain.setContentOffset(CGPoint.init(x: 0, y: -(yfinal)), animated: true)
                    //                self.view.frame.origin.y -= yfinal
                })
                
            }
        }
    }
    
    // MARK: - keyboard hide
    
    func keyboardHide(_ notification : NSNotification)
    {
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.scrollViewMain.setContentOffset(CGPoint.init(x: 0, y: 0), animated: true)
            //            self.view.frame.origin.y = 0
        })
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        UpdateLabels()
    }
    
    func UpdateLabels() {
        
        if (pickuptextfield.text?.isEmpty)! {
            pickupLbl.isHidden = true
        }
        else {
            pickupLbl.isHidden = false
        }
        
        if (droptextfield.text?.isEmpty)! {
            dropLbl.isHidden = true
        }
        else {
            dropLbl.isHidden = false
        }
        
        if (datetextfield.text?.isEmpty)! {
            dateLbl.isHidden = true
        }
        else {
            dateLbl.isHidden = false
        }
        
        if (timetextfield.text?.isEmpty)! {
            timeLbl.isHidden = true
        }
        else {
            timeLbl.isHidden = false
        }
        
        if (reasontextfield.text?.isEmpty)! {
            reasonLbl.isHidden = true
        }
        else {
            reasonLbl.isHidden = false
        }
    }
    
    func handleDatePicker(sender: UIDatePicker) {
        dateString = dateFormatter.string(from: sender.date)
    }
    
    func startTimeDiveChanged(sender: UIDatePicker) {
        timeString = timeFormatter.string(from: sender.date)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    func CheckBeforeRequest() -> Bool {
        
        let charset = NSCharacterSet.init(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
        
        let reasonStr:NSString = self.reasontextfield.text! as NSString
        
        if (pickuptextfield.text?.isEmpty)! || (droptextfield.text?.isEmpty)! || (datetextfield.text?.isEmpty)! || (timetextfield.text?.isEmpty)! || reasonStr.rangeOfCharacter(from: charset as CharacterSet).location == NSNotFound
        {
            return false
        }
        else {
            return true
        }
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}


extension NSDate
{
    
    func dateAt(hours: Int, minutes: Int) -> NSDate
    {
        let calendar = NSCalendar(calendarIdentifier: NSCalendar.Identifier.gregorian)!
        
        //get the month/day/year componentsfor today's date.
        
        print("Now = \(self)")
        
        var date_components = calendar.components([.year,.month,.day],from: self as Date)
        
        //Create an NSDate for 8:00 AM today.
        date_components.hour = hours
        date_components.minute = minutes
        date_components.second = 0
        
        let newDate = calendar.date(from: date_components)!
        return newDate as NSDate
    }
}
//-------------------------------------------------------------
//Tell the system that NSDates can be compared with ==, >, >=, <, and <= operators
extension NSDate: Comparable {}

//-------------------------------------------------------------
//Define the global operators for the
//Equatable and Comparable protocols for comparing NSDates

public func ==(lhs: NSDate, rhs: NSDate) -> Bool
{
    return lhs.timeIntervalSince1970 == rhs.timeIntervalSince1970
}

public func <(lhs: NSDate, rhs: NSDate) -> Bool
{
    return lhs.timeIntervalSince1970 < rhs.timeIntervalSince1970
}
public func >(lhs: NSDate, rhs: NSDate) -> Bool
{
    return lhs.timeIntervalSince1970 > rhs.timeIntervalSince1970
}
public func <=(lhs: NSDate, rhs: NSDate) -> Bool
{
    return lhs.timeIntervalSince1970 <= rhs.timeIntervalSince1970
}
public func >=(lhs: NSDate, rhs: NSDate) -> Bool
{
    return lhs.timeIntervalSince1970 >= rhs.timeIntervalSince1970
}


extension AdhocRequest : UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if tableView.tag == 1 {
            if pickupbutton.isSelected{
                return  self.pickupLocationsArray.count //notificationArr.count //3 //exampleContent.count //3 //notificationArr.count
            }else{
                return self.dropLocationsArray.count
            }
        }else{
            if pickupbutton.isSelected {
                return self.dropLocationsArray.count
            }else{
                return  self.pickupLocationsArray.count
            }
            
        }
        
        /*
        if self.pickupLocationFlag{
            return  self.pickupLocationsArray.count //notificationArr.count //3 //exampleContent.count //3 //notificationArr.count
        }else{
            return self.dropLocationsArray.count
        }*/
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView.tag == 1 {
            if pickupbutton.isSelected {
                let cell = tableView.dequeueReusableCell(withIdentifier: "PickupLocationsCellID", for: indexPath) as! PickupLocationsCellClass
                cell.AddressLbl.text = self.pickupLocationsArray[indexPath.row].Location
                return cell
            }else{
                let cell = tableView.dequeueReusableCell(withIdentifier: "PickupLocationsCellID", for: indexPath) as! PickupLocationsCellClass
                cell.AddressLbl.text = self.dropLocationsArray[indexPath.row].Location
                return cell
            }
           
        }else{
            if pickupbutton.isSelected{
                let cell = tableView.dequeueReusableCell(withIdentifier: "DropLocationsCellID", for: indexPath) as! DropLocationsCellClass
                cell.AddressLbl.text = self.dropLocationsArray[indexPath.row].Location
                return cell
            }else{
                let cell = tableView.dequeueReusableCell(withIdentifier: "DropLocationsCellID", for: indexPath) as! DropLocationsCellClass
                cell.AddressLbl.text = self.pickupLocationsArray[indexPath.row].Location
                return cell
            }
            
        }
        
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        if tableView.tag == 1{
            self.pickupLocationsContainer.isHidden = true
            if pickupbutton.isSelected{
                self.pickupLocationSelectedItem = self.pickupLocationsArray[indexPath.row]
                self.pickuptextfield.text = self.pickupLocationSelectedItem.Location
            }else{
                self.pickupLocationSelectedItem = self.dropLocationsArray[indexPath.row]
                self.pickuptextfield.text = self.pickupLocationSelectedItem.Location
            }
            
            
        }else{
            self.dropLocationsContainer.isHidden = true
            if pickupbutton.isSelected{
                self.dropLocationSelectedItem = self.dropLocationsArray[indexPath.row]
                self.droptextfield.text = self.dropLocationSelectedItem.Location
            }else{
                self.dropLocationSelectedItem = self.pickupLocationsArray[indexPath.row]
                self.droptextfield.text = self.dropLocationSelectedItem.Location
            }
           
        }
        
    }
    
}
class PickupLocationsCellClass : UITableViewCell {
    @IBOutlet weak var AddressLbl: UILabel!
}
class DropLocationsCellClass : UITableViewCell {
    @IBOutlet weak var AddressLbl: UILabel!
}
extension AdhocRequest:UIPickerViewDelegate,UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickupbutton.isSelected{
            return pickupShiftTimeArr.count
        }else{
            return dropShiftTimeArr.count
        }
        
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickupbutton.isSelected{
            return "\(pickupShiftTimeArr[row])"
        }else{
            return "\(dropShiftTimeArr[row])"
        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if pickupbutton.isSelected{
            shiftTimeSelectedItem = "\(pickupShiftTimeArr[row])"
        }else{
            shiftTimeSelectedItem = "\(dropShiftTimeArr[row])"
        }
        
    }
}
