

//
//  PaymentModeDetailsSelectClass.swift
//  DriveBooking
//
//  Created by SunTelematics on 21/09/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit

protocol PaymentModeDetailsSelectDelegate {
    func DidOKTapped(_ selectedPaymentMode:String!,_ controller:PaymentModeDetailsSelectClass)
}

class PaymentModeDetailsSelectClass: UIViewController {

     var myDelegateRef:PaymentModeDetailsSelectDelegate!

    @IBOutlet weak var paymentModeTableview: UITableView!
    
    var corpOrPersonalType : String!
    var hideButtons : Bool = false
    
    
    var DriveBookingResponce:DriveLoginResponce!
    var corpPaymentModesArr = [String]()
    var personalPaymentModesArr = [String]()
    var selectedIndexPath : NSIndexPath?
    
    var selectedPaymentTypeString : String!
    var paymentTypeSelectedFlag : Bool = false
    
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var okBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.white
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
        self.navigationItem.leftBarButtonItem = BackBtnItem
        
        self.navigationItem.title = "PAYMENT"
        
        self.paymentModeTableview.delegate = self
        self.paymentModeTableview.dataSource = self
        self.paymentModeTableview.tableFooterView = UIView.init(frame: CGRect.zero)
        self.paymentModeTableview.separatorStyle = .none
        
        self.DriveBookingResponce = FetchDriveResponce()
        corpPaymentModesArr = DriveBookingResponce.CorpPaymentModes.components(separatedBy: "|")
        personalPaymentModesArr = DriveBookingResponce.PersonalPaymentModes.components(separatedBy: "|")
        
        if hideButtons {
            self.cancelBtn.isHidden = true
            self.okBtn.isHidden = true
        }else{
            self.cancelBtn.isHidden = false
            self.okBtn.isHidden = false
        }
    }

    func BackAction(_ sender: UIButton) {
//        self.navigationController?.popToRootViewController(animated: true)
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func cancelBtnTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
//        self.dismiss(animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func OKBtnTapped(_ sender: UIButton) {
        
        print("selectedPaymentTypeString = ",self.selectedPaymentTypeString)
        if paymentTypeSelectedFlag {
            myDelegateRef.DidOKTapped(self.selectedPaymentTypeString, self)
        }else{
            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Select a Payment Type", Interval: 3)
        }
        
       

        //        controller.dismiss(animated: true, completion: nil)
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension PaymentModeDetailsSelectClass : UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.corpOrPersonalType == "CORPORATE" {
                return corpPaymentModesArr.count
        }else{
            return personalPaymentModesArr.count
        }
            
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "paymentModeCellID", for: indexPath) as! PaymentModeCell
        cell.paymentTypeContentView.layer.borderWidth = 1
        cell.paymentTypeContentView.layer.borderColor = UIColor.lightGray.cgColor
        cell.paymentTypeContentView.layer.cornerRadius = 5
        
        if self.corpOrPersonalType == "CORPORATE" {
                cell.paymentTypeLabel.text = self.corpPaymentModesArr[indexPath.row]
        }else {
                cell.paymentTypeLabel.text = self.personalPaymentModesArr[indexPath.row]
        }
        
//        cell.cancelButton.addTarget(self, action: #selector(cancelButtonTapped), for: .touchUpInside)
//        cell.cancelButton.tag = indexPath.row

//        cell.paymentTypeBtn.addTarget(self, action: #selector(paymentTypeSelectedBtnTapped), for: .touchUpInside)
//        cell.paymentTypeBtn.tag = indexPath.row
        
        
        
        if (selectedIndexPath == indexPath as NSIndexPath){
            cell.paymentTypeBtn.setImage(#imageLiteral(resourceName: "checkedBlack"), for: .normal)
            self.selectedPaymentTypeString = cell.paymentTypeLabel.text!
        }else{
            cell.paymentTypeBtn.setImage(#imageLiteral(resourceName: "uncheckedBlack"), for: .normal)
        }
        

        if hideButtons {
            cell.paymentTypeBtn.isHidden = true
        }else{
            cell.paymentTypeBtn.isHidden = false
        }
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        selectedIndexPath = indexPath as NSIndexPath
        paymentTypeSelectedFlag = true
        tableView.reloadData()
    }

}
class PaymentModeCell: UITableViewCell {
    
    @IBOutlet weak var paymentTypeContentView: UIView!
    @IBOutlet weak var paymentTypeLabel: UILabel!
    @IBOutlet weak var paymentTypeBtn: UIButton!
}
