//
//  ResetPassVC.swift
//  DriveFindMyCab
//
//  Created by Admin on 31/03/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit

class ResetPassVC: UIViewController,UITextFieldDelegate {

    @IBOutlet var UserIDTxt : UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func SUBMIT_BtnPressed(_ sender:UIButton) {
        
        
        if UtilitiesClassSub.removeLeadingandTralingSpace(UserIDTxt.text!).characters.count == 0 {
            UtilitiesClass.Alert(Title: "Alert!", Message: "UserId/Email should not be empty", Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
        }
        else {
            if (Reachability()?.isReachable)! {
                self.view.StartLoading()
                
                let RequestDict = ["EmpEmail":UserIDTxt.text!]
                
                WebService().callAutoAPI(Suffix: WebServicesUrl.ResetPass, parameterDict: RequestDict, completion: { (dataDict, success) in
                    
                    self.view.StopLoading()
                    
                    if success {
                        // handel of data
                        if let Dict = dataDict {
                            let Arr = Dict["data"] as! [[String:AnyObject]]
                            let ResponceData = Arr[0]
                            UtilitiesClass.Alert(Title: "Alert!", Message: ResponceData["Response"] as! NSString, Actions: [UtilitiesClass.AlertActionWithSelector(Title: "Ok", Selector: #selector(self.GoBack), Controller: self)], Controller: self)
                        }
                        else {
                            UtilitiesClass.Alert(Title: "Alert!", Message: Constants.InternalError as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                        }
                    }
                    else {
                        UtilitiesClass.Alert(Title: "Alert!", Message: Constants.InternalError as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                })
                
            }
            else {
                UtilitiesClass.Alert(Title: "Alert!", Message: Constants.NetErrorMsg as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            }
        }
        
    }
    func GoBack() {
        dismiss(animated: true, completion: nil)
    }
    @IBAction func BACK_BtnPressed(_ sender:UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }

}
