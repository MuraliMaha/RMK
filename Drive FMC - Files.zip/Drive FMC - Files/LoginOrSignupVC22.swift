//
//  LoginVC22.swift
//  DriveFindMyCab
//
//  Created by SunTelematics on 02/05/18.
//  Copyright © 2018 Suntelematics. All rights reserved.
//

import UIKit

class LoginOrSignupVC22: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    print("SUccesss")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func loginBtnTapped(_ sender: UIButton) {
        
        let loginVC = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC22SBID") as! LoginVC22
        
        let navCtrl1 : UINavigationController = self.navigationController!
//        ctrl.present(LoginObj, animated: true, completion: nil)
        navCtrl1.pushViewController(loginVC, animated: true)
    }
    @IBAction func signupBtnTapped(_ sender: UIButton) {
        let signupVC = self.storyboard?.instantiateViewController(withIdentifier: "SignupVC22SBID") as! SignupVC22
        
        let navCtrl1 : UINavigationController = self.navigationController!
        //        ctrl.present(LoginObj, animated: true, completion: nil)
        navCtrl1.pushViewController(signupVC, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
