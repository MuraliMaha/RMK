//
//  MyRidesVC.swift
//  DriveFindMyCab
//
//  Created by Admin on 01/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit

class MyRidesVC: UIViewController {

    @IBOutlet var SliderScrollView: UIScrollView!
    @IBOutlet var SliderNobView: UIView!
    @IBOutlet var PagingView: UIView!
    
    // MARK: - Page controller
    
    var PageViewController:UIPageViewController = {
        let Currentstoryboard:UIStoryboard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        let controller = Currentstoryboard.instantiateViewController(withIdentifier: "PageController") as! UIPageViewController
        return controller
    }()
    
    // MARK: - View controllers for paging
    
    let CorporateController:CorporateRidesVC = {
        let Currentstoryboard:UIStoryboard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        let controller = Currentstoryboard.instantiateViewController(withIdentifier: "CorporateRidesVC") as! CorporateRidesVC
        return controller
    }()
    
    let PersonalController:PersonalRidesVC = {
        let Currentstoryboard:UIStoryboard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        let controller = Currentstoryboard.instantiateViewController(withIdentifier: "PersonalRidesVC") as! PersonalRidesVC
        return controller
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.pagingAfterDelay), userInfo: nil, repeats: false)
    }
    
    func pagingAfterDelay() {
        
        PageViewController.setViewControllers([CorporateController], direction: .forward, animated: true) { (Completed:Bool) in
            if Completed {
            }
        }
        
        self.addChildViewController(PageViewController)
        PageViewController.view.frame = CGRect.init(x: 0, y: PagingView.frame.origin.y, width: PagingView.frame.size.width, height: PagingView.frame.size.height)
        PageViewController.dataSource = self
        PageViewController.delegate = self
        PagingView.addSubview(PageViewController.view)
        PageViewController.didMove(toParentViewController: self)
        
    }
    
    @IBAction func CorporateBtnPressed(_ sender: UIButton) {
        
        if PageViewController.viewControllers?[0] != CorporateController {
            
            PageViewController.setViewControllers([CorporateController], direction: .reverse, animated: true) { (Completed:Bool) in
                
                if Completed {
                    
                    self.SliderScrollView.setContentOffset(CGPoint.init(x: 0, y: 0), animated: true)
                }
                
            }
            
        }
        
    }
    
    @IBAction func PersonalBtnPressed(_ sender: UIButton) {
        
        if PageViewController.viewControllers?[0] != PersonalController {
            
            PageViewController.setViewControllers([PersonalController], direction: .forward, animated: true) { (Completed:Bool) in
                
                if Completed {
                    
                    self.SliderScrollView.setContentOffset(CGPoint.init(x: -(UIScreen.main.bounds.size.width)/2, y: 0), animated: true)
                    
                }
                
            }
            
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    

}


extension MyRidesVC : UIPageViewControllerDataSource,UIPageViewControllerDelegate {
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        var BeforeViewcontroller = viewController
        
        if BeforeViewcontroller == CorporateController {
            BeforeViewcontroller = PersonalController
        }
        else {
            return nil
        }
        
        return BeforeViewcontroller
    }
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        var AfterViewcontroller = viewController
        
        if AfterViewcontroller == PersonalController {
            AfterViewcontroller = CorporateController
        }
        else {
            return nil
        }
        
        return AfterViewcontroller
    }
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        if finished {
            if pageViewController.viewControllers?[0] == CorporateController {
                self.SliderScrollView.setContentOffset(CGPoint.init(x: 0, y: 0), animated: true)
            }
            else if pageViewController.viewControllers?[0] == PersonalController {
                self.SliderScrollView.setContentOffset(CGPoint.init(x: -(UIScreen.main.bounds.size.width)/2, y: 0), animated: true)
            }
        }
    }
}
