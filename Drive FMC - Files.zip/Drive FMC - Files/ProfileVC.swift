//
//  ProfileVC.swift
//  DriveFindMyCab
//
//  Created by Admin on 01/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit

class ProfileVC: UIViewController {
    @IBOutlet var EmailIdLbl: UILabel!
    @IBOutlet var UserIdLbl: UILabel!
    @IBOutlet var NameLbl: UILabel!
    @IBOutlet var MobileNumberLbl: UILabel!
    @IBOutlet var PasswordLbl: UILabel!

    var LoginResponce:LoginResponce!
    var LoginDetails:LoginDetails!

    var tappedBtnCellTag:Int!
    
    @IBOutlet weak var mobileNoEditBtn: UIButton!
    var companyName = "Murali"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        DispatchQueue.main.async {
            self.LoginDetails = FetchLoginDetails()
            self.LoginResponce = FetchLoginResponce()
            self.EmailIdLbl.text = self.LoginResponce.Email!
            self.UserIdLbl.text = self.LoginDetails.UserID!
            self.NameLbl.text = self.LoginResponce.Name!
//            if LoginResponce.CompanyName == "HPE"{
            if self.companyName == "HPE" {
                self.MobileNumberLbl.text = ""
                self.mobileNoEditBtn.isHidden = true
            }else{
                self.MobileNumberLbl.text = self.LoginResponce.PhoneNo!
                self.mobileNoEditBtn.isHidden = false
            }
            
            
            var Password = ""
            for _ in 0..<self.LoginDetails.Password!.characters.count {
                Password.append("*")
            }
            self.PasswordLbl.text = Password
        }
        
        
        let donetoolbar = UIToolbar(frame : CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        
        donetoolbar.barStyle = UIBarStyle.default
        donetoolbar.backgroundColor = UIColor.black
        let flexspace = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let done = UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(DoneReturn))
        
        donetoolbar.tintColor = UIColor.blue
        donetoolbar.items = [flexspace,done]
        donetoolbar.sizeToFit()
        
        NumberTxt.inputAccessoryView = donetoolbar
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    
    @IBAction func EmergencyContactBtn(_ sender:UIButton) {
        let Emergency = self.storyboard?.instantiateViewController(withIdentifier: "EmergencyContactVC") as! EmergencyContactVC
        
        self.navigationController?.pushViewController(Emergency, animated: true)
    }
    
    
    // MARK: - Edit Number {
    
    @IBOutlet var EditNumberView: UIView!
    @IBOutlet var NumberTxt: UITextField!
    
    var ActualEditY : CGFloat = 0

    @IBAction func EditMobileNumberBtn(_ sender:UIButton) {
        
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        
        BackView.center = (window?.center)!
        
        window?.addSubview(BackView)
        EditNumberView.center = BackView.center
        
        BackView.addSubview(EditNumberView!)
        
        NumberTxt.text = LoginResponce.PhoneNo!
        
        ActualEditY = EditNumberView.frame.origin.y

        let GuardianTap = UITapGestureRecognizer.init(target: self, action: #selector(TapEditGuardianView(_:)))
        GuardianTap.numberOfTapsRequired = 1
        BackView.addGestureRecognizer(GuardianTap)
        
        EditNumberView.alpha = 0
        
        
        UIView.animate(withDuration: 0.5) {
            self.EditNumberView.alpha = 1
        }
    }
    
    func DoneReturn() {
        NumberTxt.resignFirstResponder()
    }
    
    @IBAction func CancelBtn(_ sender:UIButton) {
        
        UIView.animate(withDuration: 0.3, animations: {
            self.EditNumberView.alpha = 0
        }) { (yes) in
            if yes {
                self.EditNumberView.alpha = 1
                self.EditNumberView.superview?.removeFromSuperview()
            }
        }
    }
    
    func CloseEditNumber() {
        UIView.animate(withDuration: 0.3, animations: {
            self.EditNumberView.alpha = 0
        }) { (yes) in
            if yes {
                self.EditNumberView.alpha = 1
                self.EditNumberView.superview?.removeFromSuperview()
            }
        }
    }
    
    func TapEditGuardianView(_ responder:UITapGestureRecognizer) {
        
        
        let Point = responder.location(in: EditNumberView.superview!)
        let Frame = EditNumberView.frame
        
        if !Frame.contains(Point) {
            
            UIView.animate(withDuration: 0.3, animations: {
                self.EditNumberView.alpha = 0
            }) { (yes) in
                if yes {
                    self.EditNumberView.alpha = 1
                    self.EditNumberView.superview?.removeFromSuperview()
                }
            }
        }
        
    }
    
    @IBAction func ChangeConfirmBtn(_ sender:UIButton) {
        
        NumberTxt.resignFirstResponder()
        
        if UtilitiesClassSub.removeLeadingandTralingSpace(NumberTxt.text).characters.count == 0 {
            EditNumberView.superview?.ShowWhiteTostWithText(message: "Invalid Number", Interval: 3)
        }
        else if NumberTxt.text?.characters.count != 10 {
            EditNumberView.superview?.ShowWhiteTostWithText(message: "Invalid Number", Interval: 3)
        }
        else {
            CallUpdateNumberService(Dict: ["Phone":"\(NumberTxt.text!)"])
        }
    }

    // MARK: - }
    
    // MARK: - Change Password {
    
    @IBOutlet var ChangePasswordView: UIView!
    @IBOutlet var OldPasswordTxt: UITextField!
    @IBOutlet var NewPasswordTxt: UITextField!
    @IBOutlet var ConfirmPasswordTxt: UITextField!
    
    var ActualPassY : CGFloat = 0

    @IBAction func ChangePasswordBtn(_ sender:UIButton) {
        
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        
        BackView.center = (window?.center)!
        
        window?.addSubview(BackView)
        ChangePasswordView.center = BackView.center
        
        BackView.addSubview(ChangePasswordView!)
        
        let GuardianTap = UITapGestureRecognizer.init(target: self, action: #selector(TapAddGuardianView(_:)))
        GuardianTap.numberOfTapsRequired = 1
        BackView.addGestureRecognizer(GuardianTap)
        
        ActualPassY = ChangePasswordView.frame.origin.y
        
        OldPasswordTxt.text = ""
        NewPasswordTxt.text = ""
        ConfirmPasswordTxt.text = ""
        
        ChangePasswordView.alpha = 0
        UIView.animate(withDuration: 0.5) {
            self.ChangePasswordView.alpha = 1
        }
    }
    
    func TapAddGuardianView(_ responder:UITapGestureRecognizer) {
        
        let Point = responder.location(in: ChangePasswordView.superview!)
        let Frame = ChangePasswordView.frame
        
        if !Frame.contains(Point) {
            CloseChangePass()
        }
        
    }
    
    func CloseChangePass(){
        UIView.animate(withDuration: 0.3, animations: {
            self.ChangePasswordView.alpha = 0
        }) { (yes) in
            if yes {
                self.ChangePasswordView.alpha = 1
                self.ChangePasswordView.superview?.removeFromSuperview()
            }
        }
    }
    
    @IBAction func ConfirmPasswordBtn(_ sender:UIButton) {
        
        self.ChangePasswordView.endEditing(true)

        if UtilitiesClassSub.removeLeadingandTralingSpace(OldPasswordTxt.text).characters.count == 0 {
            ChangePasswordView.superview?.ShowWhiteTostWithText(message: "Please enter Old Password", Interval: 3)
        }
        else if NewPasswordTxt.text?.characters.count == 0 {
            ChangePasswordView.superview?.ShowWhiteTostWithText(message: "Please enter New Password", Interval: 3)
        }
        else if UtilitiesClassSub.removeLeadingandTralingSpace(NewPasswordTxt.text).characters.count == 0
        {
            ChangePasswordView.superview?.ShowWhiteTostWithText(message: "Please enter New Password", Interval: 3)
        }
        else if ConfirmPasswordTxt.text?.characters.count == 0 {
            ChangePasswordView.superview?.ShowWhiteTostWithText(message: "Please enter Confirm Password", Interval: 3)
        }
        else if UtilitiesClassSub.removeLeadingandTralingSpace(ConfirmPasswordTxt.text).characters.count == 0
        {
            ChangePasswordView.superview?.ShowWhiteTostWithText(message: "Please enter Confirm Password", Interval: 3)
        }
        else if LoginDetails.Password! != OldPasswordTxt.text!
        {
            ChangePasswordView.superview?.ShowWhiteTostWithText(message: "Old Password is not matching", Interval: 3)
        }
        else if NewPasswordTxt.text! == OldPasswordTxt.text! {
            ChangePasswordView.superview?.ShowWhiteTostWithText(message: "Old and New Passwords are same", Interval: 3)
        }
        else if NewPasswordTxt.text! != ConfirmPasswordTxt.text {
            ChangePasswordView.superview?.ShowWhiteTostWithText(message: "Confirm Password not matching", Interval: 3)
        }
        else {
            CallChangePassService(Dict: ["userid":"\(LoginDetails.UserID!)","oldpassword":"\(LoginDetails.Password!)","newpassword":"\(NewPasswordTxt.text!)"])
        }
    }
    // MARK: - }

    
    //MARK: - Keyboard and TextField Delegates {

    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardHide(_:)), name: .UIKeyboardWillHide, object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    
    
    func keyboardShow(_ notification : NSNotification){
        
        if !NumberTxt.isFirstResponder {
            
            let info = notification.userInfo
            let keyboardframe = (info![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size
            var frame = CGRect.init()
            if OldPasswordTxt.isFirstResponder {
                frame = OldPasswordTxt.frame
            }
            else if NewPasswordTxt.isFirstResponder {
                frame = NewPasswordTxt.frame
            }
            else {
                frame = ConfirmPasswordTxt.frame
            }
            
            frame.origin.y += ChangePasswordView.frame.origin.y

            var actualframe = ChangePasswordView.superview?.frame
            actualframe?.size.height -= keyboardframe.height
            actualframe?.size.height -= (frame.size.height)
            
            if !(actualframe?.contains((frame.origin)))! {
                
                let yfinal = (frame.origin.y) - (actualframe?.size.height)!
                
                UIView.animate(withDuration: 0.3, animations: { () -> Void in
                    self.ChangePasswordView.frame.origin.y -= yfinal
                })
                
            }
        }
        else {
            
            let info = notification.userInfo
            let keyboardframe = (info![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size
            var frame = NumberTxt.frame
            
            frame.origin.y += EditNumberView.frame.origin.y
            
            var actualframe = EditNumberView.superview?.frame
            actualframe?.size.height -= keyboardframe.height
            actualframe?.size.height -= (frame.size.height)
            
            if !(actualframe?.contains((frame.origin)))! {
                
                let yfinal = (frame.origin.y) - (actualframe?.size.height)!
                
                UIView.animate(withDuration: 0.3, animations: { () -> Void in
                    self.EditNumberView.frame.origin.y -= yfinal
                })
                
            }
        }

    }
    
    
    func keyboardHide(_ notification : NSNotification)
    {
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.ChangePasswordView.frame.origin.y = self.ActualPassY
            self.EditNumberView.frame.origin.y = self.ActualEditY
        })
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField == NumberTxt {
            
            let newLength = (textField.text?.characters.count)! + string.characters.count - range.length
            
            if newLength > 10 {
                return false
            }
            
            let aSet = NSCharacterSet(charactersIn:"0123456789").inverted
            let compSepByCharInSet = string.components(separatedBy: aSet)
            let numberFiltered = compSepByCharInSet.joined(separator: "")
            return string == numberFiltered
        }
        else {
            return true
        }
    }
    
    // MARK: - }

    // MARK: - Call Service {
    
    func CallChangePassService(Dict:[String:String]) {
        
        if (Reachability()?.isReachable)! {
            UIApplication.shared.keyWindow?.StartLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.UpdatePassword, parameterDict: Dict, completion: { (dataDict, success) in
                
                UIApplication.shared.keyWindow?.StopLoading()
                
                if success {
                    // handel of data
                    if let Sub = dataDict {
                        let Arr = Sub["data"] as! [[String:AnyObject]]
                        let ResponceData = Arr[0]
                        
                        self.view.ShowWhiteTostWithText(message: "\(ResponceData["Response"]!)", Interval: 5)
                        
                        let LoginDetailsDict = ["EmpPassword":"\(Dict["newpassword"]!)","EmpCode":self.LoginDetails.EmpCode!,"DeviceToken":self.LoginDetails.DeviceToken!,"DeviceType":self.LoginDetails.DeviceType!,"DeviceIMEI":self.LoginDetails.DeviceIMEI!]
                        SaveLoginDetails(LoginDetailsdict: LoginDetailsDict)
                        self.LoginDetails.Password = "\(Dict["newpassword"]!)"
                        
                        var Password = ""
                        for _ in 0..<self.LoginDetails.Password!.characters.count {
                            Password.append("*")
                        }
                        self.PasswordLbl.text = Password
                        
                        self.CloseChangePass()
                    }
                    else {
                        self.ChangePasswordView.superview?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 3)
                    }
                    
                }
                else {
                    self.ChangePasswordView.superview?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 3)
                }
            })
            
        }
        else {
            self.ChangePasswordView.superview?.ShowWhiteTostWithText(message: "Check for Internet Conenction", Interval: 3)
        }
        
    }
    
    func CallUpdateNumberService(Dict:[String:String]) {
        
        if (Reachability()?.isReachable)! {
        
            UIApplication.shared.keyWindow?.StartLoading()
            
            let ParamsDict = ["EmpName":"\(LoginResponce.Name!)","Mobileno":"\(Dict["Phone"]!)","EmpCode":"\(LoginDetails.UserID!)"]
            WebService().callAutoAPI(Suffix: WebServicesUrl.ProfileUpdate, parameterDict: ParamsDict, completion: { (dataDict, success) in
                
                UIApplication.shared.keyWindow?.StopLoading()
                
                if success {
                    // handel of data
                    if let ResponceDict = dataDict {
                        let Arr = ResponceDict["data"] as! [[String:AnyObject]]
                        let ResponceData = Arr[0]
                        self.view.ShowWhiteTostWithText(message: "\(ResponceData["ToastMessage"]!)", Interval: 5)
                        
                        self.LoginResponce.PhoneNo = "\(Dict["Phone"]!)"
                        
                        SaveLoginResponceWithStruct(Struct: self.LoginResponce!)
                        
                        self.MobileNumberLbl.text = "\(Dict["Phone"]!)"
                        
                        self.CloseEditNumber()
                    }
                    else {
                        self.EditNumberView.superview?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 3)
                    }
                }
                else {
                    self.EditNumberView.superview?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 3)
                }
            })
            
        }
        else {
            self.EditNumberView.superview?.ShowWhiteTostWithText(message: "Check for Internet Conenction", Interval: 3)
        }
        
    }
    
    // MARK: - }
    
}
