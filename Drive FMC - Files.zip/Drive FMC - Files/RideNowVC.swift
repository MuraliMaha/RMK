//
//  RideNowVC.swift
//  DriveFindMyCab
//
//  Created by Amarnath B on 22/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit
import GoogleMaps
import LGSideMenuController
import Alamofire

 class RideNowVC: UIViewController, FavoriteLocSelectDelegate,PaymentTypeSelectionDelegate, UITextFieldDelegate, ConfirmDelegate, UIPickerViewDelegate, UIPickerViewDataSource, BiddingDelegate, MobiKwikAddMoneyDelegate, PaytmAddMoneyDelegate {

    @IBOutlet var RideLaterMap: GMSMapView!
    
    @IBOutlet var mapCenterPinImage: UIImageView!
    
    @IBOutlet var ConvenianceLabel: UILabel!
    @IBOutlet var PickUpSelectionView: UIView!
    @IBOutlet var DropSelectionView: UIView!
    
    @IBOutlet var PickUpSelectionLbl: UILabel!
    @IBOutlet var DropSelectionLbl: UILabel!

    @IBOutlet var ADDFavPickupBtn: UIButton!
    @IBOutlet var ADDFavDropBtn: UIButton!

    @IBOutlet var VehCategoryCollection: UICollectionView!
    @IBOutlet var ConfirmBookingCollection: UICollectionView!

    @IBOutlet var VehCategoryHolderView: UIView!
    @IBOutlet var ConfirmBookingHolderView: UIView!
    
    @IBOutlet var ConfirmBookingBtnView: UIView!

    @IBOutlet var RIDENOW_Btn: UIButton!

    let LocationManager = CLLocationManager()
    var camefromtrips : String! = ""
    
    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!
    
    var PickupMarkerObj: PickupMarker!
    var DropMarkerObj: DropMarker!
    
    
    var IsFirstTime = true
    var CityName = ""
    var LoadGeoLocation = true
    
    var BOFName : String!
    var BOFNumber : String!
    
    var fetchCityName : String! = ""
    
    var isTranslationSuccess = false
    var EstimatedFare :String!
    var EstimatedDistance :String!
    var sendDropForEvents : String! = "NA"
//    func rightButtonAction(sender: UIBarButtonItem) {
//        print("Bell Clicked")
//        let Track = self.storyboard?.instantiateViewController(withIdentifier: "NewOffers") as! NewOffers
//            Track.isFrom = 1
//        self.navigationController?.pushViewController(Track, animated: true)
//    }
//    var label : UILabel!
    
    
    
    var PaytmToken: String!
    var PaytmMobile: String!
    
    
    
    var MobiToken: String!
    var MobiMobile: String!
    
    var  MinimumBalanceRequired : Float! = 150.0

    
    @IBOutlet weak var rideLaterBtn: UIButton!
    @IBAction func rideLaterBtn(_ sender: UIButton) {
        ResetAll()
        
        let controller = self.storyboard?.instantiateViewController(withIdentifier: "DriveBookingVC") as! DriveBookingVC
        let transition = CATransition()
        transition.duration = 0.45
        transition.type = kCATransitionFade;
        transition.subtype = kCATransitionFromBottom;
        
        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
        
        self.navigationController?.pushViewController(controller, animated: false)
    }
    
    @IBOutlet var customerSupportView: UIView!
    @IBOutlet weak var customerSupportNumber: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        NotificationCenter.default.addObserver(self, selector: #selector(self.actOnSpecialNotification), name: NSNotification.Name(rawValue: myNotificationKey), object: nil)
 
 

        LoginRequest = FetchDriveRequest()
        DriveBookingResponce = FetchDriveResponce()
        
        PaytmToken = DriveBookingResponce.SSOToken!
        PaytmMobile = DriveBookingResponce.PaytmWalletNo!
        
        MobiToken = DriveBookingResponce.WalletToken!
        MobiMobile = DriveBookingResponce.WalletMobileNo!
        MinimumBalanceRequired = Float(DriveBookingResponce.WalletMinBalance!)!
        
        
        
        //Configuring Notification Badge (No Frameworks used its just UILabel)
        
//        label = UILabel(frame: CGRect(x: -16, y: -8, width: 27, height: 15))
//        label.layer.borderColor = UIColor.clear.cgColor
//        label.layer.borderWidth = 2
//        label.layer.cornerRadius = label.bounds.size.height / 2.4
//        label.textAlignment = .center
//        label.layer.masksToBounds = true
//        //        label.font = UIFont(name: "AvenirNextLTPro-Regular", size: 6)
//        label.font = label.font.withSize(10)
//        label.textColor = .black
//        label.backgroundColor = UIColor.init(hex: "fce45d", alpha: 1)
        
//        show badge only if notification count is greater than 0
//        if "\(DriveBookingResponce.NotificationsCount!)" > "0"{
//            label.isHidden = false
//            label.text = "\(DriveBookingResponce.NotificationsCount!)"
//
//        }else{
//
//            label.isHidden = true
//        }
//        label.text = "\(DriveBookingResponce.NotificationsCount!)"
        
//        // button
//        let rightButton = UIButton(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
//        rightButton.setBackgroundImage(#imageLiteral(resourceName: "notifSymbol").ReduceImageSize(CGSize.init(width: 20, height: 20)), for: .normal)
//        rightButton.addTarget(self, action: #selector(rightButtonAction), for: .touchUpInside)
//        rightButton.addSubview(label)
//
//        // Bar button item
//        let rightBarButtomItem = UIBarButtonItem(customView: rightButton)
//
//        self.navigationItem.rightBarButtonItem = rightBarButtomItem
        
        
        FetchFavs()
        ConfirmationMake()
        GetVehCategory()
        BookNowHiddenTxtMake()
        
//        VehCategoryCollection.reloadData()
        
        DispatchQueue.main.async {
            
            if self.PickupMarkerObj != nil {
                self.PickupMarkerObj.map = nil
            }
            
            if self.DropMarkerObj != nil {
                self.DropMarkerObj.map = nil
            }
            
            self.mapCenterPinImage.isHidden = false
            self.RideLaterMap.isMyLocationEnabled = true
            self.IsCouponAvailable = false
            self.CouponCode = ""
            self.LoadGeoLocation = true
            
            
            self.PickUpSelectionView.layer.masksToBounds = false
            self.PickUpSelectionView.layer.shadowColor = UIColor.black.cgColor
            self.PickUpSelectionView.layer.shadowOpacity = 0.35
            self.PickUpSelectionView.layer.shadowOffset = CGSize.zero
            self.PickUpSelectionView.layer.shadowRadius = 2.5
            
            self.PickUpSelectionView.layer.shadowPath = UIBezierPath(rect: self.PickUpSelectionView.bounds).cgPath
            
            
            self.DropSelectionView.layer.masksToBounds = false
            self.DropSelectionView.layer.shadowColor = UIColor.black.cgColor
            self.DropSelectionView.layer.shadowOpacity = 0.35
            self.DropSelectionView.layer.shadowOffset = CGSize.zero
            self.DropSelectionView.layer.shadowRadius = 2.5
            
            self.DropSelectionView.layer.shadowPath = UIBezierPath(rect: self.DropSelectionView.bounds).cgPath
            
            
            
//            self.VehCategoryCollection.layer.masksToBounds = false
//            self.VehCategoryCollection.layer.shadowColor = UIColor.black.cgColor
//            self.VehCategoryCollection.layer.shadowOpacity = 0.35
//            self.VehCategoryCollection.layer.shadowOffset = CGSize.zero
//            self.VehCategoryCollection.layer.shadowRadius = 2.5
//            
//            self.VehCategoryCollection.layer.shadowPath = UIBezierPath(rect: self.VehCategoryCollection.bounds).cgPath
            
            
            self.ConfirmBookingCollection.layer.masksToBounds = false
            self.ConfirmBookingCollection.layer.shadowColor = UIColor.black.cgColor
            self.ConfirmBookingCollection.layer.shadowOpacity = 0.35
            self.ConfirmBookingCollection.layer.shadowOffset = CGSize.zero
            self.ConfirmBookingCollection.layer.shadowRadius = 2.5
            
            self.ConfirmBookingCollection.layer.shadowPath = UIBezierPath(rect: self.ConfirmBookingCollection.bounds).cgPath
            
//            self.ConfirmBookingCollection.isHidden = true
//            self.VehCategoryCollection.isHidden = false
            
            self.hideUnhideVehCollectionViews(hide: false)
            
            self.DropSelectionView.isHidden = true
            self.ConfirmBookingBtnView.isHidden = true

            Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.LoaderAfter), userInfo: nil, repeats: false)
            
            self.InitializeLocationSelectionMarkers()
            
            self.DropSelectionLbl.text = "Enter Drop Location..."
            self.DropLocation = nil
            
            self.ChangeCenterPinImage(isPickup: true)
        }
        
        self.LocationManager.delegate = self

        self.LocationManager.requestWhenInUseAuthorization()
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "menu"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(MenuAction))
        BackBtnItem.tintColor = UIColor.white
        self.navigationItem.leftBarButtonItem = BackBtnItem
        directlygotoTrackingPage()
    }
    
    
    func hideUnhideVehCollectionViews(hide: Bool) {
        VehCategoryHolderView.isHidden = hide
        ConfirmBookingHolderView.isHidden = !hide
    }
    
    func hideUnhideBothCollectionViews(hide: Bool) {
        VehCategoryHolderView.isHidden = hide
        ConfirmBookingHolderView.isHidden = hide
    }
    
    
    func ChangeCenterPinImage(isPickup:Bool) {
        mapCenterPinImage.isHidden = false
        mapCenterPinImage.image = isPickup ? #imageLiteral(resourceName: "GreenTrack") : #imageLiteral(resourceName: "RedTrack")
    }
    
    
    @IBOutlet var DoneSpace: NSLayoutConstraint!
    @IBOutlet var BottomView1: UIView!
    
    
    @IBAction func DoneDropAction(_ sender:UIButton) {
        
        if (DropLocation != nil) {
            if PickUpLocation.Location! == DropLocation.Location!{
                self.view.ShowBlackTostWithText(message: "Pickup Location and Drop Location should not be same", Interval: 2)
                return
            }
            if DropLocation.Location.localizedCaseInsensitiveContains("India"){
                self.view.ShowBlackTostWithText(message: "Please Select Valid Drop Location", Interval: 3)
                return
            }
            LoadGeoLocation = false
            mapCenterPinImage.isHidden = true
            
            DoneBtnRemoveSpace()
            
            PickupMarkerObj = PickupMarker.init(Pickup: PickUpLocation!)
            PickupMarkerObj.map = RideLaterMap
            
            DropMarkerObj = DropMarker.init(Drop: DropLocation!)
            DropMarkerObj.map = RideLaterMap
            
            ZoomToWithMultiMarker(Position1: PickupMarkerObj.position, Position2: DropMarkerObj.position)
           LoadFareEstimationData()
            
        }
        else {
            self.view.ShowBlackTostWithText(message: "Please select Drop Location", Interval: 2)
        }
        
    }
    
    func DoneBtnSpaceMake() {
        DoneSpace.constant = 0
        BottomView1.isHidden = true
        
        
        self.hideUnhideBothCollectionViews(hide: true)
//        BottomView2.isHidden = true
    }
    
    func DoneBtnRemoveSpace() {
        DoneSpace.constant = 120
        BottomView1.isHidden = false
        self.hideUnhideBothCollectionViews(hide: false)

//        BottomView2.isHidden = false
    }
    
    // trigger notification when app running in foreground state. show a pop if notification message contains JOBNO
    func actOnSpecialNotification(recievedNotification: Notification) {
        print(recievedNotification.userInfo!)
        let x = recievedNotification.userInfo!["isFrom"] as! String
        
        
        let fullMessage = recievedNotification.userInfo!["Data"] as! String
        
        var JobString : String!
        
        if fullMessage.localizedCaseInsensitiveContains("Jobno:"){
            let ratingDetailsArray = fullMessage.components(separatedBy: "Jobno:")
            JobString = ratingDetailsArray[1]

        if x == "LIVE"{
            let action = UIAlertAction.init(title: "Ok", style: .default, handler: { (action) in
                self.GoToMyTripsVC(jobNo: JobString)
            })
            if !((navigationController?.visibleViewController?.isKind(of: DriveFeedbackVC.self))! || (navigationController?.visibleViewController?.isKind(of: DriveTrackVC.self))!) {
            Message.shared.Alert(Title: "Recieved Notification", Message: "\(recievedNotification.userInfo!["Data"] as! String)", TitleAlign: .left, MessageAlign: .left, Actions: [Message.AlertActionWithSelector(Title: "Cancel", Selector: #selector(DoNothing), Controller: self),action], Controller: self)
            }else{
                 Message.shared.Alert(Title: "Alert", Message: "\(recievedNotification.userInfo!["Data"] as! String)", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
             }
        }


//            else if x == "BACKGROUND"{
////            var persons = PersonalRides()
////            persons.Jobno = JobString!
////            persons.JobType = "Current"
////            
////            let controller = self.storyboard?.instantiateViewController(withIdentifier: "DriveTrackVC") as! DriveTrackVC
////            controller.TrackDetails = persons
////            controller.BackToParent = true
////            let navigationController = sideMenuController?.rootViewController as! UINavigationController
////            navigationController.pushViewController(controller, animated: true)
////            sideMenuController?.hideLeftView(animated: true, completionHandler: nil)
//        }

    }
        
    }
    func DoNothing(){
        
    }
    //    if above notification triggers when user selects ok ACtion call GoToMyTripsVC  page

    func GoToMyTripsVC(jobNo:String){
        
        var persons = PersonalRides()
        persons.Jobno = jobNo
        persons.JobType = "Current"
        
        if !(navigationController?.visibleViewController?.isKind(of: DriveFeedbackVC.self))! || !(navigationController?.visibleViewController?.isKind(of: DriveTrackVC.self))!{

        let controller = self.storyboard?.instantiateViewController(withIdentifier: "DriveTrackVC") as! DriveTrackVC
        controller.TrackDetails = persons
        controller.BackToParent = true

        let navigationController = sideMenuController?.rootViewController as! UINavigationController
        navigationController.pushViewController(controller, animated: true)
        sideMenuController?.hideLeftView(animated: true, completionHandler: nil)
        }
    }

    
    //    if there is any current running job directly goto tracking page

    func directlygotoTrackingPage(){
       
        let ratingDetails = DriveBookingResponce.RatingDetails!
        //print("ratingDetails%%%%%%%%%%%%%\(ratingDetails)")
        if  ratingDetails.contains("|") {
            
            let ratingDetailsArray = ratingDetails.components(separatedBy: "|")

            if ratingDetailsArray[0] == "0" || ratingDetailsArray[0] == "1" {
                self.view.StartLoading()
                //print(ratingDetailsArray[1])
                var persons = PersonalRides()
                persons.Jobno = ratingDetailsArray[1]
                persons.JobType = "Current"
                
                let Track = self.storyboard?.instantiateViewController(withIdentifier: "DriveTrackVC") as! DriveTrackVC
                Track.TrackDetails = persons
                Track.BackToParent = true
                self.navigationController?.pushViewController(Track, animated: true)
                self.view.StopLoading()
            }
            
        }
        
        
        
    }
    func LoaderAfter() {
        
        FetchFavs()
        print("*******testing********")
        print(FetchFavouritesLocation() ?? "NA")
        self.VehCategoryCollection.reloadData()
    }
    
    func MenuAction() {
        
        self.slideMenuController()?.openLeft()
        NotificationCenter.default.post(name: NSNotification.Name.init("MENURN"), object: nil)
        
//        sideMenuController?.showLeftView(animated: true, completionHandler: nil)
//        let transition = CATransition()
//        transition.duration = 0.45
//        transition.type = kCATransitionFade;
//        transition.subtype = kCATransitionFromBottom;
//
//        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
//
//        self.navigationController?.popViewController(animated: false)
        
    }
    
    var isPickSelected = false

    func InitializeLocationSelectionMarkers() {
       
        PickUpSelectionLbl.isUserInteractionEnabled = true
        let tapPick = UITapGestureRecognizer.init(target: self, action: #selector(PickUpViewTapped))
        tapPick.numberOfTapsRequired = 1
        PickUpSelectionLbl.addGestureRecognizer(tapPick)
        
        DropSelectionLbl.isUserInteractionEnabled = true
        let tapDrop = UITapGestureRecognizer.init(target: self, action: #selector(DropViewTapped))
        tapDrop.numberOfTapsRequired = 1
        DropSelectionLbl.addGestureRecognizer(tapDrop)
    
    }
    
    var PickUpLocation: FavouritesLocationsStruct!

    func PickUpViewTapped() {
        
        if ConfirmBookingBtnView.isHidden {
            isPickSelected = true
            
            let SearchController = FavoriteLocationSelectVC()
            SearchController.Delegate = self
            SearchController.IsSearchNeeded = true
            if PickUpLocation != nil{
                SearchController.CurrentLocationDetails = CLLocationCoordinate2DMake(PickUpLocation.Latitude!, PickUpLocation.Longitude!)
            }else{
                SearchController.CurrentLocationDetails = (RideLaterMap.myLocation?.coordinate)!
            }
            self.present(SearchController, animated: true, completion: nil)
        }
    }
    
    var DropLocation: FavouritesLocationsStruct!
    
    func DropViewTapped() {
        
        isPickSelected = false
        let SearchController = FavoriteLocationSelectVC()
        SearchController.Delegate = self
        SearchController.IsSearchNeeded = true
        SearchController.isDrop = true
        if PickUpLocation != nil{
            SearchController.CurrentLocationDetails = CLLocationCoordinate2DMake(PickUpLocation.Latitude!, PickUpLocation.Longitude!)
        }else{
            SearchController.CurrentLocationDetails = (RideLaterMap.myLocation?.coordinate)!
        }
        self.present(SearchController, animated: true, completion: nil)
        
    }
    
    // MARK: - Initilise Datas {
    struct VehCategoryStruct {
        var CategoryImage:UIImage!
        var CategoryName:String!
        var CategoryImageUrl:String!
        var CategoryId:String!
        var CategoryTime:String!
        var CatSelectedState:Bool!
        var CategorySelectedImage:UIImage!
        var CategorySelectedurl:String!
        var CategoryConveniance:String!
        var CategoryMapIcon:String!
    }
    var selectedCarImage : String!
    var VehicleDataArr = [VehCategoryStruct]()
    func ChangeConvenianceAmount(){
        ConvenianceLabel.text = SelectedVehicleCat.CategoryConveniance!
        selectedCarImage = SelectedVehicleCat.CategoryMapIcon!
        
       let x = SelectedVehicleCat.CategoryConveniance!
        if x != "" && x != "NA" {
        ConvenianceLabel.isHidden = false
        }
        else{
        ConvenianceLabel.isHidden = true
        }
    
    }
    func GetVehCategory() {
        
        var arr = [VehCategoryStruct]()
        
        var i = 0
        for Category in DriveBookingResponce.CategoryType {
            var Structt = VehCategoryStruct()
            Structt.CategoryId = Category.CategoryId!
            Structt.CategoryName = Category.CategoryName!
            Structt.CategoryImageUrl = Category.CategoryImage2!
            Structt.CategoryTime = "No cabs"
            Structt.CategorySelectedurl = Category.SelectedImage!
            Structt.CategoryConveniance = Category.PopupMessage!
            Structt.CategoryMapIcon = Category.MapIcon!
            if i == 0 {
                Structt.CatSelectedState = true
                SelectedVehicleCat = Structt
                ChangeConvenianceAmount()
            }
            else {
                Structt.CatSelectedState = false
            }
            
            i += 1
            
            arr.append(Structt)
        }
        
        VehicleDataArr.removeAll()
        
        VehicleDataArr = arr
    }
    
    
    var SelectedVehicleCat = VehCategoryStruct()
    
    // MARK: - }
    
    // MARK: - Favorate Loc selection {
    
    func DidCancelPicking(_ controller:FavoriteLocationSelectVC) {
        
        self.FetchFavs()
        
        if FavLocArr.count == 0 {
            self.ADDFavPickupBtn.isSelected = false
            self.ADDFavDropBtn.isSelected = false
        }
        else {
            if PickUpLocation == nil{
                return
            }
            if self.FavLocArr.contains(where: {$0.Location! == self.PickUpLocation.Location!}) {
                self.ADDFavPickupBtn.isSelected = true
            }
            else {
                self.ADDFavPickupBtn.isSelected = false
            }
            if (DropLocation != nil) {
                if self.FavLocArr.contains(where: {$0.Location! == self.DropLocation.Location!}) {
                    self.ADDFavDropBtn.isSelected = true
                }
                else {
                    self.ADDFavDropBtn.isSelected = false
                }
            }
            else {
                self.ADDFavDropBtn.isSelected = false
            }
        }
        controller.dismiss(animated: true, completion: nil)
    }
    
    func DidSelectChooseOnMap(_ controller: FavoriteLocationSelectVC) {
        controller.dismiss(animated: true, completion: nil)

        RideLaterMap.isUserInteractionEnabled = true
 
        LoadGeoLocation = true
        
//        self.ConfirmBookingCollection.isHidden = false
//        self.VehCategoryCollection.isHidden = true
        
        self.hideUnhideVehCollectionViews(hide: true)

        self.DropSelectionView.isHidden = false
        
        self.ConfirmBookingBtnView.isHidden = false
        
        
        self.ConfirmBookingCollection.reloadData()
        
        
        DropLocation = nil
        
        if PickupMarkerObj != nil {
            PickupMarkerObj.map = nil
            PickupMarkerObj = nil
        }
        if DropMarkerObj != nil {
            DropMarkerObj.map = nil
            DropMarkerObj = nil
        }

        ChangeCenterPinImage(isPickup: false)
        
        DoneBtnSpaceMake()
        self.perform(#selector(callZoomMarker), with: self, afterDelay: 0.2)
        
    }
    
    func callZoomMarker(){
    
        ZoomToWithSingleMarker(Position: (RideLaterMap.myLocation?.coordinate)!)

    }
    
    func DidSelect(_ FavObj:FavouritesLocationsStruct,_ isfavorite:Bool,_ controller:FavoriteLocationSelectVC){
        controller.dismiss(animated: true, completion: nil)
        if isPickSelected {
            
            if FavObj.Latitude != nil{
                let Camera = GMSCameraPosition.camera(withLatitude: FavObj.Latitude!, longitude: FavObj.Longitude!, zoom: 20)
                RideLaterMap.camera = Camera
            }else{
                let Camera = GMSCameraPosition.camera(withLatitude: (RideLaterMap.myLocation?.coordinate.latitude)!, longitude: (RideLaterMap.myLocation?.coordinate.longitude)!, zoom: 20)
                RideLaterMap.camera = Camera
            }
            
//            var Con1 = ConfirmationStruct()
//            Con1.Title = "Payment\nMode"
//            Con1.Image = #imageLiteral(resourceName: "cashinhand")
//            Con1.PaymentType = "CASH"
//            Con1.WalletAmount = "0"
//            
//            ConfirmationArr[0] = Con1
//            ConfirmBookingCollection.reloadData()
            
        }
        else {
            RideLaterMap.isUserInteractionEnabled = true

            DropLocation = FavObj
            self.DropSelectionLbl.text = DropLocation.Location!
            self.ADDFavDropBtn.isSelected = isfavorite
            
            if DropLocation != nil {
                
                if PickupMarkerObj != nil {
                    PickupMarkerObj.map = nil
                    PickupMarkerObj = nil
                }
                
                if DropMarkerObj != nil {
                    DropMarkerObj.map = nil
                    DropMarkerObj = nil
                }
                
                LoadGeoLocation = false
                mapCenterPinImage.isHidden = true
                
                DoneBtnRemoveSpace()
                
                PickupMarkerObj = PickupMarker.init(Pickup: PickUpLocation!)
                PickupMarkerObj.map = RideLaterMap
                
                DropMarkerObj = DropMarker.init(Drop: DropLocation!)
                DropMarkerObj.map = RideLaterMap

                
                if ConfirmBookingBtnView.isHidden {
                    mapCenterPinImage.isHidden = false

                }
                else {
                    mapCenterPinImage.isHidden = true
                    
//                    var Con1 = ConfirmationStruct()
//                    Con1.Title = "Payment\nMode"
//                    Con1.Image = #imageLiteral(resourceName: "cashinhand")
//                    Con1.PaymentType = "CASH"
//                    Con1.WalletAmount = "0"
//                    
//                    ConfirmationArr[0] = Con1
//                    ConfirmBookingCollection.reloadData()
                    //.....
                }
                
                ZoomToWithMultiMarker(Position1: PickupMarkerObj.position, Position2: DropMarkerObj.position)

            }
            else {
                mapCenterPinImage.isHidden = false
            }
            LoadFareEstimationData()
        }
        
    }
    
    // MARK: - }
    
    func BookForOthers(notification: Notification){
        self.view.ShowBlackTostWithText(message: "Now You Can Book For Others", Interval: 4)
        
        ResetAll()
         DoneBtnRemoveSpace()
        BOFNumber = notification.userInfo!["Number"]! as! String
        BOFName = notification.userInfo!["Name"]! as! String
//        viewDidLoad()
//        LocationManager.startUpdatingLocation()
    }
    func BookOWN(){
        self.BOFNumber = nil
        self.BOFName = nil
        
        ResetAll()
        DoneBtnRemoveSpace()
//         viewDidLoad()
//        LocationManager.startUpdatingLocation()

        
    }
//    func callCustomerSupportTapped() {
//
//        Message.shared.Alert(Title: "Customer Support", Message: "\(DriveBookingResponce.CustomerCareNo!)", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithSelector(Title: "CANCEL", Selector: #selector(customerCareCancelTapped), Controller: self),Message.AlertActionWithSelector(Title: "CALL", Selector: #selector(customerCareCallTapped), Controller: self)], Controller: self)
//        return
//    }
//
//    func customerCareCancelTapped (){
//        print("customerCare CancelTapped")
//    }
//    func customerCareCallTapped () {
//        print("customerCare CallTapped")
//        if((NSString.init(string:self.DriveBookingResponce.CustomerCareNo!)).rangeOfCharacter(from: CharacterSet.decimalDigits.inverted)).location == NSNotFound {
//            UIApplication.shared.openURL(URL.init(string: "tel://\(self.DriveBookingResponce.CustomerCareNo!)")!)
//        }
//        else {
//            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Invalid Helpdesk Number", Interval: 3)
//        }
//    }
    func callCustomerSupportTapped() {
        
        
        // call for view with helpdesk //
        
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)
        
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        
        customerSupportNumber.text = DriveBookingResponce.CustomerCareNo!
        
        BackView.center = (window?.center)!
        
        window?.addSubview(BackView)
        
        customerSupportView.center = BackView.center
        
        BackView.addSubview(customerSupportView!)
        
        customerSupportView.alpha = 0
        
        
        let GuardianTap = UITapGestureRecognizer.init(target: self, action: #selector(TapAddHelpDeskView(_:)))
        GuardianTap.numberOfTapsRequired = 1
        BackView.addGestureRecognizer(GuardianTap)
        
        UIView.animate(withDuration: 0.5) {
            self.customerSupportView.alpha = 1
        }
    }
    func TapAddHelpDeskView(_ responder:UITapGestureRecognizer) {
        
        let Point = responder.location(in: customerSupportView.superview!)
        let Frame = customerSupportView.frame
        
        if !Frame.contains(Point) {
            UIView.animate(withDuration: 0.3, animations: {
                self.customerSupportView.alpha = 0
            }) { (yes) in
                if yes {
                    self.customerSupportView.alpha = 1
                    self.customerSupportView.superview?.removeFromSuperview()
                }
            }
        }
        
    }
    @IBAction func CallBtnInCallSupportTapped(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.3, animations: {
            self.customerSupportView.alpha = 0
        }) { (yes) in
            if yes {
                self.customerSupportView.alpha = 1
                self.customerSupportView.superview?.removeFromSuperview()
                
                if ((NSString.init(string:self.DriveBookingResponce.CustomerCareNo!)).rangeOfCharacter(from: CharacterSet.decimalDigits.inverted)).location == NSNotFound {
                    UIApplication.shared.openURL(URL.init(string: "tel://\(self.DriveBookingResponce.CustomerCareNo!)")!)
                }
                else {
                    UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Invalid Helpdesk Number", Interval: 3)
                }
                
            }
            
        }
    }
    @IBAction func CancelBtnInCallSupportTapped(_ sender: UIButton) {
        UIView.animate(withDuration: 0.3, animations: {self.customerSupportView.alpha = 0 })
        { (yes) in
            if yes {
                self.customerSupportView.alpha = 1
                self.customerSupportView.superview?.removeFromSuperview()
            }
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(BookForOthers), name: NSNotification.Name(rawValue: "BOF"), object: nil)
         NotificationCenter.default.addObserver(self, selector: #selector(BookOWN), name: NSNotification.Name(rawValue: "NOW"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(BookOWN), name: NSNotification.Name(rawValue: "NOSHOW"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(callCustomerSupportTapped), name: NSNotification.Name(rawValue:"CUSTOMERSUPPORT"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardHide(_:)), name: .UIKeyboardWillHide, object: nil)
        
        sideMenuController?.isLeftViewEnabled = true
        LocationManager.requestWhenInUseAuthorization()
        LocationManager.startUpdatingLocation()
        LoginRequest = FetchDriveRequest()
        DriveBookingResponce = FetchDriveResponce()
        
//        if "\(DriveBookingResponce.NotificationsCount!)" > "0"{
//            label.isHidden = false
//            label.text = "\(DriveBookingResponce.NotificationsCount!)"
//
//        }else{
//
//            label.isHidden = true
//        }
        
 
    }
    

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
        
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "CUSTOMERSUPPORT"), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "NOSHOW"), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "NOW"), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "BOF"), object: nil)
        
        sideMenuController?.isLeftViewEnabled = false
    
    }
    
    func ResetAll() {
        
        DispatchQueue.main.async {
            
            self.LoginRequest = FetchDriveRequest()
            self.DriveBookingResponce = FetchDriveResponce()
            
            self.FetchFavs()
            self.GetVehCategory()
            self.ConfirmationMake()
            
            self.RideLaterMap.isUserInteractionEnabled = true

            self.VehCategoryCollection.reloadData()
            
            
            if self.PickupMarkerObj != nil {
                self.PickupMarkerObj.map = nil
            }

            
            if self.DropMarkerObj != nil {
                self.DropMarkerObj.map = nil
            }
            
            self.mapCenterPinImage.isHidden = false
            self.RideLaterMap.isMyLocationEnabled = true
            self.IsCouponAvailable = false
            self.CouponCode = ""
            self.LoadGeoLocation = true
            
            
            self.PickUpSelectionView.layer.masksToBounds = false
            self.PickUpSelectionView.layer.shadowColor = UIColor.black.cgColor
            self.PickUpSelectionView.layer.shadowOpacity = 0.35
            self.PickUpSelectionView.layer.shadowOffset = CGSize.zero
            self.PickUpSelectionView.layer.shadowRadius = 2.5
            
            self.PickUpSelectionView.layer.shadowPath = UIBezierPath(rect: self.PickUpSelectionView.bounds).cgPath
            
            
            self.DropSelectionView.layer.masksToBounds = false
            self.DropSelectionView.layer.shadowColor = UIColor.black.cgColor
            self.DropSelectionView.layer.shadowOpacity = 0.35
            self.DropSelectionView.layer.shadowOffset = CGSize.zero
            self.DropSelectionView.layer.shadowRadius = 2.5
            
            self.DropSelectionView.layer.shadowPath = UIBezierPath(rect: self.DropSelectionView.bounds).cgPath
            
            
            
//            self.VehCategoryCollection.layer.masksToBounds = false
//            self.VehCategoryCollection.layer.shadowColor = UIColor.black.cgColor
//            self.VehCategoryCollection.layer.shadowOpacity = 0.35
//            self.VehCategoryCollection.layer.shadowOffset = CGSize.zero
//            self.VehCategoryCollection.layer.shadowRadius = 2.5
//            
//            self.VehCategoryCollection.layer.shadowPath = UIBezierPath(rect: self.VehCategoryCollection.bounds).cgPath
            
            
            self.ConfirmBookingCollection.layer.masksToBounds = false
            self.ConfirmBookingCollection.layer.shadowColor = UIColor.black.cgColor
            self.ConfirmBookingCollection.layer.shadowOpacity = 0.35
            self.ConfirmBookingCollection.layer.shadowOffset = CGSize.zero
            self.ConfirmBookingCollection.layer.shadowRadius = 2.5
            
            self.ConfirmBookingCollection.layer.shadowPath = UIBezierPath(rect: self.ConfirmBookingCollection.bounds).cgPath
            
//            self.ConfirmBookingCollection.isHidden = true
//            self.VehCategoryCollection.isHidden = false
            
            self.hideUnhideVehCollectionViews(hide: false)

            self.DropSelectionView.isHidden = true
            self.ConfirmBookingBtnView.isHidden = true
            
            Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.LoaderAfter), userInfo: nil, repeats: false)
            
            self.InitializeLocationSelectionMarkers()
            
            self.DropSelectionLbl.text = "Enter Drop Location..."
            self.DropLocation = nil
            
            
            self.LocationManager.delegate = self
            
            self.LocationManager.requestWhenInUseAuthorization()
            
//            self.BOFNumber = nil
//            self.BOFName = nil
//            
            self.ZoomToWithSingleMarker(Position: (self.LocationManager.location?.coordinate)!)
            // self.FetchVehicles()
            
            self.ChangeCenterPinImage(isPickup: true)
            self.isZoomingAll = false
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - { __Button Actions
    
//    @IBOutlet var RideLaterBtn: UIButton!
    
    @IBAction func RIDELATER_BtnPressed(_ sender:UIButton) {
        
        let transition = CATransition()
        transition.duration = 0.45
        transition.type = kCATransitionFade;
        transition.subtype = kCATransitionFromBottom;
        
        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
        
        self.navigationController?.popViewController(animated: false)
    }
    
    @IBAction func CURRENTLOCATION_BtnPressed(_ sender:UIButton) {
      
        if LoadGeoLocation {
            
            if (RideLaterMap.myLocation != nil) {
                self.ZoomToWithSingleMarker(Position: (RideLaterMap.myLocation?.coordinate)!)
            }
        }

    }
    
    func ZoomToWithSingleMarker(Position:CLLocationCoordinate2D) {
        let Camera = GMSCameraPosition.camera(withTarget: Position, zoom: 16)
        RideLaterMap.animate(to: Camera)
    }
    
    func ZoomToWithMultiMarker(Position1:CLLocationCoordinate2D, Position2:CLLocationCoordinate2D) {
        
        var bounds = GMSCoordinateBounds()
        
        bounds = bounds.includingCoordinate(Position1)
        bounds = bounds.includingCoordinate(Position2)
        
        RideLaterMap.moveCamera(GMSCameraUpdate.fit(bounds, with: UIEdgeInsetsMake(180, 50, 65, 65)))
        //        TrackMapView.animate(with: GMSCameraUpdate.fit(bounds, withPadding: 100))
    }
    
    
    //zoom to multiple markers
    
    func ZoomToMarkers(MyLocation:CLLocationCoordinate2D,MarkerstoZoom:[GMSMarker],MapView:GMSMapView) {
        
        let userloc = CLLocation.init(latitude: MyLocation.latitude, longitude: MyLocation.longitude)
        var Distance:Double = 0.0
        let Ratio = 32553.2886853272/0.3
        
        if MarkerstoZoom.count == 0{
            ZoomToWithSingleMarker(Position: MyLocation)
            return
        }
        
        for i in 0..<MarkerstoZoom.count {
            
            let DestiCoor = MarkerstoZoom[i].position
            let DestLoc = CLLocation.init(latitude: DestiCoor.latitude, longitude: DestiCoor.longitude)
            
            if i == 1 {
                Distance = userloc.distance(from: DestLoc)
            }
            else {
                
                let newDist = userloc.distance(from: DestLoc)
                
                if newDist > Distance {
                    Distance = newDist
                }
                
            }
        }
        
        let val = Distance/Ratio
        
        let Coordinate1 = CLLocationCoordinate2DMake(MyLocation.latitude, MyLocation.longitude + val)
        let Coordinate2 = CLLocationCoordinate2DMake(MyLocation.latitude, MyLocation.longitude - val)
        let Coordinate3 = CLLocationCoordinate2DMake(MyLocation.latitude + val, MyLocation.longitude)
        let Coordinate4 = CLLocationCoordinate2DMake(MyLocation.latitude - val, MyLocation.longitude)
        
            self.ZoomToWithAllMarker(Positionns: [Coordinate1,Coordinate2,Coordinate3,Coordinate4,MyLocation], MapView: MapView)
        
    }
    
    var isZoomingAll = false
    
    func ZoomToWithAllMarker(Positionns: [CLLocationCoordinate2D], MapView:GMSMapView) {
        
        var bounds = GMSCoordinateBounds()
        for coor in Positionns {
            bounds = bounds.includingCoordinate(coor)
        }
        isZoomingAll = true
        MapView.moveCamera(GMSCameraUpdate.fit(bounds, with: UIEdgeInsetsMake(50, 50, 50, 50)))
        MapView.setMinZoom(2, maxZoom: 22)
        
      }
    

    
    @IBAction func ADDFavPickup_BtnPressed(_ sender:UIButton) {
        
        if sender.isSelected {
                Message.shared.Alert(Title: "Already a Favourites", Message: "This Location is already saved as your Favourites", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
         }
        else {
            
            if PickUpLocation == nil{
                self.view.ShowBlackTostWithText(message: "Please Select Valid Location", Interval: 3)
                return
            }
            Message.shared.Alert(Title: "Save Location as your Favourites", Message: "", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithSelector(Title: "OK", Selector: #selector(PickupAddFavorite), Controller: self),Message.AlertActionWithOutSelector(Title: "Cancel")], Controller: self)
        }
    }
    
    var FavLocArr = [FavouritesLocationsStruct]()
    
    func PickupAddFavorite() {
        FetchFavs()
        
        if FavLocArr.count == 3 {
            
            if FavLocArr.contains(where: {$0.Location! == PickUpLocation.Location!}) {
                ADDFavPickupBtn.isSelected = true
            }
            else {
                
                Message.shared.Alert(Title: "Alert!", Message: "You can add only up to 3 favourites. Delete any favourite if you need to add", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Cancel"),Message.AlertActionWithSelector(Title: "Ok", Selector: #selector(OpenFavorites), Controller: self)], Controller: self)
            }
        }
        else {
            
            if FavLocArr.contains(where: {$0.Location! == PickUpLocation.Location!}) {
                ADDFavPickupBtn.isSelected = true
            }
            else {
                ADDFavPickupBtn.isSelected = true
                FavLocArr.append(PickUpLocation!)
                UpdateFavLocation(IsPickup: true)
            }
        }
    }
    
    func OpenFavorites() {
        let SearchController = FavoriteLocationSelectVC()
        SearchController.Delegate = self
        SearchController.IsSearchNeeded = false
        SearchController.SelectionDisable = true
        self.present(SearchController, animated: true, completion: nil)
    }
    
    func UpdateFavLocation(IsPickup:Bool) {
        
        UIApplication.shared.keyWindow?.StartLoading()
        
        var StringObj = ""
        

        for FavStrObj in self.FavLocArr {
      
            let Str = "\(FavStrObj.Latitude!)" + "|" + "\(FavStrObj.Longitude!)" + "|" + "\(FavStrObj.Location!)" + "~"
            StringObj.append(Str)
        }
        
        let FavDict = ["EmpId":"\(DriveBookingResponce.EmpId!)","Favourites":StringObj,"VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
        
        WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveSetFavouritePlaces, parameterDict: FavDict, securityKey: DriveBookingResponce.AuthenticationToken!) { (ResponceDict, responceCode, success) in
            
            UIApplication.shared.keyWindow?.StopLoading()
            
            if success {
                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Favorite location Added successfully", Interval: 3)
                SaveFavoritesAs(FavoritesStructArr: self.FavLocArr)
            }
            else {
                
                if IsPickup {
                    self.ADDFavPickupBtn.isSelected = false
                }
                else {
                    self.ADDFavDropBtn.isSelected = false
                }
                
                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
            }
        }
    }
    
    func FetchFavs() {
        
        FavLocArr = [FavouritesLocationsStruct]()
        
        guard (FetchFavouritesLocation() != nil) else {
            return
        }
        FavLocArr = FetchFavouritesLocation()!
    }
    
    func DropAddFavorite() {
        
        FetchFavs()

        if FavLocArr.count == 3 {
            
            if FavLocArr.contains(where: {$0.Location! == DropLocation.Location!}) {
                ADDFavDropBtn.isSelected = true
            }
            else {
                
                Message.shared.Alert(Title: "Alert!", Message: "You can add only up to 3 favourites. Delete any favourite if you need to add", TitleAlign: .normal, MessageAlign: .normal
                    , Actions: [Message.AlertActionWithOutSelector(Title: "Cancel"),Message.AlertActionWithSelector(Title: "Ok", Selector: #selector(OpenFavorites), Controller: self)], Controller: self)
            }
        }
        else {
            
            if FavLocArr.contains(where: {$0.Location! == DropLocation.Location!}) {
                ADDFavDropBtn.isSelected = true
            }
            else {
                ADDFavDropBtn.isSelected = true
                FavLocArr.append(DropLocation!)
                UpdateFavLocation(IsPickup: false)
            }
        }
        
        
    }
    
    @IBAction func ADDFavDrop_BtnPressed(_ sender:UIButton) {
        
        if sender.isSelected {
//            sender.isSelected = false
              Message.shared.Alert(Title: "Already a Favourites", Message: "This Location is already saved as your Favourites", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
        }
        else {
 
            if DropLocation == nil {
                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Please select Drop Location", Interval: 3)
                return
            }
            if DropLocation.Latitude == nil{
                UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Drop Location Details are not Valid", Interval: 3)
                return
            }
            else {
                Message.shared.Alert(Title: "Save Location as your Favourites", Message: "", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithSelector(Title: "OK", Selector: #selector(DropAddFavorite), Controller: self),Message.AlertActionWithOutSelector(Title: "Cancel")], Controller: self)
            }
        }
    }
    
    
    var ConfirmationArr = [ConfirmationStruct]()
    struct ConfirmationStruct {

        var Title:String!
        var Image:UIImage!
        var PaymentType:String!
        var WalletAmount:String!
        var showLabel:String!
    }
    
    func ConfirmationMake() {

        ConfirmationArr.removeAll()

 
        
//        var Con1 = ConfirmationStruct()
//        Con1.Title = "Payment\nMode"
//        Con1.Image = #imageLiteral(resourceName: "cashinhand")
//        Con1.PaymentType = "CASH"
//        Con1.WalletAmount = "0"
        
        
        // from server we will get deafult payment type show we configure based payment type
        
        if DriveBookingResponce.DefaultPaymentMode.localizedCaseInsensitiveContains("MOBIKWIK"){
        
            var Con1 = ConfirmationStruct()
            Con1.Title = "Mobikwik"
            Con1.Image = #imageLiteral(resourceName: "MobikwikIcon")
            Con1.PaymentType = "MOBIKWIK"
            Con1.WalletAmount = "0"
            ConfirmationArr.append(Con1)
        
        }else if DriveBookingResponce.DefaultPaymentMode.localizedCaseInsensitiveContains("PAYTM"){
        
            var Con1 = ConfirmationStruct()
            Con1.Title = "Paytm"
            Con1.Image = #imageLiteral(resourceName: "PaytmLogo")
            Con1.PaymentType = "PAYTM"
            Con1.WalletAmount = "0"
            ConfirmationArr.append(Con1)
        
        }else{
        
            var Con1 = ConfirmationStruct()
            Con1.Title = "Cash"
            Con1.Image = #imageLiteral(resourceName: "cashinhand")
            Con1.PaymentType = "CASH"
            Con1.WalletAmount = "0"
            ConfirmationArr.append(Con1)
        }
        
        var Con2 = ConfirmationStruct()
        Con2.Title = "Fare\nEstimation"
        Con2.Image = #imageLiteral(resourceName: "fareestimate")
        Con2.showLabel = ""
        
        var Con3 = ConfirmationStruct()
        Con3.Title = "Apply\nCoupon"
        Con3.Image = #imageLiteral(resourceName: "applycoupon")
        
        
        ConfirmationArr.append(Con2)
        ConfirmationArr.append(Con3)
    }
    
    @IBAction func RIDENOW_BtnPressed(_ sender:UIButton) {
        
        if PickUpLocation == nil{
            self.view.ShowBlackTostWithText(message: "Please Select Valid Location", Interval: 3)
            return
        }
        if PickUpLocation.Location.localizedCaseInsensitiveContains("India"){
            self.view.ShowBlackTostWithText(message: "Please Select Valid Location", Interval: 3)
            return
        }
        
        if SelectedVehicleCat.CategoryTime! == "No cabs" {
            self.view.ShowBlackTostWithText(message: "No cabs available", Interval: 3)
            return
        }
        if DriveBookingResponce.DefaultPaymentMode.localizedCaseInsensitiveContains("MOBIKWIK"){
            
           
            CheckMobiKwikIsthere()
            
        }else if DriveBookingResponce.DefaultPaymentMode.localizedCaseInsensitiveContains("PAYTM"){
            
             CheckPaytmTokes()
            
        }else{
            CashSelected()
            //            translatePickupDrop()
        }
        
        ConfirmBookingCollection.reloadData()
//        if PaymentType == .paytm {
//            ConfirmationArr[0].Image = #imageLiteral(resourceName: "PaytmLogo")
//            ConfirmationArr[0].PaymentType = "PAYTM"
//            ConfirmationArr[0].WalletAmount = Balance
//        }
//        else if PaymentType == .mobikwik {
//            ConfirmationArr[0].Image = #imageLiteral(resourceName: "MobikwikIcon")
//            ConfirmationArr[0].PaymentType = "MOBIKWIK"
//            ConfirmationArr[0].WalletAmount = Balance
//        }
//        else {
//            ConfirmationArr[0].Image = #imageLiteral(resourceName: "cashinhand")
//            ConfirmationArr[0].PaymentType = "CASH"
//            ConfirmationArr[0].WalletAmount = Balance
//        }
//        ConfirmBookingCollection.reloadData()


        LoadGeoLocation = true
        
//        self.ConfirmBookingCollection.isHidden = false
//        self.VehCategoryCollection.isHidden = true
        self.hideUnhideVehCollectionViews(hide: true)

        self.DropSelectionView.isHidden = false
        
        self.ConfirmBookingBtnView.isHidden = false
        

        self.ConfirmBookingCollection.reloadData()

        for veh in VehiclesArr {
            veh.map = nil
        }
        
//        VehiclesArr.removeAll()
        
        DropLocation = nil
        
        if PickupMarkerObj != nil {
            PickupMarkerObj.map = nil
            PickupMarkerObj = nil
        }
        
        
        if DropMarkerObj != nil {
            DropMarkerObj.map = nil
            DropMarkerObj = nil
        }
        ADDFavDropBtn.isSelected = false

        ChangeCenterPinImage(isPickup: false)
        mapCenterPinImage.isHidden = true
        RideLaterMap.isUserInteractionEnabled = false
        
        
//        let selectedCategory = SelectedVehicleCat.CategoryName!
        let props = ["Chosen Category of vehicle": "\(SelectedVehicleCat.CategoryName!)"] as [String : Any]
        
//        CleverTap.sharedInstance()?.recordEvent("Ride Now", withProps: props)
        
        
        
//        DoneBtnSpaceMake()
    }
    
    @IBAction func ConfirmViewBack_BtnPressed(_ sender:UIButton) {
        
//        self.ConfirmBookingCollection.isHidden = true
//        self.VehCategoryCollection.isHidden = false
//        self.VehCategoryCollection.reloadData()
//        
//        self.ConfirmBookingBtnView.isHidden = true
//        
//        if PickupMarkerObj != nil {
//            PickupMarkerObj.map = nil
//            PickupMarkerObj = nil
//        }
//        
//        if DropMarkerObj != nil {
//            DropMarkerObj.map = nil
//            DropMarkerObj = nil
//        }
//        
//        self.DropSelectionView.isHidden = true
//        
//        mapCenterPinImage.isHidden = false
//        
//        var Con1 = ConfirmationStruct()
//        Con1.Title = "Payment\nMode"
//        Con1.Image = #imageLiteral(resourceName: "cashinhand")
//        Con1.PaymentType = "CASH"
//        Con1.WalletAmount = "0"
//        
//        ConfirmationArr[0] = Con1
//        
//        if PickUpLocation != nil{
//            ZoomToWithSingleMarker(Position: CLLocationCoordinate2DMake(PickUpLocation.Latitude!, PickUpLocation.Longitude!))
//        }
        LoadGeoLocation = true

        for veh in VehiclesArr {
            veh.map = nil
        }
        
        VehiclesArr.removeAll()
        RideLaterMap.isUserInteractionEnabled = true

        if PickupMarkerObj != nil {
            PickupMarkerObj.map = nil
            PickupMarkerObj = nil
        }
        
        if DropMarkerObj != nil {
            DropMarkerObj.map = nil
            DropMarkerObj = nil
        }
        ADDFavDropBtn.isSelected = false
//        self.BOFNumber = nil
//        self.BOFName = nil
        ResetAll()
    }
    
    var JobIdMain:String!
    
    @IBAction func CONFIRMBOOKING_BtnPressed(_ sender:UIButton) {
        
        if DropLocation != nil {
            if SelectedVehicleCat.CategoryTime! == "" || SelectedVehicleCat.CategoryTime! == "No cabs" {
                self.view.ShowBlackTostWithText(message: "No cabs are available", Interval: 3)
                return
            }
            if PickUpLocation.Location! == DropLocation.Location!
            {
                self.view.ShowBlackTostWithText(message: "PickUp Location and Drop Location Should not be same", Interval: 3)
                return
            }
            if !(cityBoundary.toBool()!){
                self.view.ShowBlackTostWithText(message: "We will not serve this location. Please change Drop Location within city bounds", Interval: 3)
                return

            
            }
            
            if ConfirmationArr[0].PaymentType.localizedCaseInsensitiveContains("MOBIKWIK"){
                
//                CheckPaytmTokes()
                
                MobikwikiLowBalanceAlert()
            
            }else if ConfirmationArr[0].PaymentType.localizedCaseInsensitiveContains("PAYTM"){
                
//                CheckMobiKwikIsthere()
                paytmAlertLowBalanceAlerty()
            
            }else{
                
                callConfirmBooking()
            }
            
            
        }
        else {
            self.view.ShowBlackTostWithText(message: "Please select Drop Location", Interval: 3)
        }
        
    }
    
//    translate pickup location and drop location to hindi using googel tanslation API
    func callConfirmBooking(){
//        DriveBookingResponce.TranslationStatus = "false"
        if DriveBookingResponce.TranslationStatus.toBool()!{
            translatePickupDrop()
        }else{
            
            self.booking(tranPickupLoc: self.PickUpLocation.Location!, transDropLoc: DropLocation.Location)
            isTranslationSuccess = false
        }
    }
    
    
//    PAYTM configuration for default payment selection
    
    func CheckPaytmTokes() {
        
        if PaytmToken == nil || PaytmToken! == "NA" || PaytmToken! == "" || PaytmMobile == nil || PaytmMobile! == "NA" || PaytmMobile! == "" {
            
           CashSelected()

            return
        }
        
        CheckPaytmBalance()
    }
    
//    Mobikwik Configuration for default payment selection
    
    func CheckMobiKwikIsthere() {
        
        
        
        if MobiToken == nil || MobiToken! == "NA" || MobiToken! == "" || MobiMobile == nil || MobiMobile! == "NA" || MobiMobile! == "" {
            //            self.ShowLink(isTrue: true, Balance: "")
          CashSelected()
            
            return
        }
        
        RegenerateToken()
        
    }

    
    //check paytm balance API
    
    func CheckPaytmBalance() {
        
        var Request = URLRequest.init(url: URL.init(string: "https://trust.paytm.in/wallet-web/checkBalance")!)
        Request.httpMethod = "GET"
        Request.allHTTPHeaderFields = ["ssotoken":PaytmToken!]
        
        Alamofire.request(Request)
            .responseJSON { (responce) in
                switch responce.result {
                case .success(let Value):
                    //print(Value)
                    let responsearray = Value as! [String:AnyObject]
                    
                    if let Responce = responsearray["response"] as? [String:AnyObject] {
                        
                        if Responce.keys.contains("amount") {
                            
                            let Balance = String.init(format: "%.2f", Float("\(Responce["amount"]!)")!)
                            
                            //                            self.PaytmLink(isLink: false, Balance: "₹" + Balance)
                            SavePaytmBalance(token: Balance)
//                            self.ConfirmationArr[0].Image = #imageLiteral(resourceName: "PaytmLogo")
//                            self.ConfirmationArr[0].PaymentType = "PAYTM"
//                            self.ConfirmationArr[0].WalletAmount = Balance
//                            self.ConfirmBookingCollection.reloadData()
                            self.PaytmSelected(Balance: Balance)
                        }
                        else{
//                            self.view.ShowBlackTostWithText(message: "Paytm is either not linked or needed Re-Authorize", Interval: 3)
                           self.CashSelected()
                            //                            self.PaytmLink(isLink: true, Balance: "")
                        }
                    }
                    else {
//                        self.view.ShowBlackTostWithText(message: "Paytm is either not linked or needed Re-Authorize", Interval: 3)
//                        self.ConfirmationArr[0].Image = #imageLiteral(resourceName: "cashinhand")
//                        self.ConfirmationArr[0].PaymentType = "CASH"
//                        self.ConfirmationArr[0].WalletAmount = "0"
//                        self.ConfirmBookingCollection.reloadData()
                        
                        self.CashSelected()

                        //                        self.PaytmLink(isLink: true, Balance: "")
                    }
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    
                    //                    self.PaytmLink(isLink: true, Balance: "")
//                    self.view.ShowBlackTostWithText(message: "Paytm is either not linked or needed Re-Authorize", Interval: 3)
                    
                    self.CashSelected()
                    break
                }
            }
        
    }
    func CashOrCardSelected(type:String){
        
        self.ConfirmationArr[0].Image = #imageLiteral(resourceName: "cashinhand")
        self.ConfirmationArr[0].PaymentType = type
        self.ConfirmationArr[0].WalletAmount = "0"
        self.ConfirmationArr[0].Title = type
        self.ConfirmBookingCollection.reloadData()
        
    }
    
    func CashSelected(){
    
        self.ConfirmationArr[0].Image = #imageLiteral(resourceName: "cashinhand")
        self.ConfirmationArr[0].PaymentType = "CASH"
        self.ConfirmationArr[0].WalletAmount = "0"
        self.ConfirmationArr[0].Title = "Cash"
        self.ConfirmBookingCollection.reloadData()
    
    }
    func PaytmSelected(Balance: String){
        self.ConfirmationArr[0].Image = #imageLiteral(resourceName: "PaytmLogo")
        self.ConfirmationArr[0].PaymentType = "PAYTM"
        self.ConfirmationArr[0].WalletAmount = Balance
        self.ConfirmationArr[0].Title = "Paytm"
        self.ConfirmBookingCollection.reloadData()
    }
    func MobiKwikSelected(Balance: String){
        self.ConfirmationArr[0].Image = #imageLiteral(resourceName: "MobikwikIcon")
        self.ConfirmationArr[0].PaymentType = "MOBIKWIK"
        self.ConfirmationArr[0].WalletAmount = Balance
        self.ConfirmationArr[0].Title = "Mobikwik"
        self.ConfirmBookingCollection.reloadData()
    
    
    }
    
// regenerate mobikwik token API
    
    
    func RegenerateToken() {
        
        if !(Reachability()?.isReachable)! {
//            self.ShowLink(isTrue: true, Balance: "")
            return
        }
        
        
        let tokentype       = "1"
        let cell            = MobiMobile!
        let msgcode         = "507"
        let mid             = MobiCreds.MID
        let merchantname    = MobiCreds.MerchentName
        
        let SecretKey = MobiCreds.RegenrationSecurity
        
        let VariableFormat  = "'\(cell)''\(merchantname)''\(mid)''\(msgcode)''\(MobiToken!)''\(tokentype)'" // ‘cell’‘merchantname’‘mid’‘msgcode’'Token''tokentype'
        
        let checksum        = VariableFormat.hmac(algorithm: .SHA256, key: SecretKey)
        
        let parserStr       = Parser(dict: ["cell":cell,"msgcode":msgcode,"mid":mid,"merchantname":merchantname,"tokentype":tokentype,"token":MobiToken!,"checksum":checksum])
        
        let UrlFormat       =  MobiCreds.BaseUrl + "/" + MobiCreds.Tokenregenerate + "?" + parserStr
        
        let url             = URL.init(string: UrlFormat.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!
        
        var Request         = URLRequest.init(url: url)
        Request.httpMethod  = "GET"
        Request.allHTTPHeaderFields = ["payloadtype":"json"]
        
        Alamofire.request(Request)
            .responseJSON { (responce) in
                
                switch responce.result {
                case .success(let Value):
                    //print(Value)
                    let responceData = Value as! [String:AnyObject]
                    if "\(responceData["status"]!)" == "SUCCESS" {
                        self.MobiToken = "\(responceData["token"]!)"
                        self.DriveBookingResponce.WalletToken = self.MobiToken
                        saveDriveResponceStuct(driveStruct: self.DriveBookingResponce!)
                        UpdatePaymentModes(WalletType_Paytm_MobiKwik: "MobiKwik", MobileNo: self.DriveBookingResponce.WalletMobileNo!, Token: self.MobiToken, ExpData_oMobi_Paytmdate: "0", CompletionAuthError: { (isauth) in
                            if isauth {
//                                authenticationCheck(controller: self)
                            }
                        })
                        self.CheckMobikwikBalance()
                    }
                    else {
//                        self.ShowLink(isTrue: true, Balance: "")
                       self.CashSelected()
                    }
                    break
                case .failure(let error):
                    print(error.localizedDescription)
//                    self.ShowLink(isTrue: true, Balance: "")
                    self.CashSelected()
                    break
                }
        }
    }
   
    
    // mobikwik check balance API
    func CheckMobikwikBalance() {
        
        if !(Reachability()?.isReachable)! {
//            self.ShowLink(isTrue: true, Balance: "")
            return
        }
        
        let cell            = MobiMobile!
        let msgcode         = "501"
        let mid             = MobiCreds.MID
        let merchantname    = MobiCreds.MerchentName
        
        let VariableFormat  = "'\(cell)''\(merchantname)''\(mid)''\(msgcode)''\(MobiToken!)'" // ‘cell’‘merchantname’‘mid’‘msgcode’'Token'
        
        let checksum        = VariableFormat.hmac(algorithm: .SHA256, key: MobiCreds.Secret)
        
        let parserStr       = Parser(dict: ["cell":cell,"msgcode":msgcode,"mid":mid,"merchantname":merchantname,"token":MobiToken!,"checksum":checksum])
        
        let UrlFormat       =  MobiCreds.BaseUrl + "/" + MobiCreds.userbalance + "?" + parserStr
        
        let url             = URL.init(string: UrlFormat.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!
        
        var Request         = URLRequest.init(url: url)
        Request.httpMethod  = "GET"
        Request.allHTTPHeaderFields = ["payloadtype":"json"]
        
        Alamofire.request(Request)
            .responseJSON { (responce) in
                
                switch responce.result {
                case .success(let Value):
                    //print(Value)
                    
                    let responceData = Value as! [String:AnyObject]
                    
                    if "\(responceData["status"]!)" == "SUCCESS" {
                        let Balance = String.init(format: "%.2f", Float("\(responceData["balanceamount"]!)")!)
                        SaveMobiKwikBalance(token: Balance)
//                        self.ConfirmationArr[0].Image = #imageLiteral(resourceName: "MobikwikIcon")
//                        self.ConfirmationArr[0].PaymentType = "MOBIKWIK"
//                        self.ConfirmationArr[0].WalletAmount = Balance
//                        self.ConfirmBookingCollection.reloadData()
                        
                        self.MobiKwikSelected(Balance: Balance)
                        
                    }
                    else {
//                        self.ShowLink(isTrue: true, Balance: "")
//                        self.ConfirmationArr[0].Image = #imageLiteral(resourceName: "cashinhand")
//                        self.ConfirmationArr[0].PaymentType = "CASH"
//                        self.ConfirmationArr[0].WalletAmount = "0"
//                        self.ConfirmBookingCollection.reloadData()
                        
                        self.CashSelected()

                    }
                    
                    break
                case .failure(let error):
                    print(error.localizedDescription)
//                    self.ConfirmationArr[0].Image = #imageLiteral(resourceName: "cashinhand")
//                    self.ConfirmationArr[0].PaymentType = "CASH"
//                    self.ConfirmationArr[0].WalletAmount = "0"
//                    self.ConfirmBookingCollection.reloadData()
//                    self.ShowLink(isTrue: true, Balance: "")
                    
                    self.CashSelected()

                    break
                }
        }
    }
    

    func paytmAlertLowBalanceAlerty(){
        let PaytmBalance = FetchPaytmBalance()
        if PaytmBalance == "NA" {
            self.view.ShowBlackTostWithText(message: "Retry", Interval: 2)
        }else
        if self.MinimumBalanceRequired >= Float(PaytmBalance)! {
            let MessageTxt = "Minimum Balance should be " + "₹" + String.init(format: "%.2f", self.MinimumBalanceRequired) + ". Please Add Money to your Paytm Wallet Or change the Payment Type."
            
            Message.shared.Alert(Title: "Add Money", Message: MessageTxt, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "No"),Message.AlertActionWithSelector(Title: "Add", Selector: #selector(PaytmAddMoney), Controller: self)], Controller: self)
        }else{
        
//            translatePickupDrop()
//            if DriveBookingResponce.TranslationStatus.toBool()!{
//                translatePickupDrop()
//            }else{
//                self.booking(tranPickupLoc: self.PickUpLocation.Location!, transDropLoc: DropLocation.Location!)
//                
//            }
            
            callConfirmBooking()
        }
     }
    
    
    func MobikwikiLowBalanceAlert(){
        let MobikwikBalance = FetchMobiKwikBalance()
        
        if MobikwikBalance == "NA" {
            
        }else
            if self.MinimumBalanceRequired >= Float(MobikwikBalance)! {
                let MessageTxt = "Minimum Balance should be " + "₹" + String.init(format: "%.2f", self.MinimumBalanceRequired) + ". Please Add Money to your MobiKwik Wallet  Or change the Payment Type."
                
                Message.shared.Alert(Title: "Add Money", Message: MessageTxt, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "No"),Message.AlertActionWithSelector(Title: "Add", Selector: #selector(MobiAddMoney), Controller: self)], Controller: self)
            }else{
//                translatePickupDrop()
//                if DriveBookingResponce.TranslationStatus.toBool()!{
//                    translatePickupDrop()
//                }else{
//                    self.booking(tranPickupLoc: self.PickUpLocation.Location!, transDropLoc: DropLocation.Location!)
//                    
//                }
                callConfirmBooking()
                
            }
        
    }
    

    
    func PaytmAddMoney() {
        let controller = self.storyboard?.instantiateViewController(withIdentifier: "PatymAddMoney") as! PatymAddMoney
        controller.Delegate = self
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    func MobiAddMoney() {
        let controller = self.storyboard?.instantiateViewController(withIdentifier: "MobiKwikAddMoney") as! MobiKwikAddMoney
        controller.Delegate = self
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    
    var PaymentsArr = [PaymentTypes]()
    
    func DidcancelAddMoney(controller: MobiKwikAddMoney) {
        controller.navigationController?.popViewController(animated: true)
    }
    
    func DidCompleteAddMoney(controller: MobiKwikAddMoney) {
        controller.navigationController?.popViewController(animated: true)
        
        // Get Money
        
        self.DriveBookingResponce = FetchDriveResponce()
        
        MobiToken = DriveBookingResponce.WalletToken!
        MobiMobile = DriveBookingResponce.WalletMobileNo!
        
        PaymentsArr[2].State = .loading
        
        CheckMobiKwikIsthere()
        
    }
    func PaytmDidcancelAddMoney(controller: PatymAddMoney) {
        controller.navigationController?.popViewController(animated: true)
    }
    
    func PaytmDidCompleteAddMoney(controller: PatymAddMoney) {
        controller.navigationController?.popViewController(animated: true)
        
        // Get Money
        
        self.DriveBookingResponce = FetchDriveResponce()
        
        PaytmToken = DriveBookingResponce.SSOToken!
        PaytmMobile = DriveBookingResponce.PaytmWalletNo!
        
        PaymentsArr[1].State = .loading
        
        CheckPaytmTokes()
    }

    
    
    
    // confirm booking API
    
    func booking(tranPickupLoc: String, transDropLoc: String){
    
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            let SelectedCategory = SelectedVehicleCat.CategoryId!
            
            let VehFil = self.VehiclesArr.filter({$0.VehicleStr.VehicleCategoryId! == SelectedCategory})
            
            var ModelName = ""
            
            if VehFil.count > 0 {
                ModelName = VehFil[0].VehicleStr.ModelName!
            }
            else {
                ModelName = "0"
            }
        
            let TodayComponents = Date().GregDateComponents(([.year,.year,.day,.month,.hour,.second]))
            
            var FilterSelectedGreg = TodayComponents
            
            let Format = DateFormatter()
            Format.dateFormat = "dd-MMM-yyyy"
            Format.locale = NSLocale.current
            Format.timeZone = NSTimeZone.local
            
            let DateStr = Format.string(from: Date())
            
            var TimeStr = ""
            
            TimeStr.append("\((FilterSelectedGreg.hour)!)".characters.count == 1 ? " 0\((FilterSelectedGreg.hour)!):" : " \((FilterSelectedGreg.hour)!):")
            TimeStr.append("\((FilterSelectedGreg.minute)!)".characters.count == 1 ? "0\((FilterSelectedGreg.minute)!)" : "\((FilterSelectedGreg.minute)!)")
            
            var AccessToken  = "0"
            var WalletNumber = "0"
            var ExpiryDate = "0"
            
            if ConfirmationArr[0].PaymentType! == "PAYTM"{
                
                     AccessToken  = DriveBookingResponce.SSOToken!
                     WalletNumber = DriveBookingResponce.PaytmWalletNo!
                     ExpiryDate   = DriveBookingResponce.ExpiryTime!
            }
            else if ConfirmationArr[0].PaymentType! == "MOBIKWIK"{
                     AccessToken  = DriveBookingResponce.WalletToken!
                     WalletNumber  = DriveBookingResponce.WalletMobileNo!
                     ExpiryDate = "0"
            }
            else  if (ConfirmationArr[0].PaymentType! == "CASH" || ConfirmationArr[0].PaymentType! == "CARD") {
                     AccessToken  = "0"
                     WalletNumber = "0"
                     ExpiryDate = "0"
            }
           
            
            
            
            var cityNam = "Mumbai"
            if fetchCityName! != ""{
                 cityNam = fetchCityName!
            }else{
            
                cityNam = "Mumbai"
            }
            let Name = BOFName ?? DriveBookingResponce.Name!
            let Number = BOFNumber ?? DriveBookingResponce.PhoneNo!
            let BookingType = BOFNumber != nil ? "Others" : "Own"
            
            var dropLat = 0.0
            var dropLan = 0.0
            var dropLoc = "NA"
            
      
            if DropLocation.Latitude != nil{
                dropLat = DropLocation.Latitude!
                dropLan = DropLocation.Longitude!
                dropLoc = DropLocation.Location!
            }
            
            var pickupLocation2 = PickUpLocation.Location!
            var DropLocation2 = dropLoc
            if isTranslationSuccess == true{
                pickupLocation2 = tranPickupLoc
                DropLocation2 = transDropLoc
            }else{
                DropLocation2 = dropLoc
                pickupLocation2 = PickUpLocation.Location!
            }
            sendDropForEvents = "\(dropLat),"+"\(dropLan)"
            
            let BookingData = ["UserName":"\(Name)",
                "EmailId":"\(DriveBookingResponce.Email!)",
                "MobileNo":"\(Number)",
                "PickUpLat":"\(PickUpLocation.Latitude!)",
                "PickUpLon":"\(PickUpLocation.Longitude!)",
                "DropLat":"\(dropLat)",
                "DropLon":"\(dropLan)",
                "PickUpLoc":"\(PickUpLocation.Location!)",
                "DropLoc":"\(dropLoc)",
                "TripType":Constants.BookingType,
                "PickUpDate":"\(DateStr)",
                "PickUpTime":"\(TimeStr)",
                "VehicleType":SelectedCategory,
                "VehicleModel":ModelName,
                "JobType":"Current",
                "Tariff":"0",
                "BookingType":"\(BookingType)",
                "EmpId":"\(DriveBookingResponce.EmpId!)",
                "CouponCode":"\(CouponCode)",
                "NoOfDays":"0",
                "City":"\(cityNam)",
                "VendorId":"\(LoginRequest.LoginCreds.VendorId!)",
                "CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)",
                "AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)",
                "PaymentType":"\(ConfirmationArr[0].PaymentType!)",
                "PaytmBalance":"\(ConfirmationArr[0].WalletAmount!)",
                "WalletMobileno":WalletNumber,
                "AccessToken":AccessToken,
                "ExpiryTime":ExpiryDate,
                "PickupLocation2":pickupLocation2,
                "DropOffLocation2":DropLocation2,
                "EstimatedFare":"\(EstimatedFare!)",
                "EstimatedDistance":"\(EstimatedDistance!)"]
            print("ConfirmBookingData =", BookingData)
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveBookingWithWallets, parameterDict: BookingData, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (BookingResponce, responceCode, success) in
                
                self.view.StopLoading()
                //print(BookingResponce,responceCode)
                if success {
                    //print(BookingResponce)
                    
                    if let Table = ((BookingResponce as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                        
                        if "\(Table["Status"]!)" == "true" && Table.keys.contains(where: {$0 == "JobNo"}) && "\(Table["JobNo"]!)" != ""  {
//                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(Table["Message"]!)", Interval: 2)
                            
                            self.JobIdMain = "\(Table["JobNo"]!)"
                            
               self.BiddingCall("\(self.JobIdMain!)", .init(latitude: Double("\(self.PickUpLocation.Latitude!)")!, longitude: Double("\(self.PickUpLocation.Longitude!)")!))
                            
                            self.DriveBookingResponce.DefaultPaymentMode = "\(self.ConfirmationArr[0].PaymentType!)"
                            saveDriveResponceStuct(driveStruct: self.DriveBookingResponce!)
                            
                            let props = ["Pick Up Location": "\(self.PickUpLocation.Latitude!)," + "\(self.PickUpLocation.Longitude!)",
                                "Drop Location":"\(dropLat),"+"\(dropLan)",
                                "Payment Mode":"\(self.ConfirmationArr[0].PaymentType!)",
                                "Selected Category":"\(self.SelectedVehicleCat.CategoryName!)",
                                "Fare Estimate":"\(self.EstimatedFare!)",
                                "Coupon Code":"\(self.CouponCode)",
                                "Job Id":"\(self.JobIdMain!)"] as [String : Any]
//                            CleverTap.sharedInstance()?.recordEvent("Confirm Booking", withProps: props)
                        }
                        else {
                            self.view.ShowBlackTostWithText(message: "\(Table["Response"]!)", Interval: 4)
                        }
                        
                    }
                    else {
                        self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                    }
                }
                else {
                    self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                }
            })
            
        }
        else {
            self.view.ShowBlackTostWithText(message: Constants.NetErrorMsg, Interval: 3)
        }
    }
    
    
    
    
    // Google Translate API.
    
    func translatePickupDrop(){
        
       
        var dropLoc = "NA"
        
        if DropLocation.Latitude != nil{
            dropLoc = DropLocation.Location!
        }
        
        

        let converstionstr = "\(PickUpLocation.Location!) || \(dropLoc)"
        
        var UrlStr = "https://translation.googleapis.com/language/translate/v2/?key=\(DriveBookingResponce.IOSGoogleTranslatorKey!)&q=\(converstionstr)&source=en&target=hi&model=nmt"
//        AIzaSyBqvaCquYYN3kf2cOrhrY59AN8NCyxJcTg
        
//        var UrlStr = "https://translation.googleapis.com/language/translate/v2/?key=AIzaSyBqvaCquYYN3kf2cOrhrYs59AN8NCyxJcTg&q=\(converstionstr)&source=en&target=hi&model=nmt"

        print(UrlStr)
        
        UrlStr = UrlStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        
        let urlRequest  = URLRequest.init(url: URL.init(string: UrlStr)!)
        Alamofire.request(urlRequest)
            .responseJSON { (DataResponce) in
                
                print(DataResponce)
                
                switch DataResponce.result {
                case .success(let value):
                    let val = value as! [String:AnyObject]
//                    print("***********val************")
//                    print(val)
//error
                    if val.keys.contains("error"){
                        self.isTranslationSuccess = false
                        self.booking(tranPickupLoc: self.PickUpLocation.Location!, transDropLoc: dropLoc)
                    return
                    }
                    
                    let data = val["data"] as! [String:AnyObject]
//                    print("***********data************")
//                    print(data)

                    let translations = data["translations"] as! [[String:AnyObject]]
//                    print("***********translations************")
//                    print(translations)

                    let translatedStr = "\(translations[0]["translatedText"]!)"
                    print("***********translatedStr************")
                    
                    print(translatedStr)

                    if  translatedStr.contains("||") {
                        self.isTranslationSuccess = true
                        let TranslatedDetailsArray = translatedStr.components(separatedBy: "||")
                        self.booking(tranPickupLoc: TranslatedDetailsArray[0] , transDropLoc: TranslatedDetailsArray[1])
                    }else{
                        self.isTranslationSuccess = false
                        self.booking(tranPickupLoc: self.PickUpLocation.Location!, transDropLoc: dropLoc)
                    }
                    break
                case .failure(_):
                    self.isTranslationSuccess = false
                    self.booking(tranPickupLoc: self.PickUpLocation.Location!, transDropLoc: dropLoc)

                    break
                }
        }
        
    }
    
    



    // MARK: - Bidding {

    func BiddingCall(_ jobID:String,_ coordinates:CLLocationCoordinate2D) {
        
        
        let bidingView = self.storyboard?.instantiateViewController(withIdentifier: "BiddingView") as! BiddingView
        bidingView.JobNo = jobID
        bidingView.PickUpCoordinates = coordinates
        bidingView.Delegate = self
        self.present(bidingView, animated: true, completion: nil)
    }
    
    func BiddingDidCancelled(controller: BiddingView, isFrom: String) {
        if isFrom == "1"{
            
            let props = ["Pick Up Location": "\(self.PickUpLocation.Latitude!)," + "\(self.PickUpLocation.Longitude!)",
                                    "Drop Locations":"\(sendDropForEvents!)",
                                    "Payment Mode":"\(self.ConfirmationArr[0].PaymentType!)",
                                    "Selected Category":"\(SelectedVehicleCat.CategoryName!)",
                                    "Fare Estimate":"\(self.EstimatedFare!)",
                                    "Coupon Code":"\(self.CouponCode)",
                                    "Job Id":"\(self.JobIdMain!)"] as [String : Any]
//                                CleverTap.sharedInstance()?.recordEvent("No Cabs Available Event", withProps: props)
        }
        controller.dismiss(animated: true, completion: nil)
    }
    
    func BiddingDidCompleteBooking(JobID:String, controller:BiddingView) {
        controller.dismiss(animated: true, completion: nil)
        // JobId for Tracking Page
//        GotoTrackingPage()
        
        controller.dismiss(animated: true, completion: nil)

        self.viewDidLoad()
        self.viewWillAppear(false)
        
        
        
            var PersonalRide = PersonalRides()
            PersonalRide.Jobno = JobID
            PersonalRide.JobType = "Current"
            
            let Track = self.storyboard?.instantiateViewController(withIdentifier: "DriveTrackVC") as! DriveTrackVC
            Track.TrackDetails = PersonalRide
            Track.BackToParent = true
            self.navigationController?.pushViewController(Track, animated: true)
        
    }
    
    // MARK: - }
    

    
    var BookNowSelectedIndex = 0
    
    var BookNowText = UITextField()
    var BookNowSelectPicker = UIPickerView()
    
    var BookNowPaymentModeArr = [String]()
    
    func BookNowHiddenTxtMake() {
        
        BookNowPaymentModeArr.append("Pay with Cash")
        
        BookNowText.frame = CGRect.init(x: 1000, y: 1000, width: 10, height: 10)
        self.view.addSubview(BookNowText)
        BookNowSelectPicker.dataSource = self
        BookNowSelectPicker.delegate = self
        
        let Toolbar = UIToolbar()
        Toolbar.barStyle = .default
        Toolbar.isTranslucent = true
        Toolbar.tintColor = UIColor.blue
        Toolbar.sizeToFit()
        let DoneItem = UIBarButtonItem.init(title: "Book", style: .done, target: self, action: #selector(BookNowPickDoneAction))
        let FlexiItem = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let TitleItem = UIBarButtonItem.init(title: "Select Mode of Payment", style: .done, target: nil, action: nil)
        let FlexiItem2 = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let CancelItem = UIBarButtonItem.init(title: "Cancel", style: .done, target: self, action: #selector(BookNowPickCancelAction))
        Toolbar.setItems([CancelItem,FlexiItem,TitleItem,FlexiItem2,DoneItem], animated: true)
        Toolbar.isUserInteractionEnabled = true
        BookNowText.inputView = BookNowSelectPicker;
        BookNowText.inputAccessoryView = Toolbar;
    }
    
    // MARK: - picker {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return BookNowPaymentModeArr.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return "\(BookNowPaymentModeArr[row])"
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        BookNowSelectedIndex = row
    }
 var cityBoundary = "true"
    
    
    // FARE estimation API
    
    func LoadFareEstimationData() {
        
 
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            
            var dropLon = 0.0
            var dropLat = 0.0
 
            if DropLocation.Latitude != nil{
                dropLat = DropLocation.Latitude!
                dropLon = DropLocation.Longitude!
            }
            
            
            let SelectedCategory = SelectedVehicleCat.CategoryId!
            
            let VehFil = self.VehiclesArr.filter({$0.VehicleStr.VehicleCategoryId! == SelectedCategory})
            
            var ModelName = ""
            
            if VehFil.count > 0 {
                ModelName = VehFil[0].VehicleStr.ModelName!
            }
            else {
                ModelName = "0"
            }
            var cityNam = "Mumbai"
            if fetchCityName! != ""{
                cityNam = fetchCityName!
            }else{
                
                cityNam = "Mumbai"
            }
            let RequestDict = ["PickUpLat":"\(PickUpLocation.Latitude!)",
                "PickUpLon":"\(PickUpLocation.Longitude!)",
                "DropLat":"\(dropLat)",
                "DropLon":"\(dropLon)",
                "VehicleCategory":"\(SelectedCategory)",
                "VehicleModel":"\(ModelName)",
                "TypeofTrip":"Meter Tariff",
                "City":"\(cityNam)",
                "EmpId":"\(DriveBookingResponce.EmpId!)",
                "BookingType":"Current",
                "VendorId":"\(LoginRequest.LoginCreds.VendorId!)",
                "CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)",
                "AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)",
                "Status":"1"]
            print(RequestDict)
            self.UpdateFareDetails(totalFare: "Loading")

            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveEstimateRideForBooking, parameterDict: RequestDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (ResponceData, responceCode, success) in
                print(ResponceData)
                if success {
                    
                    if let Table = ((ResponceData as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
//                        self.cityBoundary = "\(Table["CityBoundary"]!)"
                        
                        
                       self.cityBoundary = Table.keys.contains("CityBoundary") ? "\(Table["CityBoundary"]!)" : "true"

                        
                        if "\(Table["Status"]!)".toBool()! {
                            self.EstimatedFare = "\(Table["MinBalance"]!)"
                            self.EstimatedDistance = "\(Table["TotalDistance"]!)"
                            self.UpdateFareDetails(totalFare: "₹ \(Table["MinBalance"]!)*")
                            self.MinimumBalanceRequired = Float("\(Table["MinBalance"]!)")
                            //self.LoadViewWithData(MinBalance: "\(Table["TotalFare"]!)", TotalTime: "\(Table["TotalTime"]!)")
                        }
                        else {
//                            self.MinimumBalanceRequired = 150.0
                            self.MinimumBalanceRequired = Float(self.DriveBookingResponce.WalletMinBalance!)!

                            self.EstimatedFare = "NA"
                            self.EstimatedDistance = "NA"
                            self.UpdateFareDetails(totalFare: "NA")
                            self.view.ShowBlackTostWithText(message: "\(Table["Response"]!)", Interval: 2)
                        }
                    }
                    else {
//                        self.MinimumBalanceRequired = 150.0
                        self.MinimumBalanceRequired = Float(self.DriveBookingResponce.WalletMinBalance!)!
                        self.EstimatedFare = "NA"
                        self.EstimatedDistance = "NA"
                        self.UpdateFareDetails(totalFare: "NA")
                        self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                    }
                    
                }
                else {
//                    self.MinimumBalanceRequired = 150.0
                    self.MinimumBalanceRequired = Float(self.DriveBookingResponce.WalletMinBalance!)!
                    self.EstimatedFare = "NA"
                    self.EstimatedDistance = "NA"
                    self.UpdateFareDetails(totalFare: "NA")
                    self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                }
                
                self.view.StopLoading()
            })
        }
        else {
//            self.MinimumBalanceRequired = 150.0
            self.MinimumBalanceRequired = Float(DriveBookingResponce.WalletMinBalance!)!
            self.EstimatedFare = "NA"
            self.EstimatedDistance = "NA"
            self.UpdateFareDetails(totalFare: "NA")
            self.view.ShowBlackTostWithText(message: Constants.NetErrorMsg, Interval: 3)
        }
        
    }
    
    func UpdateFareDetails(totalFare: String){
        var Con2 = ConfirmationStruct()
        Con2.Title = "Fare\nEstimation"
        Con2.Image = nil
        Con2.showLabel = totalFare
        
        
//        var Con2 = ConfirmationStruct()
//        Con2.Title = "Fare\nEstimation"
//        
//        let TotalFare = totalFare
//        let font = UIFont.init(name: "Helvetica", size: 40)
//        let Size = (TotalFare as NSString).size(attributes: [NSFontAttributeName: font!,
//                                                             NSForegroundColorAttributeName: UIColor.black])
//        let weight = 120
//        let image = UIImage.init(named: "BGImage")!.ReduceImageSize(CGSize.init(width: weight, height: weight))
//        let rect = CGRect(x: ((image.size.width)/2) - (Size.width/2), y:((image.size.height)/2) - (Size.height/2), width: Size.width, height: Size.height)
//        let RenderedImage = image.addText(TotalFare as NSString, atRect: rect, textColor: UIColor.black, textFont: font)
//        Con2.Image = RenderedImage
        ConfirmationArr[1] = Con2
        DispatchQueue.main.async {
            self.ConfirmBookingCollection.reloadData()
        }
    }

    // MARK: - }
    
    func BookNowPickDoneAction() {
        let SelectedPaymentMode = BookNowPaymentModeArr[BookNowSelectedIndex]
        if SelectedPaymentMode == "Pay with Cash" {
            BookNowText.resignFirstResponder()
        }
    }
    func BookNowPickCancelAction() {
        BookNowText.resignFirstResponder()
    }
    
    func GoToConfirmationPageWith(JobID:String) {
        
        let Confirm = self.storyboard?.instantiateViewController(withIdentifier: "ConfirmRideNowVC") as! ConfirmRideNowVC
        
        Confirm.Delegate = self
        Confirm.JobIdMain = JobID
        
        let transition = CATransition()
        transition.duration = 0.45
        transition.type = kCATransitionFade;
        transition.subtype = kCATransitionFromTop;
        
        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
        
        self.navigationController?.pushViewController(Confirm, animated: false)
        
    }
    
    
    // MARK: - confirm delegate {
    
    func DidDone(IsDone: Bool, JobID: String,Controller: ConfirmRideNowVC) {

        let transition = CATransition()
        transition.duration = 0.45
        transition.type = kCATransitionFade;
        transition.subtype = kCATransitionFromBottom;
        
        Controller.navigationController?.view.layer.add(transition, forKey: kCATransition)
        
        Controller.navigationController?.popViewController(animated: false)
        
        
        self.viewDidLoad()
        self.viewWillAppear(false)
        
        
        if IsDone {
            
            var PersonalRide = PersonalRides()
            PersonalRide.Jobno = JobID
            PersonalRide.JobType = "Current"
            
            let Track = self.storyboard?.instantiateViewController(withIdentifier: "DriveTrackVC") as! DriveTrackVC
            Track.TrackDetails = PersonalRide
            Track.BackToParent = true
            self.navigationController?.pushViewController(Track, animated: true)
        }
        else {
            self.navigationController?.popToRootViewController(animated: true)
        }
        
    }
    
    // MARK: - }
    
    
    // MARK: -                                   __ }

    
//    var Allpositions = [CLLocationCoordinate2D]()
    
    
    //get available vehicles Details and show vehicles in google MAPS API
    func FetchVehicles() {
        
        if (Reachability()?.isReachable)! {
            
                if (self.PickUpLocation.Location.localizedCaseInsensitiveContains("India")){
                    
                    for VehObj in self.VehiclesArr {
                        VehObj.map = nil
                    }
                    self.VehiclesArr.removeAll()
                    
                    for i in 0..<self.VehicleDataArr.count {
                        self.VehicleDataArr[i].CategoryTime = "No cabs"
                    }
                    VehCategoryCollection.reloadData()
                    return
                }
            let RequestDict = ["MobileNo":"\(DriveBookingResponce.PhoneNo!)","EmpId":"\(DriveBookingResponce.EmpId!)","Latitude":"\(PickUpLocation.Latitude!)","Longitude":"\(PickUpLocation.Longitude!)","VehicleCategory":"0","VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)","Version":"1"]
            
            self.view.StartLoading()
            
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveAvailableVehicles, parameterDict: RequestDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (VehicleResponce, responceCode, success) in
                if success {
                    
                    let Table = (VehicleResponce as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
                    
                    print(Table)
                    if Table.count > 0 {
                        if "\(Table[0]["Status"]!)".toBool()! {
                            
                            for VehObj in self.VehiclesArr {
                                VehObj.map = nil
                            }
                            
                            self.VehiclesArr.removeAll()
                            
                            
                            for VehObj in Table {
                                
                                var Lat :Double! = 0.0
                                var Lon :Double! = 0.0
                                var VehicleModelId : String!
                                var VehicleCategoryId: String!
                                var Distance : String!
                                var EstimatedTime : String!
                                var Direction :Double! = 0.0
                                
                                
                                if let latitude = VehObj["Lat"],
                                    (latitude is NSNumber || latitude is String) {
                                    Lat = Double("\(latitude)")!
                                }
                                
                                if let longitude = VehObj["Lon"],
                                    (longitude is NSNumber || longitude is String) {
                                    Lon = Double("\(longitude)")!
                                }
                                
                                if let VehicleModId = VehObj["VehicleModelId"],
                                    (VehicleModId is NSNumber || VehicleModId is String) {
                                    VehicleModelId = "\(VehicleModId)"
                                }
                                
                                if let VehiclecatId = VehObj["VehicleCategoryId"],
                                    (VehiclecatId is NSNumber || VehiclecatId is String) {
                                    VehicleCategoryId = "\(VehiclecatId)"
                                }
                                
                                if let dista = VehObj["Distance"],
                                    (dista is NSNumber || dista is String) {
                                    Distance = "\(dista)"
                                }
                                
                                if let estimated = VehObj["EstimatedTime"],
                                    (estimated is NSNumber || estimated is String) {
                                    EstimatedTime = "\(estimated)"
                                }
                                
                                if let direction = VehObj["Direction"],
                                    (direction is NSNumber || direction is String) {
                                    Direction = Double("\(direction)")!
                                }
                                
                                
                                var VehicleObj = VehicleStruct()
                                VehicleObj.CategoryName = "\(VehObj["Lat"]!)"
                                VehicleObj.Direction = Direction!
                                VehicleObj.Distance = Distance!
                                VehicleObj.EstimatedTime = EstimatedTime! == "0" || EstimatedTime! == "1" ? EstimatedTime! + " min" : EstimatedTime! + " mins"
                                VehicleObj.Lat = Lat!
                                VehicleObj.Lon = Lon!
                                VehicleObj.ModelName = "\(VehObj["ModelName"]!)"
                                VehicleObj.VehicleCategoryId = VehicleCategoryId
                                VehicleObj.VehicleIcon = "\(VehObj["VehicleIcon"]!)"
                                VehicleObj.VehicleModelId = VehicleModelId!
                                VehicleObj.VehicleNo = "\(VehObj["VehicleNo"]!)"
                                
                                
                                self.VehiclesArr.append(Vehicles.init(VehicleObj: VehicleObj))
                                
                                
//                                var distanceMeters = 100
//                                var bearing = 2
//                                var direction = 0.2
//                                let origin = CLLocationCoordinate2DMake(Lat!, Lon!)
//                                for j in 0...1 {
//                                    print(j)
//
//                                    let x = self.locationWithBearing(bearing: Double(bearing), distanceMeters: Double(distanceMeters), origin: origin)
//                                    VehicleObj.Lat = x.latitude
//                                    VehicleObj.Lon = x.longitude
//                                    self.VehiclesArr.append(Vehicles.init(VehicleObj: VehicleObj))
//                                    distanceMeters = distanceMeters + 150
//                                    bearing = bearing + 5
//                                    direction = direction + 0.94
//                                    
//                                    print(x.latitude,x.longitude)
//                                }
//                                
                               
                             }
//                             self.dummyLocation()
                             for i in 0..<self.VehicleDataArr.count {
                                
                                let VehFil = self.VehiclesArr.filter({$0.VehicleStr.VehicleCategoryId! == self.VehicleDataArr[i].CategoryId!})
                                
                                
                                if VehFil.count > 0 {
                                    self.VehicleDataArr[i].CategoryTime = VehFil[0].VehicleStr.EstimatedTime!
                                }
                                else {
                                    self.VehicleDataArr[i].CategoryTime = "No cabs"
                                    
                                }
                                
                            }

                            var SelectedCab = ""

                            
                            for Obj in self.VehicleDataArr {
                                if Obj.CatSelectedState! {
                                    SelectedCab = "\(Obj.CategoryId!)"
                                }
                            }
                            let FilterSelected = self.VehiclesArr.filter({$0.VehicleStr.VehicleCategoryId! == SelectedCab})
                            
                            if FilterSelected.count > 0 {
                                self.callDummyLocation(Veh:FilterSelected.last!)
                            }
                            
                            print(FilterSelected)
                            
                            for Obj in FilterSelected {
                                Obj.map = self.RideLaterMap
                            }

                            self.ZoomToMarkers(MyLocation: (self.RideLaterMap.camera.target), MarkerstoZoom: FilterSelected, MapView: self.RideLaterMap!)
                        }
                        else {
                            
                            for VehObj in self.VehiclesArr {
                                VehObj.map = nil
                            }
                            
                            self.VehiclesArr.removeAll()
                            
                            for i in 0..<self.VehicleDataArr.count {
                                self.VehicleDataArr[i].CategoryTime = "No cabs"
                                
                            }
//                            self.dummyLocation()
//                            self.callDummyLocation()
                        }


                        

                        for Obj in self.VehicleDataArr {
                            if Obj.CatSelectedState! {
                                self.SelectedVehicleCat = Obj
                                self.ChangeConvenianceAmount()
                            }
                        }
                    }
                    else {
                        
                        for VehObj in self.VehiclesArr {
                            VehObj.map = nil
                        }
                        
                        self.VehiclesArr.removeAll()
                        
                        for i in 0..<self.VehicleDataArr.count {
                            self.VehicleDataArr[i].CategoryTime = "No cabs"
                            
                        }
                        
//                        self.dummyLocation()
//                        self.callDummyLocation()
                        
                        for Obj in self.VehicleDataArr {
                            if Obj.CatSelectedState! {
                                self.SelectedVehicleCat = Obj
                                self.ChangeConvenianceAmount()
                            }
                        }
                    }
                    
                }
                else {
                    if responceCode == .authError{
//                        authenticationCheck(controller: self)
                    }else{
                        
                        
                        for VehObj in self.VehiclesArr {
                            VehObj.map = nil
                        }
                        
                        self.VehiclesArr.removeAll()
                        
                        for i in 0..<self.VehicleDataArr.count {
                            
                            self.VehicleDataArr[i].CategoryTime = "No cabs"
                            
                        }
//                        self.dummyLocation()
//                        self.callDummyLocation()
                        
                        for Obj in self.VehicleDataArr {
                            if Obj.CatSelectedState! {
                                self.SelectedVehicleCat = Obj
                                self.ChangeConvenianceAmount()
                            }
                        }
                    }
                 }
                
                self.VehCategoryCollection.reloadData()

                self.view.StopLoading()

            })
            
        }
        else {
            
            self.view.ShowBlackTostWithText(message: "please Check your Internet Connection", Interval: 3)
             return
        }
        
    }
    
    ////aaa//
//    func dummyLocation(){
//        self.VehiclesArr.removeAll()
//        RideLaterMap.clear()
//        var VehicleObj = VehicleStruct()
//
////        print(fetchCityName)
//        if fetchCityName! == ""{
//            VehiclesArr.removeAll()
//            RideLaterMap.clear()
//            for i in 0..<self.VehicleDataArr.count {
//                
//                let VehFil = self.VehiclesArr.filter({$0.VehicleStr.VehicleCategoryId! == self.VehicleDataArr[i].CategoryId!})
//                
//                
//                if VehFil.count > 0 {
//                    self.VehicleDataArr[i].CategoryTime = VehFil[0].VehicleStr.EstimatedTime!
//                }
//                else {
//                
//                    self.VehicleDataArr[i].CategoryTime = "No cabs"
//                }
//                
//            }
//            return
//        }
//        if !(fetchCityName!.localizedCaseInsensitiveContains("mumbai") || fetchCityName!.localizedCaseInsensitiveContains("thane") || fetchCityName!.localizedCaseInsensitiveContains("navi mumbai")){
//
//            VehiclesArr.removeAll()
//            RideLaterMap.clear()
//            for i in 0..<self.VehicleDataArr.count {
//                
//                let VehFil = self.VehiclesArr.filter({$0.VehicleStr.VehicleCategoryId! == self.VehicleDataArr[i].CategoryId!})
//                
//                
//                if VehFil.count > 0 {
//                    self.VehicleDataArr[i].CategoryTime = VehFil[0].VehicleStr.EstimatedTime!
//                }
//                else {
//    
//                    self.VehicleDataArr[i].CategoryTime = "No cabs"
//                }
//    
//            }
//            return
//        }
//
//        
//        
//        VehicleObj.ModelName = SelectedVehicleCat.CategoryName
//        VehicleObj.CategoryName = SelectedVehicleCat.CategoryName
//
//        var bearing = 3
//        let origin = CLLocationCoordinate2DMake(PickUpLocation.Latitude!, PickUpLocation.Longitude!)
//        
//        
//  
//        
//        for _ in 0...Int(arc4random_uniform(3) + 1) {
//            let distanceMeters: Int = Int(arc4random_uniform(1050) + 100)
//            let direction: Int = Int(arc4random_uniform(300) + 5)
//            let x = self.locationWithBearing(bearing: Double(bearing), distanceMeters: Double(distanceMeters), origin: origin)
//            VehicleObj.Lat = x.latitude
//            VehicleObj.Lon = x.longitude
//            VehicleObj.EstimatedTime = "1 min"
//            VehicleObj.Direction = Double("\(direction)")
//            VehicleObj.Distance = "\(distanceMeters)"
//            
//            VehicleObj.VehicleCategoryId = SelectedVehicleCat.CategoryId!
//            VehicleObj.VehicleIcon = SelectedVehicleCat.CategoryMapIcon!
//      
//            
//            self.VehiclesArr.append(Vehicles.init(VehicleObj: VehicleObj))
//            bearing = bearing + 5
//            
//        }
//        
//        for i in 0..<self.VehicleDataArr.count {
//            let VehFil = self.VehiclesArr.filter({$0.VehicleStr.VehicleCategoryId! == self.VehicleDataArr[i].CategoryId!})
//            if VehFil.count > 0 {
//                self.VehicleDataArr[0].CategoryTime = "1 min"
//                self.VehicleDataArr[1].CategoryTime = "1 min"
//            }
//        }
//
//        var SelectedCab = ""
//        
//        for Obj in self.VehicleDataArr {
//            if Obj.CatSelectedState! {
//                SelectedCab = "\(Obj.CategoryId!)"
//            }
//        }
//        let FilterSelected = self.VehiclesArr.filter({$0.VehicleStr.VehicleCategoryId! == SelectedCab})
//        
//        
//        
//        for Obj in FilterSelected {
//            Obj.map = self.RideLaterMap
//        }
//        
//        self.ZoomToMarkers(MyLocation: (self.RideLaterMap.camera.target), MarkerstoZoom: FilterSelected, MapView: self.RideLaterMap!)
//
//    
//    }
    func callDummyLocation(Veh:Vehicles){
        
        if DriveBookingResponce.DummyVehStatus.toBool()!{
            dummyLocation(Veh:Veh)
        }else{
            
        }
    
    }
    //Adding DummyVehicles in ridenowPAge only if vehicles count is greater than 0
    func dummyLocation(Veh:Vehicles) {
        
//        self.VehiclesArr.removeAll()
//        RideLaterMap.clear()
        
//        if fetchCityName! == "" {
//            VehiclesArr.removeAll()
//            RideLaterMap.clear()
//            for i in 0..<self.VehicleDataArr.count {
//                
//                let VehFil = self.VehiclesArr.filter({$0.VehicleStr.VehicleCategoryId! == self.VehicleDataArr[i].CategoryId!})
//                
//                
//                if VehFil.count > 0 {
//                    self.VehicleDataArr[i].CategoryTime = VehFil[0].VehicleStr.EstimatedTime!
//                }
//                else {
//                    
//                    self.VehicleDataArr[i].CategoryTime = "No cabs"
//                }
//                
//            }
//            return
//        }
        
//        if !(fetchCityName!.localizedCaseInsensitiveContains("mumbai") || fetchCityName!.localizedCaseInsensitiveContains("thane") || fetchCityName!.localizedCaseInsensitiveContains("navi mumbai")){
////            
////            VehiclesArr.removeAll()
////            RideLaterMap.clear()
//            for i in 0..<self.VehicleDataArr.count {
//                
//                let VehFil = self.VehiclesArr.filter({$0.VehicleStr.VehicleCategoryId! == self.VehicleDataArr[i].CategoryId!})
//                
//                
//                if VehFil.count > 0 {
//                    self.VehicleDataArr[i].CategoryTime = VehFil[0].VehicleStr.EstimatedTime!
//                }
//                else {
//                    
//                    self.VehicleDataArr[i].CategoryTime = "No cabs"
//                }
//                
//            }
//            return
//        }
        
        var UrlStr = "https://maps.googleapis.com/maps/api/geocode/json?address=\(Veh.VehicleStr.Lat!),\(Veh.VehicleStr.Lon!)&clientid=gme-suntelematicsprivate"
        
        UrlStr = UrlStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        
        let urlRequest  = URLRequest.init(url: URL.init(string: UrlStr)!)
        Alamofire.request(urlRequest)
            .responseJSON { (DataResponce) in
                
                switch DataResponce.result {
                case .success(let value):
                    
                    
                    let val = value as! [String:AnyObject]
                    
                    let results  = val["results"] as! [[String:AnyObject]]
                    if results.count > 0{
                        let geometryObj = results[0]["geometry"] as! [String:AnyObject]
                        
                        
                        if  let locationsArr = geometryObj["location"]  as? [String:AnyObject]{

//                            if Count
                            var LVehicleObj = VehicleStruct()
                            LVehicleObj.ModelName = self.SelectedVehicleCat.CategoryName
                            LVehicleObj.CategoryName = self.SelectedVehicleCat.CategoryName
                            LVehicleObj.Lat = Double("\(locationsArr["lat"]!)")
                            LVehicleObj.Lon = Double("\(locationsArr["lng"]!)")
                            LVehicleObj.EstimatedTime = "2 mins"
                            LVehicleObj.Direction = Double(Int(arc4random_uniform(300) + 5))
                            LVehicleObj.VehicleCategoryId = self.SelectedVehicleCat.CategoryId!
                            LVehicleObj.VehicleIcon = self.SelectedVehicleCat.CategoryMapIcon!
//                            LVehicleObj.
                            self.VehiclesArr.append(Vehicles.init(VehicleObj: LVehicleObj))
                            
                            
                        }
                        if  let viewpointsArr = geometryObj["viewport"] as? [String:AnyObject]{
                            let northeast = viewpointsArr["northeast"] as! [String:AnyObject]
                            
                            var NVehicleObj = VehicleStruct()
                            NVehicleObj.ModelName = self.SelectedVehicleCat.CategoryName
                            NVehicleObj.CategoryName = self.SelectedVehicleCat.CategoryName
                            NVehicleObj.Lat = Double("\(northeast["lat"]!)")
                            NVehicleObj.Lon = Double("\(northeast["lng"]!)")
                            NVehicleObj.EstimatedTime = "2 mins"
                            NVehicleObj.Direction = Double(Int(arc4random_uniform(300) + 5))
                            NVehicleObj.VehicleCategoryId = self.SelectedVehicleCat.CategoryId!
                            NVehicleObj.VehicleIcon = self.SelectedVehicleCat.CategoryMapIcon!
                            self.VehiclesArr.append(Vehicles.init(VehicleObj: NVehicleObj))
                            
                            
//                            let southwest = viewpointsArr["southwest"] as! [String:AnyObject]
//
//                            var SVehicleObj = VehicleStruct()
//                            SVehicleObj.ModelName = self.SelectedVehicleCat.CategoryName
//                            SVehicleObj.CategoryName = self.SelectedVehicleCat.CategoryName
//                            SVehicleObj.Lat = Double("\(southwest["lat"]!)")
//                            SVehicleObj.Lon = Double("\(southwest["lng"]!)")
//                            SVehicleObj.EstimatedTime = "1 min"
//                            SVehicleObj.Direction = Double(Int(arc4random_uniform(300) + 5))
//                            SVehicleObj.VehicleCategoryId = self.SelectedVehicleCat.CategoryId!
//                            SVehicleObj.VehicleIcon = self.SelectedVehicleCat.CategoryMapIcon!
//                            self.VehiclesArr.append(Vehicles.init(VehicleObj: SVehicleObj))
                            
                        }
                        
//                        for i in 0..<self.VehicleDataArr.count {
//                            self.VehicleDataArr[i].CategoryTime = "1 min"
//                        }
                        
                        var SelectedCab = ""
                        
                        for Obj in self.VehicleDataArr {
                            if Obj.CatSelectedState! {
                                SelectedCab = "\(Obj.CategoryId!)"
                                self.SelectedVehicleCat = Obj
                            }
                        }
                        
                        let FilterSelected = self.VehiclesArr.filter({$0.VehicleStr.VehicleCategoryId! == SelectedCab})
                        
                        
                        for Obj in FilterSelected {
                            Obj.map = self.RideLaterMap
                        }
                        
                        
                        self.VehCategoryCollection.reloadData()
                        self.ZoomToMarkers(MyLocation: (self.RideLaterMap.camera.target), MarkerstoZoom: FilterSelected, MapView: self.RideLaterMap!)
                    }
                    
                    
                    
                    break
                case .failure(_):
                    self.VehiclesArr.removeAll()
                    self.RideLaterMap.clear()
                    self.VehCategoryCollection.reloadData()
                    break
                }
        }
        
        
        
        
        
    }
    func locationWithBearing(bearing:Double, distanceMeters:Double, origin:CLLocationCoordinate2D) -> CLLocationCoordinate2D {
        let distRadians = distanceMeters / (6372797.6) // earth radius in meters
        
        let lat1 = origin.latitude * .pi / 180
        let lon1 = origin.longitude * .pi / 180
        
        let lat2 = asin(sin(lat1) * cos(distRadians) + cos(lat1) * sin(distRadians) * cos(bearing))
        let lon2 = lon1 + atan2(sin(bearing) * sin(distRadians) * cos(lat1), cos(distRadians) - sin(lat1) * sin(lat2))
        
        return CLLocationCoordinate2D(latitude: lat2 * 180 / .pi, longitude: lon2 * 180 / .pi)
    }

    var VehiclesArr = [Vehicles]()
    
    struct VehicleStruct {
        var CategoryName: String!
        var Direction: Double!
        var Distance:String!
        var EstimatedTime:String!
        var Lat:Double!
        var Lon:Double!
        var ModelName:String!
        var VehicleCategoryId:String!
        var VehicleIcon:String!
        var VehicleModelId:String!
        var VehicleNo:String!
    }
    
    class Vehicles: GMSMarker {

        var VehicleStr:VehicleStruct!

        init(VehicleObj:VehicleStruct) {
            super.init()
            
            VehicleStr = VehicleObj
            
//            print(VehicleObj)
            
            position = CLLocationCoordinate2DMake(VehicleObj.Lat!,VehicleObj.Lon!)
            //            groundAnchor = CGPoint(x: 0.5, y: 1)
            appearAnimation = GMSMarkerAnimation.none
            rotation = VehicleObj.Direction!
            self.isTappable = false
            self.icon = #imageLiteral(resourceName: "asfalt-light")
//
//            if VehicleObj.ModelName! == "AC"{
//                self.icon = #imageLiteral(resourceName: "AC_MapIcon")
//
//            }else  if VehicleObj.ModelName! == "NON-AC"{
//                self.icon = #imageLiteral(resourceName: "NON-AC_MapIcon")
//            }
//            


            
            
            if "\(VehicleObj.VehicleIcon!)" != "" && "\(VehicleObj.VehicleIcon!)".contains("http") {
                
                DispatchQueue.global(qos: .userInteractive).async {
                    if let ImgData = try? Data.init(contentsOf: URL.init(string: VehicleObj.VehicleIcon!)!) {
                        DispatchQueue.main.async {
                            
                            self.icon = UIImage.init(data: ImgData)
                            self.icon = self.icon?.af_imageAspectScaled(toFill: CGSize(width: 35, height: 35))
                        }
                    }
                    else {
                        
                        self.icon = UIImage.init(named: "VehicleLocIcon")
                        
                    }
                }
            }
            else {
                self.icon = UIImage.init(named: "VehicleLocIcon")
            }
//
  
        }
        
    }
    
    

    
    class PickupMarker: GMSMarker {
        
        var PickupStr: FavouritesLocationsStruct!
        
        init(Pickup:FavouritesLocationsStruct) {
            super.init()
            PickupStr = Pickup
            self.isTappable = false
            position = CLLocationCoordinate2DMake(Pickup.Latitude!,Pickup.Longitude!)
            groundAnchor = CGPoint(x: 0.5, y: 1)
            appearAnimation = GMSMarkerAnimation.none
            icon = UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "GreenTrack")!, to: CGSize.init(width: 34, height: 64))
        }
    }
    
    class DropMarker: GMSMarker {
        var DropStr: FavouritesLocationsStruct!
        
        init(Drop:FavouritesLocationsStruct) {
            super.init()
            DropStr = Drop
            self.isTappable = false
            groundAnchor = CGPoint(x: 0.5, y: 1)
            if Drop.Latitude != nil {
            position = CLLocationCoordinate2DMake(Drop.Latitude!,Drop.Longitude!)
            appearAnimation = GMSMarkerAnimation.none
//            icon = UIImage.init(named: "RedTrack")
            icon = UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "RedTrack")!, to: CGSize.init(width: 34, height: 64))
            }else{
            
        
            }

        }
    }
    
    
    // MARK: - Ratecard View Make {
    
    @IBOutlet var RateCardView: UIView!
    @IBOutlet var RateCardCatImage: UIImageView!
    @IBOutlet var RateCardCatTitle: UILabel!
    @IBOutlet var RateCardBasefare: UILabel!
    @IBOutlet var RateCardMinKms: UILabel!
    @IBOutlet var RateCardMinHrs: UILabel!

    
    func RatecardViewMake(basefare:String,MinKms:String,MinHrs:String) {
        
        
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        
        BackView.center = (window?.center)!
                
        window?.addSubview(BackView)
        
        RateCardView.frame.size.width = self.view.frame.size.width - 30

        RateCardView.center = BackView.center
        
        if SelectedVehicleCat.CategoryImage != nil {
            RateCardCatImage.image = SelectedVehicleCat.CategoryImage!
        }
        else {
            RateCardCatImage.ImageLoaderStart()
            RateCardCatImage.af_setImage(withURL: URL.init(string: SelectedVehicleCat.CategoryImageUrl!)!, placeholderImage: nil, filter: nil, progress: nil, progressQueue: DispatchQueue.main, imageTransition: .noTransition, runImageTransitionIfCached: true, completion: { (ImageResponce) in
                self.RateCardCatImage.ImageLoaderStop()
                if ImageResponce.data != nil {
                    let image = UIImage.init(data: ImageResponce.data!)!
                    self.RateCardCatImage.image = image
                    self.SelectedVehicleCat.CategoryImage = image
                }
            })
        }
        
//        RateCardCatImage.image = SelectedVehicleCat.CategoryImage!
        RateCardCatTitle.text = SelectedVehicleCat.CategoryName!
        
        RateCardBasefare.text = basefare
        RateCardMinKms.text = MinKms
        RateCardMinHrs.text = MinHrs
        
        RateCardView.isHidden = false
        
        RateCardView.layer.cornerRadius = 3
        RateCardView.clipsToBounds = true
        
        let GuardianTap = UITapGestureRecognizer.init(target: self, action: #selector(TapRatecardView(_:)))
        GuardianTap.numberOfTapsRequired = 1
        BackView.addGestureRecognizer(GuardianTap)
        
        let animation = CATransition()
        animation.duration = 0.8
        animation.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
        animation.fillMode = kCAFillModeForwards
        animation.isRemovedOnCompletion = false
        animation.type = kCATransitionPush
        animation.subtype = kCATransitionFromTop
        RateCardView.layer.add(animation, forKey: "animation")
        BackView.addSubview(RateCardView!)
    }
    
    @IBAction func RateCardOkBtn(_ sender:UIButton) {
        RemoveRatecard()
    }
    
    func TapRatecardView(_ responder:UITapGestureRecognizer) {
        
        let Point = responder.location(in: RateCardView.superview!)
        let Frame = RateCardView.frame
        
        if !Frame.contains(Point) {
            RemoveRatecard()
        }
    }
    
    func RemoveRatecard() {
        
        let animation = CATransition()
        animation.duration = 0.8
        animation.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
        animation.fillMode = kCAFillModeForwards
        animation.isRemovedOnCompletion = false
        animation.type = kCATransitionPush
        animation.subtype = kCATransitionFromBottom
        RateCardView.layer.add(animation, forKey: "animation")
        
        RateCardView.isHidden = true
        
        Timer.scheduledTimer(timeInterval: 0.8, target: self, selector: #selector(RemoveRatecardSuperView), userInfo: nil, repeats: false)
        
    }
    
    func RemoveRatecardSuperView() {
        RateCardView.superview?.removeFromSuperview()
    }
    
    //Rate card API
    func LoadRatecardData() {
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            
            let SelectedCategory = SelectedVehicleCat.CategoryId!
            
            let VehFil = self.VehiclesArr.filter({$0.VehicleStr.VehicleCategoryId! == SelectedCategory})

            var ModelName = ""
            
            if VehFil.count > 0 {
                ModelName = VehFil[0].VehicleStr.ModelName!
            }
            else {
               ModelName = "0"
            }
            
            let CityArr = DriveBookingResponce.CityDetails.sorted(by: {$0.0.CityName.localizedCaseInsensitiveCompare($0.1.CityName) == ComparisonResult.orderedAscending})
            
            let RateCardDict = ["VehicleCategoryId":SelectedCategory,
                                "VehicleModelId":ModelName,
                                "City":"\(CityName == "" ? CityArr[0].CityName! : CityName.contains(" ") ? CityName.components(separatedBy: " ")[0]: CityName)",
                                "EmpId":"\(DriveBookingResponce.EmpId!)",
                                "TypeofTrip":"Meter Tariff",
                                "Type":"Current",
                                "VendorId":"\(LoginRequest.LoginCreds.VendorId!)",
                                "CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)",
                                "AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
            
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveRateCard, parameterDict: RateCardDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (RatecardResponceDict, responceCode, success) in
                
                self.view.StopLoading()

                if success {
                    if let Table = ((RatecardResponceDict as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                        
                        if "\(Table["Status"]!)" == "true" {
                            self.RatecardViewMake(basefare: "\(Table["BaseFare"]!)", MinKms: "\(Table["MinimumKms"]!)", MinHrs: "\(Table["MinimumHrs"]!)")
                        }
                        else {
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                        }
                    }
                    else {
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                    }
                }
                else {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                }
            })
            
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.NetErrorMsg, Interval: 3)
        }
    }
    
    
    // MARK: - }
    
    
    
    // MARK: - Coupon and Coupon confirm view {
    
    
    @IBOutlet var CouponViewObj:UIView!
    
    @IBOutlet var CouponTxtFld:UITextField!
    
    var IsCouponAvailable = false
    
    var CouponCode = "0"
    
    var InitialPostion:CGFloat = 0.0
    
    func CouponViewMake() {
        //        InitialPostion
        
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        
        BackView.center = (window?.center)!
        
        CouponViewObj.frame.size.width = self.view.frame.size.width
        
        window?.addSubview(BackView)
        CouponViewObj.center = BackView.center
        
        CouponViewObj.layer.cornerRadius = 3
        CouponViewObj.clipsToBounds = true
        
        BackView.addSubview(CouponViewObj!)
        
        InitialPostion = CouponViewObj.frame.origin.y
        
        CouponTxtFld.text = ""
        
        CouponViewObj.alpha = 0
        
        UIView.animate(withDuration: 0.5) {
            self.CouponViewObj.alpha = 1
        }
        
    }
    
    func CloseCouponView() {
        
        UIView.animate(withDuration: 0.3, animations: {
            self.CouponViewObj.alpha = 0
        }) { (yes) in
            if yes {
                self.CouponViewObj.alpha = 1
                self.CouponViewObj.superview?.removeFromSuperview()
            }
        }
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    
    
    //Coupon APplied button action. If valid coupon applied change button image.
    @IBAction func CouponApplyBtnPressed(_ sender:UIButton) {
        
        CouponViewObj.endEditing(true)
        
        if (CouponTxtFld.text?.isEmpty)! {
            self.CouponViewObj.superview?.ShowWhiteTostWithText(message: "Please enter coupon code", Interval: 3)
            return
        }
        
        if (Reachability()?.isReachable)! {
            
            UIApplication.shared.keyWindow?.StartLoading()
            
            let SelectedCategory = SelectedVehicleCat.CategoryId!
            
            let Dict = ["MobileNo":"\(DriveBookingResponce.PhoneNo!)",
                        "EmpId":"\(DriveBookingResponce.EmpId!)",
                        "CouponCode":"\(CouponTxtFld.text!)",
                        "VehicleCategory":"\(SelectedCategory)",
                        "BookingType":"Current",
                        "VendorId":"\(LoginRequest.LoginCreds.VendorId!)",
                        "CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)",
                        "AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
           
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveCheckCouponCode, parameterDict: Dict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (ResponceDict, responceCode, success) in
                UIApplication.shared.keyWindow?.StopLoading()
                if success {
                    
                    if let Table = ((ResponceDict as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                        //print(Table)
                        
                        if "\(Table["Status"]!)" == "true" || "\(Table["Status"]!)" == "1" {
                            self.CouponCode = "\(self.CouponTxtFld.text!)"
                            self.CloseCouponView()
                            self.CouponAppliedView(text: "\(Table["OfferMessage"]!)")
                            
                            self.CouponViewAppliedObj.superview?.ShowWhiteTostWithText(message: "\(Table["Response"]!)", Interval: 7)

                            self.LoaderStopTimer = Timer.scheduledTimer(timeInterval: 7, target: self, selector: #selector(self.CloseCouponAppledView), userInfo: nil, repeats: false)
                            self.IsCouponAvailable = true
                            self.ConfirmationArr[2].Image = #imageLiteral(resourceName: "Copoun_AppliedSuccesfully")
                            self.ConfirmBookingCollection.reloadData()
                            
                        }
                        else {
                            self.CouponViewObj.superview?.ShowWhiteTostWithText(message: "\(Table["Response"]!)", Interval: 3)
                        }
                        
                    }
                    else {
                        self.CouponViewObj.superview?.ShowWhiteTostWithText(message:Constants.InternalError, Interval: 3)
                    }
                    
                }
                else {
                    self.CouponViewObj.superview?.ShowWhiteTostWithText(message:Constants.InternalError, Interval: 3)
                }
            })
        }
        else {
            self.CouponViewObj.superview?.ShowWhiteTostWithText(message: Constants.NetErrorMsg, Interval: 2)
        }
    }
    
    
    @IBAction func CouponCloseBtnPressed(_ sender:UIButton) {
        CloseCouponView()
    }
    @IBOutlet var AppliedCouponLabel:UILabel!
    
    func keyboardShow(_ notification : NSNotification) {
        
        if CouponTxtFld.isFirstResponder {
            let info = notification.userInfo
            let keyboardframe = (info![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size
            var phoneframe = CGRect.init()
            phoneframe = CouponTxtFld.frame
            
            phoneframe.origin.y += (CouponTxtFld.superview?.frame.origin.y)!
            phoneframe.origin.y += (CouponTxtFld.superview?.superview?.frame.origin.y)!
            
            var actualframe = self.view.frame
            actualframe.size.height -= keyboardframe.height
            actualframe.size.height -= (phoneframe.size.height)
            
            if !actualframe.contains((phoneframe.origin)) {
                let yfinal = (phoneframe.origin.y) - actualframe.size.height
                
                UIView.animate(withDuration: 0.3, animations: { () -> Void in
                    
                    self.CouponViewObj.frame.origin.y -= yfinal
                })
                
            }
        }
    }
    
    func keyboardHide(_ notification : NSNotification)
    {
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.CouponViewObj.frame.origin.y = self.InitialPostion
        })
    }
    
    
    @IBOutlet var CouponViewAppliedObj:UIView!
    
    var LoaderStopTimer = Timer()
    
    func CouponAppliedView(text: String) {
        
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        
        BackView.center = (window?.center)!
        self.AppliedCouponLabel.text  = text

        CouponViewAppliedObj.frame.size.width = self.view.frame.size.width
        
        window?.addSubview(BackView)
        CouponViewAppliedObj.center = BackView.center
        
        CouponViewAppliedObj.layer.cornerRadius = 3
        CouponViewAppliedObj.clipsToBounds = true
        
        BackView.addSubview(CouponViewAppliedObj!)
        
        CouponViewAppliedObj.alpha = 0
        
        UIView.animate(withDuration: 0.5) {
            self.CouponViewAppliedObj.alpha = 1
        }
    }
    
    func CloseCouponAppledView() {
        
        UIView.animate(withDuration: 0.3, animations: {
            self.CouponViewAppliedObj.alpha = 0
        }) { (yes) in
            if yes {
                self.CouponViewAppliedObj.alpha = 1
                self.CouponViewAppliedObj.superview?.removeFromSuperview()
                self.LoaderStopTimer.invalidate()
            }
        }
    }
    
    @IBAction func CouponAppliedCloseBtnPressed(_ sender:UIButton) {
        CloseCouponAppledView()
    }
    

    
    // MARK: - }
    
}

extension RideNowVC: GMSMapViewDelegate, CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        //print(error.localizedDescription)
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse || status == .authorizedAlways {
            LocationManager.startUpdatingLocation()
        }
        else {
            ShowLocationDenied(controller: self)
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        

        
        if locations.count > 0 {
            
            let Location = locations.last!
            
            if IsFirstTime {
                IsFirstTime = false
                let Camera = GMSCameraPosition.camera(withLatitude: Location.coordinate.latitude, longitude: Location.coordinate.longitude, zoom: 17)
//              RideLaterMap.camera = Camera
                RideLaterMap.animate(to: Camera)
                self.PickUpSelectionLbl.superview?.lock()
            }
            
            CLGeocoder().reverseGeocodeLocation(locations.last!, completionHandler: { (Locations, error) in
         
                
                if error == nil {
                    let Dict = UtilitiesClassSub.getLocationDetails(fromCLPlaceMark: Locations?.last!)
                    if "\((Dict?[LocationParserCity]!)!)" != "" {
                        self.CityName = "\((Dict?[LocationParserCity]!)!)"
                        }
                    else {
                        
                    }
                }
                else {
                    
                }
            })
            
        }
    }
 
//    func getAddressFromLatLon() {
//        var center : CLLocationCoordinate2D = CLLocationCoordinate2D()
//        let lat: Double = Double("\(RideLaterMap.camera.target.latitude)")!
//        //21.228124
//        let lon: Double = Double("\((RideLaterMap.camera.target.longitude))")!
//        //72.833770
//        let ceo: CLGeocoder = CLGeocoder()
//        center.latitude = lat
//        center.longitude = lon
//        
//        let loc: CLLocation = CLLocation(latitude:center.latitude, longitude: center.longitude)
//        
//        
//        ceo.reverseGeocodeLocation(loc, completionHandler:
//            {(placemarks, error) in
//                if (error != nil)
//                {
//                    print("reverse geodcode fail: \(error!.localizedDescription)")
//                }
//                let pm = placemarks! as [CLPlacemark]
//                
//                if pm.count > 0 {
//                    let pm = placemarks![0]
////                    print(pm.country)
//                    print("reverse geodcode fail")
//                    print(pm.locality)
////                    print(pm.subLocality)
////                    print(pm.thoroughfare)
////                    print(pm.postalCode)
////                    print(pm.subThoroughfare)
////                    var addressString : String = ""
////                    if pm.subLocality != nil {
////                        addressString = addressString + pm.subLocality! + ", "
////                    }
////                    if pm.thoroughfare != nil {
////                        addressString = addressString + pm.thoroughfare! + ", "
////                    }
////                    if pm.locality != nil {
////                        addressString = addressString + pm.locality! + ", "
////                    }
////                    if pm.country != nil {
////                        addressString = addressString + pm.country! + ", "
////                    }
////                    if pm.postalCode != nil {
////                        addressString = addressString + pm.postalCode! + " "
////                    }
////                    
////                    
////                    print(addressString)
//                }
//        })
//        
//    }

    
    func mapView(_ mapView: GMSMapView, idleAt position: GMSCameraPosition) {
        
        if !isZoomingAll {
            if LoadGeoLocation {
                GeoLocationLoadOnMap(Position: position.target)
            }
        }
        else {
            isZoomingAll = false
        }
        
        
        if DropSelectionView.isHidden {
            let pickLat = RideLaterMap.camera.target.latitude
            let pickLon = RideLaterMap.camera.target.longitude
            
            let location = CLLocation(latitude: Double(pickLat), longitude: Double(pickLon)) //changed!!!
            
            CLGeocoder().reverseGeocodeLocation(location, completionHandler: {(placemarks, error) -> Void in
                
                if error != nil {
                    print("Reverse geocoder failed with error" + (error?.localizedDescription)!)
                    return
                }
                
                if (placemarks?.count)! > 0 {
                    let pm : CLPlacemark = (placemarks?[0])! as CLPlacemark
                    print("**********@@@@@@@@@@@@@@********")
                    print("\(String(describing: pm.locality))")
                    if (pm.locality) != nil{
                        self.fetchCityName = pm.locality!
                    }else{
                        
                        self.fetchCityName = ""
                    }
                }
                else {
                    self.fetchCityName = ""
                }
            })
        }

       
    }

    
    func mapView(_ mapView: GMSMapView, willMove gesture: Bool) {
        
        if !isZoomingAll {
            if LoadGeoLocation {
                
                if DropSelectionView.isHidden {
                    self.PickUpSelectionLbl.superview?.lock()
                }
                else {
                    self.DropSelectionLbl.superview?.lock()
                }
                
                
                
                if (gesture) {
                    mapCenterPinImage.fadeIn(duration: 0.25)
                    mapView.selectedMarker = nil
                }
            }
        }
        
    }
    
    
    func GeoLocationLoadOnMap(Position:CLLocationCoordinate2D) {
        
        GMSGeocoder().reverseGeocodeCoordinate(Position) { (GeocodeResponce, error) in
            
            if self.DropSelectionView.isHidden {
                self.PickUpSelectionLbl.superview?.unlock()
            }
            else {
                self.DropSelectionLbl.superview?.unlock()
            }
            
            if error == nil {
                
                if GeocodeResponce != nil {
                    let address = GeocodeResponce?.results()?[0].lines
                    
                    
                    var AddStr = ""
                    for add in address! {
                        
                        var AddFilterStr = ""
                        
                        // filter add {
                        
                        if add == "Unnamed Road" {
                            // nothing to add
                        }
                        else {
                            if add.contains("Unnamed Road, ") {
                                AddFilterStr = add.replacingOccurrences(of: "Unnamed Road, ", with: "")
                            }
                            else {
                                AddFilterStr = add
                            }
                        }
                        
                        // }
                        
                        
                        if AddFilterStr != "" {
                            AddStr.append(AddFilterStr + ", ")
                        }
                    }
                    
                    
                    if self.DropSelectionView.isHidden {

                        if AddStr.isEmpty {
                            self.PickUpSelectionLbl.text = "No Address available"
                            self.PickUpLocation = nil
                            self.clearALL()
                        }
                        else {
                            
                            self.FetchFavs()
                            
                            let addStr = AddStr.substring(to: AddStr.index(AddStr.endIndex, offsetBy: -2))
                            self.PickUpSelectionLbl.text = addStr
                            
                            self.PickUpLocation = FavouritesLocationsStruct()
                            self.PickUpLocation.Location = addStr
                            self.PickUpLocation.Latitude = Double("\(Position.latitude)")
                            self.PickUpLocation.Longitude = Double("\(Position.longitude)")
                            
                            
                            if self.FavLocArr.contains(where: {$0.Location! == self.PickUpLocation.Location!}) {
                                self.ADDFavPickupBtn.isSelected = true
                            }
                            else {
                                self.ADDFavPickupBtn.isSelected = false
                            }
                        }
//                        if self.PickUpLocation != nil{
//                            if !(self.PickUpLocation.Location.localizedCaseInsensitiveContains("India")){
//                                self.FetchVehicles()
//                            }else{
//                            
//                                for veh in self.VehiclesArr {
//                                    veh.map = nil
//                                }
//                                self.VehiclesArr.removeAll()
//                                self.VehCategoryCollection.reloadData()
//                                self.ADDFavPickupBtn.isSelected = false
//
//                            }
//                        }
                        
                        self.FetchVehicles()
                    }
                    else {
                        
                        
                        if AddStr.isEmpty {
                            self.DropSelectionLbl.text = "No Address available"
                            self.DropLocation = nil
                            self.ADDFavDropBtn.isSelected = false
                        }
                        else {
                            
                            self.FetchFavs()
                            
                            let addStr = AddStr.substring(to: AddStr.index(AddStr.endIndex, offsetBy: -2))
                            self.DropSelectionLbl.text = addStr
                            
                            self.DropLocation = FavouritesLocationsStruct()
                            self.DropLocation.Location = addStr
                            self.DropLocation.Latitude = Double("\(Position.latitude)")
                            self.DropLocation.Longitude = Double("\(Position.longitude)")
                            
                            
                            if self.FavLocArr.contains(where: {$0.Location! == self.DropLocation.Location!}) {
                                self.ADDFavDropBtn.isSelected = true
                            }
                            else {
                                self.ADDFavDropBtn.isSelected = false
                            }
                            
                        }
                        
                        
                    }
                    
                    
                }
                else {
                    
                    if self.DropSelectionView.isHidden {
                        self.PickUpSelectionLbl.text = "Invalid Location"
                        self.PickUpLocation = nil
                        self.clearALL()
                    }
                    else {
                        self.DropSelectionLbl.text = "No Address available"
                        self.DropLocation = nil
                        self.ADDFavDropBtn.isSelected = false
                    }
                    
                }
                
            }
            else {
                
                if self.DropSelectionView.isHidden {
                    self.PickUpSelectionLbl.text = "Invalid Location"
                    self.PickUpLocation = nil
                    self.clearALL()
                }
                else {
                    self.DropSelectionLbl.text = "No Address available"
                    self.DropLocation = nil
                    self.ADDFavDropBtn.isSelected = false
                }
                
            }
            
        }
        
    }
    
    func clearALL(){
    
        self.ADDFavPickupBtn.isSelected = false

        for vehicle in self.VehiclesArr{
            vehicle.map = nil
        }
        self.VehiclesArr.removeAll()
        
        for i in 0..<self.VehicleDataArr.count {
            
            self.VehicleDataArr[i].CategoryTime = "No cabs"
        }
        VehCategoryCollection.reloadData()
    }
    
    
}


extension RideNowVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == VehCategoryCollection {
            return VehicleDataArr.count
        }
        else {
            return ConfirmationArr.count + 1
        }
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView == VehCategoryCollection {
//            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NewVehCategory", for: indexPath) as! NewVehCategoryCell

            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "VehCategory", for: indexPath) as! VehCategoryCell
            
            cell.TimeLbl.text = VehicleDataArr[indexPath.row].CategoryTime!
            cell.TitleLbl.text = VehicleDataArr[indexPath.row].CategoryName!
            if VehicleDataArr[indexPath.row].CategoryImage != nil{
                cell.VehicleImage.image = VehicleDataArr[indexPath.row].CategoryImage
                print("VehicleDataArr[indexPath.row].CategoryImageUrl =",VehicleDataArr[indexPath.row].CategoryImageUrl)
                
            }else{
                cell.VehicleImage.ImageLoaderStart()
                cell.VehicleImage.af_setImage(withURL: URL.init(string: VehicleDataArr[indexPath.row].CategoryImageUrl!)!, placeholderImage: #imageLiteral(resourceName: "RHatchback"), filter: nil, progress: nil, progressQueue: DispatchQueue.main, imageTransition: .noTransition, runImageTransitionIfCached: true, completion: { (ImageResponce) in
                    cell.VehicleImage.ImageLoaderStop()
                    
                    if ImageResponce.response?.statusCode == 200{
                        if ImageResponce.data != nil {
                            let image = UIImage.init(data: ImageResponce.data!)!
                            cell.VehicleImage.image = image
                            self.VehicleDataArr[indexPath.row].CategoryImage = image
                        }
                    }
                })
            }
            if VehicleDataArr[indexPath.row].CatSelectedState! {
               
                // cell.SelectedLbl.backgroundColor = UIColor(hex: "f8bc53")
                
                cell.VehicleImage.ImageLoaderStart()
                cell.VehicleImage.af_setImage(withURL: URL.init(string: VehicleDataArr[indexPath.row].CategorySelectedurl!)!, placeholderImage: #imageLiteral(resourceName: "SelectedCars"), filter: nil, progress: nil, progressQueue: DispatchQueue.main, imageTransition: .noTransition, runImageTransitionIfCached: true, completion: { (ImageResponce) in
                    cell.VehicleImage.ImageLoaderStop()
                    
                    
                    if ImageResponce.response?.statusCode == 200{
                        if ImageResponce.data != nil {
                            let image = UIImage.init(data: ImageResponce.data!)!
                            cell.VehicleImage.image = image
                            self.VehicleDataArr[indexPath.row].CategorySelectedImage = image
                        }
                        
                    }
                    
                    
                })
 
            }
            else {
                //cell.SelectedLbl.backgroundColor = UIColor.clear
                cell.VehicleImage.ImageLoaderStart()
                cell.VehicleImage.af_setImage(withURL: URL.init(string: VehicleDataArr[indexPath.row].CategoryImageUrl!)!, placeholderImage: #imageLiteral(resourceName: "RHatchback"), filter: nil, progress: nil, progressQueue: DispatchQueue.main, imageTransition: .noTransition, runImageTransitionIfCached: true, completion: { (ImageResponce) in
                    cell.VehicleImage.ImageLoaderStop()
                    
                    if ImageResponce.response?.statusCode == 200{
                        if ImageResponce.data != nil {
                            let image = UIImage.init(data: ImageResponce.data!)!
                            cell.VehicleImage.image = image
                            self.VehicleDataArr[indexPath.row].CategoryImage = image
                        }
                    }
                })
            }
            
            return cell
        }
        else {
            
            if indexPath.row == 0 {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "VehConfirm", for: indexPath) as! VehCategoryCell
                
                cell.VehicleImage.ImageLoaderStart()
                cell.VehicleImage.af_setImage(withURL: URL.init(string: SelectedVehicleCat.CategoryImageUrl!)!, placeholderImage: #imageLiteral(resourceName: "RHatchback"), filter: nil, progress: nil, progressQueue: DispatchQueue.main, imageTransition: .noTransition, runImageTransitionIfCached: true, completion: { (ImageResponce) in
                    cell.VehicleImage.ImageLoaderStop()
                    if ImageResponce.response?.statusCode == 200{
                        if ImageResponce.data != nil {
                            let image = UIImage.init(data: ImageResponce.data!)!
                            cell.VehicleImage.image = image
                            self.SelectedVehicleCat.CategoryImage = image
                        }
                    }
                })

//                if SelectedVehicleCat.CategoryImage != nil {
//                    cell.VehicleImage.image = SelectedVehicleCat.CategoryImage!
//                }
//                else {
//                                    }
                
                cell.TimeLbl.text = SelectedVehicleCat.CategoryTime!
                cell.TitleLbl.text = SelectedVehicleCat.CategoryName!

                return cell
            }
            else {
                
                
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BookConfirmCell", for: indexPath) as! BookConfirmCell
                
                cell.TitleImage.image = ConfirmationArr[indexPath.row-1].Image
                cell.Title.text = ConfirmationArr[indexPath.row-1].Title!
//                print("BookConfirmCell title text =",cell.Title.text)
                if indexPath.row == 2{
                    if ConfirmationArr[indexPath.row-1].showLabel! == "Loading"{
                        cell.fareEstimationLbl.ImageLoaderStart()
                        cell.fareEstimationLbl.text = ""
                    }else{
                        cell.fareEstimationLbl.ImageLoaderStop()
                        cell.fareEstimationLbl.text = ConfirmationArr[indexPath.row-1].showLabel!
                    }
                    cell.fareEstimationLbl.isHidden = false
                }else{
                    cell.fareEstimationLbl.isHidden = true
                }
            
                
                return cell
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == VehCategoryCollection {

            
            if !VehicleDataArr[indexPath.row].CatSelectedState {
                
                for i in 0..<VehicleDataArr.count {
                    
                    if indexPath.row == i {
                        VehicleDataArr[i].CatSelectedState = true
                        SelectedVehicleCat = VehicleDataArr[i]
                        ChangeConvenianceAmount()
                    }
                    else {
                        VehicleDataArr[i].CatSelectedState = false
                    }

                }
                
                collectionView.reloadData()
                
                
//                for VehObj in self.VehiclesArr {
//                    VehObj.map = nil
//                }
//                
//                let FilterSelected = self.VehiclesArr.filter({$0.VehicleStr.VehicleCategoryId! == SelectedCab})
//                
//                for Obj in FilterSelected {
//                    Obj.map = self.RideLaterMap
//                }
                
                if PickUpLocation != nil{
                    self.FetchVehicles()
                }
            }
            
        }
        else {
            if indexPath.row > 0 {
                
                
                if indexPath.row == 3 {
                    if IsCouponAvailable {
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Coupon already applied", Interval: 3)
                        
                    }
                    else {
//                        CouponViewMake()
                        if DropLocation != nil {
                            CouponViewMake()
                        }else{
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Please select Drop Location", Interval: 3)
                        }
                        
                    }
                }

                else {
            
                    if DropLocation == nil {
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Please select Drop Location", Interval: 3)
                    }
                    


                    else if indexPath.row == 1 {
                        
                        let paymentModeDetailsObj = self.storyboard?.instantiateViewController(withIdentifier: "PaymentModeDetailsSelectClassSBID") as! PaymentModeDetailsSelectClass
                        
                        paymentModeDetailsObj.myDelegateRef = self
//                        paymentModeDetailsObj.corpOrPersonalType = "Personal"
                        
                        paymentModeDetailsObj.modalTransitionStyle = .coverVertical
                        
                        let transition = CATransition()
                        transition.duration = 0.45
                        transition.type = kCATransitionFromBottom
                        
                        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
                        self.navigationController?.pushViewController(paymentModeDetailsObj, animated: false)
                        
//                        let paymentController = self.storyboard?.instantiateViewController(withIdentifier: "PaymentSelectionVC") as! PaymentSelectionVC
//                        paymentController.Delegate = self
//                        paymentController.FromRide_Street = "0"
//                        paymentController.modalTransitionStyle = .coverVertical
//
//                        var Type =  PaymentType.cash //PaymentType.cash
//
//                        if ConfirmationArr[indexPath.row - 1].PaymentType! == "PAYTM" {
//                            Type = .paytm
//                        }
//                        else if ConfirmationArr[indexPath.row - 1].PaymentType! == "MOBIKWIK" {
//                            Type = .mobikwik
//                        }
//
//                        paymentController.PaymentType = Type
//
//                        paymentController.PickupDetails = PickUpLocation!
//                        paymentController.DropLocDetails = DropLocation!

//                        let SelectedCategory = SelectedVehicleCat.CategoryId!
//
//                        let VehFil = self.VehiclesArr.filter({$0.VehicleStr.VehicleCategoryId! == SelectedCategory})
//
//                        var ModelName = ""
//
//                        if VehFil.count > 0 {
//                            ModelName = VehFil[0].VehicleStr.ModelName!
//                        }
//                        else {
//                            ModelName = "0"
//                        }
//
//                        paymentController.VehicleCat = SelectedCategory
//
//                        paymentController.VehicleModelName = ModelName
//
//                        let CityArr = DriveBookingResponce.CityDetails.sorted(by: {$0.0.CityName.localizedCaseInsensitiveCompare($0.1.CityName) == ComparisonResult.orderedAscending})
//
//                        paymentController.CityName = "\(CityName == "" ? CityArr[0].CityName! : CityName.contains(" ") ? CityName.components(separatedBy: " ")[0]: CityName)"


//                        let transition = CATransition()
//                        transition.duration = 0.45
//                        transition.type = kCATransitionFromBottom
//
//                        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
//                        self.navigationController?.pushViewController(paymentController, animated: false)
                        
                        
                    }
                    else {
                        
//                        if DropLocation.Latitude == nil{
//                            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Drop Location Details are not Valid", Interval: 3)
//                            return
//                        }
                        
//                        let FareEstim = self.storyboard?.instantiateViewController(withIdentifier: "FareEstimationVC") as! FareEstimationVC
//                        
//                        FareEstim.PickupDetails = PickUpLocation!
//                        FareEstim.DropLocDetails = DropLocation!
//                        
//                        let SelectedCategory = SelectedVehicleCat.CategoryId!
//                        
//                        let VehFil = self.VehiclesArr.filter({$0.VehicleStr.VehicleCategoryId! == SelectedCategory})
//                        
//                        var ModelName = ""
//                        if VehFil.count > 0 {
//                            ModelName = VehFil[0].VehicleStr.ModelName!
//                        }
//                        else {
//                            ModelName = "0"
//                        }
//                        var cityNam = "Mumbai"
//                        if fetchCityName! != ""{
//                            cityNam = fetchCityName!
//                        }else{
//                            
//                            cityNam = "Mumbai"
//                        }
//                        
//                        FareEstim.VehicleCat = SelectedCategory
//
//                        FareEstim.VehicleModelName = ModelName
//                        
////                        let CityArr = DriveBookingResponce.CityDetails.sorted(by: {$0.0.CityName.localizedCaseInsensitiveCompare($0.1.CityName) == ComparisonResult.orderedAscending})
//                        
//                        FareEstim.CityName = "\(cityNam)"
//                        
//                        self.navigationController?.pushViewController(FareEstim, animated: true)
                    }
                }
            }
        }
    }
    
 
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if collectionView == VehCategoryCollection {
            return CGSize.init(width: (VehCategoryCollection.frame.width / 3) - 1, height: VehCategoryCollection.frame.height)
        }
        else {
            return CGSize.init(width: ConfirmBookingCollection.frame.width/4, height: ConfirmBookingCollection.frame.height)
        }
        
    }
    
    // MARK: - Payment New Select {
    
    func PaymentDidSelect(PaymentType: PaymentType, Balance:String, controller: PaymentSelectionVC) {
        controller.navigationController?.popViewController(animated: true)
        
        if PaymentType == .paytm {
//            ConfirmationArr[0].Image = #imageLiteral(resourceName: "PaytmLogo")
//            ConfirmationArr[0].PaymentType = "PAYTM"
//            ConfirmationArr[0].WalletAmount = Balance
//            ConfirmationArr[0].Title = "PAYTM"
            
            PaytmSelected(Balance: Balance)
        }
        else if PaymentType == .mobikwik {
//            ConfirmationArr[0].Image = #imageLiteral(resourceName: "MobikwikIcon")
//            ConfirmationArr[0].PaymentType = "MOBIKWIK"
//            ConfirmationArr[0].WalletAmount = Balance
//            ConfirmationArr[0].Title = "MOBIKWIK"
            
            MobiKwikSelected(Balance: Balance)
        }
        else {
//            ConfirmationArr[0].Image = #imageLiteral(resourceName: "cashinhand")
//            ConfirmationArr[0].PaymentType = "CASH"
//            ConfirmationArr[0].WalletAmount = Balance
//            ConfirmationArr[0].Title = "CASH"
            
            CashSelected()
        }
        ConfirmBookingCollection.reloadData()
    }
    
    
    
   
}

extension RideNowVC : PaymentModeDetailsSelectDelegate{
    func DidOKTapped(_ selectedPaymentMode: String!, _ controller: PaymentModeDetailsSelectClass) {
        controller.navigationController?.popViewController(animated: true)
        CashOrCardSelected(type: selectedPaymentMode)
    }
}


class BookConfirmCell: UICollectionViewCell {
    
    @IBOutlet var Title: UILabel!
    @IBOutlet var TitleImage: UIImageView!
    
    @IBOutlet weak var fareEstimationLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}

class PaymentColCell: UICollectionViewCell {
    
    @IBOutlet var SubTitle: UILabel!
    @IBOutlet var TitleImage: UIImageView!
    @IBOutlet var PayImage: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
    }
}

class VehCategoryCell: UICollectionViewCell {
    
    @IBOutlet var TimeLbl: UILabel!
    @IBOutlet var TitleLbl: UILabel!
    @IBOutlet var VehicleImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}

class NewVehCategoryCell: UICollectionViewCell {
    
    @IBOutlet var TimeLbl: UILabel!
    @IBOutlet var TitleLbl: UILabel!
    @IBOutlet var VehicleImage: UIImageView!
    @IBOutlet var SelectedLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
