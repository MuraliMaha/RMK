//
//  PlacesSearchResultsTVC.swift
//  DriveFindMyCab
//
//  Created by SunTelematics' Mac PC on 22/03/17.
//  Copyright © 2017 Divya. All rights reserved.
//

import UIKit
import GoogleMaps
import GooglePlaces
protocol LocationSelectDelegate {
    func DidselectLocation(_ Lat:Double!, _ Lag:Double!, _ Title:String!,_ controller:PlacesSearchResultsTVC)
}
class PlacesSearchResultsTVC: UITableViewController,UISearchResultsUpdating {
    
    
    var PlaceDelegate: LocationSelectDelegate!
    
    var SearchResultsArr = [PlacesStruct]()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: "PlacescellIdentifier")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func updateSearchResults(for searchController: UISearchController) {
                
        let searchTxt = searchController.searchBar.text!
        let url = URL.init(string: "https://maps.googleapis.com/maps/api/place/autocomplete/json?" + "input=\(searchTxt.replacingOccurrences(of: " ", with: "+"))&sensor=true&key=AIzaSyAE5UblSko0JCqUC05-bag8gjZFpTAicuA&rankby=prominence")
        
        let theRequest = URLRequest.init(url: url!)
        
        
        let manager = AFHTTPRequestOperation(request: theRequest)
        
        manager.setCompletionBlockWithSuccess({ (operation : AFHTTPRequestOperation, responseObject : Any) -> Void in
            self.SearchResultsArr.removeAll()
            
            var string = NSString.init(data: responseObject as! Data, encoding: UInt.allZeros)
            
            string = string?.components(separatedBy: "<")[0] as NSString?
            
            if let val:[String:AnyObject] = self.FilterData(string! as String) {
                if let dataarr:[[String:AnyObject]] = val["predictions"] as? [[String:AnyObject]] {
                    for dataObj in dataarr {
                        var structobj = PlacesStruct()
                        structobj.Title = dataObj["description"] as! String
                        structobj.ID = dataObj["place_id"] as! String
                        self.SearchResultsArr.append(structobj)
                    }
                }
            }
            
            self.tableView.reloadData()
        }, failure: { (operation : AFHTTPRequestOperation, error : Error) -> Void in
            print(error)
        })
        
        manager.start()

    }
    
    func FilterData(_ str:String) -> [String:AnyObject]? {
        let data = str.data(using: .utf8)
        if let dict:[String:AnyObject] = try? JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [String:AnyObject] {
            return dict
        }
        else {
            return nil
        }
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return SearchResultsArr.count 
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PlacescellIdentifier", for: indexPath)
        
        cell.textLabel?.text = SearchResultsArr[indexPath.row].Title
        cell.textLabel?.numberOfLines = 3
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let url = URL.init(string: "https://maps.googleapis.com/maps/api/place/details/json?placeid=\(SearchResultsArr[indexPath.row].ID!)&key=AIzaSyAE5UblSko0JCqUC05-bag8gjZFpTAicuA")
        
        let theRequest = URLRequest.init(url: url!)
        
        let manager = AFHTTPRequestOperation(request: theRequest)
        
        manager.setCompletionBlockWithSuccess({ (operation : AFHTTPRequestOperation, responseObject : Any) -> Void in
            
            var string = NSString.init(data: responseObject as! Data, encoding: UInt.allZeros)
            
            string = string?.components(separatedBy: "<")[0] as NSString?
            
            if let val:[String:AnyObject] = self.FilterData(string! as String) {
                if let result:[String:AnyObject] = val["result"] as? [String:AnyObject] {
                    if let geometry:[String:AnyObject] = result["geometry"] as? [String:AnyObject] {
                        if let Location:[String:AnyObject] = geometry["location"] as? [String:AnyObject] {
                            
                            var Lat:Double = 0
                            var Lon:Double = 0
                            
                            if let latitude = Location["lat"],
                                (latitude is NSNumber || latitude is String) {
                                Lat = Double("\(latitude)")!
                            }
                            if let longitude = Location["lng"],
                                (longitude is NSNumber || longitude is String) {
                                Lon = Double("\(longitude)")!
                            }
                            
                            self.PlaceDelegate.DidselectLocation(Lat, Lon, self.SearchResultsArr[indexPath.row].Title,self)
                        }
                    }
                }
            }
            
        }, failure: { (operation : AFHTTPRequestOperation, error : Error) -> Void in
            print(error)
        })
        
        manager.start()
        
    }
}
