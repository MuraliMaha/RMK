//
//  ShiftRequestVC.swift
//  DriveFindMyCab
//
//  Created by SunTelematics on 30/03/18.
//  Copyright © 2018 Suntelematics. All rights reserved.
//

import UIKit

class ShiftRequestVC: UIViewController {

    var loginResponse:LoginResponce!
    var loginDetails:LoginDetails!
    
    @IBOutlet weak var shiftDateTxtFld: UITextField!
    @IBOutlet weak var shiftTimeTxtFld: UITextField!
    
    var shiftDatepicker = UIDatePicker()
    
    var myDateFormat : DateFormatter = {
        let fomat = DateFormatter()
//        fomat.dateFormat = "yyyy-mm-dd"
        fomat.dateFormat = "dd-MMM-yyyy"
        return fomat
    }()
    
    var shiftDatePickedItem : String!
    
    var oneMonthAddedDate : Date?
    
    
    
    var shiftTimePicker = UIPickerView()
    var shiftTimeArr = [String]()
    
    var shiftTimePickedItem = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        shiftDateTxtFld.delegate = self
        shiftTimeTxtFld.delegate = self
        
        shiftTimePicker .delegate = self;
        shiftTimePicker.dataSource = self;
        
        loginDetails = FetchLoginDetails()
        loginResponse = FetchLoginResponce()
        
        
        var dateComponents = DateComponents()
        dateComponents.month = 1
        
        let cal = Calendar.current
        oneMonthAddedDate = cal.date(byAdding: dateComponents, to: Date())
        
        let Toolbar = UIToolbar()
        Toolbar.barStyle = .default
        Toolbar.isTranslucent = true
        Toolbar.tintColor = UIColor.blue
        Toolbar.sizeToFit()
        
        shiftDatepicker.datePickerMode = .date;
        
        
        
        shiftDatePickedItem = myDateFormat.string(from: Date())
        
        let DoneItem = UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(PickDoneAction(_:)))
        let FlexiItem = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let CancelItem = UIBarButtonItem.init(title: "Cancel", style: .done, target: self, action: #selector(PickCancelAction(_:)))
        
        
        Toolbar.setItems([CancelItem,FlexiItem,DoneItem], animated: true)
        Toolbar.isUserInteractionEnabled = true
        
        shiftDateTxtFld.inputView = shiftDatepicker
        shiftDateTxtFld.inputAccessoryView = Toolbar
        
        
        shiftTimeTxtFld.inputView = shiftTimePicker;
        shiftTimeTxtFld.inputAccessoryView = Toolbar;
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.white
        self.navigationItem.leftBarButtonItem = BackBtnItem
        
        fetchShiftTime()
    }
    
    func fetchShiftTime() {
        if (Reachability()?.isReachable)! {
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.DriveShiftTime, parameterDict: ["EmpId":"\(loginResponse.Employeeid!)"], completion: { (responceDict, success) in
                
                if success {
                    
                    if let Dict = responceDict {
                        let Arr = Dict["data"] as! [[String:AnyObject]]
                        
                        if Arr.count != 0 {
                            
                            self.shiftTimeTxtFld.text = Arr[0]["LoginTime"] as? String
                            self.shiftTimePickedItem = self.shiftTimeTxtFld.text!
                            
                            for DataDict in Arr {
                                self.shiftTimeArr.append("\(DataDict["LoginTime"]!)")
                            }
                        }
                        
                    }
                    else {
                        self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                        
                        print("Error")
                    }
                    
                }
                else {
                    self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                    
                    print("Error")
                }
            })
            
        }
        else {
            self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
            
            print("Net Error")
        }
    }
    func BackAction() {
        self.navigationController?.popViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    // MARK: - Pick Actions {
    
    func PickDoneAction(_ sender:UIBarButtonItem) {
        
        if (shiftDateTxtFld.isFirstResponder) {
            shiftDateTxtFld.text = shiftDatePickedItem;
        }
        else if (shiftTimeTxtFld.isFirstResponder) {
            shiftTimeTxtFld.text = shiftTimePickedItem;
        }
        self.view.endEditing(true)
    }
    
    func PickCancelAction(_ sender:UIBarButtonItem) {
        self.view.endEditing(true)
    }

    @IBAction func changeShiftBtnTapped(_ sender: UIButton) {

      
        
        if self.CheckBeforeRequest() {
            
//            Request Submitted Successfully!
            
            if (Reachability()?.isReachable)! {
                
//                UtilitiesClass.Alert(Title: "Request Shift Change", Message: "Are you sure?" as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "CANCEL"),UtilitiesClass.AlertActionWithSelector(Title: "YES", Selector: #selector(CheckAndSend), Controller: self)], Controller: self)
                
                CheckAndSend()
                
                
            }
            else {
                UtilitiesClass.Alert(Title: "OOPS..", Message: Constants.NetErrorMsg as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            }
        }else {
            
            
            
            var errorString = ""
            
            if (self.shiftDateTxtFld.text?.isEmpty)! {
                errorString  = "Please select shift Date"
            } else if (self.shiftTimeTxtFld.text?.isEmpty)! {
                errorString  = "Please select shift Time"
            }
            UtilitiesClass.Alert(Title: "OOPS..", Message: errorString as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            
        }
    
    }
    
    @IBAction func cancelBtnTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    func CheckBeforeRequest() -> Bool {
        
        if (shiftDateTxtFld.text?.isEmpty)! || (shiftTimeTxtFld.text?.isEmpty)!
        {
            return false
        }
        else {
            return true
        }
    }
    func CheckAndSend() {
        
        self.view.StartLoading()
        
        
        
        //            AppConstants.URL + "ShiftChangeRequest?EmpId="
        //            + sharedPref.getString(AppConstants.EMPID) + "&Date=" + edtshiftDate.getText().toString() +
        //            "&ShiftTime=" + spinnershiftTime.getSelectedItem().toString();
        
        let RequestDict = ["EmpId":"\(loginResponse.Employeeid!)","Date":"\(shiftDatePickedItem!)","ShiftTime":"\(shiftTimePickedItem)"]
        
        WebService().callAutoAPI(Suffix: WebServicesUrl.DriveShiftChangeRequest, parameterDict:RequestDict , completion: { (responceDict, success) in
            
            self.view.StopLoading()
            
            if success {
                
//                UtilitiesClass.Alert(Title: "Your Request has been registered", Message: "", Actions: [UtilitiesClass.AlertActionWithSelector(Title: "OK", Selector: #selector(self.OkAction), Controller: self)], Controller: self)
                
                self.view.ShowBlackTostWithText(message: "Request Submitted Successfully!", Interval: 3)
                
                self.perform(#selector(self.OkAction), with: nil, afterDelay: 3)
//                self.OkAction()
            }
            else {
                UtilitiesClass.Alert(Title: "OOPS..", Message: Constants.InternalError as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            }
        })
    }
    func OkAction() {
        self.navigationController?.popViewController(animated: true)
    }
}
extension ShiftRequestVC : UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if (textField == shiftDateTxtFld) {
            
            if shiftDateTxtFld.text == "" {
                shiftDatepicker.date = Date();
            }
            else {
                shiftDatepicker.date = myDateFormat.date(from: shiftDateTxtFld.text!)!
            }
            
            shiftDatepicker.minimumDate = Date();
            shiftDatepicker.maximumDate = oneMonthAddedDate
            shiftDatepicker.addTarget(self, action: #selector(shiftDateChanged(_:)), for: .valueChanged)
            
        }
        if (textField == shiftTimeTxtFld)
        {
            shiftTimePicker.reloadAllComponents()
            
            if shiftTimeArr.count != 0 {
                shiftTimePickedItem = shiftTimeArr[0]
            }
        }
    }
    func shiftDateChanged(_ shiftdate:UIDatePicker) {
        shiftDatePickedItem = myDateFormat.string(from: shiftdate.date)
    }
}
extension ShiftRequestVC:UIPickerViewDelegate,UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return shiftTimeArr.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return shiftTimeArr[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        shiftTimePickedItem = "\(shiftTimeArr[row])"
    }
}
