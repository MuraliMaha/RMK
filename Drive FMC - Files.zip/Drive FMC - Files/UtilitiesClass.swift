//
//  UtilitiesClass.swift
//  WannaHelp
//
//  Created by Appsraise on 01/01/17.
//  Copyright © 2017 WannaHelp SoftTech Pvt Ltd. All rights reserved.
//

import UIKit
import CoreLocation
import GoogleMaps
import Alamofire

class UtilitiesClass: NSObject
{
    // MARK: - Customised AlertController and actions
    
    class func Alert(Title:NSString,Message:NSString,Actions:[UIAlertAction],Controller:UIViewController)
    {
        let Alert = UIAlertController.init(title: Title as String, message: Message == "" ? nil : Message as String, preferredStyle: UIAlertControllerStyle.alert)
        
        if Actions.count == 1
        {
            Alert.addAction(Actions[0])
        }
        else if Actions.count == 2
        {
            Alert.addAction(Actions[0])
            Alert.addAction(Actions[1])
        }
        
        Controller.present(Alert, animated: true, completion: nil)
        
    }
    class func AlertActionWithSelector(Title:NSString,Selector:Selector,Controller:UIViewController) -> UIAlertAction
    {
        let Action = UIAlertAction.init(title: Title as String, style: UIAlertActionStyle.default, handler: { (AlertAction:UIAlertAction) in
            
            Controller.perform(Selector)
            
        })
        return Action
    }
    
//    class func AlertActionWithSelectorArg(Title:String,Selector:Selector,Controller:UIViewController) -> UIAlertAction
//    {
//        let Action = UIAlertAction.init(title: Title as String, style: UIAlertActionStyle.default) { (AlertAction:UIAlertAction) in
//            Controller.perform(Selector)
//        })
//        return Action
//    }
    
    class func AlertActionWithOutSelector(Title:NSString) -> UIAlertAction
    {
        let Action = UIAlertAction.init(title: Title as String, style: UIAlertActionStyle.default, handler: nil)
        return Action
    }
    
}

func ShowLocationDenied(controller:UIViewController) {
    let Location = LocationAccessView.init(nibName: "LocationAccessView", bundle: Bundle.main)
    
    let transition = CATransition()
    transition.duration = 0.45
    transition.type = kCATransitionFade;
    transition.subtype = kCATransitionFromTop;
    
    Location.view.layer.add(transition, forKey: kCATransition)
    
    controller.present(Location, animated: true, completion: nil)
}

func fetchAddressFromLatLon(Lati:Double,Long:Double,_ Completion:@escaping ([String]?,String?) -> Void) {
    GMSGeocoder().reverseGeocodeCoordinate(CLLocationCoordinate2DMake(Lati, Long)) { (ReverseGeoCodeResponce, error) in
        if error == nil {
            let address = ReverseGeoCodeResponce?.results()?[0].lines
            Completion(address,nil)
        }
        else {
            Completion(nil,error?.localizedDescription)
        }
    }
}

struct NotificationStruct {
    static let LogOutNotif = NSNotification.Name(rawValue: "LogoutNotif")
    static let HelpDeskNotif = NSNotification.Name(rawValue: "HelpDeskNotif")
}

func FetchLoginDetails() -> LoginDetails! {
    
    if UserDefaults.standard.value(forKey: "LoginDetails") != nil {
        if let LoginDetailsDict:[String:String] = try! JSONSerialization.jsonObject(with: UserDefaults.standard.value(forKey: "LoginDetails") as! Data, options: JSONSerialization.ReadingOptions.allowFragments) as? [String:String] {
            var LoginObj = LoginDetails()
            LoginObj.UserID = LoginDetailsDict["EmpCode"]!
            LoginObj.EmpCode = LoginDetailsDict["EmpCode"]!
            LoginObj.Password = LoginDetailsDict["EmpPassword"]!
            LoginObj.DeviceType = LoginDetailsDict["DeviceType"]!
            LoginObj.DeviceIMEI = LoginDetailsDict["DeviceIMEI"]!
            LoginObj.DeviceToken = LoginDetailsDict["DeviceToken"]!
            return LoginObj
        }
        else {
            return nil
        }
    }
    else {
        return nil
    }
    
}
func SaveLoginDetails(LoginDetailsdict:[String:String]){
    let Defaults = UserDefaults.standard
    let data = try? JSONSerialization.data(withJSONObject: LoginDetailsdict, options: .prettyPrinted)
    Defaults.set(data, forKey: "LoginDetails")
    Defaults.synchronize()
}

func SaveLoginDetailsWithStruct(Struct:LoginDetails) {
    
    var SaveDict = [String:String]()
    SaveDict = ["EmpCode":"\(Struct.UserID!)",
                "EmpPassword":"\(Struct.Password!)",
                "DeviceType":"\(Struct.DeviceType!)",
                "DeviceIMEI":"\(Struct.DeviceIMEI!)",
                "DeviceToken":"\(Struct.DeviceToken!)",
                ]
    
    let Defaults = UserDefaults.standard
    let data = try? JSONSerialization.data(withJSONObject: SaveDict, options: .prettyPrinted)
    Defaults.set(data, forKey: "LoginDetails")
    Defaults.synchronize()
}

struct LoginDetails {
    var UserID:String!
    var EmpCode:String!
    var Password:String!
    var DeviceType:String!
    var DeviceIMEI:String!
    var DeviceToken:String!
}

func FetchLoginResponce() -> LoginResponce? {
    
    if UserDefaults.standard.value(forKey: "LoginResponce") != nil {
        
        if let ResponceDict:[String:AnyObject] = try! JSONSerialization.jsonObject(with:UserDefaults.standard.value(forKey: "LoginResponce") as! Data, options: JSONSerialization.ReadingOptions.allowFragments) as? [String:AnyObject] {
            
            var LoginObj = LoginResponce()
            LoginObj.BookingAppCorporateId = "\(ResponceDict["BookingAppCorporateId"]!)"
            LoginObj.BookingAppTyped = "\(ResponceDict["BookingAppTyped"]!)"
            LoginObj.BookingAppVendorid = "\(ResponceDict["BookingAppVendorid"]!)"
            LoginObj.CabAssignFlag = "\(ResponceDict["CabAssignFlag"]!)"
            LoginObj.CompanyName = "\(ResponceDict["CompanyName"]!)"
            LoginObj.DailyTripMasterId = "\(ResponceDict["DailyTripMasterId"]!)"
            LoginObj.DeviceIMEINo = "\(ResponceDict["DeviceIMEINo"]!)"
            LoginObj.DeviceTocken = "\(ResponceDict["DeviceTocken"]!)"
            LoginObj.DeviceType = "\(ResponceDict["DeviceType"]!)"
            LoginObj.Email = "\(ResponceDict["Email"]!)"
            LoginObj.Empcode = "\(ResponceDict["Empcode"]!)"
            LoginObj.Employeeid = "\(ResponceDict["Employeeid"]!)"
            LoginObj.ETAAssignNotificationTime = "\(ResponceDict["ETAAssignNotificationTime"]!)"
            LoginObj.ETAFlag = "\(ResponceDict["ETAFlag"]!)"
            LoginObj.HelpDeskno = "\(ResponceDict["HelpDeskno"]!)"
            LoginObj.ID = "\(ResponceDict["ID"]!)"
            LoginObj.Name = "\(ResponceDict["Name"]!)"
            LoginObj.PhoneNo = "\(ResponceDict["PhoneNo"]!)"
            LoginObj.ShiftFlag = "\(ResponceDict["ShiftFlag"]!)"
            LoginObj.ShiftNotificationTime = "\(ResponceDict["ShiftNotificationTime"]!)"
            LoginObj.ShiftType = "\(ResponceDict["ShiftType"]!)"
            LoginObj.ShowRateTrip = "\(ResponceDict["ShowRateTrip"]!)"
            if "\(ResponceDict["TripId"]!)" != nil {
                LoginObj.TripId = "\(ResponceDict["TripId"]!)"
            }else{
                LoginObj.TripId = "NA"
            }
            
            LoginObj.TripStartDate = "\(ResponceDict["TripStartDate"]!)"
            LoginObj.FacilityAddress = "\(ResponceDict["FacilityAddress"]!)"
            LoginObj.EmpAddress = "\(ResponceDict["EmpAddress"]!)"
            LoginObj.gender = "\(ResponceDict["gender"]!)"
            
           
//            if "\(ResponceDict["ShiftTime"]!)" != nil{
//           LoginObj.ShiftTime = "\(ResponceDict["ShiftTime"]!)"
//            }else{
//                LoginObj.ShiftTime = "NA"
//            }

            LoginObj.PickUpShiftTime = "\(ResponceDict["PickUpShiftTime"]!)"
            LoginObj.DropOffShiftTime = "\(ResponceDict["DropOffShiftTime"]!)"
            
             LoginObj.Pickuplocationstatus = "\(ResponceDict["Pickuplocationstatus"]!)"
//            if LoginObj.Pickuplocationstatus != nil{
//
//            }
//            else{
//                    LoginObj.Pickuplocationstatus = "NA"
//                }
            
            
            
            return LoginObj
        }
        else {
            
            return nil
        }
    }
    else {
        return nil
    }
}
func SaveLoginResponce(Responcedict:[String:AnyObject]){
    let Defaults = UserDefaults.standard
    let data = try? JSONSerialization.data(withJSONObject: Responcedict, options: .prettyPrinted)
    Defaults.set(data, forKey: "LoginResponce")
    Defaults.synchronize()
}
func SaveLoginResponceWithStruct(Struct:LoginResponce) {
    
    var SaveDict = [String:AnyObject]()
    SaveDict = ["BookingAppCorporateId":"\(Struct.BookingAppCorporateId!)" as AnyObject,
                "BookingAppTyped":"\(Struct.BookingAppTyped!)" as AnyObject,
                "BookingAppVendorid":"\(Struct.BookingAppVendorid!)" as AnyObject,
                "CabAssignFlag":"\(Struct.CabAssignFlag!)" as AnyObject,
                "CompanyName":"\(Struct.CompanyName!)" as AnyObject,
                "DailyTripMasterId":"\(Struct.DailyTripMasterId!)" as AnyObject,
                "DeviceIMEINo":"\(Struct.DeviceIMEINo!)" as AnyObject,
                "DeviceTocken":"\(Struct.DeviceTocken!)" as AnyObject,
                "DeviceType":"\(Struct.DeviceType!)" as AnyObject,
                "Email":"\(Struct.Email!)" as AnyObject,
                "Empcode":"\(Struct.Empcode!)" as AnyObject,
                "Employeeid":"\(Struct.Employeeid!)" as AnyObject,
                "ETAAssignNotificationTime":"\(Struct.ETAAssignNotificationTime!)" as AnyObject,
                "ETAFlag":"\(Struct.ETAFlag!)" as AnyObject,
                "HelpDeskno":"\(Struct.HelpDeskno!)" as AnyObject,
                "ID":"\(Struct.ID!)" as AnyObject,
                "Name":"\(Struct.Name!)" as AnyObject,
                "PhoneNo":"\(Struct.PhoneNo!)" as AnyObject,
                "ShiftFlag":"\(Struct.ShiftFlag!)" as AnyObject,
                "ShiftNotificationTime":"\(Struct.ShiftNotificationTime!)" as AnyObject,
                "ShiftType":"\(Struct.ShiftType!)" as AnyObject,
                "ShowRateTrip":"\(Struct.ShowRateTrip!)" as AnyObject,
                "TripId":"\(Struct.TripId!)" as AnyObject,
                "TripStartDate":"\(Struct.TripStartDate!)" as AnyObject,
                "FacilityAddress":"\(Struct.FacilityAddress)" as AnyObject,
                "EmpAddress":"\(Struct.EmpAddress)" as AnyObject]
    
    
    
    let Defaults = UserDefaults.standard
    let data = try? JSONSerialization.data(withJSONObject: SaveDict, options: .prettyPrinted)
    Defaults.set(data, forKey: "LoginResponce")
    Defaults.synchronize()
}

struct LoginResponce {
    var BookingAppCorporateId:String!
    var BookingAppTyped:String!
    var BookingAppVendorid:String!
    var CabAssignFlag:String!
    var CompanyName:String!
    var DailyTripMasterId:String!
    var DeviceIMEINo:String!
    var DeviceTocken:String!
    var DeviceType:String!
    var Email:String!
    var Empcode:String!
    var Employeeid:String!
    var ETAAssignNotificationTime:String!
    var ETAFlag:String!
    var HelpDeskno:String!
    var ID:String!
    var Name:String!
    var PhoneNo:String!
    var ShiftFlag:String!
    var ShiftNotificationTime:String!
    var ShiftType:String!
    var ShowRateTrip:String!
    var TripId:String!
    var TripStartDate:String!
    
    var FacilityAddress:String!
    var EmpAddress:String!
    
    var gender : String!
//    var ShiftTime : String!
    var PickUpShiftTime : String!
    var DropOffShiftTime : String!
    var Pickuplocationstatus : String!
}


extension WebService {
    
//    func callDriveBookingAPI(Suffix:String,parameterDict: [String:String], completion: @escaping ([String:AnyObject]?,Bool) -> ()) {
//        
//        var ParamsStr = "<ns1:\(Suffix)>"
//        
//        for (key,value) in parameterDict {
//            ParamsStr.append("<ns1:\(key)>\(value)</ns1:\(key)>")
//        }
//        
//        ParamsStr.append("</ns1:\(Suffix)>")
//        
//        
//        let soapMessage =  "<?xml version='1.0' encoding='UTF-8'?><SOAP-ENV:Envelope xmlns:SOAP-ENV='http://schemas.xmlsoap.org/soap/envelope/' xmlns:ns1='http://tempuri.org/'><SOAP-ENV:Body>\(ParamsStr)</SOAP-ENV:Body></SOAP-ENV:Envelope>"
//        
//        let soapLenth = String(soapMessage.characters.count)
//        let theUrlString = WebServicesUrl.DriveBookingBase
//        let theURL = URL(string: theUrlString)
//        let mutableR = NSMutableURLRequest(url: theURL!)
//        
//        mutableR.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
//        
//        mutableR.addValue(soapLenth, forHTTPHeaderField: "Content-Length")
//        mutableR.httpMethod = "POST"
//        mutableR.httpBody = soapMessage.data(using: String.Encoding.utf8)
//        
//        let manager = AFHTTPRequestOperation(request: mutableR as URLRequest)
//        
//        manager.setCompletionBlockWithSuccess({ (operation : AFHTTPRequestOperation, responseObject : Any) -> Void in
//            
//            let data = NSMutableData(data: responseObject as! Data)
//            
//            let str = NSString(bytes: data.mutableBytes, length: data.length, encoding: String.Encoding.utf8.rawValue)
//            
//            let arr = str?.components(separatedBy: "<")
//            let finStr = arr?[0]
//            
//            if let FinalData = finStr?.data(using: .utf8) {
//                if let JsonDict:[String:AnyObject] = try? JSONSerialization.jsonObject(with: FinalData, options: .allowFragments) as! [String:AnyObject] {
//                    completion(JsonDict,true)
//                }
//                else {
//                    completion(nil,false)
//                }
//            }
//            else {
//                completion(nil,false)
//            }
//            
//        }, failure: { (operation : AFHTTPRequestOperation, error : Error) -> Void in
//            
//            print(error, terminator: "")
//            
//            completion(nil,false)
//            
//        })
//        
//        manager.start()
//    
//    }
    
    
    //Used
    func callAutoAPI(Suffix:String,parameterDict: [String:String], completion: @escaping ([String:AnyObject]?,Bool) -> ()) {
        
        var ParamsStr = "<ns1:\(Suffix)>"
        
        for (key,value) in parameterDict {
            ParamsStr.append("<ns1:\(key)>\(value)</ns1:\(key)>")
        }
        
        ParamsStr.append("</ns1:\(Suffix)>")
    
        
        let soapMessage =  "<?xml version='1.0' encoding='UTF-8'?><SOAP-ENV:Envelope xmlns:SOAP-ENV='http://schemas.xmlsoap.org/soap/envelope/' xmlns:ns1='http://tempuri.org/'><SOAP-ENV:Body>\(ParamsStr)</SOAP-ENV:Body></SOAP-ENV:Envelope>"
        
        
        let soapLenth = String(soapMessage.characters.count)
        let theUrlString = WebServicesUrl.MainBaseUrl
        let theURL = URL(string: theUrlString)
        let mutableR = NSMutableURLRequest(url: theURL!)
        
        mutableR.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        
        mutableR.addValue(soapLenth, forHTTPHeaderField: "Content-Length")
        mutableR.httpMethod = "POST"
        mutableR.httpBody = soapMessage.data(using: String.Encoding.utf8)
        
        let manager = AFHTTPRequestOperation(request: mutableR as URLRequest)
        
        manager.setCompletionBlockWithSuccess({ (operation : AFHTTPRequestOperation, responseObject : Any) -> Void in
            
            let data = NSMutableData(data: responseObject as! Data)
            
            let str = NSString(bytes: data.mutableBytes, length: data.length, encoding: String.Encoding.utf8.rawValue)
            
            let arr = str?.components(separatedBy: "<")
            let finStr = arr?[0]
            
            if let FinalData = finStr?.data(using: .utf8) {
                if let JsonDict:[String:AnyObject] = try? JSONSerialization.jsonObject(with: FinalData, options: .allowFragments) as! [String:AnyObject] {
                    completion(JsonDict,true)
                }
                else {
                    completion(nil,false)
                }
            }
            else {
                completion(nil,false)
            }
            
        }, failure: { (operation : AFHTTPRequestOperation, error : Error) -> Void in
            
            print(error, terminator: "")
            
            completion(nil,false)

        })
        
        manager.start()
        
    }
    
    //Used in Tracking
    func callAutoAllAPI(Baseurl:String, Suffix:String,parameterDict: [String:String], completion: @escaping (AnyObject?,Bool) -> ()) {
        
        
        var parameters = ""
        for (key,value) in parameterDict {
            parameters.append(key + "=" + value + "&")
        }
        parameters.remove(at: parameters.index(parameters.endIndex, offsetBy: -1))
        
        let soapLenth = String(parameters.characters.count)
        let theUrlString = Baseurl
        let theURL = URL(string: theUrlString)
        let mutableR = NSMutableURLRequest(url: theURL!)
        
        // MUTABLE REQUEST
        
//        mutableR.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        
        mutableR.addValue("http://tempuri.org/", forHTTPHeaderField: "SOAPAction")
        mutableR.addValue(soapLenth, forHTTPHeaderField: "Content-Length")
        mutableR.httpMethod = "POST"
        mutableR.httpBody = parameters.data(using: String.Encoding.utf8)
        
        // AFNETWORKING REQUEST
        
        let manager = AFHTTPRequestOperation(request: mutableR as URLRequest)
        
        manager.setCompletionBlockWithSuccess({ (operation : AFHTTPRequestOperation, responseObject : Any) -> Void in
            
            let data = NSMutableData(data: responseObject as! Data)
            
            let str = NSString(bytes: data.mutableBytes, length: data.length, encoding: String.Encoding.utf8.rawValue)
            
            let Arr = str?.components(separatedBy: "<")
            
            let FilterdStr = UtilitiesClassSub.removeLeadingandTralingSpace(Arr?[0])
            
            completion(FilterdStr as AnyObject?,true)

        }, failure: { (operation : AFHTTPRequestOperation, error : Error) -> Void in
            
            print(error, terminator: "")
            
            completion(nil,false)
            
        })
        
        manager.start()
        
    }
    
    
    func callNotifAPI(Suffix:String,parameterDict: [String:String], completion: @escaping ([String:AnyObject]?,Bool) -> ()) {
        
        var ParamsStr = "<ns1:\(Suffix)>"
        
        for (key,value) in parameterDict {
            ParamsStr.append("<ns1:\(key)>\(value)</ns1:\(key)>")
        }
        
        ParamsStr.append("</ns1:\(Suffix)>")
        
        
        // MUTABLE REQUEST
        
        let soapMessage =  "<?xml version='1.0' encoding='UTF-8'?><SOAP-ENV:Envelope xmlns:SOAP-ENV='http://schemas.xmlsoap.org/soap/envelope/' xmlns:ns1='http://tempuri.org/'><SOAP-ENV:Body>\(ParamsStr)</SOAP-ENV:Body></SOAP-ENV:Envelope>"
        
        let soapLenth = String(soapMessage.characters.count)
        let theUrlString = WebServicesUrl.NotifUrl
        let theURL = URL(string: theUrlString)
        let mutableR = NSMutableURLRequest(url: theURL!)
        
        // MUTABLE REQUEST
        
        mutableR.addValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        
        mutableR.addValue(soapLenth, forHTTPHeaderField: "Content-Length")
        mutableR.addValue("http://tempuri.org/PushNotificationsWithTTL", forHTTPHeaderField: "SOAPAction")

        mutableR.httpMethod = "POST"
        mutableR.httpBody = soapMessage.data(using: String.Encoding.utf8)
        
        // AFNETWORKING REQUEST
        
        let manager = AFHTTPRequestOperation(request: mutableR as URLRequest)
        
        manager.setCompletionBlockWithSuccess({ (operation : AFHTTPRequestOperation, responseObject : Any) -> Void in
            
            let data = NSMutableData(data: responseObject as! Data)
            
            let str = NSString(bytes: data.mutableBytes, length: data.length, encoding: String.Encoding.utf8.rawValue)
            
            let arr = str?.components(separatedBy: "<")
            let finStr = arr?[0]
            
            if let FinalData = finStr?.data(using: .utf8) {
                if let JsonDict:[String:AnyObject] = try? JSONSerialization.jsonObject(with: FinalData, options: .allowFragments) as! [String:AnyObject] {
                    completion(JsonDict,true)
                }
                else {
                    completion(nil,false)
                }
            }
            else {
                completion(nil,false)
            }
            
        }, failure: { (operation : AFHTTPRequestOperation, error : Error) -> Void in
            
            print(error, terminator: "")
            
            completion(nil,false)
            
        })
        
        manager.start()
        
    }

    //MARK:- HTTP POST
    func HTTP_POST_WebServiceMethod(parameterDict : [String:String],completion:@escaping (_ Data:Any,_ IsSuccess:Bool) -> ())
    {
        
        //Part 1
        var parameters = ""
        for (key,value) in parameterDict {
            parameters.append(key + "=" + value + "&")
        }
        parameters.remove(at: parameters.index(parameters.endIndex, offsetBy: -1))
        let soapLenth = String(parameters.count)
        
        
        //Part 2
        let theUrlString = "https://developers.myoperator.co/clickOcall"
        let theURL = URL(string: theUrlString)
        
        //Part 3
        var mutableR = URLRequest.init(url: theURL!)
        mutableR.httpMethod = "POST"
        mutableR.allHTTPHeaderFields = ["Content-Type":"application/x-www-form-urlencoded","Content-Length":soapLenth]
        mutableR.httpBody = parameters.data(using: String.Encoding.utf8)
        
        
        //Part 4
        if !(Alamofire.NetworkReachabilityManager()?.isReachable)! {
            completion([:],false)
            return
        }
        
        mutableR.timeoutInterval = 35
        mutableR.allowsCellularAccess = true
        
        Alamofire.request(mutableR).responseJSON { (DataResponse) in
            
            switch DataResponse.result{
            case .success(let value):
                completion(value,true)
                break
            case .failure(let error):
                print("Error From AlamoFire - webServiceMethod - WebServiceClass :",error.localizedDescription)
                completion([:],false)
                break
            }
        }
    }
    

}

// MARK: - Distance Calculater

func getDistanceFromLatLonInKm(lat1:Double,lon1:Double,lat2:Double,lon2:Double) -> Double {
    let R = 6371.0
    let dLat = deg2rad(deg: lat2-lat1)
    let dLon = deg2rad(deg: lon2-lon1)
    let a =
        sin(dLat/2) * sin(dLat/2) +
            cos(deg2rad(deg: lat1)) * cos(deg2rad(deg: lat2)) *
            sin(dLon/2) * sin(dLon/2)
    ;
    let c = 2 * atan2(sqrt(a), sqrt(1-a))
    let d = R * c
    return d;
}

func deg2rad(deg:Double) -> Double {
    let Div = M_PI / 180
    
    return deg * Div
}

// MARK: - Drive Booking Credenticals {

class MainVender {
    static let VendorId = "1147"
    static let CorporateId = "1"
    static let AppCustomerType = "3"
}
