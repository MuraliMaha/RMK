//
//  Patym.swift
//  DriveBooking
//
//  Created by Amarnath B on 30/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit
import Alamofire

protocol PaytmSignInDelegate {
    func PaytmDidSignInComplete(controller:PaytmSignInVC)
    func PaytmDidSignInCancel(controller:PaytmSignInVC)
}
class PaytmSignInVC: UIViewController, UITextFieldDelegate {

    @IBOutlet var OTPView: UIView!
    @IBOutlet var OTPTxt: UITextField!
    
    @IBOutlet var MobileNumberTxt: UITextField!
    
    var Delegate: PaytmSignInDelegate!

    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!
    
    var PaytmState: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.LoginRequest = FetchDriveRequest()
        self.DriveBookingResponce = FetchDriveResponce()
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.black
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
        self.navigationItem.leftBarButtonItem = BackBtnItem
        
        MobileNumberTxt.text = self.DriveBookingResponce.PhoneNo!
        MobileNumberTxt.isEnabled = false
        
        PaytmState = nil
    }
    
    func BackAction() {
        Delegate.PaytmDidSignInCancel(controller: self)
    }
    //paytm request OTP API
    
    @IBAction func RequestOtpBtn(_ sender:UIButton) {
        
        self.view.endEditing(true)
        
        if (MobileNumberTxt.text?.isEmpty)! {
            self.view.ShowBlackTostWithText(message: "Please enter mobile number", Interval: 3)
            return
        }
        else if !(MobileNumberTxt.text?.isValidMobileNumber())! {
            self.view.ShowBlackTostWithText(message: "Please enter valid mobile number", Interval: 3)
            return
        }
        
        self.view.StartLoading()
    
        let postSTR = ["phone":"\(MobileNumberTxt.text!)","scope":"wallet","responseType":"token","clientId":PaytmCreds.clientID]
        let data =  try? JSONSerialization.data(withJSONObject: postSTR, options: .prettyPrinted)
        var Request = URLRequest.init(url: URL.init(string: "https://accounts.paytm.com/signin/otp")!)
        Request.httpMethod = "POST"
        Request.allHTTPHeaderFields = ["Content-Type":"application/json; charset=utf-8","Accept":"application/json"]
        Request.httpBody = data!
        Alamofire.request(Request)
            .responseJSON { (responce) in
                self.view.StopLoading()
                switch responce.result {
                case .success(let Value):
                    print(Value)
                    let data = Value as! [String:AnyObject]
                    if data.keys.contains("state") {
                        self.PaytmState = "\(data["state"]!)"
                        print(self.PaytmState)
                        self.ShowOtpView()
                    }else{
                        Message.shared.Alert(Title: "Alert", Message: "\(data["message"]!)", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                        self.PaytmState = nil
                    }
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    self.PaytmState = nil
                    break
                }
        }
    }
    
    // PAytm resend OTP API
    
    func Resend() {
        
        self.view.StartLoading()
        
        let postSTR = ["phone":"\(MobileNumberTxt.text!)","scope":"wallet","responseType":"token","clientId":PaytmCreds.clientID]
        let data =  try? JSONSerialization.data(withJSONObject: postSTR, options: .prettyPrinted)
        var Request = URLRequest.init(url: URL.init(string: "https://accounts.paytm.com/signin/otp")!)
        Request.httpMethod = "POST"
        Request.allHTTPHeaderFields = ["Content-Type":"application/json; charset=utf-8","Accept":"application/json"]
        Request.httpBody = data!
        Alamofire.request(Request)
            .responseJSON { (responce) in
                self.view.StopLoading()
                switch responce.result {
                case .success(let Value):
                    print(Value)
                    let data = Value as! [String:AnyObject]
                    if data.keys.contains("state") {
                        self.PaytmState = "\(data["state"]!)"
                        print(self.PaytmState)
                    }else{
                        Message.shared.Alert(Title: "Alert", Message: "\(data["message"]!)", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                        self.PaytmState = nil
                    }
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    self.PaytmState = nil
                    break
                }
                
        }
    }

    func CloseOtpView() {
        UIView.animate(withDuration: 0.3, animations: {
            self.OTPView.alpha = 0
        }) { (yes) in
            if yes {
                self.OTPView.alpha = 1
                self.OTPView.superview?.removeFromSuperview()
            }
        }
    }
    
    @IBAction func EditNumber(_ sender:UIButton) {
        MobileNumberTxt.isEnabled = true
        MobileNumberTxt.becomeFirstResponder()
    }
    
    func TapOTPReturn(_ responder:UITapGestureRecognizer) {
        let Point = responder.location(in: OTPView.superview!)
        let Frame = OTPView.frame
        
        if !Frame.contains(Point) {
            CloseOtpView()
        }
    }
    
    var ActualX:CGFloat = 0
    
    func ShowOtpView() {
        
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        
        BackView.center = (window?.center)!
        
        window?.addSubview(BackView)
        OTPView.center = BackView.center
        
        BackView.addSubview(OTPView!)
        
        OTPTxt.text = ""
        
        ActualX = OTPView.frame.origin.y
        
        let GuardianTap = UITapGestureRecognizer.init(target: self, action: #selector(TapOTPReturn(_:)))
        GuardianTap.numberOfTapsRequired = 1
        BackView.addGestureRecognizer(GuardianTap)
        
        OTPView.alpha = 0
        
        UIView.animate(withDuration: 0.5) {
            self.OTPView.alpha = 1
            self.OTPTxt.becomeFirstResponder()
        }
    }
        
    @IBAction func VeryfyOtp(_ sender:UIButton) {
        
        self.OTPView.endEditing(true)
        
        if (OTPTxt.text?.isEmpty)! {
            self.view.ShowBlackTostWithText(message: "Please enter OTP", Interval: 3)
            return
        }
        
        verifyOTP()
    }
    
    //Verify OTP API
    
    func verifyOTP(){
        
        if self.PaytmState == nil || self.PaytmState == "NA" || self.PaytmState == "" {
            self.view.ShowBlackTostWithText(message: Constants.InternalError + ".\nPlease press on resend", Interval: 3)
            return
        }
        
        UIApplication.shared.keyWindow?.StartLoading()
        
        let postSTR = ["otp":"\(OTPTxt.text!)","state":self.PaytmState!]
        let data =  try? JSONSerialization.data(withJSONObject: postSTR, options: .prettyPrinted)
        var Request = URLRequest.init(url: URL.init(string: "https://accounts.paytm.com/signin/validate/otp")!)
        Request.httpMethod = "POST"
        Request.allHTTPHeaderFields = ["Authorization":PaytmCreds.ClintAuth,"Content-Type":"application/json; charset=utf-8","Accept":"application/json"]
        Request.httpBody = data!
        Alamofire.request(Request)
            .responseJSON { (responce) in
                
                UIApplication.shared.keyWindow?.StopLoading()
                
                switch responce.result {
                case .success(let Value):
                    print(Value)
                    
                    /*
                     {
                     "access_token" = "12072352-1e16-4c74-afbd-b6f43c5afbd3";
                     expires = 1498906898277;
                     resourceOwnerId = 10652306;
                     scope = wallet;
                     }
                     */
                    
                    let data = Value as! [String:AnyObject]
                    if (data.keys.contains("access_token")){
                        let Date = "\(data["expires"]!)".DateFromTimeStamp()
                        let Token = "\(data["access_token"]!)"
                        
                        self.DriveBookingResponce.PaytmWalletNo = self.MobileNumberTxt.text!
                        self.DriveBookingResponce.SSOToken = Token
                        self.DriveBookingResponce.ExpiryTime = Date
                        self.DriveBookingResponce.DefaultPaymentMode = "PAYTM"
                        saveDriveResponceStuct(driveStruct: self.DriveBookingResponce!)
                        
                        
                        UpdatePaymentModes(WalletType_Paytm_MobiKwik: "Paytm", MobileNo: self.DriveBookingResponce.PaytmWalletNo!, Token: Token, ExpData_oMobi_Paytmdate: Date, CompletionAuthError: { (isauth) in
                            if isauth {
//                                authenticationCheck(controller: self)
                            }
                        })
                        self.CloseOtpView()
                        self.Delegate.PaytmDidSignInComplete(controller: self)
                    }
                    else{
                        Message.shared.Alert(Title: "Alert", Message: "\(data["message"]!)", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    break
                }
                
        }
        
    }
    
    @IBAction func ResendOtp(_ sender:UIButton) {
        self.OTPView.endEditing(true)
        self.Resend()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardHide(_:)), name: .UIKeyboardWillHide, object: nil)
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func keyboardShow(_ notification : NSNotification){
        
        if MobileNumberTxt.isFirstResponder {
            
            let info = notification.userInfo
            let keyboardframe = (info![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size
            var frame = CGRect.init()
            
            frame = MobileNumberTxt.frame
            frame.origin.y += (MobileNumberTxt.superview?.frame.origin.y)!
            frame.origin.y += 64
            
            var actualframe = self.view.frame
            actualframe.size.height -= keyboardframe.height
            actualframe.size.height -= (frame.size.height)
            
            if !actualframe.contains(frame.origin) {
                let yfinal = frame.origin.y - actualframe.size.height
                
                UIView.animate(withDuration: 0.3, animations: { () -> Void in
                    self.view.frame.origin.y -= yfinal
                })
            }
        }
        else if OTPTxt.isFirstResponder {
            
            let info = notification.userInfo
            let keyboardframe = (info![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size
            var frame = CGRect.init()
            
            frame.origin.y += (OTPTxt.superview?.frame.origin.y)!
            
            var actualframe = (UIApplication.shared.keyWindow?.frame)!
            actualframe.size.height -= keyboardframe.height
            actualframe.size.height -= (frame.size.height)
            
            if !actualframe.contains(frame.origin) {
                let yfinal = frame.origin.y - actualframe.size.height
                
                UIView.animate(withDuration: 0.3, animations: { () -> Void in
                    self.OTPView.frame.origin.y -= yfinal
                })
                
            }
        }
        
    }
    // MARK: - keyboard hide
    
    func keyboardHide(_ notification : NSNotification)
    {
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.view.frame.origin.y = +64
            self.OTPView.frame.origin.y = self.ActualX
        })
    }
}
