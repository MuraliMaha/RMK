//
//  SplashScreenVC22.swift
//  DriveFindMyCab
//
//  Created by SunTelematics on 02/05/18.
//  Copyright © 2018 Suntelematics. All rights reserved.
//

import UIKit
import OneSignal
import FirebaseInstanceID

class SplashScreenVC22: UIViewController {

    @IBOutlet var Version:UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        DispatchQueue.main.async {
            self.Version.text = "V " + "\(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString")!)"
        }
        
        Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(Call), userInfo: nil, repeats: false)
        
    }

    func Call() {
        
        if !(Reachability()!.isReachable) {
            
            UtilitiesClass.Alert(Title: "Alert!", Message: Constants.NetErrorMsg as NSString, Actions: [UtilitiesClass.AlertActionWithSelector(Title: "Ok", Selector: #selector(QuitApp), Controller: self)], Controller: self)
            
        }
        else {
            
            guard FetchLoginResponce() != nil  else {
                GoToLoginOrSignup()
                return
            }
            
            CallService()
        }
        
    }
    func GoToLoginOrSignup() {
        
         let LoginObj = self.storyboard?.instantiateViewController(withIdentifier: "LoginOrSignupVC22SBID") as! LoginOrSignupVC22
        
//        let ctrl : UINavigationController = self.navigationController!
        
        
        let navCtrl1 = self.storyboard?.instantiateViewController(withIdentifier: "NavigationCtrl1SBID")
//        navCtrl1?.present(LoginObj, animated: true, completion: nil)
        
        self.present(navCtrl1!, animated: true, completion: nil)
       
        
    }
    
    func QuitApp() {
        exit(0)
    }
    
    var LoginDetails:LoginDetails!
    
    
    func CallService() {
        
        if let LoginDetal = FetchLoginDetails() {
            
            LoginDetails = LoginDetal
            self.view.StartLoading()
            
//            var OneSignalID = ""
//            let State = OneSignal.getPermissionSubscriptionState()
//            if State?.permissionStatus.status == .authorized {
//                
//                if State?.subscriptionStatus.userId != nil {
//                    OneSignalID = "\((State?.subscriptionStatus.userId!)!)"
//                    LoginDetails.DeviceToken = OneSignalID
//                    print("OnesignalID::::",OneSignalID)
//                }
//                
//            }
//            
//            let RequestDict = ["EmpCode":LoginDetal.UserID!,"EmpPassword":LoginDetal.Password!,"DeviceType":LoginDetal.DeviceType!,"DeviceIMEI":LoginDetal.DeviceIMEI!,"DeviceToken":"\(OneSignalID)"]
            
            let fcmDeviceToken :String = InstanceID.instanceID().token()!
            print("FCM token: \(fcmDeviceToken)")
            
            let RequestDict = ["EmpCode":LoginDetal.UserID!,"EmpPassword":LoginDetal.Password!,"DeviceType":LoginDetal.DeviceType!,"DeviceIMEI":LoginDetal.DeviceIMEI!,"DeviceToken":fcmDeviceToken]
            
            print("Login Input = ",RequestDict)
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.LoginApi, parameterDict: RequestDict, completion: { (dataDict, success) in
                
                self.view.StopLoading()
                print("Login Response from Splash = ",dataDict)
                if success {
                    // handel of data
                    if let Dict = dataDict {
                        let Arr = Dict["data"] as! [[String:AnyObject]]
                        let ResponceData = Arr[0]
                        print(Arr);
                        
                        if ResponceData.keys.contains("Response") {
                            self.GoToLoginOrSignup()
                        }
                        else {
                            
                            SaveLoginDetailsWithStruct(Struct: self.LoginDetails)
                            SaveLoginResponce(Responcedict: ResponceData)
                            
                            let lgCtrl = self.storyboard?.instantiateViewController(withIdentifier: "LGSideMenuControllerSBID22")
                            self.present(lgCtrl!, animated: true, completion: nil)
                        }
                    }
                    else {
                        Message.shared.Alert(Title: "", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithSelector(Title: "quit", Selector: #selector(self.QuitApp), Controller: self),Message.AlertActionWithSelector(Title: "retry", Selector: #selector(self.CallService), Controller: self)], Controller: self)
                    }
                }
                else {
                    Message.shared.Alert(Title: "", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithSelector(Title: "quit", Selector: #selector(self.QuitApp), Controller: self),Message.AlertActionWithSelector(Title: "retry", Selector: #selector(self.CallService), Controller: self)], Controller: self)
                }
            })
        }
        else {
            
            self.GoToLoginOrSignup()
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
