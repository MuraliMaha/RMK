

import UIKit

struct MobiCreds {
    static let MID = "MBK07719"
    static let Secret = "57xIuUq2UaXEDlrW7Dal9WPGpqDF"
    static let MerchentName = "Suntelematics"
    static let RegenrationSecurity = "sub8uUq2UasydDldW6ap9WPuhyDo"
    static let BaseUrl = "https://walletapi.mobikwik.com"
    static let MaxAmount = "20000"
    static let RedirectUrl = "https://www.aamchidrivebooking.in/MobiKwikPage/MKresponse.aspx"
    static let CheckUSer = "querywallet"


    static let OtpGeneration = "otpgenerate"
    static let Tokengenerate = "tokengenerate"
    static let Tokenregenerate = "tokenregenerate"


    static let userbalance = "userbalance"
    static let addmoneytowallet = "addmoneytowallet"
    static let createwalletuser = "createwalletuser"


    static let debitwallet = "debitwallet"
}

func SaveMobiKwikBalance(token:String) {
    let Defaults = UserDefaults.standard
    Defaults.set("\(token)", forKey: "MobiBalance")
    Defaults.synchronize()
}

func FetchMobiKwikBalance() -> String {
    if UserDefaults.standard.value(forKey: "MobiBalance") != nil {
        let Token = UserDefaults.standard.value(forKey: "MobiBalance")! as! String
        return Token
    }
    else {
        return "NA"
    }
}

func SavePaytmBalance(token:String) {
    let Defaults = UserDefaults.standard
    Defaults.set("\(token)", forKey: "PaytmBalance")
    Defaults.synchronize()
}

func FetchPaytmBalance() -> String {
    if UserDefaults.standard.value(forKey: "PaytmBalance") != nil {
        let Token = UserDefaults.standard.value(forKey: "PaytmBalance")! as! String
        return Token
    }
    else {
        return "NA"
    }
}

struct PaytmCreds {
    static let clientID = "merchant-sun-telematics"
    static let clientSecret = "25bc0953-6633-4ae1-9b93-05cbd776c4e3"
    static let ClintAuth:String = {
        let Str = clientID + ":" + clientSecret
        let ClintData = Str.data(using: .utf8)
        return "Basic " + (ClintData?.base64EncodedString(options: Data.Base64EncodingOptions(rawValue: 0)))!
    }()
    static let ClintMID = "SunTel56065179998240"
    static let WEBSITE = "SunTelWEB"
}

func Parser(dict:[String:String]) -> String {
    var soapMessage = ""
    
    for (key,value) in dict {
        soapMessage.append("\(key)=\(value)&")
    }
    if soapMessage != "" {
        soapMessage = soapMessage.substring(to: soapMessage.index(soapMessage.endIndex, offsetBy: -1))
    }
    return soapMessage
}

//HMAC Algorithm
enum HMACAlgorithm {
    case MD5, SHA1, SHA224, SHA256, SHA384, SHA512
    
    func toCCHmacAlgorithm() -> CCHmacAlgorithm {
        var result: Int = 0
        switch self {
        case .MD5:
            result = kCCHmacAlgMD5
        case .SHA1:
            result = kCCHmacAlgSHA1
        case .SHA224:
            result = kCCHmacAlgSHA224
        case .SHA256:
            result = kCCHmacAlgSHA256
        case .SHA384:
            result = kCCHmacAlgSHA384
        case .SHA512:
            result = kCCHmacAlgSHA512
        }
        return CCHmacAlgorithm(result)
    }
    
    func digestLength() -> Int {
        var result: CInt = 0
        switch self {
        case .MD5:
            result = CC_MD5_DIGEST_LENGTH
        case .SHA1:
            result = CC_SHA1_DIGEST_LENGTH
        case .SHA224:
            result = CC_SHA224_DIGEST_LENGTH
        case .SHA256:
            result = CC_SHA256_DIGEST_LENGTH
        case .SHA384:
            result = CC_SHA384_DIGEST_LENGTH
        case .SHA512:
            result = CC_SHA512_DIGEST_LENGTH
        }
        return Int(result)
    }
}

extension String {
    //converting to SHA256 encrypted algorithm
    
    func hmac(algorithm: HMACAlgorithm, key: String) -> String {
        let cKey = key.cString(using: String.Encoding.utf8)
        let cData = self.cString(using: String.Encoding.utf8)
        var result = [CUnsignedChar](repeating: 0, count: Int(algorithm.digestLength()))
        let length : Int = Int(strlen(cKey!))
        let data : Int = Int(strlen(cData!))
        CCHmac(algorithm.toCCHmacAlgorithm(), cKey!,length , cData!, data, &result)
        
        let hmacData:NSData = NSData(bytes: result, length: (Int(algorithm.digestLength())))
        
        var bytes = [UInt8](repeating: 0, count: hmacData.length)
        hmacData.getBytes(&bytes, length: hmacData.length)
        
        var hexString = ""
        for byte in bytes {
            hexString += String(format:"%02x", UInt8(byte))
        }
        
        return hexString
    }
}


//update payment details to backend using this API

func UpdatePaymentModes(WalletType_Paytm_MobiKwik:String,MobileNo:String,Token:String,ExpData_oMobi_Paytmdate:String, CompletionAuthError:@escaping (Bool) -> ()) {
    var Drive = FetchDriveResponce()!
    let Dict = ["EmpId": Drive.EmpId!,
        "Mobileno":MobileNo,
        "SSOToken":Token,
        "ExpiryDate":ExpData_oMobi_Paytmdate,
        "WalletType":WalletType_Paytm_MobiKwik,
        "Status":Token == "NA" || Token == "" ? "1" : "0"]
    WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveWalletAccessDetails, parameterDict: Dict, securityKey: Drive.AuthenticationToken!) { (responce, responceCode, success) in
        if !success {
            if responceCode == .authError {
                CompletionAuthError(true)
            }
            else {
                CompletionAuthError(false)
            }
        }
        else {
            if WalletType_Paytm_MobiKwik == "Paytm" {
                if Token == "NA" || Token == "" {
                    Drive.PaytmWalletNo = "NA"
                    Drive.SSOToken = "NA"
                    Drive.ExpiryTime = "NA"
                    Drive.TokenValidity = "NA"
                    saveDriveResponceStuct(driveStruct: Drive)
                }
            }
            else if WalletType_Paytm_MobiKwik == "MobiKwik" {
                if Token == "NA" || Token == "" {
                    Drive.WalletToken = "NA"
                    Drive.WalletMobileNo = "NA"
                    saveDriveResponceStuct(driveStruct: Drive)
                }
            }
            CompletionAuthError(false)
        }
    }
}
