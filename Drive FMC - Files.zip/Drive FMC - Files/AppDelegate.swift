//
//  AppDelegate.swift
//  DriveFindMyCab
//
//  Created by Admin on 31/03/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit
import OneSignal
import UserNotifications
import GoogleMaps
import AlamofireImage
import Firebase
import UserNotifications
import FirebaseInstanceID
import FirebaseMessaging

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    
    let gcmMessageIDKey = "gcm.message_id"
    let aps = "aps"
    let customMsg = "message"
    
    var navController:UINavigationController!
    

    
    //MARK : App Update
    
    func checkForUpdate(){
        do {
            let update = try self.isUpdateAvailable()
            print("update value = \(update)")
            if update{
                let alertCtrl = UIAlertController(title: "Update", message: "There is an update available.\n Please update to use this App!", preferredStyle: .alert)
                let alertAct = UIAlertAction(title: "Update", style: .destructive, handler: { (UIAlertAction) in
                    print("Ok tapped to update")
                    
                    let appStoreDriveFMCURL = URL(string: "https://itunes.apple.com/us/app/drive-findmycab/id1227747309?ls=1&mt=8")
                    UIApplication.shared.openURL(appStoreDriveFMCURL!)
                    
                })
                let alertCancel = UIAlertAction(title: "Cancel", style: .destructive, handler: { (UIAlertAction) in
                    print("update cancel tapped")
                })
                alertCtrl.addAction(alertCancel)
                alertCtrl.addAction(alertAct)
                
                
                let alertWindow = UIWindow(frame: UIScreen.main.bounds)
                alertWindow.rootViewController = UIViewController()
                alertWindow.windowLevel = UIWindowLevelAlert + 1
                alertWindow.makeKeyAndVisible()
                alertWindow.rootViewController?.present(alertCtrl, animated: true, completion: { _ in })
            }
            
            
        } catch {
            print("error from UpdateApp=\(error)")
        }
        
        
    }
    func isUpdateAvailable() throws -> Bool {
        
        print("isUpdateAvail entered")
        guard let info = Bundle.main.infoDictionary,
            let currentVersion = info["CFBundleShortVersionString"] as? String,
            let identifier = info["CFBundleIdentifier"] as? String,
            let url = URL(string: "http://itunes.apple.com/lookup?bundleId=\(identifier)") else {
                throw VersionError.invalidBundleInfo
        }
        let data = try Data(contentsOf: url)
        guard let json = try JSONSerialization.jsonObject(with: data, options: [.allowFragments]) as? [String: Any] else {
            throw VersionError.invalidResponse
        }
        if let result = (json["results"] as? [Any])?.first as? [String: Any], let version = result["version"] as? String {
            //            print("Mobile Version = \(currentVersion) \n App Store Version = \(version)")
            
            
            //            var doubleValue : Double = NSString(string: str).doubleValue
            
            let mobileVersion : Double = NSString(string: currentVersion).doubleValue
            let appStoreVersion : Double = NSString(string : version).doubleValue
            
            print("Mobile Version = \(mobileVersion) \n App Store Version = \(appStoreVersion)")
            
            return(mobileVersion < appStoreVersion)
            //            return ((Float("\(currentVersion)")!) < (Float("\(version)")!))
            
        }
        throw VersionError.invalidResponse
    }
    enum VersionError: Error {
        case invalidResponse, invalidBundleInfo
    }
    
    
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization afacter application launch.
        
        /*
        if (Reachability()?.isReachable)!{
            checkForUpdate()
        } */
        
            if #available(iOS 10.0, *) {
                // For iOS 10 display notification (sent via APNS)
                UNUserNotificationCenter.current().delegate = self
                
                let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
                UNUserNotificationCenter.current().requestAuthorization(
                    options: authOptions,
                    completionHandler: {_, _ in })
                // For iOS 10 data message (sent via FCM
                //            Messaging.messaging().remoteMessageDelegate = self
                Messaging.messaging().delegate = self
            } else {
                let settings: UIUserNotificationSettings =
                    UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: nil)
                application.registerUserNotificationSettings(settings)
            }
            
            application.registerForRemoteNotifications()
            
            FirebaseApp.configure()
            
            GMSServices.provideAPIKey(GOOGLEKeys.MainKey)
        
    
        return true
    }

    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String) {
        let token = Messaging.messaging().fcmToken
        print("FCM token: \(token ?? "")")
    }
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data)
    {
        var token: String = ""
        for i in 0..<deviceToken.count{
            token += String(format: "%02.2hhx", deviceToken[i] as CVarArg)
        }
        print("Device Token...\(token)")
    }
    
    //This method is not calling
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable: Any],
                     fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
       
        print("Inside didReceiveRemoteNotification.....")
        
    }
    
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        
        if CLLocationManager.authorizationStatus() == .authorizedWhenInUse || CLLocationManager.authorizationStatus() == .authorizedAlways {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "LocationDenied"), object: nil)
        }
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
        
        let imageDownloader = UIImageView.af_sharedImageDownloader
        imageDownloader.imageCache?.removeAllImages()
    }

    
    // MARK: - HandlePayload {
    var notificationTypeFlag : String!
    func ShowPayLoad(with Body:String?) {
        
        guard FetchLoginResponce() != nil  else {
            
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Please Login", Interval: 4)
            
            return
        }
        
        if Body != nil {
            
            if (Body?.contains("Are You Reached Home?"))!
            {
                notificationTypeFlag = "safehome"
                
                if let infoView = UIView.viewFromNibName(name: "SafeHomePopView") as? SafeHomePopView {
                    
                    let LoginResponce = FetchLoginResponce()
                    
                    // Previous Code
//                    let TripSubArr = Body?.components(separatedBy: "~")
//                    let tripID = (TripSubArr?[1])!
                    
                    let TripSubArr = Body?.components(separatedBy: "|")
                    let tripID = (TripSubArr?[2])!
                    
                    infoView.restorationIdentifier = "\(tripID)"
                    
                    infoView.BodyText.text = "\((LoginResponce?.Name!)!)" + ", Are You Reached Home?"
                    
                    infoView.OkBtn.addTarget(self, action: #selector(OkBtnAction), for: .touchUpInside)
                    
                    let MainWindow = UIApplication.shared.keyWindow
                    let View = UIView.init(frame:(MainWindow?.frame)!)
                    View.backgroundColor = UIColor.black.withAlphaComponent(0.8)
                    View.clipsToBounds = true
                    
                    View.center = (MainWindow?.center)!
                    
                    MainWindow?.addSubview(View)
                    
                    let height = (MainWindow?.frame.width)! * 0.7
                    
                    infoView.frame.size.height = height
                    
                    infoView.center = View.center
                    
                    View.addSubview(infoView)
                    
                    View.alpha = 0
                    UIView.animate(withDuration: 0.4) {
                        View.alpha = 1
                    }
                    
                }
            }else if (Body?.contains("SUNEMPVERIFY"))!{
//                $SUNEMPVERIFY|Janani_P201806061130003086957|1745|0|d696fb64-8ee0-4ad2-8693-22f1c0a81ddd|
                
                
//                if let infoView = UIView.viewFromNibName(name: "SafeHomePopView") as? SafeHomePopView {
                if let infoView = UIView.viewFromNibName(name: "LoginLogoutPopView") as? LoginLogoutPopView {
                    let TripSubArr = Body?.components(separatedBy: "|")
                    let status = (TripSubArr?[3])!
                    let tripID = (TripSubArr?[1])!
                    
                    if status == "0" {
                        notificationTypeFlag = "login"
                        infoView.bodyTextLbl.text =  "Are you sure to Login?"
                        infoView.restorationIdentifier = "\(tripID)"
                    }else{
                        notificationTypeFlag = "logout"
                        infoView.bodyTextLbl.text =  "Are you sure to Logout?"
                        infoView.restorationIdentifier = "\(tripID)"
                    }
                    
                    infoView.okBtn.addTarget(self, action: #selector(OkBtnAction), for: .touchUpInside)
                    infoView.cancelBtn.addTarget(self, action: #selector(cancelBtnAction), for: .touchUpInside)
                    
                    let MainWindow = UIApplication.shared.keyWindow
                    let View = UIView.init(frame:(MainWindow?.frame)!)
                    View.backgroundColor = UIColor.black.withAlphaComponent(0.8)
                    View.clipsToBounds = true
                    
                    View.center = (MainWindow?.center)!
                    
                    MainWindow?.addSubview(View)
                    
                    let height = (MainWindow?.frame.width)! * 0.7
                    
                    infoView.frame.size.height = height
                    
                    infoView.center = View.center
                    
                    View.addSubview(infoView)
                    
                    View.alpha = 0
                    UIView.animate(withDuration: 0.4) {
                        View.alpha = 1
                    }
                }
            }
            else {
                
                if let infoView = UIView.viewFromNibName(name: "NotificationView") as? NotificationView {
                    infoView.BodyText.text = Body!
                    
                    let MainWindow = UIApplication.shared.keyWindow
                    let View = UIView.init(frame:(MainWindow?.frame)!)
                    View.backgroundColor = UIColor.black.withAlphaComponent(0.8)
                    View.clipsToBounds = true
                    
                    View.center = (MainWindow?.center)!
                    
                    MainWindow?.addSubview(View)
                    
                    let Width = (MainWindow?.frame.width)! * 0.8
                    
                    infoView.frame.size.width = Width
                    
                    infoView.center = View.center
                    
                    View.addSubview(infoView)
                    
                    View.alpha = 0
                    UIView.animate(withDuration: 0.4) {
                        View.alpha = 1
                    }
                    
                }
                
            }
            
        }
        
    }
    func cancelBtnAction(_ sender:UIButton){
        UIView.animate(withDuration: 0.3, animations: {
            sender.superview?.alpha = 0
        })
        { (yes) in
            if yes {
                sender.superview?.alpha = 1
                sender.superview?.superview?.removeFromSuperview()
            }
        }
    }
    func OkBtnAction(_ sender:UIButton) {
        UIView.animate(withDuration: 0.3, animations: {
            sender.superview?.alpha = 0
        })
        { (yes) in
            if yes {
                sender.superview?.alpha = 1
                sender.superview?.superview?.removeFromSuperview()
                
                
                
                let tripID = "\((sender.superview?.restorationIdentifier!)!)"
                
                let StoryBoard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
                if  self.notificationTypeFlag == "login"{
                    self.SendNotifToDriverNew(tripID: tripID)
                }else if self.notificationTypeFlag == "logout" {
                    self.SendNotifToDriverNew(tripID: tripID)
                    self.navController.popToRootViewController(animated: true)
                }else{
                    let SafeHome = StoryBoard.instantiateViewController(withIdentifier: "SafeHomeVC") as! SafeHomeVC
                    SafeHome.TripID = tripID
                    self.navController.pushViewController(SafeHome, animated: true)
                }
            }
        }
    }
    
    func SendNotifToDriverNew(tripID : String){
        print("Control inside SendNotifToDriverNew of AppDel")
        
        let LoginDetails = FetchLoginDetails()
        let LoginResponce = FetchLoginResponce()
        
        
        let SoapDict = ["EmpCode": (LoginDetails?.EmpCode!)!,"EmpId":(LoginResponce?.ID!)!,"TripCode":tripID]
        
        print("Input for SendNotifToDriverNew from App Del  =",SoapDict)
        
        if (Reachability()?.isReachable)! {
            
//            self.view.StartLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.EmpAuthenticationNotification, parameterDict: SoapDict, completion: { (dataDict, success) in
                
//                self.view.StopLoading()
                
                if success {
                    // handel of data
                    if let Dict = dataDict {
                        let Arr = Dict["data"] as! [[String:AnyObject]]
                        let ResponceData = Arr[0]
                        
                        if "\(ResponceData["status"]!)" == "true"{

                            print("SendNotifToDriverNew success.. from appdel of login/logout notification")
                        } else {

                            print("SendNotifToDriverNew fails (may be trip code is not valid one).. from appdel of login/logout notification")
                        }
                    }
                    else {

                        print("internal error of SendNotifToDriverNew from appdel of login/logout notification")
                    }
                }
                else {

                    print("Something went wrong of SendNotifToDriverNew from appdel of login/logout notification")
                }
            })
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "No Active internet connection available", Interval: 3)
        }
    }
    // MARK: - }

}

// [START ios_10_message_handling]
@available(iOS 10, *)
extension AppDelegate : UNUserNotificationCenterDelegate {
    
    // Receive displayed notifications for iOS 10 devices.
    //    func userNotificationCenter(_ center: UNUserNotificationCenter,
    //                                willPresent notification: UNNotification,
    //                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
    //        let userInfo = notification.request.content.userInfo
    //
    //        // With swizzling disabled you must let Messaging know about the message, for Analytics
    //        // Messaging.messaging().appDidReceiveMessage(userInfo)
    //        // Print message ID.
    //        if let messageID = userInfo[gcmMessageIDKey] {
    //            print("Message ID: \(messageID)")
    //        }
    //
    //        // Print full message.
    //        print("from willPresent notification : ",userInfo)
    //
    //        // Change this to your preferred presentation option
    //        completionHandler([])
    //
    //    }
    
    
    // Firebase notification received
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter,  willPresent notification: UNNotification, withCompletionHandler   completionHandler: @escaping (_ options:   UNNotificationPresentationOptions) -> Void) {
        
        // custom code to handle push while app is in the foreground
        // When app is in foreground,and if a notification comes,control will come here
            print("Handle push from foreground, received: \n \(notification.request.content)")
     


            let notificationBody = notification.request.content.body
            print("body msg from willPresent = ",notificationBody)
        
        
        let userInfo = notification.request.content.userInfo
//        let customMessage : String! = userInfo[customMsg] as! String
        
        if let customMessage = userInfo[customMsg] {
            if "\(customMessage)" != "NA" {
                print("Custom msg = \(customMessage)")
                
                let range = "\(customMessage)".range(of: "$", options:.caseInsensitive)
                if let range = range {
                    print("Notification starts with $");
                    self.ShowPayLoad(with: "\(customMessage)")
                }else{
                    print("Notification doesnt starts with $")
//                    self.ShowPayLoad(with: "\(customMessage)")
                    completionHandler([.alert, .badge, .sound])
//                    completionHandler()
                    
                }

//                self.ShowPayLoad(with: "\(customMessage)")



            }
            else{
                print("No Custom Message/NA in custom msg")
                completionHandler([.alert, .badge, .sound])
            }
        }else{
            //Control comes here only if there is no data meassage(ie.body msg from willPresent)
            self.ShowPayLoad(with: "\(notificationBody)")
        }
        
        
        
        
        
//        if we want notification to display in our custom view, call ShowPayLoad
//            self.ShowPayLoad(with: notificationBody)

//        if we want notification to display on top of the device, call completionHandler
//            completionHandler([.alert, .badge, .sound])

//        below if else is for showing  custom notication message
//        if let cusStr = notification.request.content.userInfo[customMsg] as? String {
//            //            self.ShowPayLoad(with: "\(notification.request.content.userInfo[customMsg]!)")
//            self.ShowPayLoad(with:cusStr)
//        }else{
//            print("Something is nil.....")
//        }

    }
    
    
    //When, app is in background and notification is on the top of the device,and when user taps on the notification,control will come here
    func userNotificationCenter(_ center: UNUserNotificationCenter,didReceive response: UNNotificationResponse,withCompletionHandler completionHandler: @escaping () -> Void) {
        
        
        let notificationMsg = response.notification.request.content.body
        print("Notification Msg = ",notificationMsg)
        
        
        let userInfo = response.notification.request.content.userInfo
        // Print message ID.
        if let messageID = userInfo[gcmMessageIDKey] {
            print("Message ID: \(messageID)")
        }
        
        
//        if let customMessage : String = userInfo[customMsg] as? String  {
//            print("Custom msg = \(customMessage)")
//
//            let range = customMessage.range(of: "$safe", options:.caseInsensitive)
//            if let range = range {
//                print("Notification starts with $safe");
//                self.ShowPayLoad(with: "\(customMessage)")
//            }
//
//        }

        
        
//        if customMessage.count > 0 {
//            print("Custom msg = \(customMessage)")
//
//            let range = customMessage.range(of: "$", options:.caseInsensitive)
//            if let range = range {
//                print("Notification starts with $");
//                self.ShowPayLoad(with: "\(customMessage)")
//            }
//        }
//        else{
//            print("No Custom Message in Notification")
//        }
        
        
        
        
        if let customMessage = userInfo[customMsg] {
            if "\(customMessage)" != "NA" {
                print("Custom msg = \(customMessage)")
                
                let range = "\(customMessage)".range(of: "$", options:.caseInsensitive)
                if let range = range {
                    print("Notification starts with $");
                    self.ShowPayLoad(with: "\(customMessage)")
                }else{
                    print("Notification doesnt starts with $")
                    self.ShowPayLoad(with: "\(customMessage)")

                }
            }
            else{
                print("No Custom Message in Notification")
//                completionHandler([.alert, .badge, .sound])
//                completionHandler() //this line not needed as the notification already came and this function called only on tapping the notification.
            }
        }else{
            //This appears when "someone already logged in " notification comes
            self.ShowPayLoad(with: "\(notificationMsg)")
        }
        
        
        
        
        
        // Print full message.
//        print("userInfo from didReceive....",userInfo)
        
//        completionHandler()
        
    }
    
}
// [END ios_10_message_handling]

extension AppDelegate : MessagingDelegate {
    
    // [START ios_10_data_message]
    // Receive data messages on iOS 10+ directly from FCM (bypassing APNs) when the app is in the foreground.
    // To enable direct data messages, you can set Messaging.messaging().shouldEstablishDirectChannel to true.
    
//    this method is not calling
    func messaging(_ messaging: Messaging, didReceive remoteMessage: MessagingRemoteMessage) {
        print("message from didReceive remoteMessage: \(remoteMessage.appData)")
    }
    // [END ios_10_data_message]
}
