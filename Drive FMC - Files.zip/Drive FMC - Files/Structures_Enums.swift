//
//  Structures_Enums.swift
//  DriveBooking
//
//  Created by Raja Bhuma on 12/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit

enum ResponceCodes {
    case success, authError, badRequest, requestTimeOut, internalServerError, serviceUnavailable, notFound, forbidden, OtherError, NoInternet
    
    func GetResponceCode() -> Int {
        var result: Int = 0
        switch self {
        case .success:
            result = 200
        case .authError:
            result = 401
        case .badRequest:
            result = 400
        case .requestTimeOut:
            result = 408
        case .internalServerError:
            result = 500
        case .serviceUnavailable:
            result = 503
        case .notFound:
            result = 404
        case .forbidden:
            result = 403
        case .NoInternet:
            result = 007
        case .OtherError:
            result = 0
        }
        return result
    }
}

struct DriveLoginRequest {
    var LoginCreds = DriveCredentials()
    var UserName: String!
    var Password: String!
    var Version: String!
    var DeviceToken: String!
    var DeviceIMEINO: String!
    var DeviceType: String!
}

struct DriveLoginResponce {
    
    var CategoryType = [CategoryTypeStruct]()
    var CityDetails = [CityDetailsStruct]()
    var CompanyId: String!
    var CorpPaymentModes : String!
    var PersonalPaymentModes : String!
    var AppCustomerType: String!
    var CorporateId: String!
    var CorporateId2: String!
    var CorporateName: String!
    var CustomerCareNo : String!
    var CustomerTypeId: String!
    var Email: String!
    var EmergencyContacts: String!
    var ReferralCode : String!
    var ReferralHeader: String!
    var ReferralMessage: String! //CorpPaymentModes
    
    var Favourites: String!
    
    var EmpId: String!
    var Name: String!
    var PhoneNo: String!
    var RatingDetails: String!
    var Response: String!
    var Status: String!
    var TripType = [TripTypeStruct]()
    var LocationType = [LocationTypeStruct]()
    var VendorId: String!
    
    var AdvanceBookingTime: String!
    var AdvanceBookingDuration: String!
    var PaymentType: String!
    var PaymentStatus: String!
    var WalletDialogueStatus: String!
    
    var AuthenticationToken: String!
    
    var PaytmWalletNo: String!
    var IOSGoogleTranslatorKey: String!
    var SSOToken: String!
    var ExpiryTime: String!
    var TokenValidity: String!
    
    var WalletToken: String!
    var WalletMobileNo: String!
    
    var ShowHideReferFriend: String!
    
    var MapApiKey : String!
    var CustomerCareNumber : String!
    var BiddingInterval : String!
    var NotificationsCount : String!
    var RetryInterval : String!
    var BiddingRetryMsg : String!
    
    
    var DefaultPaymentMode : String!
    var WalletMinBalance : String!
    var TranslationStatus : String!
    var DummyVehStatus : String!
    
    var CorpBookingStatus: String!
    var RideNowStatus : String!
}

struct CategoryTypeStruct {
    var CategoryId: String!
    var CategoryImage1: String!
    var CategoryImage2: String!
    var SelectedImage: String!
    var CategoryName: String!
    var PopupMessage: String!
    var MapIcon: String!
}

struct CityDetailsStruct {
    var CityId: String!
    var CityName: String!
}

struct TripTypeStruct {
    var TripId: String!
    var TripImage: String!
    var TripName: String!
}
struct LocationTypeStruct {
    var LocationImage : String!
    var LocationName : String!
}

struct EmergencyContactStruct {
    var MobileNumber: String!
    var Name: String!
}
struct FavouritesLocationsStruct {
    var Latitude: Double!
    var Longitude: Double!
    var Location: String!
}
struct DriveCredentials {
    var VendorId: String!
    var CorporateId: String!
    var AppCustomerType: String!
}
struct PlacesStruct {
    var ID:String!
    var Title:String!
    var lat:Double!
    var lon:Double!
    var isfromService:Bool = false
}
struct PickupOrDropLocationsStruct{
    var Latitude: Double!
    var Longitude: Double!
    var Location: String!
}

/* struct PickupLocationsStruct{
    var Latitude: Double!
    var Longitude: Double!
    var Location: String!
}
struct DropLocationsStruct{
    var Latitude: Double!
    var Longitude: Double!
    var Location: String!
} */
