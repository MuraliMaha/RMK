//
//  UpdateLocationVC.swift
//  DriveFindMyCab
//
//  Created by Admin on 01/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit
import GoogleMaps
class UpdateLocationVC: UIViewController {

    @IBOutlet var MapView : GMSMapView!
    @IBOutlet var AddressTxt : UILabel!
    
    var LocationManager = CLLocationManager()
    
    var LoginResponce:LoginResponce!
    var LoginDetails:LoginDetails!
    
    var isfirstTime = true
    
    @IBOutlet weak var myLocationTitleBtn: UIButton!
    @IBAction func myLocationTitleBtnTapped(_ sender: UIButton) {
        if self.locationsContainerView.isHidden{
            self.locationsContainerView.isHidden = false
        }else{
            self.locationsContainerView.isHidden = true
        }
        
    }
    
    @IBOutlet weak var locationsContainerView: UIView!
    @IBAction func myLocation1BtnTapped(_ sender: UIButton) {
        self.locationsContainerView.isHidden = true
        self.myLocationTitleBtn.setTitle("PickupLocation1", for: .normal)
//        FetchMyLocationNew(pickupLocationType: "1")
    }
    
    @IBAction func myLocation2BtnTapped(_ sender: UIButton) {
        self.locationsContainerView.isHidden = true
        self.myLocationTitleBtn.setTitle("PickupLocation2", for: .normal)
//        FetchMyLocationNew(pickupLocationType: "2")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.locationsContainerView.isHidden = true
        
        LoginDetails = FetchLoginDetails()
        LoginResponce = FetchLoginResponce()
        
        LocationManager.requestWhenInUseAuthorization()
        LocationManager.delegate = self;
        MapView.isMyLocationEnabled = true
        
        
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.white
        self.navigationItem.leftBarButtonItem = BackBtnItem
    }
    
    func BackAction() {
        self.navigationController?.popViewController(animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func LoadAddress(Lat:Double,Lon:Double) {
        
        fetchAddressFromLatLon(Lati: Lat, Long: Lon, { (Address, error) in
            if error == nil {
                
                var AddressFilter = ""
                
                for AddObj in Address! {
                    AddressFilter.append("\(AddObj)" + ("\(AddObj)".isEmpty ? "" : ", "))
                }
                
                var FilterAdd = ""
                if AddressFilter != "" && AddressFilter.characters.count > 2 {
                    FilterAdd = AddressFilter.substring(to: AddressFilter.index(AddressFilter.endIndex, offsetBy: -2))
                }
                else {
                    FilterAdd = AddressFilter
                }
                
                self.AddressTxt.text = FilterAdd
            }
            else {
                print(error!)
                self.AddressTxt.text = ""
            }
        })
    }
    
    @IBAction func UpdateAddressBtnAction(_ sender:UIButton) {
//        callUpdateAddressService()
        if myLocationTitleBtn.titleLabel?.text == "PickupLocation1"{
            callUpdateAddressServiceNew(pickupLocationType: "1")
        }else{
            callUpdateAddressServiceNew(pickupLocationType: "2")
        }

    }
    
    func callUpdateAddressServiceNew(pickupLocationType : String){
        if (Reachability()?.isReachable)! {
            
            UIApplication.shared.keyWindow?.StartLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.ChangeAddress, parameterDict: ["LoginId":LoginDetails.UserID!,"Address":self.AddressTxt.text!,"Lat":"\(MapView.camera.target.latitude)","Lon":"\(MapView.camera.target.longitude)","pickuptype":pickupLocationType], completion: { (Reponcedict, success) in
                
                UIApplication.shared.keyWindow?.StopLoading()
                
                if success {
                    
                    if let Dict = Reponcedict {
                        
                        let Arr = Dict["data"] as! [[String:AnyObject]]
                        let ResponceData = Arr[0]
                        
                        if "\(ResponceData["Status"]!)" == "Success" {
                            
                            UtilitiesClass.Alert(Title: "Alert!!", Message: "\(ResponceData["Response"]!)" as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "OK")], Controller: self)
                            
                            self.navigationController?.popToRootViewController(animated: true)
                        }
                        else {
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(ResponceData["Response"]!)", Interval: 3)
                        }
                        
                    }
                    else {
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                    }
                    
                }
                else {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                }
                
            })
            
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "No Internet Connection", Interval: 3)
        }
    }
    
    /*
    func callUpdateAddressService(){
        if (Reachability()?.isReachable)! {
            
            UIApplication.shared.keyWindow?.StartLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.ChangeAddress, parameterDict: ["LoginId":LoginDetails.UserID!,"Address":self.AddressTxt.text!,"Lat":"\(MapView.camera.target.latitude)","Lon":"\(MapView.camera.target.longitude)"], completion: { (Reponcedict, success) in
                
                UIApplication.shared.keyWindow?.StopLoading()
                
                if success {
                    
                    if let Dict = Reponcedict {
                        
                        let Arr = Dict["data"] as! [[String:AnyObject]]
                        let ResponceData = Arr[0]
                        
                        if "\(ResponceData["Status"]!)" == "Success" {
                            
                            UtilitiesClass.Alert(Title: "Alert!!", Message: "\(ResponceData["Response"]!)" as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "OK")], Controller: self)
                            
                            self.navigationController?.popToRootViewController(animated: true)
                        }
                        else {
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(ResponceData["Response"]!)", Interval: 3)
                        }
                        
                    }
                    else {
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                    }
                    
                }
                else {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                }
                
            })
            
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "No Internet Connection", Interval: 3)
        }
    
    
    } */
    
    @IBAction func MyLocationBtnAction(_ sender:UIButton) {
        let Position = GMSCameraPosition.camera(withTarget: (LocationManager.location?.coordinate)!, zoom: 15)
        MapView.animate(to: Position)
    }
}
extension UpdateLocationVC:CLLocationManagerDelegate , GMSMapViewDelegate {
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("LocationError:===:", error.localizedDescription)
    }
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedAlways || status == .authorizedWhenInUse {
            manager.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if isfirstTime {
            isfirstTime = false
            let Position = GMSCameraPosition.camera(withTarget: (LocationManager.location?.coordinate)!, zoom: 15)
            MapView.animate(to: Position)
        }
    }
    
    func mapView(_ mapView: GMSMapView, idleAt position: GMSCameraPosition) {
        LoadAddress(Lat: MapView.camera.target.latitude, Lon: MapView.camera.target.longitude)
    }
}
