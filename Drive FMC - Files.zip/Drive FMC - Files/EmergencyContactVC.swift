//
//  EmergencyContactVC.swift
//  DriveFindMyCab
//
//  Created by Admin on 01/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit

class EmergencyContactVC: UIViewController,UITextFieldDelegate {

    @IBOutlet var EmergencyTB: UITableView!
    
    @IBOutlet var PrimaryGuardianName: UILabel!
    @IBOutlet var PrimaryGuardianNumber: UILabel!

    var LoginResponce:LoginResponce!
    
    var EmergencyCArr = [EmergencyCStruct]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        LoginResponce = FetchLoginResponce()
        PrimaryGuardianNumber.text = LoginResponce.HelpDeskno!
        
        Fetch()
        EmergencyTB.tableFooterView = UIView.init(frame: CGRect.zero)
        EmergencyTB.reloadData()
        
        let donetoolbar = UIToolbar(frame : CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        
        donetoolbar.barStyle = UIBarStyle.default
        donetoolbar.backgroundColor = UIColor.black
        let flexspace = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let done = UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(DoneReturn))
        
        donetoolbar.tintColor = UIColor.blue
        donetoolbar.items = [flexspace,done]
        donetoolbar.sizeToFit()
        
        SecondaryGuardianNumber.inputAccessoryView = donetoolbar

        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.white
        self.navigationItem.leftBarButtonItem = BackBtnItem
    }
    
    func DoneReturn() {
        SecondaryGuardianNumber.resignFirstResponder()
    }
    
    func BackAction() {
        self.navigationController?.popViewController(animated: true)
    }
    func Fetch() {
        guard FetchEmergencyContacts() != nil  else {
            return
        }
        EmergencyCArr = FetchEmergencyContacts()!
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    
    @IBAction func AddNewEmergencyContact(_ sender:UIButton) {
        ShowAddSecondaryGuardianWith(Name: nil, Number: nil, IsEdit: false)
    }
    
    
    
    // MARK: - Add Emergency Contact {
    @IBOutlet var AddGuardianView: UIView!

    @IBOutlet var SecondaryGuardianName: UITextField!
    @IBOutlet var SecondaryGuardianNumber: UITextField!
    @IBOutlet var Save_OkBtn: UIButton!

    var SelectedIndex:Int! = 0
    var IsEditGuardian:Bool = false
    
    var ActualY : CGFloat = 0
    
    @IBAction func SaveNewEmergencyContact(_ sender:UIButton) {
        
        self.AddGuardianView.endEditing(true)

//        let Map = EmergencyCArr.filter({$0.Number == SecondaryGuardianNumber.text!})
        
        if (SecondaryGuardianName.text?.count)! == 0 {
            AddGuardianView.superview?.ShowWhiteTostWithText(message: "Please enter Guardian name", Interval: 3)
        }
        else if (UtilitiesClassSub.removeLeadingandTralingSpace(SecondaryGuardianName.text!)).characters.count == 0 {
            AddGuardianView.superview?.ShowWhiteTostWithText(message: "Invalid Name", Interval: 3)
        }
        else if (SecondaryGuardianName.text?.count)! < 3 {
            AddGuardianView.superview?.ShowWhiteTostWithText(message: "Guardian name should be minimum 3 charecters", Interval: 3)
        }
        else if (SecondaryGuardianNumber.text?.count)! == 0 {
            AddGuardianView.superview?.ShowWhiteTostWithText(message: "Please enter Guardian Number", Interval: 3)
        }
//        else if Map.count != 0 {
//            AddGuardianView.superview?.ShowWhiteTostWithText(message: "Number already exists", Interval: 3)
//        }
        else if SecondaryGuardianNumber.text?.count != 10 {
            AddGuardianView.superview?.ShowWhiteTostWithText(message: "Invalid Number", Interval: 3)
        }
        else if SecondaryGuardianNumber.text == self.LoginResponce.HelpDeskno {
            AddGuardianView.superview?.ShowWhiteTostWithText(message: "Help Desk Number cannot be in Emergency Contacts.", Interval: 3)
        }
        else if SecondaryGuardianNumber.text == self.LoginResponce.PhoneNo {
            AddGuardianView.superview?.ShowWhiteTostWithText(message: "Registered mobile number cannot be in Emergency contacts", Interval: 3)
        }
        else {
            
            if IsEditGuardian {
                var EObj = EmergencyCArr[SelectedIndex!]
                EObj.Name = SecondaryGuardianName.text!
                EObj.Number = SecondaryGuardianNumber.text!
                EmergencyCArr[SelectedIndex!] = EObj
                SaveEmergencyContacts(EmergencyArr: EmergencyCArr)
            }
            else {
                var Eobj = EmergencyCStruct()
                Eobj.Name = SecondaryGuardianName.text!
                Eobj.Number = SecondaryGuardianNumber.text!
                EmergencyCArr.append(Eobj)
                SaveEmergencyContacts(EmergencyArr: EmergencyCArr)
            }
            
            EmergencyTB.reloadData()
            
            UIView.animate(withDuration: 0.3, animations: {
                self.AddGuardianView.alpha = 0
            }) { (yes) in
                if yes {
                    self.AddGuardianView.alpha = 1
                    self.AddGuardianView.superview?.removeFromSuperview()
                }
            }
        }
    }
    
    func ShowAddSecondaryGuardianWith(Name:String?,Number:String?,IsEdit:Bool) {
        
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        
        BackView.center = (window?.center)!
        
        window?.addSubview(BackView)
        
        if IsEdit {
            IsEditGuardian = true
            SecondaryGuardianName.text = Name!
            SecondaryGuardianNumber.text = Number!
            Save_OkBtn.setTitle("Save", for: .normal)
        }
        else {
            IsEditGuardian = false
            SecondaryGuardianName.text = ""
            SecondaryGuardianNumber.text = ""
            Save_OkBtn.setTitle("Ok", for: .normal)
        }
        
        AddGuardianView.center = BackView.center
        
        BackView.addSubview(AddGuardianView!)
        
        let GuardianTap = UITapGestureRecognizer.init(target: self, action: #selector(TapAddGuardianView(_:)))
        GuardianTap.numberOfTapsRequired = 1
        BackView.addGestureRecognizer(GuardianTap)

        ActualY = AddGuardianView.frame.origin.y
        
        AddGuardianView.alpha = 0
        UIView.animate(withDuration: 0.5) {
            self.AddGuardianView.alpha = 1
        }
    }
    
    func TapAddGuardianView(_ responder:UITapGestureRecognizer) {
        
        let Point = responder.location(in: AddGuardianView.superview!)
        let Frame = AddGuardianView.frame
        
        if !Frame.contains(Point) {
            
            UIView.animate(withDuration: 0.3, animations: {
                self.AddGuardianView.alpha = 0
            }) { (yes) in
                if yes {
                    self.AddGuardianView.alpha = 1
                    self.AddGuardianView.superview?.removeFromSuperview()
                }
            }
        }
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == SecondaryGuardianNumber {
            
            let newLength = (textField.text?.characters.count)! + string.characters.count - range.length
            
            if newLength > 10 {
                return false
            }
            
            let aSet = NSCharacterSet(charactersIn:"0123456789").inverted
            let compSepByCharInSet = string.components(separatedBy: aSet)
            let numberFiltered = compSepByCharInSet.joined(separator: "")
            return string == numberFiltered
        }
        else {
            return true
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardHide(_:)), name: .UIKeyboardWillHide, object: nil)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    //MARK: - Keyboard show
    
    func keyboardShow(_ notification : NSNotification){
        
        let info = notification.userInfo
        let keyboardframe = (info![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size
        var frame = CGRect.init()
        if SecondaryGuardianName.isFirstResponder {
            frame = SecondaryGuardianName.frame
        }
        else {
            frame = SecondaryGuardianNumber.frame
        }
        
        frame.origin.y += AddGuardianView.frame.origin.y
        
        var actualframe = AddGuardianView.superview?.frame
        actualframe?.size.height -= keyboardframe.height
        actualframe?.size.height -= (frame.size.height)
        
        if !(actualframe?.contains((frame.origin)))! {
            let yfinal = (frame.origin.y) - (actualframe?.size.height)!
            
            UIView.animate(withDuration: 0.3, animations: { () -> Void in
                self.AddGuardianView.frame.origin.y -= yfinal
            })
            
        }
    }
    // MARK: - keyboard hide
    
    func keyboardHide(_ notification : NSNotification)
    {
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.AddGuardianView.frame.origin.y = self.ActualY
        })
    }
    
    // MARK: - }
}

extension EmergencyContactVC:UITableViewDelegate,UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return EmergencyCArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EmergencyContactCell", for: indexPath) as! EmergencyContactCell
        cell.GuardianName.text = EmergencyCArr[indexPath.row].Name!
        cell.GuardianNumber.text = EmergencyCArr[indexPath.row].Number!
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        let DeleteAction = UITableViewRowAction.init(style: .destructive, title: "Delete") { (action, DeleteIndex) in
            
            self.EmergencyTB.beginUpdates()
            self.EmergencyCArr.remove(at: DeleteIndex.row)
            SaveEmergencyContacts(EmergencyArr: self.EmergencyCArr)
            self.EmergencyTB.deleteRows(at: [DeleteIndex], with: .automatic)
            self.EmergencyTB.endUpdates()
            
        }
        
        let ModifyAction = UITableViewRowAction.init(style: .normal, title: "Modify") { (Action, ModifyIndex) in
            self.SelectedIndex = ModifyIndex.row
            self.ShowAddSecondaryGuardianWith(Name: self.EmergencyCArr[indexPath.row].Name!, Number: self.EmergencyCArr[indexPath.row].Number!, IsEdit: true)
        }
        
        return [ModifyAction,DeleteAction]
    }
}



class EmergencyContactCell:UITableViewCell {
    @IBOutlet var GuardianName: UILabel!
    @IBOutlet var GuardianNumber: UILabel!
}

// MARK: - Data Handling {

struct EmergencyCStruct {
    var Name:String!
    var Number:String!
}

func FetchEmergencyContacts() -> [EmergencyCStruct]? {
    if UserDefaults.standard.value(forKey: "EmergencyContactDetails") != nil {
        if let EmergencyDetailsArr:[[String:String]] = try! JSONSerialization.jsonObject(with: UserDefaults.standard.value(forKey: "EmergencyContactDetails") as! Data, options: JSONSerialization.ReadingOptions.allowFragments) as? [[String:String]] {
            var Arr = [EmergencyCStruct]()
            for obj in EmergencyDetailsArr {
                var Eobj = EmergencyCStruct()
                Eobj.Name = obj["Name"]!
                Eobj.Number = obj["Number"]!
                Arr.append(Eobj)
            }
            return Arr
        }
        else {
            return nil
        }
    }
    else {
        return nil
    }
}

func SaveEmergencyContacts(EmergencyArr:[EmergencyCStruct]) {
    
    let defaults = UserDefaults.standard
    
    var EArray = [[String:String]]()
    
    for EObj in EmergencyArr {
        let Obj = ["Name":EObj.Name!,"Number":EObj.Number!]
        EArray.append(Obj)
    }
    
    let data = try? JSONSerialization.data(withJSONObject: EArray, options: .prettyPrinted)
    
    defaults.set(data!, forKey: "EmergencyContactDetails")
    defaults.synchronize()
    
}

// MARK: - }
