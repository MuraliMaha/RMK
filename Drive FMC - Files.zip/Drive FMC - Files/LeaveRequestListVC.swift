//
//  LeaveRequestListVC.swift
//  DriveFindMyCab
//
//  Created by Admin on 01/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit

class LeaveRequestCell:UITableViewCell {
    @IBOutlet var fromLbl:UILabel!
    @IBOutlet var ToLbl:UILabel!
    @IBOutlet var LeaveTypeLbl:UILabel!
    @IBOutlet var Status:UILabel!
    @IBOutlet weak var deleteBtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}

class LeaveRequestListVC: UIViewController {

    @IBOutlet var LeaveRequestTB:UITableView!

    var LeaveRequestListArr = [[String:AnyObject]]()
    
    var LoginResponce:LoginResponce!
    var LoginDetails:LoginDetails!
    
    var dateFormatter = DateFormatter()
    var currentDateString : String!
    
    @IBOutlet var confirmationView: UIView!
    var tappedBtnCellTag:Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LoginDetails = FetchLoginDetails()
        LoginResponce = FetchLoginResponce()
        
        LeaveRequestTB.tableFooterView = UIView.init(frame: CGRect.zero)
        
        let RightItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "ic_add"), to: CGSize.init(width: 30, height: 30)), style: .done, target: self, action: #selector(RightBarItem))
        RightItem.tintColor = UIColor.white
        self.navigationItem.rightBarButtonItem = RightItem
        
        dateFormatter.dateFormat = "dd-MMM-yyyy"
        currentDateString = dateFormatter.string(from: Date())
    }
    
    func RightBarItem() {
        if (Reachability()?.isReachable)!{
            let request = self.storyboard?.instantiateViewController(withIdentifier: "LeaveRequestVC") as! LeaveRequestVC
            self.navigationController?.pushViewController(request, animated: true)
        }else {
            self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
        }
        
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        Timer.scheduledTimer(timeInterval: 0.2, target: self, selector: #selector(CallServiceToFetchAdHocList), userInfo: nil, repeats: false)
    }
    
    func CallServiceToFetchAdHocList() {
        if (Reachability()?.isReachable)! {
            UIApplication.shared.keyWindow?.StartLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.EmpRequestList, parameterDict: ["EmpCode":"\(LoginDetails.UserID!)","RequestType":"Leave"], completion: { (responceDict, success) in
                UIApplication.shared.keyWindow?.StopLoading()
                if success {
                    
                    if let Dict = responceDict {
                        let Arr = Dict["data"] as! [[String:AnyObject]]
                        if Arr.count > 0 {
                            self.LeaveRequestListArr = Arr
                            self.LeaveRequestTB.isHidden = false
                        }
                        else {
//                            print("Error")
//                            self.view.ShowWhiteTostWithText(message: "No Requests found", Interval: 2)
                            self.LeaveRequestTB.isHidden = true
                        }
                        self.LeaveRequestTB.reloadData()
                    }
                    else {
                        self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)

                        print("Error")
                    }
                }
                else {
                    self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)

                    print("Error")
                }
            })
            
        }
        else {
            self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)

            print("Net Error")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension LeaveRequestListVC:UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return LeaveRequestListArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "LeaveRequestCell", for: indexPath) as! LeaveRequestCell
        
        cell.fromLbl.text = "\(LeaveRequestListArr[indexPath.row]["FromDate"]!)"
        cell.ToLbl.text = "\(LeaveRequestListArr[indexPath.row]["ToDate"]!)"
        cell.LeaveTypeLbl.text = "\(LeaveRequestListArr[indexPath.row]["LeaveType"]!)"
        cell.Status.text = "\(LeaveRequestListArr[indexPath.row]["Status"]!)"
        
        cell.deleteBtn.tag = indexPath.row
        cell.deleteBtn.addTarget(self, action: #selector(self.deleteButtonTapped), for: .touchUpInside)
        
        
        cell.selectionStyle = .none
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 124
    }
    func deleteButtonTapped(_sender : UIButton ){
        print("delete button tapped....")
        self.tappedBtnCellTag = _sender.tag
        showConfirmation()
//        UtilitiesClass.Alert(Title: "Delete Leave Request", Message: "Are you sure?", Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "CANCEL"),UtilitiesClass.AlertActionWithSelector(Title: "OK", Selector: #selector(deleteOkAction(_:)), Controller: self)], Controller: self)
    }
//    func deleteOkAction(_ sender:UIButton) {
//        callDeleteService(requestId: "\(LeaveRequestListArr[sender.tag]["Id"]!)")
//    }
    
    //MARK: - ConfirmationView
    func showConfirmation(){
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        
        BackView.center = (window?.center)!
        
        window?.addSubview(BackView)
        confirmationView.center = BackView.center
        
        BackView.addSubview(confirmationView!)
        
        let GuardianTap = UITapGestureRecognizer.init(target: self, action: #selector(TapEditGuardianView(_:)))
        GuardianTap.numberOfTapsRequired = 1
        BackView.addGestureRecognizer(GuardianTap)
        
        confirmationView.alpha = 0
        
        
        UIView.animate(withDuration: 0.5) {
            self.confirmationView.alpha = 1
        }
        
    }
    func TapEditGuardianView(_ responder:UITapGestureRecognizer) {
        
        
        let Point = responder.location(in: confirmationView.superview!)
        let Frame = confirmationView.frame
        
        if !Frame.contains(Point) {
            
            UIView.animate(withDuration: 0.3, animations: {
                self.confirmationView.alpha = 0
            }) { (yes) in
                if yes {
                    self.confirmationView.alpha = 1
                    self.confirmationView.superview?.removeFromSuperview()
                }
            }
        }
        
    }
    
    
    
    @IBAction func confirmationCancelTapped(_ sender: UIButton) {
        closeConfirmationView()
    }
    
    
    @IBAction func confirmationOKTapped(_ sender: UIButton) {
        closeConfirmationView()
//        callDeleteService(requestId: "\(LeaveRequestListArr[self.tappedBtnCellTag]["Id"]!)")
        callDeleteService(requestId: "\(LeaveRequestListArr[self.tappedBtnCellTag]["Id"]!)", date: "\(LeaveRequestListArr[self.tappedBtnCellTag]["RequestedDate"]!)")
    }
    
    func closeConfirmationView() {
        UIView.animate(withDuration: 0.3, animations: {
            self.confirmationView.alpha = 0
        }) { (yes) in
            if yes {
                self.confirmationView.alpha = 1
                self.confirmationView.superview?.removeFromSuperview()
            }
        }
    }
    
    func callDeleteService(requestId : String , date :String){
        if (Reachability()?.isReachable)! {
            UIApplication.shared.keyWindow?.StartLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.DriveCancelRequest, parameterDict: ["CancelType":"2","RequestId" : requestId,"DateTime": date,"EmpCode":"\(LoginResponce.Empcode!)"], completion: { (responceDict, success) in
                UIApplication.shared.keyWindow?.StopLoading()
                if success {
                    
                    if let Dict = responceDict {
                        let Arr = Dict["data"] as! [[String:AnyObject]]
                        
                        if Arr.count > 0 {
                            self.CallServiceToFetchAdHocList()
                            self.view.ShowWhiteTostWithText(message:"\(Arr[0]["Response"]!)", Interval: 2)
                        }
                    }
                    else {
                        self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                        
                        print("Error")
                    }
                }
                else {
                    self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                    
                    print("Error")
                }
            })
            
        }
        else {
            self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
            
            print("Net Error")
        }
    }
    
    /*
    func callDeleteService(requestId : String){
        if (Reachability()?.isReachable)! {
            UIApplication.shared.keyWindow?.StartLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.DriveCancelRequest, parameterDict: ["CancelType":"2","RequestId" : requestId,"DateTime": self.currentDateString!,"EmpCode":"\(LoginDetails.EmpCode!)"], completion: { (responceDict, success) in
                UIApplication.shared.keyWindow?.StopLoading()
                if success {
                    
                    if let Dict = responceDict {
                        let Arr = Dict["data"] as! [[String:AnyObject]]
                       
                        if Arr.count > 0 {
                            self.CallServiceToFetchAdHocList()
                            self.view.ShowWhiteTostWithText(message:"\(Arr[0]["Response"]!)", Interval: 2)
                        }
                    }
                    else {
                        self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                        
                        print("Error")
                    }
                }
                else {
                    self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                    
                    print("Error")
                }
            })
            
        }
        else {
            self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
            
            print("Net Error")
        }
    }
    */
}
