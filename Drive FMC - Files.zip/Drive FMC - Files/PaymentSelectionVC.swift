//
//  PaymentSelectionVC.swift
//  DriveBooking
//
//  Created by Amarnath B on 30/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit
import Alamofire

protocol PaymentTypeSelectionDelegate {
    func PaymentDidSelect(PaymentType:PaymentType,Balance:String, controller:PaymentSelectionVC)
}

protocol StreetJobsPaymentSuccess {
    func StreetJobsPaymentSuccess(controller:PaymentSelectionVC, Response: String, JobNo: String, PaymentType: PaymentType)
}
class PaymentSelectionVC: UIViewController, MobiKwikSignInDelegate, MobiKwikAddMoneyDelegate, PaytmSignInDelegate, PaytmAddMoneyDelegate {

    @IBOutlet var PaymentTable: UITableView!
    
    var PaymentsArr = [PaymentTypes]()
    
    var MobiToken: String!
    var MobiMobile: String!
    
    var PaytmToken: String!
    var PaytmMobile: String!
    
    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!
    
    var PaymentType: PaymentType!
    
    var Delegate: PaymentTypeSelectionDelegate!
    
    
    var StreetJobsDelegate: StreetJobsPaymentSuccess!

    var PickupDetails: FavouritesLocationsStruct!
    var DropLocDetails: FavouritesLocationsStruct!
    var VehicleModelName: String!
    var VehicleCat: String!
    var CityName: String!
    
    var MinimumBalanceRequired:Float = 150.0
    
    var FromRide_Street : String!
    var JobNo : String!
    var amounttobepaid : String!
    
//    override func viewWillDisappear(_ animated: Bool) {
//        super.viewWillDisappear(animated)
//        self.navigationController?.isNavigationBarHidden = false
//    }
//    override func viewDidDisappear(_ animated: Bool) {
//        super.viewDidDisappear(animated)
//        self.navigationController?.isNavigationBarHidden = false
//        
//    }
//    self.navigationController?.isNavigationBarHidden = true
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // FromRide_Street  == 0 means is trigge red from regular booking and FromRide_Street == 1 means triggered from streetJobs.

        
        
        
        // Do any additional setup after loading the view.
        // self.navigationController?.isNavigationBarHidden = true

        self.navigationItem.title = "PAYMENT"
        PaymentTable.tableFooterView = UIView.init(frame: CGRect.zero)
        
        var Type1 = PaymentTypes()
        Type1.PaymentTitle = "Cash"
        Type1.PaymentImage = #imageLiteral(resourceName: "cashinhand")
        Type1.State = .notRequired
        Type1.PaymentTypeObj = .cash
        
        var Type2 = PaymentTypes()
        Type2.PaymentTitle = "Paytm"
        Type2.PaymentImage = #imageLiteral(resourceName: "PaytmLogo")
        Type2.State = PaymentOptionState.loading
        Type2.PaymentTypeObj = .paytm
        
        var Type3 = PaymentTypes()
        Type3.PaymentTitle = "MobiKwik"
        Type3.PaymentImage = #imageLiteral(resourceName: "MobikwikIcon")
        Type3.State = PaymentOptionState.loading
        Type3.PaymentTypeObj = .mobikwik
        
        PaymentsArr.append(Type1)
        PaymentsArr.append(Type2)
        PaymentsArr.append(Type3)
        
        self.LoginRequest = FetchDriveRequest()
        self.DriveBookingResponce = FetchDriveResponce()
        
        PaytmToken = DriveBookingResponce.SSOToken!
        PaytmMobile = DriveBookingResponce.PaytmWalletNo!
        
        MobiToken = DriveBookingResponce.WalletToken!
        MobiMobile = DriveBookingResponce.WalletMobileNo!
        MinimumBalanceRequired = Float(DriveBookingResponce.WalletMinBalance!)!
        // FromRide_Street  == 0 means is trigge red from regular booking and FromRide_Street == 1 means triggered from streetJobs.

        if FromRide_Street == "1"{
            MinimumBalanceRequired = Float(amounttobepaid)!
        }

        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.black
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
        self.navigationItem.leftBarButtonItem = BackBtnItem
        
        self.perform(#selector(LoadAfterDelay), with: self, afterDelay: 0.2)
    }
    
    func BackAction() {
        if FromRide_Street == "1"{
//            var payment = PaymentType
//            if payment == nil{
//                payment = PaymentType.description
//            }
            PaymentType = .cash
            StreetJobsDelegate.StreetJobsPaymentSuccess(controller: self, Response: "0", JobNo: JobNo!, PaymentType: PaymentType)
            
        }
        if FromRide_Street == "0"{
            
            var balance = "0"
            
            if PaymentType == .paytm {
                balance = FetchPaytmBalance()
            }
            else if PaymentType == .mobikwik {
                balance = FetchMobiKwikBalance()
            }
            
            if balance == "NA" {
                Delegate.PaymentDidSelect(PaymentType: .cash, Balance: "0", controller: self)
            }
            else {
                Delegate.PaymentDidSelect(PaymentType: PaymentType, Balance: balance, controller: self)
            }
        }

    }
    
        
    
    func LoadAfterDelay() {
        PaymentTable.reloadData()
        if FromRide_Street == "0"{
            
            FetchFareEstimation()

        }
 //        FetchFareEstimation()
        CheckPaytmTokes()
        CheckMobiKwikIsthere()
    }
    
    
    //fetch fare estimation and assign it as minimum balance
    
    func FetchFareEstimation(){
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            var dropLon = 0.0
            var dropLat = 0.0
            if DropLocDetails.Latitude != nil{
                dropLat = DropLocDetails.Latitude!
                dropLon = DropLocDetails.Longitude!
            }

            
            let RequestDict = ["PickUpLat":"\(PickupDetails.Latitude!)",
                "PickUpLon":"\(PickupDetails.Longitude!)",
                "DropLat":"\(dropLat)",
                "DropLon":"\(dropLon)",
                "VehicleCategory":"\(VehicleCat!)",
                "VehicleModel":"\(VehicleModelName!)",
                "TypeofTrip":"Meter Tariff",
                "City":"Mumbai",
                "EmpId":"\(DriveBookingResponce.EmpId!)",
                "BookingType":"Current",
                "VendorId":"\(LoginRequest.LoginCreds.VendorId!)",
                "CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)",
                "AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)",
                "Status":"1"]
            print(CityName!)
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveEstimateRideForBooking, parameterDict: RequestDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (ResponceData, responceCode, success) in
                
                if success {
                    
                    if let Table = ((ResponceData as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                        
                        if "\(Table["Status"]!)".toBool()! {
                            if "\(Table["MinBalance"]!)" != "0" {
                                self.MinimumBalanceRequired = Float("\(Table["MinBalance"]!)")!
                            }else{
//                                self.MinimumBalanceRequired  = 150.0
                                self.MinimumBalanceRequired = Float(self.DriveBookingResponce.WalletMinBalance!)!

                            }
                        }
                        else {
//                            self.view.ShowBlackTostWithText(message: "\(Table["Response"]!)", Interval: 2)
//                            self.MinimumBalanceRequired  = 150.0
                            self.MinimumBalanceRequired = Float(self.DriveBookingResponce.WalletMinBalance!)!
                        }
                    }
                    else {
                        self.MinimumBalanceRequired = Float(self.DriveBookingResponce.WalletMinBalance!)!
                        self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)

                    }
                    
                }
                else {
                    self.MinimumBalanceRequired = Float(self.DriveBookingResponce.WalletMinBalance!)!
                    self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                }
                
                self.view.StopLoading()
            })
        }
        else {
            self.view.ShowBlackTostWithText(message: Constants.NetErrorMsg, Interval: 3)
        }
    }
    
    func ShowLink(isTrue:Bool,Balance:String) {
        
        if isTrue {
            PaymentsArr[2].State = PaymentOptionState.notLinked
            if PaymentType != nil{
            if PaymentType == .mobikwik{
                PaymentType = .cash
                }
            }else{
                PaymentType = .cash
            }
        }
        else {
            
//            if PaymentType == .mobikwik {
//                PaymentType = .cash
//            }
            
            var Done = PaymentMethodData()
            Done.balance = Balance
            Done.mobileNumber = DriveBookingResponce.WalletMobileNo!
            PaymentsArr[2].State = PaymentOptionState.Done(Done)
//            PaymentType = .mobikwik
        }
        
        self.PaymentTable.reloadData()
    }
    
    func CheckMobiKwikIsthere() {
        
        if MobiToken == nil || MobiToken! == "NA" || MobiToken! == "" || MobiMobile == nil || MobiMobile! == "NA" || MobiMobile! == "" {
            self.ShowLink(isTrue: true, Balance: "")
            return
        }
        RegenerateToken()
    }
    //mobikwik token generation
    func RegenerateToken() {
        
        if !(Reachability()?.isReachable)! {
            self.ShowLink(isTrue: true, Balance: "")
            return
        }
        
        
        let tokentype       = "1"
        let cell            = MobiMobile!
        let msgcode         = "507"
        let mid             = MobiCreds.MID
        let merchantname    = MobiCreds.MerchentName
        
        let SecretKey = MobiCreds.RegenrationSecurity
        
        let VariableFormat  = "'\(cell)''\(merchantname)''\(mid)''\(msgcode)''\(MobiToken!)''\(tokentype)'" // ‘cell’‘merchantname’‘mid’‘msgcode’'Token''tokentype'
        
        let checksum        = VariableFormat.hmac(algorithm: .SHA256, key: SecretKey)
        
        let parserStr       = Parser(dict: ["cell":cell,"msgcode":msgcode,"mid":mid,"merchantname":merchantname,"tokentype":tokentype,"token":MobiToken!,"checksum":checksum])
        
        let UrlFormat       =  MobiCreds.BaseUrl + "/" + MobiCreds.Tokenregenerate + "?" + parserStr
        
        let url             = URL.init(string: UrlFormat.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!
        
        var Request         = URLRequest.init(url: url)
        Request.httpMethod  = "GET"
        Request.allHTTPHeaderFields = ["payloadtype":"json"]
        
        Alamofire.request(Request)
            .responseJSON { (responce) in
                
                switch responce.result {
                case .success(let Value):
                    //print(Value)
                    let responceData = Value as! [String:AnyObject]
                    if "\(responceData["status"]!)" == "SUCCESS" {
                        self.MobiToken = "\(responceData["token"]!)"
                        self.DriveBookingResponce.WalletToken = self.MobiToken
                        saveDriveResponceStuct(driveStruct: self.DriveBookingResponce!)
                        UpdatePaymentModes(WalletType_Paytm_MobiKwik: "MobiKwik", MobileNo: self.DriveBookingResponce.WalletMobileNo!, Token: self.MobiToken, ExpData_oMobi_Paytmdate: "0", CompletionAuthError: { (isauth) in
                            if isauth {
//                                authenticationCheck(controller: self)
                            }
                        })
                        self.CheckBalance()
                    }
                    else {
                        self.ShowLink(isTrue: true, Balance: "")
                    }
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    self.ShowLink(isTrue: true, Balance: "")
                    break
                }
        }
    }
    
    
    //check mobikwik balance
    
    func CheckBalance() {
        
        if !(Reachability()?.isReachable)! {
            self.ShowLink(isTrue: true, Balance: "")
            return
        }

        
        let cell            = MobiMobile!
        let msgcode         = "501"
        let mid             = MobiCreds.MID
        let merchantname    = MobiCreds.MerchentName
        
        let VariableFormat  = "'\(cell)''\(merchantname)''\(mid)''\(msgcode)''\(MobiToken!)'" // ‘cell’‘merchantname’‘mid’‘msgcode’'Token'
        
        let checksum        = VariableFormat.hmac(algorithm: .SHA256, key: MobiCreds.Secret)
        
        let parserStr       = Parser(dict: ["cell":cell,"msgcode":msgcode,"mid":mid,"merchantname":merchantname,"token":MobiToken!,"checksum":checksum])
        
        let UrlFormat       =  MobiCreds.BaseUrl + "/" + MobiCreds.userbalance + "?" + parserStr
        
        let url             = URL.init(string: UrlFormat.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!
        
        var Request         = URLRequest.init(url: url)
        Request.httpMethod  = "GET"
        Request.allHTTPHeaderFields = ["payloadtype":"json"]
        
        Alamofire.request(Request)
            .responseJSON { (responce) in
                
                switch responce.result {
                case .success(let Value):
                    //print(Value)
                    
                    let responceData = Value as! [String:AnyObject]
                    
                    if "\(responceData["status"]!)" == "SUCCESS" {
                        let Balance = String.init(format: "%.2f", Float("\(responceData["balanceamount"]!)")!)

                        self.ShowLink(isTrue: false, Balance: "₹" + Balance)
                        SaveMobiKwikBalance(token: Balance)
                        
                        self.DriveBookingResponce.DefaultPaymentMode = "MOBIKWIK"
                        saveDriveResponceStuct(driveStruct: self.DriveBookingResponce!)
                    }
                    else {
                        self.DriveBookingResponce.DefaultPaymentMode = "CASH"
                        saveDriveResponceStuct(driveStruct: self.DriveBookingResponce!)
                        self.ShowLink(isTrue: true, Balance: "")
                    }
                    
                    break
                case .failure(let error):
                    self.DriveBookingResponce.DefaultPaymentMode = "CASH"
                    saveDriveResponceStuct(driveStruct: self.DriveBookingResponce!)
                    print(error.localizedDescription)
                    self.ShowLink(isTrue: true, Balance: "")
                    break
                }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //street job payment status checking delegate
    
    func streetJOBPayment(SSOToken: String, Wallettype: PaymentType, MobileNumber:String, Balance: String){
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            let DriveDict = ["SSOToken":SSOToken,"WalletType":"\(Wallettype)","JobNo":JobNo!,"Mobileno":MobileNumber,"VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)","EmpId":"\(DriveBookingResponce.EmpId!)"]
            print(DriveDict)
            
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.WalletPaymentForStreetJobs, parameterDict: DriveDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (response, ErrorCode, success) in
                
                print("*******\(response)")
                
                self.view.StopLoading()
                
                
                if success{
                    let TableArray = (response as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
                    //print(TableArray)
                    let tabledata = TableArray[0]
                    if "\(tabledata["Status"]!)" == "true"{
                        Message.shared.Alert(Title: " ", Message: "\(tabledata["Response"]!)", TitleAlign: .normal , MessageAlign: .normal, Actions: [Message.AlertActionWithSelector(Title: "Ok", Selector: #selector(self.successSJPayment), Controller: self)], Controller: self)

                    }else{
                        let action = UIAlertAction.init(title: "Retry", style: .default, handler: { (action) in
                            self.streetJOBPayment(SSOToken: SSOToken, Wallettype: Wallettype, MobileNumber: MobileNumber, Balance: Balance)
                        })
                        
//                        Message.shared.Alert(Title: "Alert", Message: "\(tabledata["Response"]!)", TitleAlign: .normal , MessageAlign: .normal, Actions: [Message.AlertActionWithSelector(Title: "Cancel", Selector: #selector(self.ClosePayment), Controller: self),action], Controller: self)
                        
                        Message.shared.Alert(Title: "Alert", Message: "\(tabledata["Response"]!)", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Cancel"), action], Controller: self)

                        
                    }
                }else{
                    Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    return
                }

                
            })
        }else{
            
            
            Message.shared.Alert(Title: "Alert", Message: "Please Check your Internet Connection", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            
            
            return
        }
        
    }
    
    //success payment when comes from street job
    
    func successSJPayment(){
    
        StreetJobsDelegate.StreetJobsPaymentSuccess(controller: self, Response: "1", JobNo: JobNo!, PaymentType: PaymentType)
    }
    
    func ClosePayment(){
//        StreetJobsDelegate.StreetJobsPaymentSuccess(controller: self, Response: "0", JobNo: JobNo!, PaymentType: PaymentType)
    }
    // MARK: - Sign delegate
    func DidSignInCancel(controller: MobiKwikSignInVc) {
        controller.navigationController?.popViewController(animated: true)
    }
    
    func DidSignInComplete(controller: MobiKwikSignInVc) {
        controller.navigationController?.popViewController(animated: true)
        
        // Get money
        self.DriveBookingResponce = FetchDriveResponce()
        
        MobiToken = DriveBookingResponce.WalletToken!
        MobiMobile = DriveBookingResponce.WalletMobileNo!
        
        PaymentsArr[2].State = .loading
        
        CheckMobiKwikIsthere()
        
    }
    
    // MARK: - Add Money delegate
    
    func DidcancelAddMoney(controller: MobiKwikAddMoney) {
        controller.navigationController?.popViewController(animated: true)
    }
    
    func DidCompleteAddMoney(controller: MobiKwikAddMoney) {
        controller.navigationController?.popViewController(animated: true)
        
        // Get Money
        
        self.DriveBookingResponce = FetchDriveResponce()
        
        MobiToken = DriveBookingResponce.WalletToken!
        MobiMobile = DriveBookingResponce.WalletMobileNo!
        
        PaymentsArr[2].State = .loading
        
        CheckMobiKwikIsthere()
        
    }
    
    
    // MARK: - Paytm
    
    func CheckPaytmTokes() {
        
        if PaytmToken == nil || PaytmToken! == "NA" || PaytmToken! == "" || PaytmMobile == nil || PaytmMobile! == "NA" || PaytmMobile! == "" {
            self.PaytmLink(isLink: true, Balance: "")
            return
        }
        
        CheckPaytmBalance()
    }
    
    func PaytmLink(isLink:Bool, Balance:String) {
        
        if isLink {
            PaymentsArr[1].State = PaymentOptionState.notLinked
            if PaymentType == .paytm{
                PaymentType = .cash
            }

//            PaymentType = .cash
        }
        else {
            var Done = PaymentMethodData()
            Done.balance = Balance
            Done.mobileNumber = DriveBookingResponce.PaytmWalletNo!
            PaymentsArr[1].State = PaymentOptionState.Done(Done)
//            PaymentType = .paytm

        }
        self.PaymentTable.reloadData()
    }
    
    //paytm get balance API
    
    func CheckPaytmBalance() {
        
        var Request = URLRequest.init(url: URL.init(string: "https://trust.paytm.in/wallet-web/checkBalance")!)
        Request.httpMethod = "GET"
        Request.allHTTPHeaderFields = ["ssotoken":PaytmToken!]
        
        Alamofire.request(Request)
            .responseJSON { (responce) in
                switch responce.result {
                case .success(let Value):
                    //print(Value)
                    let responsearray = Value as! [String:AnyObject]
                    
                    if let Responce = responsearray["response"] as? [String:AnyObject] {
                        
                        if Responce.keys.contains("amount") {
                            
                             let Balance = String.init(format: "%.2f", Float("\(Responce["amount"]!)")!)
                            
                            self.PaytmLink(isLink: false, Balance: "₹" + Balance)
                            SavePaytmBalance(token: Balance)
                            
                            
                            self.DriveBookingResponce.DefaultPaymentMode = "PAYTM"
                            saveDriveResponceStuct(driveStruct: self.DriveBookingResponce!)

                        }
                        else{
                            
                            self.DriveBookingResponce.DefaultPaymentMode = "CASH"
                            saveDriveResponceStuct(driveStruct: self.DriveBookingResponce!)
                            self.view.ShowBlackTostWithText(message: "Paytm is either not linked or needed Re-Authorize", Interval: 3)
                            self.PaytmLink(isLink: true, Balance: "")
                        }
                    }
                    else {
                        self.DriveBookingResponce.DefaultPaymentMode = "CASH"
                        saveDriveResponceStuct(driveStruct: self.DriveBookingResponce!)

                        self.view.ShowBlackTostWithText(message: "Paytm is either not linked or needed Re-Authorize", Interval: 3)
                        self.PaytmLink(isLink: true, Balance: "")
                    }
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    self.DriveBookingResponce.DefaultPaymentMode = "CASH"
                    saveDriveResponceStuct(driveStruct: self.DriveBookingResponce!)
                    self.PaytmLink(isLink: true, Balance: "")
                    self.view.ShowBlackTostWithText(message: "Paytm is either not linked or needed Re-Authorize", Interval: 3)
                    break
                }
                
        }
    }
    
    
    // Paytm SigninDelegate
    
    func PaytmDidSignInCancel(controller: PaytmSignInVC) {
        controller.navigationController?.popViewController(animated: true)
    }
    
    func PaytmDidSignInComplete(controller: PaytmSignInVC) {
        controller.navigationController?.popViewController(animated: true)
        
        // Get money
        self.DriveBookingResponce = FetchDriveResponce()
        
        PaytmToken = DriveBookingResponce.SSOToken!
        PaytmMobile = DriveBookingResponce.PaytmWalletNo!
        
        PaymentsArr[1].State = .loading
        
        CheckPaytmTokes()
    }
    
    // Paytm AddMoney Delegate
    
    func PaytmDidcancelAddMoney(controller: PatymAddMoney) {
        controller.navigationController?.popViewController(animated: true)
    }
    
    func PaytmDidCompleteAddMoney(controller: PatymAddMoney) {
        controller.navigationController?.popViewController(animated: true)
        
        // Get Money
        
        self.DriveBookingResponce = FetchDriveResponce()
        
        PaytmToken = DriveBookingResponce.SSOToken!
        PaytmMobile = DriveBookingResponce.PaytmWalletNo!
        
        PaymentsArr[1].State = .loading
        
        CheckPaytmTokes()
    }
    

    static let LoadingTxt = "Loading..."
    static let PaytmNotLinkedTxt = "Connect to your Paytm Wallet"
    static let MobiKwikNotLinkedTxt = "Connect to your MobiKwik Wallet"
    
}


extension PaymentSelectionVC: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return PaymentsArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "PaymentCashSelectCell", for: indexPath) as! PaymentCashSelectCell
            if FromRide_Street == "1"{
                cell.checkMark.isHidden = true
             }
            if FromRide_Street == "0"{

                if PaymentType == .cash {
                    cell.checkMark.isHidden = false
                }
                else {
                    cell.checkMark.isHidden = true
                }
            }
            cell.TitleLbl.text = PaymentsArr[indexPath.row].PaymentTitle!
            cell.TitleImage.image = PaymentsArr[indexPath.row].PaymentImage!
            cell.selectionStyle = .none
            return cell
        }
        else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "PaymentSelectCell", for: indexPath) as! PaymentSelectCell
 
            cell.TitleImage.image = PaymentsArr[indexPath.row].PaymentImage!
            if FromRide_Street == "1"{
                cell.checkMark.isHidden = true
                
            }
            if FromRide_Street == "0"{
                
                if PaymentType! == PaymentsArr[indexPath.row].PaymentTypeObj! {
                    cell.checkMark.isHidden = false
                }
                else {
                    cell.checkMark.isHidden = true
                }
                
                print(PaymentType)
            }
            switch PaymentsArr[indexPath.row].State! {
            case .notRequired:
                
                if PaymentsArr[indexPath.row].PaymentTypeObj == .paytm {
                    cell.BalanceDescLbl.text = PaymentSelectionVC.PaytmNotLinkedTxt
                }
                else if PaymentsArr[indexPath.row].PaymentTypeObj == .mobikwik {
                    cell.BalanceDescLbl.text = PaymentSelectionVC.MobiKwikNotLinkedTxt
                }
                else {
                    cell.BalanceDescLbl.text = PaymentSelectionVC.LoadingTxt
                }
                cell.TitleLbl.text = PaymentsArr[indexPath.row].PaymentTitle!
                
                break
            case .notLinked:
                if PaymentsArr[indexPath.row].PaymentTypeObj == .paytm {
                    cell.BalanceDescLbl.text = PaymentSelectionVC.PaytmNotLinkedTxt
                }
                else if PaymentsArr[indexPath.row].PaymentTypeObj == .mobikwik {
                    cell.BalanceDescLbl.text = PaymentSelectionVC.MobiKwikNotLinkedTxt
                }
                else {
                    cell.BalanceDescLbl.text = PaymentSelectionVC.LoadingTxt
                }
                cell.TitleLbl.text = PaymentsArr[indexPath.row].PaymentTitle!
                break
            case .loading:
                cell.BalanceDescLbl.text = PaymentSelectionVC.LoadingTxt
                cell.TitleLbl.text = PaymentsArr[indexPath.row].PaymentTitle!
                break
            case .Done(let Done):
                
                cell.BalanceDescLbl.text = "Available Balance: " + Done.balance
                cell.TitleLbl.text = PaymentsArr[indexPath.row].PaymentTitle! + " (" + Done.mobileNumber! + ")"
                break
            }
            
            cell.selectionStyle = .none
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        switch PaymentsArr[indexPath.row].State! {
        case .notRequired:
            PaymentType = .cash
            if FromRide_Street == "0"{

            self.Delegate.PaymentDidSelect(PaymentType: PaymentType, Balance: "0", controller: self)
            }
            if FromRide_Street == "1"{
            streetJOBPayment(SSOToken: "0", Wallettype: PaymentType, MobileNumber: DriveBookingResponce.PhoneNo!, Balance: "0")
            
            }
            break
        case .notLinked:
            if PaymentsArr[indexPath.row].PaymentTypeObj! == .paytm {
                let controller = self.storyboard?.instantiateViewController(withIdentifier: "PaytmSignInVC") as! PaytmSignInVC
                controller.Delegate = self
                self.navigationController?.pushViewController(controller, animated: true)
            }
            else if PaymentsArr[indexPath.row].PaymentTypeObj! == .mobikwik {
                let controller = self.storyboard?.instantiateViewController(withIdentifier: "MobiKwikSignInVc") as! MobiKwikSignInVc
                controller.Delegate = self
                self.navigationController?.pushViewController(controller, animated: true)
            }
            break
        case .loading:
            self.view.ShowBlackTostWithText(message: "Please wait while we loading data", Interval: 2)
            break
        case .Done(_):
            
            // check Money Condition
            let PaytmBalance = FetchPaytmBalance()
            let MobikwikBalance = FetchMobiKwikBalance()
            if PaymentsArr[indexPath.row].PaymentTypeObj! == .paytm {
//                self.MinimumBalanceRequired = 0.0
                if PaytmBalance == "NA" {
                    self.view.ShowBlackTostWithText(message: "Retry", Interval: 2)
                }
                else if self.MinimumBalanceRequired >= Float(PaytmBalance)! {
                    let MessageTxt = "Minimum Balance should be " + "₹" + String.init(format: "%.2f", self.MinimumBalanceRequired) + ". Please Add Money to your Paytm Wallet"
                    
                    Message.shared.Alert(Title: "Add Money", Message: MessageTxt, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "No"),Message.AlertActionWithSelector(Title: "Add", Selector: #selector(PaytmAddMoney), Controller: self)], Controller: self)
                }
                else {
                    PaymentType = .paytm
                    if FromRide_Street == "0"{
                        
                    self.Delegate.PaymentDidSelect(PaymentType: PaymentType, Balance: PaytmBalance, controller: self)
                    }
                    if FromRide_Street == "1"{
                        
                        streetJOBPayment(SSOToken: DriveBookingResponce.SSOToken!, Wallettype: PaymentType, MobileNumber: DriveBookingResponce.PaytmWalletNo!, Balance: PaytmBalance)

                    }

//                    self.Delegate.PaymentDidSelect(PaymentType: PaymentType, Balance: PaytmBalance, controller: self)
                }
                
            }
            else if PaymentsArr[indexPath.row].PaymentTypeObj! == .mobikwik {
//                self.MinimumBalanceRequired = -1
                if MobikwikBalance == "NA" {
                    self.view.ShowBlackTostWithText(message: "Retry", Interval: 2)
                }
                else if self.MinimumBalanceRequired >= Float(MobikwikBalance)! {
                    let MessageTxt = "Minimum Balance should be " + "₹" + String.init(format: "%.2f", self.MinimumBalanceRequired) + ". Please Add Money to your MobiKwik Wallet"
                    
                    Message.shared.Alert(Title: "Add Money", Message: MessageTxt, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "No"),Message.AlertActionWithSelector(Title: "Add", Selector: #selector(MobiAddMoney), Controller: self)], Controller: self)
                }
                else {
                    PaymentType = .mobikwik
                    if FromRide_Street == "0"{
                        
                        self.Delegate.PaymentDidSelect(PaymentType: PaymentType, Balance: MobikwikBalance, controller: self)
                    }
                    if FromRide_Street == "1"{
                        streetJOBPayment(SSOToken: DriveBookingResponce.WalletToken!, Wallettype: PaymentType, MobileNumber: DriveBookingResponce.WalletMobileNo!, Balance: MobikwikBalance)

                        
                    }

//                    self.Delegate.PaymentDidSelect(PaymentType: PaymentType, Balance: MobikwikBalance, controller: self)
                }
                
            }
            break
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 75
        }
        else {
            return 83
        }
    }
    
    func MobiAddMoney() {
        let controller = self.storyboard?.instantiateViewController(withIdentifier: "MobiKwikAddMoney") as! MobiKwikAddMoney
        controller.Delegate = self
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    func PaytmAddMoney() {
        let controller = self.storyboard?.instantiateViewController(withIdentifier: "PatymAddMoney") as! PatymAddMoney
        controller.Delegate = self
        self.navigationController?.pushViewController(controller, animated: true)
    }
}

class PaymentSelectCell: UITableViewCell {
    @IBOutlet var TitleLbl: UILabel!
    @IBOutlet var TitleImage: UIImageView!
    @IBOutlet var BalanceDescLbl: UILabel!
    @IBOutlet var checkMark: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}

class PaymentCashSelectCell: UITableViewCell {
    @IBOutlet var TitleLbl: UILabel!
    @IBOutlet var TitleImage: UIImageView!
    @IBOutlet var checkMark: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}

enum PaymentType {
    case cash, paytm, mobikwik
}

