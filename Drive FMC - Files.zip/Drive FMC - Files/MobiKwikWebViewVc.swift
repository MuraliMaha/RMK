//
//  MobiKwikWebViewVc.swift
//  DriveBooking
//
//  Created by Amarnath B on 22/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit
import Alamofire
class MobiKwikWebViewVc: UIViewController, UIWebViewDelegate {

    @IBOutlet var MobiKwikView: UIWebView!

    var PostUrl: URL!
    
    var Delegate: MobiKwikTransactionDelegate!
    var MobiKwikTransctionContent: MobiKwikValue!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationItem.title = "Payment"
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.black
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
        self.navigationItem.leftBarButtonItem = BackBtnItem
        
        // Do any additional setup after loading the view.
        self.view.StartLoading()

        
        //Load Mobikwik add money url into webVIew
        MobiKwikView.loadRequest(URLRequest.init(url: PostUrl!))
    }
    
    func BackAction() {
        self.Delegate.TransactionDidCancel(controller: self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        //print(error.localizedDescription)
    }
    func webViewDidStartLoad(_ webView: UIWebView) {
    }
    func webViewDidFinishLoad(_ webView: UIWebView) {
        self.view.StopLoading()
        if (webView.request?.url != nil) {
            if (webView.request?.url?.absoluteString)! == MobiCreds.RedirectUrl {
                LoadWithRequest(request: webView.request!)
            }
        }
    }
    func webView(_ webView: UIWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        
        return true
    }

    func LoadWithRequest(request:URLRequest) {
        
        self.view.StartLoading()
        
        Alamofire.request(request)
            .responseJSON { (responce) in
                
                self.view.StopLoading()

                if (responce.data != nil) {
                    let StatusCode = self.MobiKwikView.stringByEvaluatingJavaScript(from: "document.getElementById(\"txtStatuscode\").value")!
                    let StatusMsg = self.MobiKwikView.stringByEvaluatingJavaScript(from: "document.getElementById(\"txtStatusmessage\").value")!
                    let OrderID = self.MobiKwikView.stringByEvaluatingJavaScript(from: "document.getElementById(\"txtOrderID\").value")!
                    let Amount = self.MobiKwikView.stringByEvaluatingJavaScript(from: "document.getElementById(\"txtAmount\").value")!

                    var value = MobiKwikValue()
                    value.statusCode = StatusCode
                    value.statusMsg = StatusMsg
                    value.orderID = OrderID
                    value.amount = Amount
                    
                    if StatusCode == "0" {
                        let result = MobiKwikTransactionResult.success(value)

                        self.Delegate.TransactionDidComplete(Result: result, controller: self)
                    }
                    else {
                        let result = MobiKwikTransactionResult.failure(value)

                        self.Delegate.TransactionDidComplete(Result: result, controller: self)
                    }
                }
                else {
                    
                    var value = MobiKwikValue()
                    value.statusCode = "41"
                    value.statusMsg = "Unable to process Transaction"
                    value.orderID = self.MobiKwikTransctionContent.orderID!
                    value.amount = self.MobiKwikTransctionContent.amount!
                    
                    let result = MobiKwikTransactionResult.failure(value)
                    
                    self.Delegate.TransactionDidComplete(Result: result, controller: self)
                }
        }
    }
    
}

protocol MobiKwikTransactionDelegate {
    func TransactionDidCancel(controller:MobiKwikWebViewVc)
    func TransactionDidComplete(Result:MobiKwikTransactionResult, controller:MobiKwikWebViewVc)
}

enum MobiKwikTransactionResult {
    case success(MobiKwikValue)
    case failure(MobiKwikValue)
    
    public var isSuccess: Bool {
        switch self {
        case .success:
            return true
        case .failure:
            return false
        }
    }
    
    public var isFailure: Bool {
        return !isSuccess
    }
    
    public var value: MobiKwikValue? {
        switch self {
        case .success(let value):
            return value
        case .failure:
            return nil
        }
    }
    
    public var failure: MobiKwikValue? {
        switch self {
        case .success:
            return nil
        case .failure(let error):
            return error
        }
    }

}

struct MobiKwikValue {
    var statusCode: String!
    var statusMsg: String!
    var orderID: String!
    var amount: String!
}


