//
//  SplashScreenVC.swift
//  DriveFindMyCab
//
//  Created by Admin on 31/03/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit
import OneSignal
import FirebaseInstanceID

class SplashScreenVC: UIViewController {

    @IBOutlet var Version:UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.p
        
        DispatchQueue.main.async {
            self.Version.text = "V " + "\(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString")!)"
        }
        
        Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(Call), userInfo: nil, repeats: false)
    }
    
   
    func Call() {
        
        if !(Reachability()!.isReachable) {
            
            UtilitiesClass.Alert(Title: "Alert!", Message: Constants.NetErrorMsg as NSString, Actions: [UtilitiesClass.AlertActionWithSelector(Title: "Ok", Selector: #selector(QuitApp), Controller: self)], Controller: self)

        }
        else {
            
            guard FetchLoginResponce() != nil  else {
                GoToLogin()
                return
            }
            
            CallService()
        }
        
    }
    
    func GoToLogin() {
        let LoginObj = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        present(LoginObj, animated: true, completion: nil)
    }
    
    func QuitApp() {
        exit(0)
    }
    
    var LoginDetails:LoginDetails!


    func CallService() {
        
        if let LoginDetal = FetchLoginDetails() {
            
            LoginDetails = LoginDetal
            self.view.StartLoading()

//            var OneSignalID = ""
//            let State = OneSignal.getPermissionSubscriptionState()
//            if State?.permissionStatus.status == .authorized {
//
//                if State?.subscriptionStatus.userId != nil {
//                    OneSignalID = "\((State?.subscriptionStatus.userId!)!)"
//                    LoginDetails.DeviceToken = OneSignalID
//                    print("OnesignalID::::",OneSignalID)
//                }
//
//            }
//
//            let RequestDict = ["EmpCode":LoginDetal.UserID!,"EmpPassword":LoginDetal.Password!,"DeviceType":LoginDetal.DeviceType!,"DeviceIMEI":LoginDetal.DeviceIMEI!,"DeviceToken":"\(OneSignalID)"]
            
//            let fcmDeviceToken :String = InstanceID.instanceID().token()!
//            print("FCM token from Splashscreen: \(fcmDeviceToken)")
            
            var fcmDeviceToken = ""
            
            if InstanceID.instanceID().token() != nil {
                fcmDeviceToken = InstanceID.instanceID().token()!
                
                let RequestDict = ["EmpCode":LoginDetal.UserID!,"EmpPassword":LoginDetal.Password!,"DeviceType":LoginDetal.DeviceType!,"DeviceIMEI":LoginDetal.DeviceIMEI!,"DeviceToken":fcmDeviceToken]
                
                print("Login Input = ",RequestDict)
                
                WebService().callAutoAPI(Suffix: WebServicesUrl.LoginApi, parameterDict: RequestDict, completion: { (dataDict, success) in
                    
                    self.view.StopLoading()
                    print("Login Response from Splash = ",dataDict)
                    if success {
                        // handel of data
                        if let Dict = dataDict {
                            let Arr = Dict["data"] as! [[String:AnyObject]]
                            let ResponceData = Arr[0]
                            print(Arr);
                            
                            if ResponceData.keys.contains("Response") {
                                self.GoToLogin()
                            }
                            else {
                                
                                SaveLoginDetailsWithStruct(Struct: self.LoginDetails)
                                SaveLoginResponce(Responcedict: ResponceData)
                                
                                let NavMain = self.storyboard?.instantiateViewController(withIdentifier: "LGSideMenu")
                                self.present(NavMain!, animated: true, completion: nil)
                            }
                        }
                        else {
                            Message.shared.Alert(Title: "", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithSelector(Title: "quit", Selector: #selector(self.QuitApp), Controller: self),Message.AlertActionWithSelector(Title: "retry", Selector: #selector(self.CallService), Controller: self)], Controller: self)
                        }
                    }
                    else {
                        Message.shared.Alert(Title: "", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithSelector(Title: "quit", Selector: #selector(self.QuitApp), Controller: self),Message.AlertActionWithSelector(Title: "retry", Selector: #selector(self.CallService), Controller: self)], Controller: self)
                    }
                })
            }else{
                self.view.StopLoading()
//                self.view.ShowBlackTostWithText(message: "Device Registration Fails...", Interval: 3.0)
//                Timer.scheduledTimer(timeInterval: 4.0, target: self, selector: #selector(self.QuitApp), userInfo: nil, repeats: false)

                Message.shared.Alert(Title: "Registration", Message: "Device Registration Fails...", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithSelector(Title: "quit", Selector: #selector(self.QuitApp), Controller: self),Message.AlertActionWithSelector(Title: "retry", Selector: #selector(self.CallService), Controller: self)], Controller: self)
            }
            

        }
        else {
            
            self.GoToLogin()
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
