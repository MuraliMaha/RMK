//
//  SafeHomePopView.swift
//  DriveFindMyCab
//
//  Created by Admin on 12/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit

class SafeHomePopView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    @IBOutlet var BodyText:UILabel!
    @IBOutlet var OkBtn:UIButton!

}
