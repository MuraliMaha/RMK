//
//  Constants.swift
//  DriveBooking
//
//  Created by Raja Bhuma on 12/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit

struct GOOGLEKeys {
    static let DummyKey = "AIzaSyBwKzcInt-L0LPdWeRDoSeZtDhigdlkvng"

//    static let MainKey = "AIzaSyB3lb1fCGobT25ehTkwsGqVPNaaeK33mjc";
    
    //      New Key Created on 27 Mar 2018 - AIzaSyAVuxAMxJb-f6ephaeJ1oiOrUG4fTLAFao
    static let MainKey = "AIzaSyAVuxAMxJb-f6ephaeJ1oiOrUG4fTLAFao";
}

struct Constants {
    static let NetErrorMsg = "please Check your Internet Connection. Turn on mobile data or use WiFi"
//    static let InternalError = "Something went wrong..!"
    static let InternalError = "please Check your Internet Connection..!"
    static let InternetErrorMsg = "please Check your Internet Connection..!"
    static let BookingType = "Meter Tariff"
}

struct WebServicesUrl
{
    
    static let MainBaseUrl = ""

    
    static let SunBaseUrl = ""
    static let NotifUrl = ""
    
    static let LoginApi = "GetEMSEmplLogin"
    static let ResetPass = "EMSEmpForgetPassword"
    
    static let GetPlacesAPI = ""

    
    static let GetLocationofShuttleServiceIOS = "GetLocationofShuttleServiceIOS"
//    static let ShuttleServiceLocation = "ShuttleServiceLocation"
    static let EmpRequestList = "EMSEmpRequestDetails"
    
//    static let AdhocRequest = "InsCabRequestWithShiftType"
    static let AdhocRequest = "InsCabRequestWithShiftTypeNew"
    
    static let LeaveTypesFetch = "GetEMSLeaveTypes"
    static let EmployeeLeaveRequest = "InsEmployeeLeaveRequest"
    
    static let GetEMSTipHistory = "GetEMSTipHistory"
    static let EMSEmpTripCancelNew = "EMSEmpTripCancelNew"
    
    static let InsEmployeeNotificationSettings = "InsEmployeeNotificationSettings"
    
    
    static let GetEventDetails = "GetEventDetails"
    
    static let ProfileUpdate = "EMSEmpProfileUpdate"
    static let UpdatePassword = "EMSEmpUpdatePassword"
    
    static let EMSRateYourTrip = "EMSRateYourTrip"
    
//    static let FetchAddress = "SetLocationDetails"
    static let FetchAddress = "SetLocationDetailsNew"
//    static let ChangeAddress = "InsChangeAddress"
    static let ChangeAddress = "InsChangeAddressNew"
    
    
    
    static let SafeHomeDetails = "SafeHomeDetails"
    static let EMSEmpSafeHomeReach = "EMSEmpSafeHomeReach"
    
    // drive corporate
    
    static let DriveBookingBase = ""
    static let DummySecurity = "A5F0E074-2A1E-4C39-84C4-0E28296BC54D"
    
    static let DriveLogin = "LoginUser"
    static let DriveGetOtp = "GetOtp"
    static let DriveRegisterUser = "RegisterUser"
    static let DriveGetUpdatedPassword = "GetUpdatedPassword"
    static let DriveSetUpdatedName = "GetProfileDetail"
    static let DriveSetFavouritePlaces = "SetFavouritePlaces"
    static let DriveVehicleModelDetails = "VehicleModelDetails"
    
    static let DriveBookingWithWallets = "BookingWithWallets"
    
    static let DrivePackageTariffs = "GetPackageTariff"
    static let DriveEstimateRideForBooking = "EstimateRideForBooking"
    static let DriveCheckCouponCode = "CheckCouponCode"
    static let DriveBookingWithPayTm = "BookingWithPayTm"
    static let DriveGetOffers = "GetOffer"
    static let DriveBookingsHistory = "BookingsHistory"
    static let DrivePaytmAccessDetails = "PaytmAccessDetails"
    static let DriveCancellationReasons = "CancellationReasons"
    static let DriveCancelBooking = "CancelBooking"
    static let EmergencyContactDetails = "EmergencyContactDetails"
    static let WalletPaymentForStreetJobs = "WalletPaymentForStreetJobs"

    static let PaytmTransactionDetails = "PaytmTransactionDetails"
    
    static let GetNotificationDetails = "GetNotificationDetails"
    
    // Ride Now
    
    static let DriveAvailableVehicles = "AvailableVehicles"
    static let DriveRateCard = "GetRateCard"
    
    static let CallgooglePlacesAPI = "GetGoogleLocation"

    
    // Track Page
    static let DriveGetBookingDetails = "GetBookingDetails"
    static let DriveRateYourRide = "RateYourRide"
    static let DriveContactCustomerCare = "ContactCustomerCare"
    static let DriveRequestInvoice = "GetInvoice"
    
    static let DriveReDispatch = "ReDispatch"
    static let DriveWalletAccessDetails = "WalletAccessDetails"
    
    //Shift Request
//    static let DriveShiftChangeRequestList = "ShiftChangeRequestList"
    static let DriveShiftChangeList = "ShiftChangeList"
    static let DriveShiftTime = "ShiftTimings"
    static let DriveShiftChangeRequest = "ShiftChangeRequest"
    
    //PlanMyTrip
    static let EditPlannedTrip = "EditPlannedTrip"
    
    static let EmpAuthenticationNotification = "FMCappNotification"
    static let DriveCancelRequest = "CancelRequest"
    
    static let PlanMySchedule = "PlanMySchedule"
    static let CancelCutoffRequest = "CancelCutoffRequest"
    
    static let AdhocTripRequestDetails = "getAdhocTripRequestDetails"
    
}

struct StaticCredentials {
    
    //Stpl Credential
//    static let VendorId = "1246"
//    static let CorporateId = "10620"
//    static let AppCustomerType = "2"

    //VendorTest Credential
    static let VendorId = "1196"
    static let CorporateId = "10490"
    static let AppCustomerType = "2"
    
    
}
