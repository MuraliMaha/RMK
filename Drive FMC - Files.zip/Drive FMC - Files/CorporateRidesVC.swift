//
//  CorporateRidesVC.swift
//  DriveFindMyCab
//
//  Created by Admin on 01/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit

class CorporateTripCell:UITableViewCell {
    
    @IBOutlet var TripIDLbl: UILabel!
    @IBOutlet var VehicleNoLbl: UILabel!
    @IBOutlet var DateLbl: UILabel!
    @IBOutlet var ShiftTypeLbl: UILabel!
    @IBOutlet var StatusLbl: UILabel!
    @IBOutlet var CancelBtn: UIButton!

    override func awakeFromNib() {
        super.awakeFromNib()
    }
}

class CorporateRidesVC: UIViewController {

    @IBOutlet var CorporateTB: UITableView!

    
    var LoginResponce:LoginResponce!
    var LoginDetails:LoginDetails!
    
    var CorporateTripsArr = [[String:AnyObject]]()
    
    var companyName = "HPE"
    var cancelReason : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        LoginDetails = FetchLoginDetails()
        LoginResponce = FetchLoginResponce()


        // Do any additional setup after loading the view.
        
        CorporateTB.tableFooterView = UIView.init(frame: CGRect.zero)
        CorporateTB.estimatedRowHeight = 103
        CorporateTB.rowHeight = UITableViewAutomaticDimension
        
//        CallCorporateRides()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        CallCorporateRides()
    }
    
    func CallCorporateRides() {
        
        if (Reachability()?.isReachable)! {
            
            UIApplication.shared.keyWindow?.StartLoading()
            
            let ParamsDict = ["EmpCode":"\(LoginDetails.UserID!)"]
            print("MyTrips input is,",ParamsDict)
            WebService().callAutoAPI(Suffix: WebServicesUrl.GetEMSTipHistory, parameterDict: ParamsDict, completion: { (dataDict, success) in
                
                UIApplication.shared.keyWindow?.StopLoading()
                
                if success {
                    // handel of data
                    if let ResponceDict = dataDict {
                        
                        let Arr = ResponceDict["data"] as! [[String:AnyObject]]
                        
                        if Arr.count != 0 {
                            self.CorporateTripsArr = Arr
                            self.CorporateTB.isHidden = false
                        }
                        else {
                            self.CorporateTB.isHidden = true
                        }
                        
                        DispatchQueue.main.async {
                            self.CorporateTB.reloadData()
                        }
                    }
                    else {
                        UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 3)
                    }
                }
                else {
                    UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 3)
                }
            })
            
        }
        else {
            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Check for Internet Conenction", Interval: 3)
        }

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    var SelectedIndex = 0
    
    func cancelAction(_ sender:UIButton) {
        print(sender.tag)
        SelectedIndex = sender.tag
        if (Reachability()?.isReachable)! {
            
            UtilitiesClass.Alert(Title: "Cancel Trip.", Message: "Are you sure you want cancel Trip?", Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "NO"),UtilitiesClass.AlertActionWithSelector(Title: "YES", Selector: #selector(self.CancelTripFunc), Controller: self)], Controller: self)
            
            /*
            if "\(CorporateTripsArr[SelectedIndex]["corporatename"]!)" == "PwCSDC" {
                UtilitiesClass.Alert(Title: "Cancel Trip.", Message: "Are you sure you want cancel Trip?", Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "NO"),UtilitiesClass.AlertActionWithSelector(Title: "YES", Selector: #selector(self.confirmCancelForPwCSDC), Controller: self)], Controller: self)
            }else{
                UtilitiesClass.Alert(Title: "Cancel Trip.", Message: "Are you sure you want cancel Trip?", Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "NO"),UtilitiesClass.AlertActionWithSelector(Title: "YES", Selector: #selector(self.CancelTripFunc), Controller: self)], Controller: self)
            } */
            
            
            
            
        }
        else {
            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Check for Internet Conenction", Interval: 3)
        }
    }
    /*
    func confirmCancelForPwCSDC() {
        CancelTripAfterCutOffTime()
//        UtilitiesClass.Alert(Title: "Confirm Cancel Trip?", Message: "Are you sure?This trip will get cancelled and you can make new cab request", Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "NO"),UtilitiesClass.AlertActionWithSelector(Title: "YES", Selector: #selector(self.CancelTripFunc), Controller: self)], Controller: self)
    } */
    func CancelTripAfterCutOffTime(){
        UIApplication.shared.keyWindow?.StartLoading()
        
        let ParamsDictForAfterCutOffTime = ["EmpCode":"\(LoginDetails.UserID!)","TripCode":"\(CorporateTripsArr[SelectedIndex]["TripCode"]!)","CancelReason":"\(self.cancelReason!)"]
        print("ParamsDict of CancelTripAfterCutOffTime = ",ParamsDictForAfterCutOffTime)
        
        WebService().callAutoAPI(Suffix: WebServicesUrl.CancelCutoffRequest, parameterDict: ParamsDictForAfterCutOffTime, completion: { (dataDict, success) in
            
            UIApplication.shared.keyWindow?.StopLoading()
            
            if success {
                // handel of data
                if let ResponceDict = dataDict {
                    
                    let Arr = ResponceDict["data"] as! [[String:AnyObject]]
                    let Dict = Arr[0]
                    
                    if Dict.keys.contains("TripCode") {
//                        self.CallCorporateRides()
                        let Controller = self.storyboard?.instantiateViewController(withIdentifier: "AdhocRequest") as! AdhocRequest
                        self.navigationController?.pushViewController(Controller, animated: true)
                        
                    }
                    else {

                        UtilitiesClass.Alert(Title: "Cancellation", Message: "\(Dict["Response"]!)" as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "OK")], Controller: self)
                    }
                    
                }
                else {
                    UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 3)
                }
            }
            else {
                UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 3)
            }
        })
    }
    func CancelTripFunc() {
        
        UIApplication.shared.keyWindow?.StartLoading()
        
        let ParamsDict = ["EmpCode":"\(LoginDetails.UserID!)","TripCode":"\(CorporateTripsArr[SelectedIndex]["TripCode"]!)"]
        print("ParamsDict = ",ParamsDict)
        WebService().callAutoAPI(Suffix: WebServicesUrl.EMSEmpTripCancelNew, parameterDict: ParamsDict, completion: { (dataDict, success) in
            
            UIApplication.shared.keyWindow?.StopLoading()
            
            if success {
                // handel of data
                if let ResponceDict = dataDict {
                    
                    let Arr = ResponceDict["data"] as! [[String:AnyObject]]
                    let Dict = Arr[0]
                    
                    if Dict.keys.contains("TripCode") {
                        self.CallCorporateRides()
                      
                        /*
                        if "\(self.CorporateTripsArr[self.SelectedIndex]["corporatename"]!)" == "PwCSDC"
                        {
                        
                            let Controller = self.storyboard?.instantiateViewController(withIdentifier: "AdhocRequest") as! AdhocRequest
                            self.navigationController?.pushViewController(Controller, animated: true)
                        }else{
                            self.CallCorporateRides()
                        } */
                        
                    }
                    else {
                        if "\(Dict["Response"]!)" as NSString == "PWCsdc"{
                            print("after cutoff time....")
                            
                            /*
                            //1. Create the alert controller.
                            let alert = UIAlertController(title: "Reason", message: "What is the reason to cancel?", preferredStyle: .alert)
                            
                            //2. Add the text field. You can configure it however you need.
                            alert.addTextField { (textField) in
                                textField.text = ""
                            }
                            
                            // 3. Grab the value from the text field, and print it when the user clicks OK.
                            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak alert] (_) in
                                let textField = alert?.textFields![0] // Force unwrapping because we know it exists.
                                print("Text field: \(textField?.text)")
                                
                                self.cancelReason = "\(textField?.text)"
                                
                                if let abc = self.cancelReason {
                                    UtilitiesClass.Alert(Title: "Terms", Message: "Previous Trip will be marked as no show", Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "DisAgree"),UtilitiesClass.AlertActionWithSelector(Title: "Agree", Selector: #selector(self.CancelTripAfterCutOffTime), Controller: self)], Controller: self)
                                }
                                
                                
                            }))
                            
                            // 4. Present the alert.
                            self.present(alert, animated: true, completion: nil)
                            */
                            
                            let alertController = UIAlertController(title: "Add New Name", message: "", preferredStyle: .alert)
                            alertController.addTextField { (textField : UITextField!) -> Void in
                                textField.placeholder = "Enter Second Name"
//                                self.cancelReason =
                                let abc = alertController.textFields![0] as UITextField
                                print ("The Text is ",abc.text)
                            }
                            let saveAction = UIAlertAction(title: "Save", style: .default, handler: { alert -> Void in
                                let firstTextField = alertController.textFields![0] as UITextField
                                let secondTextField = alertController.textFields![1] as UITextField
                                print("firstName \(firstTextField.text!), secondName \(secondTextField.text)!")
                            })
                            let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: { (action : UIAlertAction!) -> Void in })
                            alertController.addTextField { (textField : UITextField!) -> Void in
                                textField.placeholder = "Enter First Name"
                            }
                            
                            alertController.addAction(saveAction)
                            alertController.addAction(cancelAction)
                            
                            self.present(alertController, animated: true, completion: nil)
                            
                        }else{
                             UtilitiesClass.Alert(Title: "Cancellation", Message: "\(Dict["Response"]!)" as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "OK")], Controller: self)
                        }
                        
                       
                        
                       
                    }
                    
                }
                else {
                    UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 3)
                }
            }
            else {
                UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 3)
            }
        })
    }
}

extension CorporateRidesVC: UITableViewDelegate,UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return CorporateTripsArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CorporateTripCell", for: indexPath) as! CorporateTripCell
        
        cell.CancelBtn.isHidden = true
        
        cell.TripIDLbl.text = "\(CorporateTripsArr[indexPath.row]["TripCode"]!)"
        cell.VehicleNoLbl.text = "\(CorporateTripsArr[indexPath.row]["VehicleNo"]!)"
        cell.DateLbl.text = "\(CorporateTripsArr[indexPath.row]["Date"]!)"
        cell.ShiftTypeLbl.text = "\(CorporateTripsArr[indexPath.row]["ShiftType"]!)"
        cell.StatusLbl.text = "\(CorporateTripsArr[indexPath.row]["Status"]!)"
        
        if cell.StatusLbl.text == "NotStarted" {
            cell.StatusLbl.backgroundColor =  UIColor.init(red: 242.0/255.0, green: 203.0/255.0, blue: 29.0/255.0, alpha: 1)
            
            if LoginResponce.CompanyName == "HPE" {
//            if self.companyName == "HPE" {
                cell.CancelBtn.isHidden = true
            }else{
                cell.CancelBtn.isHidden=false
                cell.CancelBtn.addTarget(self, action: #selector(cancelAction(_:)), for: .touchUpInside)
                cell.CancelBtn.tag  = indexPath.row
            }
            
        }
        else if cell.StatusLbl.text == "NoShow" {
            cell.StatusLbl.backgroundColor = UIColor.init(red: 255.0/255.0, green: 163.0/255.0, blue: 0.0, alpha: 1)
            cell.CancelBtn.isHidden = true
        }
        else if cell.StatusLbl.text == "Logged In" {
            cell.CancelBtn.isHidden = true
            cell.StatusLbl.backgroundColor = UIColor.init(red: 255.0/255.0, green: 163.0/255.0, blue: 0.0, alpha: 1)
        }
        else if cell.StatusLbl.text == "Logged Out"{
            cell.CancelBtn.isHidden = true
            cell.StatusLbl.backgroundColor = UIColor.init(red: 54.0/255.0, green: 141.0/255.0, blue: 32.0/255.0, alpha: 1)
        }
        else if cell.StatusLbl.text == "Cancelled" {
            cell.CancelBtn.isHidden=true
            cell.StatusLbl.backgroundColor = UIColor.red
        }
        
        cell.selectionStyle = .none
        
        return cell
    }
    
}
