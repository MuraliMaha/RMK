//
//  NotificationView.swift
//  DriveFindMyCab
//
//  Created by Admin on 07/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit

class NotificationView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    @IBOutlet var BodyText:UILabel!
    
    @IBAction func OkBtnPressed(_ sender:UIButton) {
        
        UIView.animate(withDuration: 0.3, animations: {
            self.alpha = 0
        })
        { (yes) in
            if yes {
                self.alpha = 1
                self.superview?.removeFromSuperview()
            }
            
        }
        
    }
    
    

}
