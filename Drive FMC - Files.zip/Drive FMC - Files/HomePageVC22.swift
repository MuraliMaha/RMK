//
//  HomePageVC.swift
//  DriveFindMyCab
//
//  Created by SunTelematics on 07/05/18.
//  Copyright © 2018 Suntelematics. All rights reserved.
//

import UIKit

class HomePageVC22: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        print("Home Page")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Slider Actions And Settings {
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        sideMenuController?.isLeftViewEnabled = true
        NotificationCenter.default.addObserver(self, selector: #selector(self.CallForLogout), name:NotificationStruct.LogOutNotif , object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(self.CallForHelpDesk), name:NotificationStruct.HelpDeskNotif , object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sideMenuController?.isLeftViewEnabled = false
        NotificationCenter.default.removeObserver(self, name: NotificationStruct.LogOutNotif, object: nil)
//        NotificationCenter.default.removeObserver(self, name: NotificationStruct.HelpDeskNotif, object: nil)
    }
    @IBAction func LeftMenuAction(_ sender:UIBarButtonItem) {
        sideMenuController?.showLeftView(animated: true, completionHandler: nil)
    }
    
    
    
    func CallForLogout() {
        UtilitiesClass.Alert(Title: "Log Out", Message: "Are you sure?", Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "CANCEL"),UtilitiesClass.AlertActionWithSelector(Title: "OK", Selector: #selector(LogoutOkAction), Controller: self)], Controller: self)
    }
    var EmergencyArr = [EmergencyCStruct]()
    func LogoutOkAction() {
        // Clear all here //
        
        self.view.StartLoading()
        
        GetContacts()
        
        let defaults = UserDefaults.standard
        defaults.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
        defaults.synchronize()
        
        if EmergencyArr.count >= 0 {
            SaveEmergencyContacts(EmergencyArr: EmergencyArr)
        }
        
        self.view.StopLoading()
        
        let LoginObj = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC22SBID") as! LoginVC22
        present(LoginObj, animated: true, completion: nil)
        
    }
    
    func GetContacts() {
        guard FetchEmergencyContacts() != nil  else {
            return
        }
        EmergencyArr = FetchEmergencyContacts()!
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func logoutBtnTapped(_ sender: UIButton) {
        
        
        // Clear all here //
        
        self.view.StartLoading()
        
        GetContacts()
        
        let defaults = UserDefaults.standard
        defaults.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
        defaults.synchronize()
        
        if EmergencyArr.count >= 0 {
            SaveEmergencyContacts(EmergencyArr: EmergencyArr)
        }
        
        self.view.StopLoading()
    
//        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC22SBID") as! LoginVC22
//        self.present(ctrl, animated: true, completion: nil)
        
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "NavigationCtrl1SBID")
        self.present(ctrl!, animated: true, completion: nil)
    }
    
}
