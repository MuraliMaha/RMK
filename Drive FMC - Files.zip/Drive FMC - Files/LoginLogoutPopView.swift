//
//  LoginLogoutPopView.swift
//  DriveFindMyCab
//
//  Created by SunTelematics on 14/08/18.
//  Copyright © 2018 Suntelematics. All rights reserved.
//

import UIKit

class LoginLogoutPopView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

    @IBOutlet weak var bodyTextLbl: UILabel!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var okBtn: UIButton!
}
