//
//  LoginVC.swift
//  DriveFindMyCab
//
//  Created by Admin on 31/03/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit
import OneSignal
import FirebaseInstanceID
import FirebaseAnalytics

class LoginVC: UIViewController {

    @IBOutlet var UserIDTxt : UITextField!
    @IBOutlet var PasswordTxt : UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardHide(_:)), name: .UIKeyboardWillHide, object: nil)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    //MARK: - Keyboard show
    
    func keyboardShow(_ notification : NSNotification){
        
        let info = notification.userInfo
        let keyboardframe = (info![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size
        var frame = CGRect.init()
        if UserIDTxt.isFirstResponder {
            frame = UserIDTxt.frame
        }
        else {
            frame = PasswordTxt.frame
        }
        
        var actualframe = self.view.frame
        actualframe.size.height -= keyboardframe.height
        actualframe.size.height -= (frame.size.height)
        
        if !actualframe.contains((frame.origin)) {
            let yfinal = (frame.origin.y) - actualframe.size.height
            
            UIView.animate(withDuration: 0.3, animations: { () -> Void in
                self.view.frame.origin.y -= yfinal
            })
            
        }
    }
    // MARK: - keyboard hide
    
    func keyboardHide(_ notification : NSNotification)
    {
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.view.frame.origin.y = 0
        })
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func QuitApp() {
        exit(0)
    }
    // MARK: - Actions {
    
    func callLoginService() {
        if (Reachability()?.isReachable)! {
            self.view.StartLoading()
            
            //                var OneSignalID = ""
            //                let State = OneSignal.getPermissionSubscriptionState()
            //                if State?.permissionStatus.status == .authorized {
            //                    if State?.subscriptionStatus.userId != nil {
            //                        OneSignalID = "\((State?.subscriptionStatus.userId!)!)"
            //                        print("OnesignalID::::",OneSignalID)
            //                    }
            //                }
            //
            //                let RequestDict = ["EmpCode":UserIDTxt.text!,"EmpPassword":PasswordTxt.text!,"DeviceType":UIDevice.current.systemName,"DeviceIMEI":UIDevice.current.identifierForVendor!.uuidString,"DeviceToken":"\(OneSignalID)"]
            
            
            
            
            //                let fcmDeviceToken = InstanceID.instanceID().token()
            //                print("FCM token from LoginVC : \(fcmDeviceToken ?? "")")
            
            var fcmDeviceToken = ""
            
            if InstanceID.instanceID().token() != nil {
                fcmDeviceToken = InstanceID.instanceID().token()!
                
                let RequestDict : [String:String] = ["EmpCode":UserIDTxt.text!,"EmpPassword":PasswordTxt.text!,"DeviceType":UIDevice.current.systemName,"DeviceIMEI":UIDevice.current.identifierForVendor!.uuidString,"DeviceToken":fcmDeviceToken]
               print("Login Response from Login..",RequestDict)
                
                WebService().callAutoAPI(Suffix: WebServicesUrl.LoginApi, parameterDict: RequestDict, completion: { (dataDict, success) in
                    
                    self.view.StopLoading()
                    
                    if success {
                        // handel of data
                        if let Dict = dataDict {
                            let Arr = Dict["data"] as! [[String:AnyObject]]
                            let ResponceData = Arr[0]
                            if ResponceData.keys.contains("Response") {
                                UtilitiesClass.Alert(Title: "Alert!", Message: ResponceData["Response"] as! NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                            }
                            else {
                                SaveLoginDetails(LoginDetailsdict: RequestDict)
                                SaveLoginResponce(Responcedict: ResponceData)
                                
                                let NavMain = self.storyboard?.instantiateViewController(withIdentifier: "LGSideMenu")
                                self.present(NavMain!, animated: true, completion: nil)
                            }
                        }
                        else {
                            UtilitiesClass.Alert(Title: "Alert!", Message: Constants.InternalError as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                        }
                    }
                    else {
                        UtilitiesClass.Alert(Title: "Alert!", Message: Constants.InternalError as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                })
            } else{
                self.view.StopLoading()
                //                    self.view.ShowBlackTostWithText(message: "Device Registration Fails...", Interval: 3.0)
                //                    Timer.scheduledTimer(timeInterval: 4.0, target: self, selector: #selector(self.QuitApp), userInfo: nil, repeats: false)
                
                Message.shared.Alert(Title: "Registration", Message: "Device Registration Fails...", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithSelector(Title: "quit", Selector: #selector(self.QuitApp), Controller: self),Message.AlertActionWithSelector(Title: "retry", Selector: #selector(self.callLoginService), Controller: self)], Controller: self)
            }
        }
        else {
            UtilitiesClass.Alert(Title: "Alert!", Message: Constants.NetErrorMsg as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
        }
    }
    
    @IBAction func LOGIN_BtnPressed(_ sender:UIButton) {
        
        if UserIDTxt.isFirstResponder {
            UserIDTxt.resignFirstResponder()
        }else{
            PasswordTxt.resignFirstResponder()
        }
        
        
        Analytics.logEvent("RMKLogin", parameters: [
            "userName": "\(UserIDTxt.text!)",
            "LoginID": "100"
            ])
        
        
        
        if UtilitiesClassSub.removeLeadingandTralingSpace(UserIDTxt.text!).characters.count == 0 {
            UtilitiesClass.Alert(Title: "Alert!", Message: "UserId should not be empty", Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
        }
        else if UtilitiesClassSub.removeLeadingandTralingSpace(PasswordTxt.text!).characters.count == 0 {
            UtilitiesClass.Alert(Title: "Alert!", Message: "Password should not be empty", Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
        }
        else {
            
            callLoginService()
            
        }
        
    }
    
    @IBAction func ResetPassword_BtnPressed(_ sender:UIButton) {
        let resetPassword = self.storyboard?.instantiateViewController(withIdentifier: "ResetPassVC") as! ResetPassVC
        self.present(resetPassword, animated: true, completion: nil)
    }
    
    // MARK: - }

}

extension LoginVC:UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
}





