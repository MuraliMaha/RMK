//
//  PlanMyTripVC.swift
//  DriveFindMyCab
//
//  Created by SunTelematics on 24/05/18.
//  Copyright © 2018 Suntelematics. All rights reserved.
//

import UIKit

class PlanMyTripVC: UIViewController{

    
    var selectedDateStr : String!
    var selectedShiftType : String!
    var selectedShiftTime : String!
    var mode : String!
    
    var loginResponse:LoginResponce!
    var loginDetails:LoginDetails!
    
    @IBOutlet weak var shiftDateTxtFld: UITextField!
    
//    @IBOutlet weak var loginTimeTxtFld: UITextField!
//    @IBOutlet weak var logoutTimeTxtFld: UITextField!
    
    @IBOutlet weak var shiftTypeTxtFld: UITextField!
    @IBOutlet weak var shiftTimeTxtFld: UITextField!
    
    var shiftDatepicker = UIDatePicker()
    
    var myDateFormat : DateFormatter = {
        let fomat = DateFormatter()
        fomat.dateFormat = "yyyy-MM-dd"
//        fomat.dateFormat = "dd-MMM-yyyy"
        return fomat
    }()
    
    var shiftDatePickedItemPT : String!
    
    var oneMonthAddedDate : Date?
    
    
    
//    var loginTimePicker = UIPickerView()
//    var logoutTimePicker = UIPickerView()
    
    var shiftTypePicker = UIPickerView()
    var shiftTimePicker = UIPickerView()
    
    
    var shiftTypeArr = [String]()
    
    var loginTimeArr = [String]()
    var logoutTimeArr = [String]()
    
//    var loginTimePickedItem = ""
//    var logoutTimePickedItem = ""
    
    var shiftTypePickedItem = ""
    var shiftTimePickedItem = ""
    
//    var shiftTypeSelectIndex = 0
    var shiftTimeLoginPickedIndex = 0
    var shiftTimeLogoutPickedIndex = 0
    
    @IBOutlet weak var dropdownImgShiftDate: UIImageView!
    @IBOutlet weak var dropdownImgShiftType: UIImageView!
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()


        self.shiftDateTxtFld.text = selectedDateStr
        
        shiftDateTxtFld.delegate = self
//        loginTimeTxtFld.delegate = self
//        logoutTimeTxtFld.delegate = self
        shiftTypeTxtFld.delegate = self
        shiftTimeTxtFld.delegate = self
        

        
//        loginTimePicker .delegate = self;
//        loginTimePicker.dataSource = self;

        shiftTypePicker.delegate = self
        shiftTypePicker.dataSource = self
        
//        logoutTimePicker .delegate = self;
//        logoutTimePicker.dataSource = self;

        shiftTimePicker.delegate = self
        shiftTimePicker.dataSource = self
        
        loginDetails = FetchLoginDetails()
        loginResponse = FetchLoginResponce()
        
        
        
        var dateComponents = DateComponents()
        dateComponents.month = 1
        
        let cal = Calendar.current
        oneMonthAddedDate = cal.date(byAdding: dateComponents, to: Date())
        
        let Toolbar = UIToolbar()
        Toolbar.barStyle = .default
        Toolbar.isTranslucent = true
        Toolbar.tintColor = UIColor.blue
        Toolbar.sizeToFit()
        
        shiftDatepicker.datePickerMode = .date;
        
        
        
        shiftDatePickedItemPT = myDateFormat.string(from: Date())
        
        let DoneItem = UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(PickDoneAction(_:)))
        let FlexiItem = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
//        let CancelItem = UIBarButtonItem.init(title: "Cancel", style: .done, target: self, action: #selector(PickCancelAction(_:)))
        
        
//        Toolbar.setItems([CancelItem,FlexiItem,DoneItem], animated: true)
        Toolbar.setItems([FlexiItem,DoneItem], animated: true)
        Toolbar.isUserInteractionEnabled = true
        
        shiftDateTxtFld.inputView = shiftDatepicker
        shiftDateTxtFld.inputAccessoryView = Toolbar
        
//        loginTimeTxtFld.inputView = loginTimePicker;
//        loginTimeTxtFld.inputAccessoryView = Toolbar;
//        loginTimePicker.tag = 1
        
        shiftTypeTxtFld.inputView = shiftTypePicker
        shiftTypeTxtFld.inputAccessoryView = Toolbar
        shiftTypePicker.tag = 1

//        logoutTimeTxtFld.inputView = logoutTimePicker;
//        logoutTimeTxtFld.inputAccessoryView = Toolbar;
//        logoutTimePicker.tag = 2

        shiftTimeTxtFld.inputView = shiftTimePicker
        shiftTimeTxtFld.inputAccessoryView = Toolbar
        shiftTimePicker.tag = 2
        
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.white
        self.navigationItem.leftBarButtonItem = BackBtnItem
        
        
        shiftTypeArr.append("Login")
        shiftTypeArr.append("Logout")
        
        if self.mode != "0"{
            dropdownImgShiftDate.isHidden = true
            dropdownImgShiftType.isHidden = true
            shiftTypeTxtFld.text = selectedShiftType
            shiftTimeTxtFld.text = selectedShiftTime
        }else{
            dropdownImgShiftDate.isHidden = false
            dropdownImgShiftType.isHidden = false
            
        }
        fetchShiftTime()
    }

    
    func fetchShiftTime() {
        if (Reachability()?.isReachable)! {
            
            UIApplication.shared.keyWindow?.StartLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.DriveShiftTime, parameterDict: ["EmpId":"\(loginResponse.Employeeid!)"], completion: { (responceDict, success) in
                
                UIApplication.shared.keyWindow?.StopLoading()
                
                if success {
                    
                    if let Dict = responceDict {
                        
                        self.loginTimeArr.removeAll()
                        self.logoutTimeArr.removeAll()
                        
                        let Arr = Dict["data"] as! [[String:AnyObject]]
                        
                        if Arr.count != 0 {
                            /*
                            self.loginTimeTxtFld.text = Arr[0]["LoginTime"] as? String
                            self.loginTimePickedItem = self.loginTimeTxtFld.text!
                            
                            for DataDict in Arr {
                                self.loginTimeArr.append("\(DataDict["LoginTime"]!)")
                            }
                            
                            self.logoutTimeTxtFld.text = Arr[0]["LogoutTime"] as? String
                            self.logoutTimePickedItem = self.logoutTimeTxtFld.text!
                            
                            for abc in Arr {
                                self.logoutTimeArr.append("\(abc["LogoutTime"]!)")
                            }*/
                            
                            for DataDict in Arr {
                                self.loginTimeArr.append("\(DataDict["LoginTime"]!)")
                            }
                            for abc in Arr {
                                self.logoutTimeArr.append("\(abc["LogoutTime"]!)")
                            }
                            
                            if self.mode == "0"{
                                self.shiftTypeTxtFld.text = self.shiftTypeArr[0]
                                self.shiftTypePickedItem = self.shiftTypeTxtFld.text!
                                
                                if self.loginTimeArr.count > 0 {
                                    self.shiftTimeTxtFld.text = self.loginTimeArr[0]
                                    self.shiftTimePickedItem = self.loginTimeArr[0]
                                    self.shiftTimeLoginPickedIndex = 0
                                }
                            }else{
                                if self.selectedShiftType == "Login" {
//                                    if self.loginTimeArr.count > 0 {
//                                        self.shiftTimeTxtFld.text = self.loginTimeArr[0]
//                                        self.shiftTimePickedItem = self.loginTimeArr[0]
//                                        self.shiftTimeLoginPickedIndex = 0
//                                    }
                                }else{
//                                    if self.logoutTimeArr.count > 0 {
//                                        self.shiftTimeTxtFld.text = self.logoutTimeArr[0]
//                                        self.shiftTimePickedItem = self.logoutTimeArr[0]
//                                        self.shiftTimeLogoutPickedIndex = 0
//                                    }
                                }
                                
                            }
                            
                        
                        }
                        
                    }
                    else {
                        self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                        
                        print("Error")
                    }
                    
                }
                else {
                    self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                    
                    print("Error")
                }
            })
            
        }
        else {
            self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
            
            print("Net Error")
        }
    }
    func BackAction() {
        self.navigationController?.popViewController(animated: true)
    }
    // MARK: - Pick Actions {
    
    func PickDoneAction(_ sender:UIBarButtonItem) {
        
        if (shiftDateTxtFld.isFirstResponder) {
            shiftDateTxtFld.text = shiftDatePickedItemPT;
        }/*
        else if (loginTimeTxtFld.isFirstResponder) {
            loginTimeTxtFld.text = loginTimePickedItem;
        }
        else if (logoutTimeTxtFld.isFirstResponder) {
            logoutTimeTxtFld.text = logoutTimePickedItem;
        }*/
        else if (shiftTypeTxtFld.isFirstResponder){
            
            if shiftTypePickedItem != shiftTypeTxtFld.text! {
                shiftTypeTxtFld.text = shiftTypePickedItem
                
                if shiftTypeTxtFld.text == "Login"{
                    shiftTimeTxtFld.text = loginTimeArr[0]
                    shiftTimePickedItem = loginTimeArr[0]
                    shiftTimeLoginPickedIndex = 0
                }else{
                    shiftTimeTxtFld.text = logoutTimeArr[0]
                    shiftTimePickedItem = logoutTimeArr[0]
                    shiftTimeLogoutPickedIndex = 0
                }
            }else{
                print("Same item selected..So do nothing ....")
            }
            
        }else if (shiftTimeTxtFld.isFirstResponder){
            shiftTimeTxtFld.text = shiftTimePickedItem
        }
        self.view.endEditing(true)
    }
    
    /*
    func PickCancelAction(_ sender:UIBarButtonItem) {
        self.view.endEditing(true)
        if sender.tag == 1{
            shiftTypeTxtFld.resignFirstResponder()
        }else{
            shiftTimeTxtFld.resignFirstResponder()
        }
        
    } */
    
    @IBAction func submitBtnTapped(_ sender: UIButton) {

        if self.CheckBeforeRequest() {
            
            if (Reachability()?.isReachable)! {
                
                //                UtilitiesClass.Alert(Title: "Request Shift Change", Message: "Are you sure?" as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "CANCEL"),UtilitiesClass.AlertActionWithSelector(Title: "YES", Selector: #selector(CheckAndSend), Controller: self)], Controller: self)
                
                
                CheckAndSend()
                
                
            }
            else {
                UtilitiesClass.Alert(Title: "OOPS..", Message: Constants.NetErrorMsg as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            }
        }else {
            
            
            
            var errorString = ""
            
            if (self.shiftDateTxtFld.text?.isEmpty)! {
                errorString  = "Please select shift Date"
            } /*
             else if (self.loginTimeTxtFld.text?.isEmpty)! {
                errorString  = "Please select Login Time"
            }else if (self.logoutTimeTxtFld.text?.isEmpty)! {
                errorString  = "Please select Logout Time"
            }*/
            else if (self.shiftTypeTxtFld.text?.isEmpty)!{
                errorString  = "Please select shiftType"
            }else if (self.shiftTimeTxtFld.text?.isEmpty)!{
                errorString  = "Please select Shift Time"
            }
            
            UtilitiesClass.Alert(Title: "OOPS..", Message: errorString as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            
        }
        
    }
    
    @IBAction func cancelBtnTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    func CheckBeforeRequest() -> Bool {
        
//        if (shiftDateTxtFld.text?.isEmpty)! || (loginTimeTxtFld.text?.isEmpty)! || (logoutTimeTxtFld.text?.isEmpty)!
        if (shiftDateTxtFld.text?.isEmpty)! || (shiftTypeTxtFld.text?.isEmpty)! || (shiftTimeTxtFld.text?.isEmpty)!
        {
            return false
        }
        else {
            return true
        }
    }
    /*
    func CheckAndSend() {
        
        self.view.StartLoading()
        
        let RequestDict = ["EmpId":"\(loginResponse.Employeeid!)","DateTime":"\(shiftDatePickedItem!)","LoginTime":"\(loginTimePickedItem)","LogoutTime":"\(logoutTimePickedItem)","Mode":"\(self.mode!)"]
        
        WebService().callAutoAPI(Suffix:WebServicesUrl.EditPlannedTrip, parameterDict:RequestDict , completion: { (responceDict, success) in
            
            self.view.StopLoading()
            
            if success {
                
                //                UtilitiesClass.Alert(Title: "Your Request has been registered", Message: "", Actions: [UtilitiesClass.AlertActionWithSelector(Title: "OK", Selector: #selector(self.OkAction), Controller: self)], Controller: self)
                
                if let Dict = responceDict {
                    let Arr = Dict["data"] as! [[String:AnyObject]]
                    self.view.ShowBlackTostWithText(message:"\(Arr[0]["Response"]!)", Interval: 3)
                    
                    self.perform(#selector(self.OkAction), with: nil, afterDelay: 3)

                    
                }
                
                
                
                
                //                self.OkAction()
            }
            else {
                UtilitiesClass.Alert(Title: "OOPS..", Message: Constants.InternalError as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            }
        })
    }
    */
    
    func CheckAndSend() {
        
        self.view.StartLoading()
        
        //Mode 1 for Editing
        if self.mode != "1" {
            
            //For the user hp1030 , loginResponse.Empcode is hp1030
            let RequestDict = ["EmpId":"\(loginResponse.Empcode!)","DateTime":"\(self.shiftDatePickedItemPT!)","ShiftType":"\(self.shiftTypePickedItem)","ShiftTime":"\(self.shiftTimePickedItem)"]
            
            WebService().callAutoAPI(Suffix:WebServicesUrl.PlanMySchedule, parameterDict:RequestDict , completion: { (responceDict, success) in
                
                self.view.StopLoading()
                
                if success {
                    
                    //                UtilitiesClass.Alert(Title: "Your Request has been registered", Message: "", Actions: [UtilitiesClass.AlertActionWithSelector(Title: "OK", Selector: #selector(self.OkAction), Controller: self)], Controller: self)
                    
                    if let Dict = responceDict {
                        let Arr = Dict["data"] as! [[String:AnyObject]]
                        self.view.ShowBlackTostWithText(message:"\(Arr[0]["Response"]!)", Interval: 3)
                        
                        self.perform(#selector(self.OkAction), with: nil, afterDelay: 3)
                        
                        
                    }
                    
                    
                    
                    
                    //                self.OkAction()
                }
                else {
                    UtilitiesClass.Alert(Title: "OOPS..", Message: Constants.InternalError as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                }
            })
            
        }
        else{
            
            
            let RequestDict = ["EmpId":"\(loginResponse.Employeeid!)","DateTime":"\(self.selectedDateStr!)","ShiftType":"\(self.selectedShiftType!)","ShiftTime":"\(self.shiftTimePickedItem)","Mode" : self.mode!]
            
            //For the user hp1030 , loginResponse.Employeeid is 62
            WebService().callAutoAPI(Suffix:WebServicesUrl.EditPlannedTrip, parameterDict:RequestDict , completion: { (responceDict, success) in
                
                self.view.StopLoading()
                
                if success {
                    
                    //                UtilitiesClass.Alert(Title: "Your Request has been registered", Message: "", Actions: [UtilitiesClass.AlertActionWithSelector(Title: "OK", Selector: #selector(self.OkAction), Controller: self)], Controller: self)
                    
                    if let Dict = responceDict {
                        let Arr = Dict["data"] as! [[String:AnyObject]]
                        self.view.ShowBlackTostWithText(message:"\(Arr[0]["Response"]!)", Interval: 3)
                        
                        self.perform(#selector(self.OkAction), with: nil, afterDelay: 3)
                        
                    }
                    
                    //                self.OkAction()
                }
                else {
                    UtilitiesClass.Alert(Title: "OOPS..", Message: Constants.InternalError as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                }
            })
        }
        
    }
    
    
    func OkAction() {
        self.navigationController?.popViewController(animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension PlanMyTripVC : UITextFieldDelegate {
    
//    func caretRect(for position: UITextPosition) -&gt; CGRect {
//        return CGRect.zero
//    }

   
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if (textField == shiftDateTxtFld) || (textField == shiftTypeTxtFld) {
            if self.mode != "0"{
                print("Cant edit date as we clicked on edit button")
                return false
            }else{
                return true
            }
        }else{
            return true
        }
    }
//        if (textField == shiftTypeTxtFld){
//            if self.mode != "0"{
//                print("Cant edit date as we clicked on edit button")
//                return false
//            }else{
//                return true
//            }
//        }
    
    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if (textField == shiftDateTxtFld) {
            
            
            if self.mode == "0" {
                shiftDateTxtFld.isUserInteractionEnabled = true
                if shiftDateTxtFld.text == "" {
                    shiftDatepicker.date = Date();
                }
                else {
                    shiftDatepicker.date = myDateFormat.date(from: shiftDateTxtFld.text!)!
                }
                
                shiftDatepicker.minimumDate = Date();
                shiftDatepicker.maximumDate = oneMonthAddedDate
                shiftDatepicker.addTarget(self, action: #selector(shiftDateChanged(_:)), for: .valueChanged)
            }else{
                print("Cant edit date as we clicked on edit button")
                shiftDateTxtFld.isUserInteractionEnabled = false
            }
            
            
        }
        /*
        if (textField == loginTimeTxtFld)
        {
            loginTimePicker.reloadAllComponents()
            
            if loginTimeArr.count != 0 {
                loginTimePickedItem = loginTimeArr[0]
            }
        }
        if (textField == logoutTimeTxtFld)
        {
            logoutTimePicker.reloadAllComponents()
            
            if logoutTimeArr.count != 0 {
                logoutTimePickedItem = logoutTimeArr[0]
            }
        }*/
        
        if (textField == shiftTypeTxtFld){
            
//            shiftTypePicker.reloadAllComponents()
            
            
            
//            if shiftTypeArr.count != 0 {
//                shiftTypePickedItem = shiftTypeArr[0]
//            }
        }
        if (textField == shiftTimeTxtFld){
//            shiftTimePicker.reloadAllComponents()
            
            let pickerView : UIPickerView = self.shiftTimeTxtFld.inputView as! UIPickerView
            if shiftTypeTxtFld.text == "Login"{
                pickerView.selectRow(shiftTimeLoginPickedIndex, inComponent: 0, animated: true)
            }else{
                pickerView.selectRow(shiftTimeLogoutPickedIndex, inComponent: 0, animated: true)
            }
            
            
//            if shiftTypePickedItem == "Login"{
//                if loginTimeArr.count != 0{
//                    shiftTimePickedItem = loginTimeArr[0]
//                }
//            }else{
//                if logoutTimeArr.count != 0 {
//                    shiftTimePickedItem = logoutTimeArr[0]
//                }
//            }
        }
    }
    func shiftDateChanged(_ shiftdate:UIDatePicker) {
        shiftDatePickedItemPT = myDateFormat.string(from: shiftdate.date)
    }
}
extension PlanMyTripVC:UIPickerViewDelegate,UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        /*
        if pickerView.tag == 1 {
            return loginTimeArr.count
        }else{
            return logoutTimeArr.count
        }*/
        if pickerView.tag == 1{
            return shiftTypeArr.count
        }else{
            if shiftTypeTxtFld.text == "Login"{
                return loginTimeArr.count
            }else{
                return logoutTimeArr.count
            }
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        /*
        if pickerView.tag == 1 {
            return loginTimeArr[row]
        }else{
            return logoutTimeArr[row]
        } */
        
        if pickerView.tag == 1{
            return shiftTypeArr[row]
        }else{
            if shiftTypeTxtFld.text == "Login" {
                return loginTimeArr[row]
            }else{
                return logoutTimeArr[row]
            }
        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        /*
        if pickerView.tag == 1 {
            loginTimePickedItem = "\(loginTimeArr[row])"
        }else{
            logoutTimePickedItem = "\(logoutTimeArr[row])"
        } */
        if pickerView.tag == 1 {
//            shiftTypePickedItem = "\(shiftTypeArr[row])"
            shiftTypePickedItem = "\(shiftTypeArr[row])"
        }else{
            if shiftTypeTxtFld.text == "Login"{
                shiftTimePickedItem = "\(loginTimeArr[row])"
                shiftTimeLoginPickedIndex = row
            }else{
                shiftTimePickedItem = "\(logoutTimeArr[row])"
                shiftTimeLogoutPickedIndex = row
            }
        }
    }
}
class TextFieldSubClass : UITextField {
    
//    override func caretRect(for position: UITextPosition) -> CGRect {
//        return .zero
//    }
}
