//
//  MenuVC.swift
//  DriveBooking
//
//  Created by Raja Bhuma on 13/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit
//import SlideMenuControllerSwift

class MenuCarporateVC: UIViewController {

    @IBOutlet var MenuTable: UITableView!
    @IBOutlet var VersionLbl: UILabel!

    let MenusArray : [[String:String]] = {
        let Arr = [
                    ["Title":"Drive","Image":"Drive","Identifier":"RideNowVC"],
                    ["Title":"Book for Others","Image":"carcircle","Identifier":"BookForOthers"],
                    ["Title":"My Trips","Image":"Your Drivers","Identifier":"MyTripsVC"],
//                    ["Title":"Rate Card","Image":"est_fare","Identifier":"RateCardRideLater"],
                    ["Title":"Rate Card","Image":"est_fare","Identifier":"RateCardViewController"],
                    ["Title":"Offers","Image":"Offer","Identifier":"Offers"],
                    ["Title":"Emergency Contacts","Image":"contact_logo","Identifier":"Emergency"],
//                    ["Title":"Refer a Friend","Image":"Offer","Identifier":"ReferAFriend"],
                    ["Title":"Payment","Image":"Payment_Icon","Identifier":"PaymentModeDetailsSelectClassSBID"],
//                    ["Title":"Call Customer Support","Image":"contact_logo","Identifier":"CustomerSupport"]
                    ["Title":"Call Customer Support","Image":"contact_logo","Identifier":"NOID"],
//                   ["Title":"About","Image":"About","Identifier":"About"]
                ]
        
        return Arr
    }()
    
    var DriveBookingResponce:DriveLoginResponce!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(LoadAgain), name: NSNotification.Name.LGSideMenuWillShowLeftView, object: nil)
        
        // Do any additional setup after loading the view.
//        self.VersionLbl.text = "Version " + "\(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString")!)"
        
    }

    func LoadAgain() {
        DriveBookingResponce = FetchDriveResponce()!
//        ProfileBtn.setTitle(DriveBookingResponce.Name?.capitalized, for: .normal)
        self.MenuTable.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        DriveBookingResponce = FetchDriveResponce()!
//        ProfileBtn.setTitle(DriveBookingResponce.Name?.capitalized, for: .normal)
        NotificationCenter.default.addObserver(self, selector: #selector(Corporate), name: NSNotification.Name.init("BOFC"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(personal), name: NSNotification.Name.init("BOFP"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(RideNow), name: NSNotification.Name.init("MENURN"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(RideLater), name: NSNotification.Name.init("MENURL"), object: nil)

        self.MenuTable.reloadData()
    }
    
    var isCorporate = true
    
    func Corporate() {
        isCorporate = true
    }
    
    func personal() {
        isCorporate = false
    }
    
    var isRideNow = false

    func RideNow() {
        isRideNow = true
    }
    
    func RideLater() {
        isRideNow = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet var ProfileBtn: UIButton!
    @IBAction func ProfileBtnPressed(_ sender:UIButton) {
        
        self.slideMenuController()?.closeLeft()

        //let controller = self.storyboard?.instantiateViewController(withIdentifier: "Profile") as! Profile
//       let navigationController = sideMenuController?.rootViewController as! UINavigationController
//        navigationController.pushViewController(controller, animated: true)
//
        self.slideMenuController()?.dismiss(animated: true, completion: nil)
    }
}

extension MenuCarporateVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 60
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return MenusArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuCarporateCell", for: indexPath) as! MenuCarporateCell
        
        
        cell.MenuImage.image = UIImage.init(named: MenusArray[indexPath.row]["Image"]!)
        cell.MenuName.text = MenusArray[indexPath.row]["Title"]!
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        if isRideNow {
            
            if indexPath.row == 0 {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "NOW"), object: nil)
                self.slideMenuController()?.closeLeft()
            }
            else if indexPath.row == 1 {
                

                self.slideMenuController()?.closeLeftNonAnimation()
                    let controller = self.storyboard?.instantiateViewController(withIdentifier: MenusArray[indexPath.row]["Identifier"]!) as! BookForOthers
                    controller.fromRideNowOrLater = "RideNow"
                    controller.modalPresentationStyle = .overFullScreen
                
                let navigationController = self.slideMenuController()?.mainViewController as! UINavigationController
                
                controller.previous = navigationController
                navigationController.present(controller, animated: true, completion: nil)
//                }
//                else {
//                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Book for others not available for Corporate bookings", Interval: 4)
//                }
                
            }//offers
            else if indexPath.row == 4 {
                self.slideMenuController()?.closeLeft()
                let controller = self.storyboard?.instantiateViewController(withIdentifier: MenusArray[indexPath.row]["Identifier"]!)
                controller?.modalPresentationStyle = .overFullScreen
                let navigationController = self.slideMenuController()?.mainViewController as! UINavigationController
                navigationController.present(controller!, animated: true, completion: nil)
            }
                //Payments
            else if indexPath.row == 6 {
                let controller = self.storyboard?.instantiateViewController(withIdentifier: MenusArray[indexPath.row]["Identifier"]!) as! PaymentModeDetailsSelectClass
                controller.corpOrPersonalType = isCorporate ? "CORPORATE" : "PERSONAL"
                controller.hideButtons = true
                
                let navigationController = self.slideMenuController()?.mainViewController as! UINavigationController
                navigationController.pushViewController(controller, animated: true)
                self.slideMenuController()?.closeLeft()
                
            }
            else if indexPath.row == 7 {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue:"CUSTOMERSUPPORT"), object: nil)
                self.slideMenuController()?.closeLeftNonAnimation()
                
            }
            else {
                let controller = self.storyboard?.instantiateViewController(withIdentifier: MenusArray[indexPath.row]["Identifier"]!)
                let navigationController = self.slideMenuController()?.mainViewController as! UINavigationController
                navigationController.pushViewController(controller!, animated: true)
                self.slideMenuController()?.closeLeft()
            }
            
            
            
        }
        // this else block for RideLater
        else {
            
            //Home
            if indexPath.row == 0 {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "NOW"), object: nil)
                self.slideMenuController()?.closeLeft()
            }
            //Book for others
            else if indexPath.row == 1 {
                
//                self.slideMenuController()?.closeLeft()
                self.slideMenuController()?.closeLeftNonAnimation()
                
                if !isCorporate {
                    let controller = self.storyboard?.instantiateViewController(withIdentifier: MenusArray[indexPath.row]["Identifier"]!) as! BookForOthers
                    controller.fromRideNowOrLater = "RideLater"
                    controller.modalPresentationStyle = .overFullScreen

                    let navigationController = self.slideMenuController()?.mainViewController as! UINavigationController
                    
                    controller.previous = navigationController
                    
                    navigationController.present(controller, animated: true, completion: nil)
                }
                else {
//                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Book for others available only for Personal trips", Interval: 4)
                    let customAlertMsgDict : [String:String] = ["alertMsg":"Book for others available only for Personal trips"]
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue:"CUSTOMALERT"), object: nil,userInfo: customAlertMsgDict)
                    self.slideMenuController()?.closeLeftNonAnimation()
                }
                
            }
            //RateCard
            else if indexPath.row == 3 {
                self.slideMenuController()?.closeLeft()
                
                let controller : UIViewController!
                if "\(self.DriveBookingResponce.RideNowStatus!)".toBool()! {
                    controller = self.storyboard?.instantiateViewController(withIdentifier: MenusArray[indexPath.row]["Identifier"]!)
                }else{
                    controller = self.storyboard?.instantiateViewController(withIdentifier: MenusArray[indexPath.row]["RateCardRideLater"]!)
                }
                let navigationController = self.slideMenuController()?.mainViewController as! UINavigationController
                navigationController.pushViewController(controller!, animated: true)
                
                //temporary
//                let temp = false
//                if temp{
//                    controller = self.storyboard?.instantiateViewController(withIdentifier: MenusArray[indexPath.row]["Identifier"]!)
//                }else{
//                    controller = self.storyboard?.instantiateViewController(withIdentifier:"RateCardRideLater")
//                }
//                let navigationController = self.slideMenuController()?.mainViewController as! UINavigationController
//                navigationController.pushViewController(controller!, animated: true)
            }
            //offers
            else if indexPath.row == 4{
                self.slideMenuController()?.closeLeftNonAnimation()
                if !isCorporate{
                    let controller = self.storyboard?.instantiateViewController(withIdentifier: MenusArray[indexPath.row]["Identifier"]!)
                    controller?.modalPresentationStyle = .overFullScreen
                    let navigationController = self.slideMenuController()?.mainViewController as! UINavigationController
                    navigationController.present(controller!, animated: true, completion: nil)
                }else{
//                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Offers available only for Personal trips", Interval: 4)
                    let customAlertMsgDict : [String:String] = ["alertMsg":"Offers available only for Personal trips"]
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue:"CUSTOMALERT"), object: nil,userInfo: customAlertMsgDict)
                    
                }
            }
            //Payments
            else if indexPath.row == 6 {
                let controller = self.storyboard?.instantiateViewController(withIdentifier: MenusArray[indexPath.row]["Identifier"]!) as! PaymentModeDetailsSelectClass
                controller.corpOrPersonalType = isCorporate ? "CORPORATE" : "PERSONAL"
                controller.hideButtons = true
//                controller.myDelegateRef = self
                
                let navigationController = self.slideMenuController()?.mainViewController as! UINavigationController
                navigationController.pushViewController(controller, animated: true)
                self.slideMenuController()?.closeLeft()
            }
            else if indexPath.row == 7 {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue:"CUSTOMERSUPPORT"), object: nil)
//                sideMenuController?.hideLeftView(animated: true, completionHandler: nil)
//                self.slideMenuController()?.closeLeft()
                self.slideMenuController()?.closeLeftNonAnimation()
            }
            else {
                let controller = self.storyboard?.instantiateViewController(withIdentifier: MenusArray[indexPath.row]["Identifier"]!)
                let navigationController = self.slideMenuController()?.mainViewController as! UINavigationController
                navigationController.pushViewController(controller!, animated: true)
                self.slideMenuController()?.closeLeft()
            }
        }
        
        
        
    }
}

class MenuCarporateCell: UITableViewCell {
    @IBOutlet var MenuImage:UIImageView!
    @IBOutlet var MenuName:UILabel!
}
//extension MenuCarporateVC : PaymentModeDetailsSelectDelegate{
//
//    func DidOKTapped(_ selectedPaymentMode: String!, _ controller: PaymentModeDetailsSelectClass) {
//
//        self.paymentMode = selectedPaymentMode
//        self.selectPaymentBtn.setTitle(selectedPaymentMode, for: .normal)
//        controller.navigationController?.popViewController(animated: true)
//        //        controller.dismiss(animated: true, completion: nil)
//    }
//
//
//}

