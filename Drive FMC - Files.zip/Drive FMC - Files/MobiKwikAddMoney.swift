//
//  MobiKwikAddMoney.swift
//  IBMBlueMix
//
//  Created by Amarnath B on 22/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
import UIKit

protocol MobiKwikAddMoneyDelegate {
    func DidCompleteAddMoney(controller:MobiKwikAddMoney)
    func DidcancelAddMoney(controller:MobiKwikAddMoney)
}

class MobiKwikAddMoney: UIViewController, UITextFieldDelegate {

    var HideDelink = false

    @IBOutlet var AddmoneyTxt: UITextField!
    @IBOutlet var WalletBalanceLbl: UILabel!

    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!
    
    var Delegate: MobiKwikAddMoneyDelegate!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.LoginRequest = FetchDriveRequest()
        self.DriveBookingResponce = FetchDriveResponce()
        
        // Do any additional setup after loading the view.
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.black
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
        self.navigationItem.leftBarButtonItem = BackBtnItem
        
        WalletBalanceLbl.text = "₹" + FetchMobiKwikBalance()
        
        if !HideDelink {
            let rightItm = UIBarButtonItem.init(image: UIImage.init(named: "MenuDelete"), style: .done, target: self, action: #selector(DelinkAccountBtnPressed))
            rightItm.tintColor = UIColor.black
            self.navigationItem.rightBarButtonItem = rightItm
        }
    }
    
    func BackAction() {
        self.Delegate.DidcancelAddMoney(controller: self)
    }
    
    
    //de Link Mobikwik account from payments
    
    func DelinkAccountBtnPressed(_ sender:UIBarButtonItem) {
        
        let button = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 180, height: 44))
        button.setTitle("DeLink Account   ", for: .normal)
        button.backgroundColor = UIColor.black
        button.tintColor = UIColor.clear
        button.addTarget(self, action: #selector(DeleteAccount(_:)), for: .touchUpInside)
        
        let Layout = KLCPopupLayout.init(horizontal: .right, vertical: .custom64)
        let viewLay = KLCPopup.init(contentView: button, showType: .bounceInFromRight, dismissType: .fadeOut, maskType: .dimmed, dismissOnBackgroundTouch: true, dismissOnContentTouch: false)
        viewLay?.show(with: Layout)
    }
    
    func DeleteAccount(_ sender:UIButton) {
        sender.dismissPresentingPopup()
        Message.shared.Alert(Title: "DeLink MobiKwik!", Message: "Do you want to DeLink account", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "No"),Message.AlertActionWithSelector(Title: "Yes", Selector: #selector(ConfirmDelink), Controller: self)], Controller: self)
    }
    
    func ConfirmDelink() {
        //print("Action for delink account")
        
        self.DriveBookingResponce.DefaultPaymentMode = "CASH"
        saveDriveResponceStuct(driveStruct: self.DriveBookingResponce!)

        UpdatePaymentModes(WalletType_Paytm_MobiKwik: "MobiKwik", MobileNo: DriveBookingResponce.WalletMobileNo!, Token: "NA", ExpData_oMobi_Paytmdate: "0") { (isauth) in
            if isauth {
//                authenticationCheck(controller: self)
            }
            else {
                self.Delegate.DidCompleteAddMoney(controller: self)
            }
            
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // Add Money to mobikwik Action
    
    @IBAction func AddMoneyToWalletBtnPreesed(_ sender:UIButton) {

        self.view.endEditing(true)
        
        if (AddmoneyTxt.text?.isEmpty)! {
            self.view.ShowBlackTostWithText(message: "Amount should not be empty", Interval: 3)
            return
        }
        else  {
           
            let Amount = Int(AddmoneyTxt.text!)!
            if Amount == 0 {
                self.view.ShowBlackTostWithText(message: "Amount need to be morethan 0", Interval: 3)
                return
            }
            else {
               
                let orderid = generateOrderIDWithPrefix(prefix: "_" + self.DriveBookingResponce.EmpId!)
                
                let cellemail = self.DriveBookingResponce.WalletMobileNo!
                let mid = MobiCreds.MID
                let merchantname = MobiCreds.MerchentName
                let redirecturl = MobiCreds.RedirectUrl
                let Token = DriveBookingResponce.WalletToken!
                let HashStr = "'\(Amount)''\(cellemail)''\(merchantname)''\(mid)''\(orderid)''\(redirecturl)''\(Token)'"
                
                //print(HashStr)
                let CheckSum = HashStr.hmac(algorithm: .SHA256, key: MobiCreds.Secret)
                //print(CheckSum)
                
                let GetSTR = "amount=\(Amount)&cell=\(cellemail)&orderid=\(orderid)&mid=\(mid)&merchantname=\(merchantname)&token=\(Token)&redirecturl=\(redirecturl)&checksum=\(CheckSum)"
                //print("https://walletapi.mobikwik.com/addmoneytowallet?\(GetSTR)")
                
                let Appendstr = MobiCreds.BaseUrl + "/" + MobiCreds.addmoneytowallet + "?" + GetSTR
                let AddMoneyUrl = URL.init(string: Appendstr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!
                
                
                let Webview = self.storyboard?.instantiateViewController(withIdentifier: "MobiKwikWebViewVc") as! MobiKwikWebViewVc
                Webview.PostUrl = AddMoneyUrl
                Webview.Delegate = self
                
                var Content = MobiKwikValue()
                Content.amount = "\(Amount)"
                Content.orderID = "\(orderid)"
                Webview.MobiKwikTransctionContent = Content
                
                self.navigationController?.pushViewController(Webview, animated: true)
            }
            
        }
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    @IBAction func Money200Btn(_ sender:UIButton) {
        
        var InitalAmount:Int = 0
        
        if AddmoneyTxt.text! == "" {
            InitalAmount = 200
            AddmoneyTxt.text = String.init(format: "%ld", InitalAmount)
        }
        else {
            let Amount = Int(AddmoneyTxt.text!)! + 200
            
            if Amount >= Int(MobiCreds.MaxAmount)! {
                self.view.ShowBlackTostWithText(message: "Amount should be lessthan ₹ " + MobiCreds.MaxAmount, Interval: 3)
            }
            else {
                InitalAmount = Int(AddmoneyTxt.text!)! + 200

                AddmoneyTxt.text = String.init(format: "%ld", InitalAmount)
            }
        }
        
        
    }
    
    @IBAction func Money500Btn(_ sender:UIButton) {
        
        var InitalAmount:Int = 0
        
        if AddmoneyTxt.text! == "" {
            InitalAmount = 500
            AddmoneyTxt.text = String.init(format: "%ld", InitalAmount)
        }
        else {
            let Amount = Int(AddmoneyTxt.text!)! + 500
            
            if Amount >= Int(MobiCreds.MaxAmount)! {
                self.view.ShowBlackTostWithText(message: "Amount should be lessthan ₹ " + MobiCreds.MaxAmount, Interval: 3)
            }
            else {
                InitalAmount = Int(AddmoneyTxt.text!)! + 500
                
                AddmoneyTxt.text = String.init(format: "%ld", InitalAmount)
            }
        }
    }
    
    @IBAction func Money1000Btn(_ sender:UIButton) {
        
        var InitalAmount:Int = 0
        
        if AddmoneyTxt.text! == "" {
            InitalAmount = 1000
            AddmoneyTxt.text = String.init(format: "%ld", InitalAmount)
        }
        else {
            let Amount = Int(AddmoneyTxt.text!)! + 1000
            
            if Amount >= Int(MobiCreds.MaxAmount)! {
                self.view.ShowBlackTostWithText(message: "Amount should be lessthan ₹ " + MobiCreds.MaxAmount, Interval: 3)
            }
            else {
                InitalAmount = Int(AddmoneyTxt.text!)! + 1000
                
                AddmoneyTxt.text = String.init(format: "%ld", InitalAmount)
            }
        }
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let set = CharacterSet.init(charactersIn: "1234567890")
        
        if string == "" {
            return true
        }
        else {
            if string.rangeOfCharacter(from: set) != nil {
                
                let text = textField.text!
                
                let OldLenght = text.characters.count
                let newLength = text.characters.count + string.characters.count - range.length
                
                var Number = 0
                
                if OldLenght < newLength {
                    let str = text + string
                    Number = Int(str)!
                }
                else {
                    let str = text.substring(to: text.index(text.endIndex, offsetBy: -1))
                    Number = Int(str)!
                }
                
                if Number >= Int(MobiCreds.MaxAmount)! {
                    self.view.endEditing(true)
                    self.view.ShowBlackTostWithText(message: "Amount should be lessthan ₹ " + MobiCreds.MaxAmount, Interval: 3)
                    return false
                }
                else {
                    return true
 
                }
            }
            else {
                return false
            }
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    
}
// Mobikwik addmoney success and failure delegates reDirected from Mobikwik webview

extension MobiKwikAddMoney:MobiKwikTransactionDelegate {
    func TransactionDidCancel(controller: MobiKwikWebViewVc) {
        controller.navigationController?.popViewController(animated: true)
        Message.shared.Alert(Title: "Transaction cancelled", Message: "", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
    }
    func TransactionDidComplete(Result: MobiKwikTransactionResult, controller: MobiKwikWebViewVc) {
        controller.navigationController?.popViewController(animated: true)
        switch Result {
        case .success(let value):
            
            if FetchMobiKwikBalance() != "NA" {
                
                let FlotVal = Float(FetchMobiKwikBalance())! + Float(value.amount!)!
                
                SaveMobiKwikBalance(token: String.init(format: "%.2f", FlotVal))
            }
            else {
                SaveMobiKwikBalance(token: value.amount!)
            }
            self.WalletBalanceLbl.text = "₹" + FetchMobiKwikBalance()
            Message.shared.Alert(Title: "Transaction Complete", Message: value.statusMsg!, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithSelector(Title: "Ok", Selector: #selector(SuccessCall), Controller: self)], Controller: self)
            break
        case .failure(let value):
            Message.shared.Alert(Title: "Transaction unsuccessful", Message: value.statusMsg!, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            break
        }
    }
    
    func SuccessCall() {
        self.Delegate.DidCompleteAddMoney(controller: self)
    }
    
}

func generateOrderIDWithPrefix(prefix: String) -> String {
    
    srandom(UInt32(time(nil)))
    
    let randomNo: Int = Int(arc4random_uniform(97362984) + 1)
    let orderID: String = "\(randomNo)\(prefix)"
    return orderID
    
}
