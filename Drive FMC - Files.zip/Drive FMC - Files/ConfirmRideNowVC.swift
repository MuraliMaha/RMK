//
//  ConfirmRideNowVC.swift
//  DriveFindMyCab
//
//  Created by Amarnath B on 22/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.//

import UIKit

protocol ConfirmDelegate {
    func DidDone(IsDone:Bool, JobID:String, Controller:ConfirmRideNowVC)
}


class ConfirmRideNowVC: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    
    @IBOutlet var BookConfirmShadowView:UIView!
    @IBOutlet var BookConfirmText:UILabel!
    
    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!
    
    var Delegate:ConfirmDelegate!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        LoginRequest = FetchDriveRequest()
        DriveBookingResponce = FetchDriveResponce()
        
        
        self.BookConfirmText.text = "Your booking Id " + self.JobIdMain! + " has been confirmed. Please go to My Rides or click View Details button to track the vehicle"
        
        CancelBookingHiddenTxt()
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.black
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
        self.navigationItem.leftBarButtonItem = BackBtnItem
    }
    
    func BackAction() {
        Delegate.DidDone(IsDone: false, JobID: "", Controller: self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    var JobIdMain: String!
    
    var CancelBookingText = UITextField()
    var CancelSelectPicker = UIPickerView()
    
    @IBAction func ViewDetailsBookingBtnPressed(_ sender:UIButton) {
        
        Delegate.DidDone(IsDone: true, JobID: JobIdMain!, Controller: self)

    }
    
    var CancelReasonsArr = [String]()
    
    @IBAction func CancelBookingBtnPressed(_ sender:UIButton) {
        // action for cancel booking
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            let CancelReasonsDict = ["EmpId":"\(DriveBookingResponce.EmpId!)",
                "VendorId":"\(LoginRequest.LoginCreds.VendorId!)",
                "CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)",
                "AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveCancellationReasons, parameterDict: CancelReasonsDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (CancelReasonsDict, responceCode, success) in
                self.view.StopLoading()
                if success {
                    if let Table = ((CancelReasonsDict as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                        
                        if "\(Table["Status"]!)" == "true" && Table.keys.contains(where: {$0 == "Reasons"}) && "\(Table["Reasons"]!)" != ""  {
                            let Reasons = "\(Table["Reasons"]!)".components(separatedBy: "|")
                            self.CancelReasonsArr.removeAll()
                            for i in 0..<Reasons.count-1 {
                                self.CancelReasonsArr.append(Reasons[i])
                            }
                            self.CancelBookingText.becomeFirstResponder()
                            self.CancelSelectPicker.reloadAllComponents()
                        }
                        else {
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                        }
                        
                    }
                    else {
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                    }
                }
                else {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                }
            })
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.NetErrorMsg, Interval: 2)
        }
    }
    
    func CancelBookingHiddenTxt() {
        
        CancelBookingText.frame = CGRect.init(x: 1000, y: 1000, width: 10, height: 10)
        self.view.addSubview(CancelBookingText)
        CancelSelectPicker.dataSource = self
        CancelSelectPicker.delegate = self
        
        let Toolbar = UIToolbar()
        Toolbar.barStyle = .default
        Toolbar.isTranslucent = true
        Toolbar.tintColor = UIColor.blue
        Toolbar.sizeToFit()
        let DoneItem = UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(cancelBookingPickDoneAction))
        let FlexiItem = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let TitleItem = UIBarButtonItem.init(title: "Select Reason to Cancel", style: .done, target: nil, action: nil)
        let FlexiItem2 = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let CancelItem = UIBarButtonItem.init(title: "Cancel", style: .done, target: self, action: #selector(cancelBookingPickCancelAction))
        Toolbar.setItems([CancelItem,FlexiItem,TitleItem,FlexiItem2,DoneItem], animated: true)
        Toolbar.isUserInteractionEnabled = true
        CancelBookingText.inputView = CancelSelectPicker;
        CancelBookingText.inputAccessoryView = Toolbar;
    }
    
    
    var CancelBookingSelectedIndex = 0
    
    func cancelBookingPickDoneAction() {
        let ReasonSelected = CancelReasonsArr[CancelBookingSelectedIndex]
        CancelBookingText.resignFirstResponder()
        CancelTrip(Reason: ReasonSelected)
    }
    
    func CancelTrip(Reason:String) {
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            let CancelRequestDict = ["JobNo":"\(JobIdMain!)","JobType":"Current","CancelReason":"\(Reason)","EmpId":"\(DriveBookingResponce.EmpId!)","VendorId":"\(LoginRequest.LoginCreds.VendorId!)",
                "CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)",
                "AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveCancelBooking, parameterDict: CancelRequestDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (CancelDict, responceCode, success) in
                self.view.StopLoading()
                if success {
                    if let Table = ((CancelDict as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                        
                        if "\(Table["Status"]!)" == "true" {
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(Table["Response"]!)", Interval: 2)
                            
                            self.Delegate.DidDone(IsDone: false, JobID: "",Controller: self)
                            
                        }
                        else {
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(Table["Response"]!)", Interval: 2)
                        }
                    }
                }
                else {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                }
            })
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.NetErrorMsg, Interval: 2)
        }
    }
    
    
    func cancelBookingPickCancelAction() {
        CancelBookingText.resignFirstResponder()
    }

    // MARK: - picker {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return CancelReasonsArr.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return "\(CancelReasonsArr[row])"
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        CancelBookingSelectedIndex = row
    }
    
    // MARK: - }
}
