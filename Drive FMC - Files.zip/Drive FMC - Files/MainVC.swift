//
//  MainVC.swift
//  DriveFindMyCab
//
//  Created by Admin on 31/03/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit
import LGSideMenuController
import AVKit
import AVFoundation
import Messages
import MessageUI
import GoogleMaps
import SlideMenuControllerSwift

class MainVC: UIViewController,UIScrollViewDelegate,MFMessageComposeViewControllerDelegate,CLLocationManagerDelegate {

    @IBOutlet weak var testURLLbl: UILabel!
    
    var LoginResponce:LoginResponce!
    var LoginDetails:LoginDetails!
    
    
    @IBOutlet var Version:UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if WebServicesUrl.MainBaseUrl == "http://drivee.in/DriveFMC/FindMycab.asmx" {
            testURLLbl.isHidden = true
        }else{
            testURLLbl.isHidden = false
        }
        
        
        LoginDetails = FetchLoginDetails()
        LoginResponce = FetchLoginResponce()
        
        DispatchQueue.main.async {
            self.Version.text = "V " + "\(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString")!)"
        }

        
        let delegate = UIApplication.shared.delegate as! AppDelegate
        delegate.navController = self.navigationController
        
        Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(ScrollItemsSetup), userInfo: nil, repeats: false)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Scroll Animation Setup {

    @IBOutlet var AnimatedScrollV: UIScrollView!

    var AnimationObjectsArr = [UIButton]()
    
    func ScrollItemsSetup() {
        
        let Items = 4
        let ViewSize = AnimatedScrollV.frame.size.width * 0.6
        let Width = AnimatedScrollV.frame.size.width/2
        AnimationObjectsArr.removeAll()
        let imagesArray = ["menu_company","menu_safehome","menu_calendar","menu_drive"]
        
        AnimatedScrollV.contentSize = CGSize.init(width: AnimatedScrollV.frame.size.width, height: CGFloat(Float(ViewSize * 1.2) * Float(Items)))
        
        for i in 0..<Items {
            
            let MenuBtn = UIButton.init(frame: CGRect.init(x: Width, y: (ViewSize * 1.15) * CGFloat(i), width: ViewSize, height: ViewSize))
            MenuBtn.setImage(UIImage.init(named: imagesArray[i]), for: .normal)
            MenuBtn.layer.cornerRadius = ViewSize/2
            MenuBtn.layer.masksToBounds = true
            MenuBtn.backgroundColor = UIColor.clear
            MenuBtn.tintColor = UIColor.clear
            MenuBtn.tag = i
            MenuBtn.addTarget(self, action: #selector(MenuSelect(_:)), for: .touchUpInside)
            AnimatedScrollV.addSubview(MenuBtn)
                    
            AnimationObjectsArr.append(MenuBtn)
            
        }
        AnimatedScrollV.contentOffset = CGPoint.init(x: 0, y: 1)
        
        
        
        if LoginResponce.ShowRateTrip.toBool()! {
            
            if !(LoginResponce.DailyTripMasterId! == "<null>") {
                print("TripID",LoginResponce.DailyTripMasterId!);
                
                let FbObj = self.storyboard?.instantiateViewController(withIdentifier: "TripFeedbackVC") as! TripFeedbackVC
                FbObj.TripID = "\(LoginResponce.DailyTripMasterId!)"
                FbObj.TripDate = "\(LoginResponce.TripStartDate!)"
                FbObj.TripShift = "\(LoginResponce.ShiftType!)"
                self.present(FbObj, animated: true, completion: nil)
            }
        }
        
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        let Start = scrollView.contentOffset.y
        let height = scrollView.frame.size.height
        let end = Start + height
        var viewOffset , viewTop : CGFloat!
        var index = 0
        
        for Btn in AnimationObjectsArr {
            viewTop = Btn.frame.maxY
            if (viewTop>Start) && (Btn.frame.minY<end) {
                viewOffset = Btn.frame.minY - Start
                var rect = Btn.frame
                rect.origin.x = 90 - sin((viewOffset/height)*4) * 70
                Btn.frame = rect
                index += 1
            }
        }
    }
    
    func MenuSelect(_ sender:UIButton) {
        switch sender.tag {
        case 0:
            let Controller = self.storyboard?.instantiateViewController(withIdentifier: "TripTrackVC") as! TripTrackVC
            self.navigationController?.pushViewController(Controller, animated: true)
            break
        case 1:
            let Controller = self.storyboard?.instantiateViewController(withIdentifier: "SafeHomeVC") as! SafeHomeVC
            self.navigationController?.pushViewController(Controller, animated: true)
            break
        case 2:
//            let Controller = self.storyboard?.instantiateViewController(withIdentifier: "MyEventsVC") as! MyEventsVC
//            let Controller = self.storyboard?.instantiateViewController(withIdentifier: "MyEventsVCNewSBID") as! MyEventsVCNew
            
            let Controller = self.storyboard?.instantiateViewController(withIdentifier: "CalenderVCTemp2SBID") as! CalenderVC
            
            self.navigationController?.pushViewController(Controller, animated: true)
            break
        case 3:
            
//            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Drive booking currently not available", Interval: 3)
            
//            CallDriveBooking()
            
            break
        default:
            break
        }
    }
    
    
    // MARK: - }

    
    // MARK: - Slider Actions And Settings {
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        sideMenuController?.isLeftViewEnabled = true
        NotificationCenter.default.addObserver(self, selector: #selector(self.CallForLogout), name:NotificationStruct.LogOutNotif , object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.CallForHelpDesk), name:NotificationStruct.HelpDeskNotif , object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sideMenuController?.isLeftViewEnabled = false
        NotificationCenter.default.removeObserver(self, name: NotificationStruct.LogOutNotif, object: nil)
        NotificationCenter.default.removeObserver(self, name: NotificationStruct.HelpDeskNotif, object: nil)
    }
    
    @IBAction func LeftMenuAction(_ sender:UIBarButtonItem) {
        sideMenuController?.showLeftView(animated: true, completionHandler: nil)
    }
    
    // MARK: - }
    
    // MARK: - Logout {

    func CallForLogout() {
        UtilitiesClass.Alert(Title: "Log Out", Message: "Are you sure?", Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "CANCEL"),UtilitiesClass.AlertActionWithSelector(Title: "OK", Selector: #selector(LogoutOkAction), Controller: self)], Controller: self)
    }
    
    
    var EmergencyArr = [EmergencyCStruct]()
    func LogoutOkAction() {
         // Clear all here //
        
        self.view.StartLoading()
        
        GetContacts()
        
        let defaults = UserDefaults.standard
        defaults.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
        defaults.synchronize()
        
        if EmergencyArr.count >= 0 {
            SaveEmergencyContacts(EmergencyArr: EmergencyArr)
        }
        
        self.view.StopLoading()
        
        let LoginObj = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        present(LoginObj, animated: true, completion: nil)
        
    }
    
    func GetContacts() {
        guard FetchEmergencyContacts() != nil  else {
            return
        }
        EmergencyArr = FetchEmergencyContacts()!
    }
    
    // MARK: - }
    
    // MARK: - Help Desk {

    @IBOutlet var HelpDeskView: UIView!
    @IBOutlet var HelpDesknumber: UILabel!
    
    func CallForHelpDesk() {
        // call for view with helpdesk //
        
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        HelpDesknumber.text = LoginResponce.HelpDeskno!
        
        BackView.center = (window?.center)!
        
        window?.addSubview(BackView)
        
        HelpDeskView.center = BackView.center
        
        BackView.addSubview(HelpDeskView!)
        
        HelpDeskView.alpha = 0

        
        let GuardianTap = UITapGestureRecognizer.init(target: self, action: #selector(TapAddHelpDeskView(_:)))
        GuardianTap.numberOfTapsRequired = 1
        BackView.addGestureRecognizer(GuardianTap)
        
        UIView.animate(withDuration: 0.5) {
            self.HelpDeskView.alpha = 1
        }
    }
    func TapAddHelpDeskView(_ responder:UITapGestureRecognizer) {
        
        let Point = responder.location(in: HelpDeskView.superview!)
        let Frame = HelpDeskView.frame
        
        if !Frame.contains(Point) {
            UIView.animate(withDuration: 0.3, animations: {
                self.HelpDeskView.alpha = 0
            }) { (yes) in
                if yes {
                    self.HelpDeskView.alpha = 1
                    self.HelpDeskView.superview?.removeFromSuperview()
                }
            }
        }
        
    }
    
    @IBAction func CancelHelpDesk(_ sender:UIButton) {
        
        UIView.animate(withDuration: 0.3, animations: {
            self.HelpDeskView.alpha = 0
        }) { (yes) in
            if yes {
                self.HelpDeskView.alpha = 1
                self.HelpDeskView.superview?.removeFromSuperview()
            }
        }
    }
    
    @IBAction func CallHelpDesk(_ sender:UIButton) {
        
        UIView.animate(withDuration: 0.3, animations: {
            self.HelpDeskView.alpha = 0
        }) { (yes) in
            if yes {
                self.HelpDeskView.alpha = 1
                self.HelpDeskView.superview?.removeFromSuperview()
                
                if ((NSString.init(string:self.LoginResponce.HelpDeskno!)).rangeOfCharacter(from: CharacterSet.decimalDigits.inverted)).location == NSNotFound {
                    UIApplication.shared.openURL(URL.init(string: "tel://\(self.LoginResponce.HelpDeskno!)")!)
                }
                else {
                    UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Invalid Helpdesk Number", Interval: 3)
                }
                
            }
            
        }

    }
    
    // MARK: - }
    
    
    // MARK: - SOS {
    
    @IBOutlet var SOSView: UIView!
    @IBOutlet var SiranBtn: UIButton!
    @IBOutlet var TimerLbl: UILabel!

    var TimerSOS = Timer()
    
    var TimerCount = 15
    
    @IBAction func SOSBtnPressed(_ sender:UIButton) {
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        
        BackView.center = (window?.center)!
        
        window?.addSubview(BackView)
        SOSView.center = BackView.center
        
        BackView.addSubview(SOSView!)
       
        self.TimerLbl.text = "15"
        TimerCount = 15
        SOSView.alpha = 0
        UIView.animate(withDuration: 0.5) {
            self.SOSView.alpha = 1
            
            self.TimerSOS = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.TimerRunningSOS(_:)), userInfo: nil, repeats: true)
        }
    }
    
    func TimerRunningSOS(_ timer:Timer) {
    
        if TimerCount > 0 {
            TimerCount -= 1
            TimerLbl.text = "\(TimerCount)"
        }
        else {
            
            CloseSos()

            if ((NSString.init(string:LoginResponce.HelpDeskno!)).rangeOfCharacter(from: CharacterSet.decimalDigits.inverted)).location == NSNotFound {
                UIApplication.shared.openURL(URL.init(string: "tel://\(LoginResponce.HelpDeskno!)")!)
            }
            else {
                UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Invalid Helpdesk Number", Interval: 3)
            }
            
            
            sendToEmergencyContacts()
            
        }
        
    }
    
    var LocationManager = CLLocationManager()
    var IsLocationSend = false
    var Numbers = [String]()
    func sendToEmergencyContacts() {
        
        
        guard FetchEmergencyContacts() != nil  else {
            return
        }
        
        if (FetchEmergencyContacts()?.count)! > 0 {
            Numbers = [String]()
            
            for number in FetchEmergencyContacts()! {
                Numbers.append(number.Number!)
            }
            
            LocationManager.delegate = self
            LocationManager.requestWhenInUseAuthorization()
            LocationManager.startUpdatingLocation()

        }
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let CurrentLocation = locations.last!
        if !IsLocationSend {
            IsLocationSend = false
            manager.stopUpdatingLocation()
            GMSGeocoder().reverseGeocodeCoordinate(CurrentLocation.coordinate) { (ReverseGeoCodeResponce, error) in
                if error == nil {
                    let address = ReverseGeoCodeResponce?.results()?[0].lines
                    
                    var AddAddress = ""
                    for addstr in address! {
                        AddAddress.append(addstr + ", ")
                    }
                    
                    let addStr = AddAddress.substring(to: AddAddress.index(AddAddress.endIndex, offsetBy: -2))
                    
                    if (MFMessageComposeViewController.canSendText()) {
                        let controller = MFMessageComposeViewController()
                        controller.body = "\(self.LoginResponce.Name!)" + " is in an emergency situation and needs help immediately.\nLocation: "
                            + addStr + "\nhttp://maps.google.com/?q="
                            + "\(CurrentLocation.coordinate.latitude)" + ","
                            + "\(CurrentLocation.coordinate.longitude)"
                        controller.recipients = self.Numbers
                        controller.messageComposeDelegate = self
                        self.present(controller, animated: true, completion: nil)
                    }
                }
                else {
                    print("reverseGeoCodeResponse is nil (no location):",(error?.localizedDescription)!)
                    if (MFMessageComposeViewController.canSendText()) {
                        let controller = MFMessageComposeViewController()
                        controller.body = "\(self.LoginResponce.Name!)" + " is in an emergency situation and needs help immediately."
                        controller.recipients = self.Numbers
                        controller.messageComposeDelegate = self
                        self.present(controller, animated: true, completion: nil)
                    }
                }
            }
            
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse || status == .authorizedAlways {
            LocationManager.startUpdatingLocation()
        }else{
            print("In didChangeAuthorization,not allowed location")
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("LocationError:===:", error.localizedDescription)
    }

    
    func CloseSos() {
        UIView.animate(withDuration: 0.3, animations: {
            self.SOSView.alpha = 0
        }) { (yes) in
            if yes {
                self.SOSView.alpha = 1
                self.SOSView.superview?.removeFromSuperview()
                self.stopSound()
                self.SiranBtn.isSelected = false
                self.TimerSOS.invalidate()
            }
        }
    }
    
    @IBAction func CallImediately(_ sender:UIButton) {
        
        CloseSos()

        if ((NSString.init(string:LoginResponce.HelpDeskno!)).rangeOfCharacter(from: CharacterSet.decimalDigits.inverted)).location == NSNotFound {
            
            if #available(iOS 10, *) {
                UIApplication.shared.open(URL.init(string: "tel://\(LoginResponce.HelpDeskno!)")!, options: [:], completionHandler: nil)
            }
            else {
                UIApplication.shared.openURL(URL.init(string: "tel://\(LoginResponce.HelpDeskno!)")!)
            }
            
        }
        else {
            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Invalid Helpdesk Number", Interval: 3)
        }
        
        sendToEmergencyContacts()
    }
    
    
    @IBAction func StopCallBtn(_ sender:UIButton) {
        CloseSos()
    }
    
    @IBAction func Play_StopSiranBtn(_ sender:UIButton) {
        if sender.isSelected {
            sender.isSelected = false
            stopSound()
        }
        else {
            sender.isSelected = true
            playSound()
        }
    }
    
    var player : AVAudioPlayer?
    
    func playSound() {
        let url = Bundle.main.url(forResource: "Siren", withExtension: "mp3")!
        
        do {
            player = try AVAudioPlayer(contentsOf: url)
            guard let player = player else { return }
            
            player.prepareToPlay()
            player.play()
        } catch let error as NSError {
            print(error.description)
        }
    }
    func stopSound(){
        player?.stop()
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    // MARK: - }
    
    
    // MARK: - Call For DriveBooking Api {
    
    func CallDriveBooking() {
        if (Reachability()?.isReachable)! {
            
            UIApplication.shared.keyWindow?.StartLoading()

            let Dict = ["UserName":"\(LoginDetails.UserID!)",
                        "Password":"\(LoginDetails.Password!)",
                        "VendorId":"\(LoginResponce.BookingAppVendorid!)",
                        "CorporateId":"\(LoginResponce.BookingAppCorporateId!)",
                        "AppCustomerType":"\(LoginResponce.BookingAppTyped!)",
                        "Version":"\(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString")!)",
                        "DeviceToken":"\(LoginDetails.DeviceToken!)",
                        "DeviceIMEINO":"\(LoginDetails.DeviceIMEI!)",
                        "DeviceType":"\(LoginDetails.DeviceType!)"]
            
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveLogin, parameterDict: Dict, securityKey: WebServicesUrl.DummySecurity, completion: { (DriveResponceDict, responceDoce, success)  in
                
                if success {
                    
                    let data = DriveResponceDict as! [String:AnyObject]
                    
                    print("From MainVC CallDriveBooking :",data);
                    
                    if let Table = (data["Table"] as! [[String:AnyObject]?])[0] , "\(Table["Status"]!)".toBool()! {
                        
                        SaveDriveRequest(request: Dict)

                        SaveDriveResponce(DriveResponce: Table)
                        
                        let MainController = self.storyboard?.instantiateViewController(withIdentifier: "corporate") as! UINavigationController
                        let LeftController = self.storyboard?.instantiateViewController(withIdentifier: "MenuCarporateVC")

                        
                        let slideMenuController = SlideMenuController(mainViewController: MainController, leftMenuViewController: LeftController!)

                        self.present(slideMenuController, animated: true, completion: nil)

                        
                    }
                    else {
                        UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "\(((data["Table"] as! [[String:AnyObject]?])[0]?["Response"]!)!)", Interval: 3)
                    }
                    
                }
                else {
                    UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Internal Error", Interval: 3)
                }
                
                UIApplication.shared.keyWindow?.StopLoading()

            })
        }
        else {
            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "No Active Internet Connection found", Interval: 3)
        }
    }
    
    // MARK: - }
    
}

