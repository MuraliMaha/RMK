//
//  OffersCell.swift
//  Drive Booking
//
//  Created by Amar on 18/04/17.
//  Copyright © 2017 suntelematics. All rights reserved.
//

import UIKit

class OffersCell: UICollectionViewCell {
    
    @IBOutlet weak var offersImage: UIImageView!
}
