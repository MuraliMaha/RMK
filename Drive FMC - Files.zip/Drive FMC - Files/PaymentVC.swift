
//
//  PaymentVC.swift
//  IBMBlueMix
//
//  Created by Amarnath B on 22/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit
import Alamofire

class PaymentVC: UIViewController, MobiKwikSignInDelegate, MobiKwikAddMoneyDelegate, PaytmSignInDelegate, PaytmAddMoneyDelegate {

    @IBOutlet var PaymentTable: UITableView!
    
    var PaymentsArr = [PaymentTypes]()

    var MobiToken: String!
    var MobiMobile: String!
    
    var PaytmToken: String!
    var PaytmMobile: String!
    
    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!
   
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        PaymentTable.tableFooterView = UIView.init(frame: CGRect.zero)
        
        var Type1 = PaymentTypes()
        Type1.PaymentTitle = "Cash"
        Type1.PaymentImage = #imageLiteral(resourceName: "cashinhand")
        Type1.State = .notRequired
        
        var Type2 = PaymentTypes()
        Type2.PaymentTitle = "Paytm"
        Type2.PaymentImage = #imageLiteral(resourceName: "PaytmLogo")
        Type2.State = PaymentOptionState.loading
        
        var Type3 = PaymentTypes()
        Type3.PaymentTitle = "MobiKwik"
        Type3.PaymentImage = #imageLiteral(resourceName: "MobikwikIcon")
        Type3.State = PaymentOptionState.loading
        
        PaymentsArr.append(Type1)
        PaymentsArr.append(Type2)
        PaymentsArr.append(Type3)
        
        self.LoginRequest = FetchDriveRequest()
        self.DriveBookingResponce = FetchDriveResponce()
        
        PaytmToken = DriveBookingResponce.SSOToken!
        PaytmMobile = DriveBookingResponce.PaytmWalletNo!
        
        MobiToken = DriveBookingResponce.WalletToken!
        MobiMobile = DriveBookingResponce.WalletMobileNo!
        
        self.perform(#selector(LoadAfterDelay), with: self, afterDelay: 0.2)
    }
    
    func LoadAfterDelay() {
        PaymentTable.reloadData()
        CheckPaytmTokes()
        CheckMobiKwikIsthere()
    }
    
    func ShowLink(isTrue:Bool,Balance:String) {
        
        if isTrue {
            PaymentsArr[2].State = PaymentOptionState.notLinked
        }
        else {
            var Done = PaymentMethodData()
            Done.balance = Balance
            Done.mobileNumber = DriveBookingResponce.WalletMobileNo!
            PaymentsArr[2].State = PaymentOptionState.Done(Done)
        }
        
        self.PaymentTable.reloadData()
    }
    
    func CheckMobiKwikIsthere() {
        
        if MobiToken == nil || MobiToken! == "NA" || MobiToken! == "" || MobiMobile == nil || MobiMobile! == "NA" || MobiMobile! == "" {
            self.ShowLink(isTrue: true, Balance: "")
            return
        }
        
        RegenerateToken()
        
    }

    func RegenerateToken() {
        
        if !(Reachability()?.isReachable)! {
            self.ShowLink(isTrue: true, Balance: "")
            return
        }
        
        
        let tokentype       = "1"
        let cell            = MobiMobile!
        let msgcode         = "507"
        let mid             = MobiCreds.MID
        let merchantname    = MobiCreds.MerchentName
        
        let SecretKey = MobiCreds.RegenrationSecurity
        
        let VariableFormat  = "'\(cell)''\(merchantname)''\(mid)''\(msgcode)''\(MobiToken!)''\(tokentype)'" // ‘cell’‘merchantname’‘mid’‘msgcode’'Token''tokentype'
        
        let checksum        = VariableFormat.hmac(algorithm: .SHA256, key: SecretKey)
        
        let parserStr       = Parser(dict: ["cell":cell,"msgcode":msgcode,"mid":mid,"merchantname":merchantname,"tokentype":tokentype,"token":MobiToken!,"checksum":checksum])
        
        let UrlFormat       =  MobiCreds.BaseUrl + "/" + MobiCreds.Tokenregenerate + "?" + parserStr
        
        let url             = URL.init(string: UrlFormat.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!
        
        var Request         = URLRequest.init(url: url)
        Request.httpMethod  = "GET"
        Request.allHTTPHeaderFields = ["payloadtype":"json"]
        
        Alamofire.request(Request)
            .responseJSON { (responce) in
                
                switch responce.result {
                case .success(let Value):
                    //print(Value)
                    let responceData = Value as! [String:AnyObject]
                    if "\(responceData["status"]!)" == "SUCCESS" {
                        self.MobiToken = "\(responceData["token"]!)"
                        self.DriveBookingResponce.WalletToken = self.MobiToken
                        saveDriveResponceStuct(driveStruct: self.DriveBookingResponce!)
                        UpdatePaymentModes(WalletType_Paytm_MobiKwik: "MobiKwik", MobileNo: self.DriveBookingResponce.WalletMobileNo!, Token: self.MobiToken, ExpData_oMobi_Paytmdate: "0", CompletionAuthError: { (isauth) in
                            if isauth {
//                                authenticationCheck(controller: self)
                            }
                        })
                        self.CheckBalance()
                    }
                    else {
                        self.ShowLink(isTrue: true, Balance: "")
                    }
                    
                    break
                case .failure(let error):
                    //print(error.localizedDescription)
                    self.ShowLink(isTrue: true, Balance: "")
                    break
                }
        }
    }

    
    func CheckBalance() {
        
        if !(Reachability()?.isReachable)! {
            self.ShowLink(isTrue: true, Balance: "")
            return
        }
        
        let cell            = MobiMobile!
        let msgcode         = "501"
        let mid             = MobiCreds.MID
        let merchantname    = MobiCreds.MerchentName
        
        let VariableFormat  = "'\(cell)''\(merchantname)''\(mid)''\(msgcode)''\(MobiToken!)'" // ‘cell’‘merchantname’‘mid’‘msgcode’'Token'
        
        let checksum        = VariableFormat.hmac(algorithm: .SHA256, key: MobiCreds.Secret)
        
        let parserStr       = Parser(dict: ["cell":cell,"msgcode":msgcode,"mid":mid,"merchantname":merchantname,"token":MobiToken!,"checksum":checksum])
        
        let UrlFormat       =  MobiCreds.BaseUrl + "/" + MobiCreds.userbalance + "?" + parserStr
        
        let url             = URL.init(string: UrlFormat.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!
        
        var Request         = URLRequest.init(url: url)
        Request.httpMethod  = "GET"
        Request.allHTTPHeaderFields = ["payloadtype":"json"]
        Alamofire.request(Request)
            .responseJSON { (responce) in
                
                switch responce.result {
                case .success(let Value):
                    print(Value)
                    
                    let responceData = Value as! [String:AnyObject]

                    if "\(responceData["status"]!)" == "SUCCESS" {
                        let Balance = String.init(format: "%.2f", Float("\(responceData["balanceamount"]!)")!)
                        self.ShowLink(isTrue: false, Balance: "₹" + Balance)
                        SaveMobiKwikBalance(token: Balance)
                    }
                    else {
                        self.ShowLink(isTrue: true, Balance: "")
                    }
                    
                    break
                case .failure(let error):
                    //print(error.localizedDescription)
                    self.ShowLink(isTrue: true, Balance: "")
                    break
                }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        
        if segue.identifier == "MobiKwikSigninSeg" {
            let controller = segue.destination as! MobiKwikSignInVc
            controller.Delegate = self
        }
        else if segue.identifier == "MobiKwikAfterSignin" {
            let controller = segue.destination as! MobiKwikAddMoney
            controller.Delegate = self
        }
        else if segue.identifier == "PaytmSignInSeg" {
            let controller = segue.destination as! PaytmSignInVC
            controller.Delegate = self
        }
        else if segue.identifier == "PaytmAddMoneySeg" {
            let controller = segue.destination as! PatymAddMoney
            controller.Delegate = self
        }
    }

    
    // MARK: - Sign delegate
    func DidSignInCancel(controller: MobiKwikSignInVc) {
        controller.navigationController?.popViewController(animated: true)
    }
    
    func DidSignInComplete(controller: MobiKwikSignInVc) {
        controller.navigationController?.popViewController(animated: true)
        
        // Get money
        self.DriveBookingResponce = FetchDriveResponce()
        
        MobiToken = DriveBookingResponce.WalletToken!
        MobiMobile = DriveBookingResponce.WalletMobileNo!
        
        PaymentsArr[2].State = .loading
        
        CheckMobiKwikIsthere()

    }
    
    // MARK: - Add Money delegate

    func DidcancelAddMoney(controller: MobiKwikAddMoney) {
        controller.navigationController?.popViewController(animated: true)
    }
    
    func DidCompleteAddMoney(controller: MobiKwikAddMoney) {
        controller.navigationController?.popViewController(animated: true)
        
        // Get Money
        
        self.DriveBookingResponce = FetchDriveResponce()
        
        MobiToken = DriveBookingResponce.WalletToken!
        MobiMobile = DriveBookingResponce.WalletMobileNo!
        
        PaymentsArr[2].State = .loading

        CheckMobiKwikIsthere()

    }
    
    
    // MARK: - Paytm
    
    func CheckPaytmTokes() {
        
        if PaytmToken == nil || PaytmToken! == "NA" || PaytmToken! == "" || PaytmMobile == nil || PaytmMobile! == "NA" || PaytmMobile! == "" {
            self.PaytmLink(isLink: true, Balance: "")
            return
        }

        CheckPaytmBalance()
    }
    
    func PaytmLink(isLink:Bool, Balance:String) {
        if isLink {
            PaymentsArr[1].State = PaymentOptionState.notLinked
        }
        else {
            var Done = PaymentMethodData()
            Done.balance = Balance
            Done.mobileNumber = DriveBookingResponce.PaytmWalletNo!
            PaymentsArr[1].State = PaymentOptionState.Done(Done)
        }
        self.PaymentTable.reloadData()
    }
    
    func CheckPaytmBalance() {
        
        var Request = URLRequest.init(url: URL.init(string: "https://trust.paytm.in/wallet-web/checkBalance")!)
        Request.httpMethod = "GET"
        Request.allHTTPHeaderFields = ["ssotoken":PaytmToken!]
        
        Alamofire.request(Request)
            .responseJSON { (responce) in
                switch responce.result {
                case .success(let Value):
                    //print(Value)
                    let responsearray = Value as! [String:AnyObject]

                    if let Responce = responsearray["response"] as? [String:AnyObject] {
                        
                        if Responce.keys.contains("amount") {
                            let Balance = String.init(format: "%.2f", Float("\(Responce["amount"]!)")!)
                            
                            self.PaytmLink(isLink: false, Balance: "₹" + Balance)
                            SavePaytmBalance(token: Balance)
                        }
                        else{
                            Message.shared.Alert(Title: "Alert", Message: "\(Responce["message"]!) Please Re_Authorize Paytm Wallet", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                            self.PaytmLink(isLink: true, Balance: "")
                        }
                    }
                    else {
                        Message.shared.Alert(Title: "Alert", Message: "\(responsearray["statusMessage"]!) Please Re_Authorize Paytm Wallet", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                        self.PaytmLink(isLink: true, Balance: "")
                    }
                    break
                case .failure(let error):
                    //print(error.localizedDescription)
                    self.PaytmLink(isLink: true, Balance: "")

                    break
                }
                
        }
    }
    
    
    
    // Paytm SigninDelegate
    
    func PaytmDidSignInCancel(controller: PaytmSignInVC) {
        controller.navigationController?.popViewController(animated: true)
    }
    
    func PaytmDidSignInComplete(controller: PaytmSignInVC) {
        controller.navigationController?.popViewController(animated: true)
        
        // Get money
        self.DriveBookingResponce = FetchDriveResponce()
        
        PaytmToken = DriveBookingResponce.SSOToken!
        PaytmMobile = DriveBookingResponce.PaytmWalletNo!
        
        PaymentsArr[1].State = .loading
        
        CheckPaytmTokes()
    }
    
    // Paytm AddMoney Delegate

    func PaytmDidcancelAddMoney(controller: PatymAddMoney) {
        controller.navigationController?.popViewController(animated: true)
    }
    
    func PaytmDidCompleteAddMoney(controller: PatymAddMoney) {
        controller.navigationController?.popViewController(animated: true)
        
        // Get Money
        
        self.DriveBookingResponce = FetchDriveResponce()
        
        PaytmToken = DriveBookingResponce.SSOToken!
        PaytmMobile = DriveBookingResponce.PaytmWalletNo!
        
        PaymentsArr[1].State = .loading
        
        CheckPaytmTokes()
    }
}


extension PaymentVC: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return PaymentsArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PaymentCell", for: indexPath) as! PaymentCell
        
        cell.TitleImage.image = PaymentsArr[indexPath.row].PaymentImage!

        cell.contentView.layer.masksToBounds = false

        
        switch PaymentsArr[indexPath.row].State! {
        case .notRequired:
            cell.LinkBtn.isHidden = true
            cell.BalanceLbl.isHidden = true
            cell.Loader.stopAnimating()
            cell.Loader.isHidden = true
            cell.TitleLbl.text = PaymentsArr[indexPath.row].PaymentTitle!
            break
        case .notLinked:
            cell.Loader.stopAnimating()
            cell.Loader.isHidden = true
            cell.LinkBtn.isHidden = false
            cell.BalanceLbl.isHidden = true
            cell.TitleLbl.text = PaymentsArr[indexPath.row].PaymentTitle!
            break
        case .loading:
            if !cell.isLoading() {
                cell.Loader.startAnimating()
            }
            cell.Loader.isHidden = false
            cell.LinkBtn.isHidden = true
            cell.BalanceLbl.isHidden = true
            cell.TitleLbl.text = PaymentsArr[indexPath.row].PaymentTitle!
            break
        case .Done(let Done):
            cell.LinkBtn.isHidden = true
            cell.BalanceLbl.isHidden = false
            cell.Loader.stopAnimating()
            cell.Loader.isHidden = true
            
            cell.BalanceLbl.text = Done.balance!
            cell.TitleLbl.text = PaymentsArr[indexPath.row].PaymentTitle! + " (" + Done.mobileNumber! + ")"
            break
        }
        
        if indexPath.row == 0 {
            cell.Line.isHidden = false
        }
        else {
            if indexPath.row == PaymentsArr.count-1 {
                cell.Line.isHidden = true
            }
            else {
                cell.Line.isHidden = false
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        switch PaymentsArr[indexPath.row].State! {
        case .notRequired:
            break
        case .notLinked:
            if PaymentsArr[indexPath.row].PaymentTitle! == "Paytm" {
                self.performSegue(withIdentifier: "PaytmSignInSeg", sender: self)
            }
            else if PaymentsArr[indexPath.row].PaymentTitle! == "MobiKwik" {
                self.performSegue(withIdentifier: "MobiKwikSigninSeg", sender: self)
            }
            break
        case .loading:
            self.view.ShowBlackTostWithText(message: "Please wait while we loading data", Interval: 2)
            break
        case .Done(_):
            
            if PaymentsArr[indexPath.row].PaymentTitle! == "Paytm" {
                self.performSegue(withIdentifier: "PaytmAddMoneySeg", sender: self)
            }
            else if PaymentsArr[indexPath.row].PaymentTitle! == "MobiKwik" {
                self.performSegue(withIdentifier: "MobiKwikAfterSignin", sender: self)
            }
            
            break
        }
    }
}


class PaymentCell: UITableViewCell {
    @IBOutlet var TitleLbl: UILabel!
    @IBOutlet var TitleImage: UIImageView!
    @IBOutlet var LinkBtn: UIButton!
    @IBOutlet var BalanceLbl: UILabel!
    @IBOutlet var Line: UILabel!
    @IBOutlet var Loader: UIActivityIndicatorView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}

struct PaymentTypes {
    var PaymentTitle: String!
    var PaymentImage: UIImage!
    var PaymentTypeObj: PaymentType!
    var State: PaymentOptionState!
}

enum PaymentOptionState {
    case notRequired, loading, notLinked, Done(PaymentMethodData)
}

struct PaymentMethodData {
    var mobileNumber: String!
    var balance: String!
}

