//
//  DriveBookingVC.swift
//  DriveFindMyCab
//
//  Created by Admin on 08/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit
import AlamofireImage

class DriveBookingVC: UIViewController,UIAccelerometerDelegate,UIPickerViewDelegate,UIPickerViewDataSource {
    
    @IBOutlet var RideLaterType: iCarousel!
    @IBOutlet var CarType: iCarousel!
    @IBOutlet var LocationType: iCarousel!
    
    @IBOutlet var RideLaterTitle: UILabel!
    @IBOutlet var CarTitle: UILabel!
    @IBOutlet var LocationTitle: UILabel!
    
//    @IBOutlet weak var corporateButton: UIButton!
//    @IBOutlet weak var PersonalButton: UIButton!
    
    @IBOutlet var BookConfirmView:UIView!
    @IBOutlet var BookConfirmShadowView:UIView!
    @IBOutlet var BookConfirmText:UILabel!

    
    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce! 
    
    var BookingPhNo: String!
    var BookingName: String!
  
    var corporate_personal : String!
    var corporate_ID : String!
    
    @IBOutlet weak var selectPaymentBtn: UIButton!
    
    var paymentMode : String! = "SELECT PAYMENT"
    
//    @IBAction func personalAction(_ sender: UIButton) {
//        ResetAllToDefaults()
//        corporateButton.setImage(#imageLiteral(resourceName: "uncheckedBlack"), for: .normal)
//        sender.setImage(#imageLiteral(resourceName: "checkedBlack"), for: .normal)
//        corporate_personal  = "PERSONAL"
//        corporate_ID = "\(DriveBookingResponce.CorporateId!)"
//
//    }
//
//    @IBAction func corporatelAction(_ sender: UIButton) {
//        ResetAllToDefaults()
//        sender.setImage(#imageLiteral(resourceName: "checkedBlack"), for: .normal)
//        PersonalButton.setImage(#imageLiteral(resourceName: "uncheckedBlack"), for: .normal)
//        corporate_personal  = "CORPORATE"
//        corporate_ID = "\(DriveBookingResponce.CorporateId2!)"
//
//
//    }
    
    @IBOutlet var customerSupportView: UIView!
    @IBOutlet weak var customerSupportNumber: UILabel!
    
    @IBOutlet var customAlertView: UIView!
    @IBOutlet weak var alertTextLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        RideNowBtn.isHidden = true


        self.LoginRequest = FetchDriveRequest()
        self.DriveBookingResponce = FetchDriveResponce()
        
        
        if self.DriveBookingResponce.CorpBookingStatus.toBool()! {
            corporate_personal  = "CORPORATE"
            corporate_ID = "\(DriveBookingResponce.CorporateId2!)"
            CarporateLbl.alpha = 1
            PersonalLbl.alpha = 0.4
        }
        else {
            corporate_personal  = "PERSONAL"
            corporate_ID = "\(DriveBookingResponce.CorporateId!)"
            self.navigationItem.titleView = nil
            self.navigationItem.title = "RIDE LATER"
        }
        
//        corporateButton.setImage(#imageLiteral(resourceName: "checkedBlack"), for: .normal)
//        PersonalButton.setImage(#imageLiteral(resourceName: "uncheckedBlack"), for: .normal)
//        corporate_personal  = "CORPORATE"
//        corporate_ID = "\(DriveBookingResponce.CorporateId2!)"
        
        
//        corporateButton.titleLabel?.minimumScaleFactor = 0.4
//        corporateButton.titleLabel?.numberOfLines = 1
//        corporateButton.titleLabel?.adjustsFontSizeToFitWidth = true
//
//
//        PersonalButton.titleLabel?.minimumScaleFactor = 0.4
//        PersonalButton.titleLabel?.numberOfLines = 1
//        PersonalButton.titleLabel?.adjustsFontSizeToFitWidth = true

        
        RideLaterType.type = .linear
        RideLaterType.isPagingEnabled = true
        RideLaterType.stopAtItemBoundary = true
        RideLaterType.bounces = false
        
        CarType.type = .linear
        CarType.isPagingEnabled = true
        CarType.stopAtItemBoundary = true
        CarType.bounces = false
        
        LocationType.type = .linear
        LocationType.isPagingEnabled = true
        LocationType.stopAtItemBoundary = true
        LocationType.bounces = false
        
        GetVehCategory()
        GetTripTypeData()
        GetLocationImages()
        
        LocationManager.delegate = self
        LocationManager.requestWhenInUseAuthorization()
        
        // Do any additional setup after loading the view.
        self.view.StartLoading()

        FetchFavs()
        
        Timer.scheduledTimer(timeInterval: 0.2, target: self, selector: #selector(LoadTitles), userInfo: nil, repeats: false)
        
        AddSwipeGestureForOverLayViews()
        TripTypeView.isHidden = true
        VehicleSelectView.isHidden = true
        LocationSelectView.isHidden = true
        
        BookConfirmShadowView.layer.shadowColor = UIColor.lightGray.cgColor
        BookConfirmShadowView.layer.shadowOpacity = 0.5
        BookConfirmShadowView.layer.shadowOffset = CGSize.zero
        BookConfirmShadowView.layer.shadowRadius = 3
        
        AddHiddenTextfld()
        BookNowHiddenTxtMake()
        CancelBookingHiddenTxt()
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "menu"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(MenuAction))
        BackBtnItem.tintColor = UIColor.white
        self.navigationItem.leftBarButtonItem = BackBtnItem
     
//        makeCorporateSwitch()
    }
    func customAlertTapped(_ notification: NSNotification) {
        ResetAllToDefaults()
        
        // call for view with helpdesk //
        
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        //        HelpDesknumber.text = LoginResponce.HelpDeskno!
//        HelpDesknumber.text = DriveBookingResponce.CustomerCareNo!
        alertTextLabel.text = notification.userInfo?["alertMsg"] as? String
        
        BackView.center = (window?.center)!
        
        window?.addSubview(BackView)
        
        customAlertView.layer.cornerRadius = 5
        customAlertView.center = BackView.center
        
        BackView.addSubview(customAlertView!)
        
        customAlertView.alpha = 0
        
        
        let GuardianTap = UITapGestureRecognizer.init(target: self, action: #selector(BackViewTapped(_:)))
        GuardianTap.numberOfTapsRequired = 1
        BackView.addGestureRecognizer(GuardianTap)
        
        UIView.animate(withDuration: 0.5) {
            self.customAlertView.alpha = 1
        }
    }
    func BackViewTapped(_ responder:UITapGestureRecognizer) {
        
        let Point = responder.location(in: customAlertView.superview!)
        let Frame = customAlertView.frame
        
        if !Frame.contains(Point) {
            UIView.animate(withDuration: 0.3, animations: {
                self.customAlertView.alpha = 0
            }) { (yes) in
                if yes {
                    self.customAlertView.alpha = 1
                    self.customAlertView.superview?.removeFromSuperview()
                }
            }
        }
    }
        
    @IBAction func customAlertOKBtnTapped(_ sender: Any) {
        UIView.animate(withDuration: 0.3, animations: {
            self.customAlertView.alpha = 0
        }) { (yes) in
            if yes {
                self.customAlertView.alpha = 1
                self.customAlertView.superview?.removeFromSuperview()
            }
        }
    }
    
    //Customer Support
    func callCustomerSupportTapped() {
        ResetAllToDefaults()
        
        // call for view with helpdesk //
        
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)

//        let window = self.view
//        let BackView = UIView.init(frame: (window?.frame)!)
        
        
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)

        customerSupportNumber.text = DriveBookingResponce.CustomerCareNo!
        
        BackView.center = (window?.center)!
        
        window?.addSubview(BackView)
        
        customerSupportView.center = BackView.center
        
        BackView.addSubview(customerSupportView!)
        
        customerSupportView.alpha = 0
        
        
        let GuardianTap = UITapGestureRecognizer.init(target: self, action: #selector(TapAddHelpDeskView(_:)))
        GuardianTap.numberOfTapsRequired = 1
        BackView.addGestureRecognizer(GuardianTap)
        
        UIView.animate(withDuration: 0.5) {
            self.customerSupportView.alpha = 1
        }
    }
    func TapAddHelpDeskView(_ responder:UITapGestureRecognizer) {
        
        let Point = responder.location(in: customerSupportView.superview!)
        let Frame = customerSupportView.frame
        
        if !Frame.contains(Point) {
            UIView.animate(withDuration: 0.3, animations: {
                self.customerSupportView.alpha = 0
            }) { (yes) in
                if yes {
                    self.customerSupportView.alpha = 1
                    self.customerSupportView.superview?.removeFromSuperview()
                }
            }
        }
        
    }
    @IBAction func CallBtnInCallSupportTapped(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.3, animations: {
            self.customerSupportView.alpha = 0
        }) { (yes) in
            if yes {
                self.customerSupportView.alpha = 1
                self.customerSupportView.superview?.removeFromSuperview()
                
                if ((NSString.init(string:self.DriveBookingResponce.CustomerCareNo!)).rangeOfCharacter(from: CharacterSet.decimalDigits.inverted)).location == NSNotFound {
                    UIApplication.shared.openURL(URL.init(string: "tel://\(self.DriveBookingResponce.CustomerCareNo!)")!)
                }
                else {
                    UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Invalid Helpdesk Number", Interval: 3)
                }
                
            }
            
        }
    }
    @IBAction func CancelBtnInCallSupportTapped(_ sender: UIButton) {
        UIView.animate(withDuration: 0.3, animations: {self.customerSupportView.alpha = 0 })
        { (yes) in
            if yes {
                self.customerSupportView.alpha = 1
                self.customerSupportView.superview?.removeFromSuperview()
            }
        }
    }
    
   
    @IBOutlet var CarporateLbl: UILabel!
    @IBOutlet var PersonalLbl: UILabel!

    @IBOutlet var corporateSwitch: UISwitch!
    
    @IBAction func makeCorporateSwitch(sender:UISwitch) {
        if (sender.isOn) {
            CarporateLbl.alpha = 0.4
            PersonalLbl.alpha = 1
            corporate_personal  = "PERSONAL"
            corporate_ID = "\(DriveBookingResponce.CorporateId!)"
            if "\(DriveBookingResponce.RideNowStatus!)".toBool()! {
                RideNowBtn.isHidden = false
            }else{
                RideNowBtn.isHidden = true
            }
            
        }
        else {
            CarporateLbl.alpha = 1
            PersonalLbl.alpha = 0.4
            corporate_personal  = "CORPORATE"
            corporate_ID = "\(DriveBookingResponce.CorporateId2!)"
            RideNowBtn.isHidden = true
        }
        
        ResetAllToDefaults()

    }
    
    func MenuAction() {
        
        if corporate_personal == "CORPORATE" {
            NotificationCenter.default.post(name: NSNotification.Name.init("BOFC"), object: nil)
        }
        else {
            NotificationCenter.default.post(name: NSNotification.Name.init("BOFP"), object: nil)
        }
        
        self.slideMenuController()?.openLeft()
        NotificationCenter.default.post(name: NSNotification.Name.init("MENURL"), object: nil)

//        sideMenuController?.showLeftView(animated: true, completionHandler: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Data Block {
    
    struct RideTypeModel {
        var RideTypeImage:UIImage!
        var rideTypeImagerStr: String!
        var RideTypeName:String!
        var RidetypeId:String!
    }
   
    struct LocationTypeModel {
        var LocationTypeImage:UIImage!
        var LocationTypeImageStr : String!
        var LocationTypeImageName: String!
    }
 

    func GetTripTypeData() {
        
        var arr = [RideTypeModel]()
        
        for type in DriveBookingResponce.TripType {
            var Structt = RideTypeModel()
            Structt.rideTypeImagerStr = type.TripImage!
            Structt.RideTypeName = type.TripName!
            Structt.RidetypeId = type.TripId!
            arr.append(Structt)
        }
        
        RideTypeArr.removeAll()
        
        RideTypeArr = arr
    }
   
    func  GetLocationImages(){
        
        var arr = [LocationTypeModel]()
        
        for type in DriveBookingResponce.LocationType {
            var Structt = LocationTypeModel()
            Structt.LocationTypeImageStr = type.LocationImage!
            Structt.LocationTypeImageName = type.LocationName!
            arr.append(Structt)
        }
        
        LocationTypeArr.removeAll()
        
        LocationTypeArr = arr
    }

//    struct LocationTypeModel {
//        var LocationTypeImage:UIImage!
//        var LocationTypeName:String!
//    }

    
    var RideTypeArr = [RideTypeModel]()
    var LocationTypeArr = [LocationTypeModel]()
    
    struct CategoryTypeModel {
        var CategoryTypeImage:UIImage!
        var CategoryTypeName:String!
        var CategoryTypeImageUrl:String!
        var CategoryTypeId:String!
    }
    
    var CarTypeMainArr = [CategoryTypeModel]()

    func GetVehCategory() {
        
        var arr = [CategoryTypeModel]()

        for Category in DriveBookingResponce.CategoryType {
            var Structt = CategoryTypeModel()
            Structt.CategoryTypeId = Category.CategoryId!
            Structt.CategoryTypeName = Category.CategoryName!
            Structt.CategoryTypeImageUrl = Category.CategoryImage1!
            arr.append(Structt)
        }
        
        CarTypeMainArr.removeAll()
        
        CarTypeMainArr = arr
    }
    
//    var LocationTypeArr: [LocationTypeModel] = {
//        var arr = [LocationTypeModel]()
//        
//        var Location1 = LocationTypeModel()
//        Location1.LocationTypeName = "ENTER MANUALLY"
//        Location1.LocationTypeImage = #imageLiteral(resourceName: "Enter")
//        arr.append(Location1)
//        
//        var Location2 = LocationTypeModel()
//        Location2.LocationTypeName = "CURRENT LOCATION"
//        Location2.LocationTypeImage = #imageLiteral(resourceName: "Location")
//        arr.append(Location2)
//        
//        var Location3 = LocationTypeModel()
//        Location3.LocationTypeName = "FAVOURITES"
//        Location3.LocationTypeImage = #imageLiteral(resourceName: "Favourite")
//        arr.append(Location3)
//        
//        return arr
//    }()
    
    // MARK: - }

//    @IBAction func BackBtnAction(_ sender:UIButton) {
//        
//    }
    
    // MARK: - Button main actions {

    @IBOutlet var RideNowBtn:UIButton!

    @IBAction func RideBtnAction(_ sender:UIButton) {
        ResetAllToDefaults()
        
        let RideNow = self.storyboard?.instantiateViewController(withIdentifier: "RideNowVC") as! RideNowVC
        
        let transition = CATransition()
        transition.duration = 0.45
        transition.type = kCATransitionFade;
        transition.subtype = kCATransitionFromTop;
        
        self.navigationController?.view.layer.add(transition, forKey: kCATransition)
        
        self.navigationController?.pushViewController(RideNow, animated: false)
        
    }
    
    @IBOutlet var RefreshAllBtn:UIButton!
    
    @IBAction func RefreshAllBtnAction(_ sender:UIButton) {
        ResetAllToDefaults()
    }
    
    // MARK: - }
    
    // MARK: - Overlay Confirm View Make {
    
    @IBOutlet var TripTypeView: UIView!
    @IBOutlet var VehicleSelectView: UIView!
    @IBOutlet var LocationSelectView: UIView!

    @IBOutlet var TripTypeCollectionView: UICollectionView!
    @IBOutlet var VehicleSelectCollectionView: UICollectionView!
    
    @IBOutlet var CouponCodeBtn: UIButton!
    @IBOutlet var FevorateBtn: UIButton!
    @IBOutlet var SelectedLocationLbl: UILabel!

    @IBAction func FavorateBtnAction(_ sender:UIButton) {
        if sender.isSelected {
            sender.isSelected = false
        }
        else {
            Message.shared.Alert(Title: "Save Location as your Favourites", Message: "", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Cancel"), Message.AlertActionWithSelector(Title: "OK", Selector: #selector(AddFavorite), Controller: self)], Controller: self)
        }
    }
    
    var FavLocArr = [FavouritesLocationsStruct]()
    func AddFavorite() {
        FetchFavs()
        
        if FavLocArr.count == 3 {
            
            if FavLocArr.contains(where: {$0.Location! == LocationViewStruct.Location!}) {
                FevorateBtn.isSelected = true
            }
            else {
                
                Message.shared.Alert(Title: "Alert!", Message: "You can add only up to 3 favourites. Delete any favourite if you need to add", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Cancel"),Message.AlertActionWithSelector(Title: "Ok", Selector: #selector(OpenFavorites), Controller: self)], Controller: self)
            }
        }
        else {
            
            if FavLocArr.contains(where: {$0.Location! == LocationViewStruct.Location!}) {
                FevorateBtn.isSelected = true
            }
            else {
                FevorateBtn.isSelected = true
                FavLocArr.append(LocationViewStruct!)
                UpdateFavLocation()
            }
        }
    }
    
    func OpenFavorites() {
        let SearchController = FavoriteLocationSelectVC()
        SearchController.Delegate = self
        SearchController.IsSearchNeeded = false
        SearchController.SelectionDisable = true
        self.present(SearchController, animated: true, completion: nil)
    }
    
    func UpdateFavLocation() {
        
        UIApplication.shared.keyWindow?.StartLoading()
        
        var StringObj = ""
        for FavStrObj in self.FavLocArr {
            let Str = "\(FavStrObj.Latitude!)" + "|" + "\(FavStrObj.Longitude!)" + "|" + "\(FavStrObj.Location!)" + "~"
            StringObj.append(Str)
        }
        
        let FavDict = ["EmpId":"\(DriveBookingResponce.EmpId!)","Favourites":StringObj,"VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
        
        WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveSetFavouritePlaces, parameterDict: FavDict, securityKey: DriveBookingResponce.AuthenticationToken!) { (ResponceDict, responceCode, success) in
            
            UIApplication.shared.keyWindow?.StopLoading()
            
            if success {
                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Favorite location Added successfully", Interval: 3)
                SaveFavoritesAs(FavoritesStructArr: self.FavLocArr)
            }
            else {
                self.FevorateBtn.isSelected = false
                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
            }
        }
    }
    
    func FetchFavs() {
        guard (FetchFavouritesLocation() != nil) else {
            return
        }
        FavLocArr = FetchFavouritesLocation()!
    }
    
    @IBAction func HaveAcouponBtnAction(_ sender:UIButton) {
        if sender.titleLabel?.text == "Have a Coupon?" {
            CouponViewMake()
        }
    }
    
    

    struct CollectionSelectStruct {
        var Image:UIImage!
        var Title:String!
        var Desc:String!
    }
    
    var SelectedTripType : TripType!
    
    var TripTypeArr = [CollectionSelectStruct]()
    
    var IsGoingToAirport = true
    var TripDateTime: String!
    
    var NumberOfDays = "0"
    var OutStationFav: FavouritesLocationsStruct!

    
    
    // MARK: - Adding Overlays {
    
    func AddTripView() {
        
        TripTypeView.removeFromSuperview()

        TripTypeView.isHidden = false
        
//        TripTypeView.frame = CGRect.init(x: 0, y: RideLaterType.frame.minY, width: self.view.frame.width, height: RideLaterTitle.frame.maxY)
        TripTypeView.frame = CGRect.init(x: 0, y: RideLaterType.frame.minY, width: self.view.frame.width, height: RideLaterTitle.frame.maxY - RideLaterType.frame.minY)
        
        TripTypeArr.removeAll()
        
        switch SelectedTripType! {
        case .airport:
            var Struc1 = CollectionSelectStruct()
            Struc1.Image = UIImage.init(named: "trip_dash")
            Struc1.Title = "TRIP TYPE"
            Struc1.Desc = "Airport"
            
            var Struc2 = CollectionSelectStruct()
            Struc2.Image = UIImage.init(named: "date_dash")
            Struc2.Title = "DateTime"
            Struc2.Desc = TripDateTime!
            
            TripTypeArr = [Struc1,Struc2]
            break
        case .outstation:
            var Struc1 = CollectionSelectStruct()
            Struc1.Image = UIImage.init(named: "trip_dash")
            Struc1.Title = "TRIP TYPE"
            Struc1.Desc = "Outstation"
            
            var Struc2 = CollectionSelectStruct()
            Struc2.Image = UIImage.init(named: "date_dash")
            Struc2.Title = "DateTime"
            Struc2.Desc = TripDateTime!
            
            var Struc3 = CollectionSelectStruct()
            Struc3.Image = UIImage.init(named: "days_dash")
            Struc3.Title = "No of Days"
            Struc3.Desc = NumberOfDays
            
            var Struc4 = CollectionSelectStruct()
            Struc4.Image = UIImage.init(named: "dest_dash")
            Struc4.Title = "Destination"
            Struc4.Desc = OutStationFav.Location!
            
            TripTypeArr = [Struc1,Struc2,Struc3,Struc4]
            
            break
        case .package:
            
            var Struc1 = CollectionSelectStruct()
            Struc1.Image = UIImage.init(named: "trip_dash")
            Struc1.Title = "TRIP TYPE"
            Struc1.Desc = "Package"
            
            var Struc2 = CollectionSelectStruct()
            Struc2.Image = UIImage.init(named: "date_dash")
            Struc2.Title = "DateTime"
            Struc2.Desc = TripDateTime!
            
            TripTypeArr = [Struc1,Struc2]
            
            break
        }
        
        let animation = CATransition()
        animation.duration = 0.8
        animation.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
        animation.fillMode = kCAFillModeForwards
        animation.isRemovedOnCompletion = false
        animation.type = kCATransitionPush
        animation.subtype = kCATransitionFromLeft
        TripTypeView.layer.add(animation, forKey: "animation")
        self.view.addSubview(TripTypeView)
        
        TripTypeCollectionView.reloadData()
    }
    
    var vehicleTypeArr = [CollectionSelectStruct]()
    
    func AddVehicleTypeView() {
        
        VehicleSelectView.removeFromSuperview()
        
        VehicleSelectView.isHidden = false
        
//        VehicleSelectView.frame = CGRect.init(x: 0, y: RideLaterTitle.frame.maxY, width: self.view.frame.width, height: CarTitle.frame.maxY-CarType.frame.minY)
        
//        VehicleSelectView.frame = CGRect.init(x: 0, y: CarType.frame.minY, width: self.view.frame.width, height: CarTitle.frame.maxY-CarType.frame.minY)
        
        VehicleSelectView.frame = CGRect.init(x: 0, y: CarType.frame.minY, width: self.view.frame.width, height: CarTitle.frame.maxY-CarType.frame.minY)
        
        vehicleTypeArr.removeAll()
        
        let Vehicle = ParseVehicle(Tariff: "\(PackageSelected["Tariff"]!)")
        
        var Struc1 = CollectionSelectStruct()
        Struc1.Image = UIImage.init(named: "Drive")
        Struc1.Title = "VEHICLE TYPE"
        Struc1.Desc = CarTypeMainArr[CarType.currentItemIndex].CategoryTypeName!
        
        var Struc2 = CollectionSelectStruct()
        Struc2.Image = UIImage.init(named: "est_fare")
        Struc2.Title = "ESTIMATED FARE"
        Struc2.Desc = "N/A"
        
        var Struc3 = CollectionSelectStruct()
        Struc3.Image = UIImage.init(named: "model_dash")
        Struc3.Title = "MODEL"
        Struc3.Desc = Vehicle.Name!
        
        vehicleTypeArr = [Struc1,Struc2,Struc3]
        
        let animation = CATransition()
        animation.duration = 0.8
        animation.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
        animation.fillMode = kCAFillModeForwards
        animation.isRemovedOnCompletion = false
        animation.type = kCATransitionPush
        animation.subtype = kCATransitionFromLeft
        VehicleSelectView.layer.add(animation, forKey: "animation")
        self.view.addSubview(VehicleSelectView)
        
        VehicleSelectCollectionView.reloadData()
    }
    
    func ParseVehicle(Tariff:String) -> vehicleTarif {
        let ParseArr = Tariff.components(separatedBy: "#")
        let VehicleParse = ParseArr[0].components(separatedBy: "|")
        let VehicleTitle = VehicleParse[0]
        let VehicleFare = VehicleParse[1].components(separatedBy: ",")
        
        var StructObj = vehicleTarif()
        StructObj.Name = VehicleTitle
        StructObj.BaseFare = VehicleFare[0].components(separatedBy: ":")[1]
        StructObj.BaseKM = VehicleFare[1].components(separatedBy: ":")[1]
        StructObj.BaseHour = VehicleFare[2].components(separatedBy: ":")[1]
        StructObj.ExtraRatePerKM = VehicleFare[3].components(separatedBy: ":")[1]
        StructObj.ExtraRatePerHour = VehicleFare[4].components(separatedBy: ":")[1]

        return StructObj
    }
    
    struct vehicleTarif {
        var Name:String!
        var BaseFare:String!
        var BaseKM:String!
        var BaseHour:String!
        var ExtraRatePerKM:String!
        var ExtraRatePerHour:String!
    }
    
    
    var LocationViewStruct :FavouritesLocationsStruct!
    var isFavLocation = false
    
    var LocationManager = CLLocationManager()
    
    var IsCouponAvailable = false
    
    var CouponCode = "0"
    
    func AddLocationAndFinal() {
        
        LocationSelectView.removeFromSuperview()
        
        LocationSelectView.isHidden = false
        
//        LocationSelectView.frame = CGRect.init(x: 0, y: LocationType.frame.minY, width: self.view.frame.width, height: (RefreshAllBtn.frame.minY-LocationType.frame.minY)-10)
        
        LocationSelectView.frame = CGRect.init(x: 0, y: LocationType.frame.minY, width: self.view.frame.width, height: (RefreshAllBtn.frame.minY-LocationType.frame.minY)-10)
        
        SelectedLocationLbl.text = LocationViewStruct.Location!
        FevorateBtn.isSelected = isFavLocation
        
        HaveACouponChange()
        
        let animation = CATransition()
        animation.duration = 0.8
        animation.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
        animation.fillMode = kCAFillModeForwards
        animation.isRemovedOnCompletion = false
        animation.type = kCATransitionPush
        animation.subtype = kCATransitionFromLeft
        LocationSelectView.layer.add(animation, forKey: "animation")
        self.view.addSubview(LocationSelectView)
        self.perform(#selector(loadLocationText), with: self, afterDelay: 0.8)
    }
    func loadLocationText() {
        self.selectPaymentBtn.setTitle(paymentMode, for: .normal)
    }
    func HaveACouponChange() {
        
        if IsCouponAvailable {
            let underlineAttribute = [NSUnderlineStyleAttributeName: NSUnderlineStyle.styleSingle.rawValue,NSForegroundColorAttributeName:UIColor.blue] as [String : Any]
            let underlineAttributedString = NSAttributedString(string: "Coupon applied successfully", attributes: underlineAttribute)
            CouponCodeBtn.setAttributedTitle(underlineAttributedString, for: .normal)
            CouponCodeBtn.setTitleColor(UIColor.blue, for: .normal)
        }
        else {
            let underlineAttribute = [NSUnderlineStyleAttributeName: NSUnderlineStyle.styleSingle.rawValue,NSForegroundColorAttributeName:UIColor.darkGray] as [String : Any]
            let underlineAttributedString = NSAttributedString(string: "Have a Coupon?", attributes: underlineAttribute)
            CouponCodeBtn.setAttributedTitle(underlineAttributedString, for: .normal)
            CouponCodeBtn.setTitleColor(UIColor.darkGray, for: .normal)
        }
    }
    
    var CityName = ""
    
    func CallServiceForEstimationFetch() {
        
        if SelectedTripType! == .package {
            
            let Vehicle = ParseVehicle(Tariff: "\(PackageSelected["Tariff"]!)")
            vehicleTypeArr[1].Desc = "Rs. \(Vehicle.BaseFare!)"
            VehicleSelectCollectionView.reloadData()
            
            AddLocationAndFinal()

        }
        else {
//            AddLocationAndFinal()
            if (LocationManager.location == nil) {
                ShowLocationDenied(controller: self)
            }
            else if (Reachability()?.isReachable)! {
                
                var PickLat = 0.0
                var PickLon = 0.0
                var DropLat = 0.0
                var DropLon = 0.0
                
                let ManagerLat = (LocationManager.location?.coordinate.latitude)!
                let ManagerLon = (LocationManager.location?.coordinate.longitude)!
                
                switch SelectedTripType! {
                case .airport:
                    if IsGoingToAirport {
                        PickLat = ManagerLat
                        PickLon = ManagerLon
                        DropLat = 0.0
                        DropLon = 0.0
                    }
                    else {
                        PickLat = 0.0
                        PickLon = 0.0
                        DropLat = ManagerLat
                        DropLon = ManagerLon
                    }
                    break
                case .outstation:
                    PickLat = ManagerLat
                    PickLon = ManagerLon
                    DropLat = OutStationFav.Latitude!
                    DropLon = OutStationFav.Longitude!
                    break
                default:
                    break
                }
                let CityArr = DriveBookingResponce.CityDetails.sorted(by: {$0.0.CityName.localizedCaseInsensitiveCompare($0.1.CityName) == ComparisonResult.orderedAscending})
                let RequestDict = ["PickUpLat":"\(PickLat)",
                    "PickUpLon":"\(PickLon)",
                    "DropLat":"\(DropLat)",
                    "DropLon":"\(DropLon)",
                    "VehicleCategory":"\(CarTypeMainArr[CarType.currentItemIndex].CategoryTypeId!)",
                    "VehicleModel":"\(vehicleTypeArr[2].Desc!)",
                    "TypeofTrip":"\(RideTypeArr[RideLaterType.currentItemIndex].RideTypeName!)",
                    "City":"\(CityName == "" ? CityArr[0].CityName! : CityName.contains(" ") ? CityName.components(separatedBy: " ")[0]: CityName)",
                    "EmpId":"\(DriveBookingResponce.EmpId!)",
//                    "BookingType":"\(RideTypeArr[RideLaterType.currentItemIndex].RideTypeName!)",
                    "VendorId":"\(LoginRequest.LoginCreds.VendorId!)",
//                    "CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)",
                    "AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)",
                    "BookingType":"\(corporate_personal!)",
                    "CorporateId":"\(corporate_ID!)",
                    "Status":"1"]
                print("In CallServiceForEstimationFetch ie.CurrentLocation in CollectionView Tapped",RequestDict)
                WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveEstimateRideForBooking, parameterDict: RequestDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (ResponceDict, responceCode, success) in
                    if success {
                        if let Table = ((ResponceDict as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0],"\(Table["Response"]!)" == "Success" && ( "\(Table["Status"]!)" == "true" ) {
                            print(Table)
                            self.vehicleTypeArr[1].Desc = "\(Table["TotalFare"]!)"
                            self.VehicleSelectCollectionView.reloadData()
                            self.AddLocationAndFinal()
                        }
                        else {
                            self.AddLocationAndFinal()
                        }
                    }
                    else {
                        
//                        self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                        self.vehicleTypeArr[1].Desc = "NA"
                        self.VehicleSelectCollectionView.reloadData()
                        self.AddLocationAndFinal()
                    }
                })
                
            }
            else {
                self.view.ShowBlackTostWithText(message: "No Active Internet Connection Found", Interval: 2)
            }
            

        }
        
    }
    
    // MARK: - }
    
    // MARK: - Remove Overlay {

    func RemoveTripView(Direction Right:Bool) {
        
        if !LocationSelectView.isHidden {
            let animationVeh = CATransition()
            animationVeh.duration = 0.6
            animationVeh.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
            animationVeh.fillMode = kCAFillModeForwards
            animationVeh.isRemovedOnCompletion = false
            animationVeh.type = kCATransitionPush
            animationVeh.subtype = Right ? kCATransitionFromRight : kCATransitionFromLeft
            VehicleSelectView.layer.add(animationVeh, forKey: "animation")
            
            let animationTrip = CATransition()
            animationTrip.duration = 0.6
            animationTrip.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
            animationTrip.fillMode = kCAFillModeForwards
            animationTrip.isRemovedOnCompletion = false
            animationTrip.type = kCATransitionPush
            animationTrip.subtype = Right ? kCATransitionFromRight : kCATransitionFromLeft
            TripTypeView.layer.add(animationTrip, forKey: "animation")
            
            let animationLoc = CATransition()
            animationLoc.duration = 0.6
            animationLoc.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
            animationLoc.fillMode = kCAFillModeForwards
            animationLoc.isRemovedOnCompletion = false
            animationLoc.type = kCATransitionPush
            animationLoc.subtype = Right ? kCATransitionFromRight : kCATransitionFromLeft
            LocationSelectView.layer.add(animationLoc, forKey: "animation")
        }
        else if !VehicleSelectView.isHidden {
            let animationVeh = CATransition()
            animationVeh.duration = 0.6
            animationVeh.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
            animationVeh.fillMode = kCAFillModeForwards
            animationVeh.isRemovedOnCompletion = false
            animationVeh.type = kCATransitionPush
            animationVeh.subtype = Right ? kCATransitionFromRight : kCATransitionFromLeft
            VehicleSelectView.layer.add(animationVeh, forKey: "animation")
            
            let animationTrip = CATransition()
            animationTrip.duration = 0.6
            animationTrip.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
            animationTrip.fillMode = kCAFillModeForwards
            animationTrip.isRemovedOnCompletion = false
            animationTrip.type = kCATransitionPush
            animationTrip.subtype = Right ? kCATransitionFromRight : kCATransitionFromLeft
            TripTypeView.layer.add(animationTrip, forKey: "animation")
        }
        else {
            let animation = CATransition()
            animation.duration = 0.6
            animation.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
            animation.fillMode = kCAFillModeForwards
            animation.isRemovedOnCompletion = false
            animation.type = kCATransitionPush
            animation.subtype = Right ? kCATransitionFromRight : kCATransitionFromLeft
            TripTypeView.layer.add(animation, forKey: "animation")
        }
        TripTypeView.isHidden = true
        VehicleSelectView.isHidden = true
        LocationSelectView.isHidden = true
    }
    
    func RemoveVehicleView(Direction Right:Bool) {
        
        if !LocationSelectView.isHidden {
            let animationVeh = CATransition()
            animationVeh.duration = 0.6
            animationVeh.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
            animationVeh.fillMode = kCAFillModeForwards
            animationVeh.isRemovedOnCompletion = false
            animationVeh.type = kCATransitionPush
            animationVeh.subtype = Right ? kCATransitionFromRight : kCATransitionFromLeft
            VehicleSelectView.layer.add(animationVeh, forKey: "animation")
            
            let animationLoc = CATransition()
            animationLoc.duration = 0.6
            animationLoc.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
            animationLoc.fillMode = kCAFillModeForwards
            animationLoc.isRemovedOnCompletion = false
            animationLoc.type = kCATransitionPush
            animationLoc.subtype = Right ? kCATransitionFromRight : kCATransitionFromLeft
            LocationSelectView.layer.add(animationLoc, forKey: "animation")
        }
        else {
            let animationVeh = CATransition()
            animationVeh.duration = 0.6
            animationVeh.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
            animationVeh.fillMode = kCAFillModeForwards
            animationVeh.isRemovedOnCompletion = false
            animationVeh.type = kCATransitionPush
            animationVeh.subtype = Right ? kCATransitionFromRight : kCATransitionFromLeft
            VehicleSelectView.layer.add(animationVeh, forKey: "animation")

        }
        VehicleSelectView.isHidden = true
        LocationSelectView.isHidden = true
    }
    
    func RemoveLocationAndFinalView(Direction Right:Bool) {
        
        LocationSelectView.isHidden = true
        
        let animationLoc = CATransition()
        animationLoc.duration = 0.6
        animationLoc.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
        animationLoc.fillMode = kCAFillModeForwards
        animationLoc.isRemovedOnCompletion = false
        animationLoc.type = kCATransitionPush
        animationLoc.subtype = Right ? kCATransitionFromRight : kCATransitionFromLeft
        LocationSelectView.layer.add(animationLoc, forKey: "animation")
    }
    
    
    func AddSwipeGestureForOverLayViews() {
        
        for i in 1..<4 {
            let LeftGesture = UISwipeGestureRecognizer.init(target: self, action: #selector(Swipe(_:)))
            LeftGesture.view?.tag = i
            LeftGesture.direction = .left
            
            let RightGesture = UISwipeGestureRecognizer.init(target: self, action: #selector(Swipe(_:)))
            RightGesture.view?.tag = i
            RightGesture.direction = .right
            
            switch i {
            case 1:
                TripTypeView.addGestureRecognizer(RightGesture)
                TripTypeView.addGestureRecognizer(LeftGesture)
                TripTypeView.tag = i
                break
            case 2:
                VehicleSelectView.addGestureRecognizer(RightGesture)
                VehicleSelectView.addGestureRecognizer(LeftGesture)
                VehicleSelectView.tag = i
                break
            case 3:
                LocationSelectView.addGestureRecognizer(RightGesture)
                LocationSelectView.addGestureRecognizer(LeftGesture)
                LocationSelectView.tag = i
                break
            default:
                break
            }
            
        }
        
    }
    
    func Swipe(_ responder:UISwipeGestureRecognizer) {
        switch responder.state {
        case .ended:

            switch (responder.view?.tag)! {
            case 1:
                self.RemoveTripView(Direction: responder.direction == .right ? false : true)
                break
            case 2:
                self.RemoveVehicleView(Direction: responder.direction == .right ? false : true)
                break
            case 3:
                self.RemoveLocationAndFinalView(Direction: responder.direction == .right ? false : true)
                break
            default:
                break
            }
            
            break
        default:
            break
        }
    }

    // MARK: - }
    
    var HiddenTxt = UITextField()
    var PackageSelectPicker = UIPickerView()
    var PackageDetailsArr = [[String:AnyObject]]()
    var PackageSelected = [String:AnyObject]()
    
    func AddHiddenTextfld() {
        
        HiddenTxt.frame = CGRect.init(x: 1000, y: 1000, width: 10, height: 10)
        self.view.addSubview(HiddenTxt)
        PackageSelectPicker.dataSource = self
        PackageSelectPicker.delegate = self
        
        let Toolbar = UIToolbar()
        Toolbar.barStyle = .default
        Toolbar.isTranslucent = true
        Toolbar.tintColor = UIColor.blue
        Toolbar.sizeToFit()
        let DoneItem = UIBarButtonItem.init(title: "SELECT", style: .done, target: self, action: #selector(PickselectAction))
        let FlexiItem = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let CancelItem = UIBarButtonItem.init(title: "CANCEL", style: .done, target: self, action: #selector(PickCancelAction))
        Toolbar.setItems([CancelItem,FlexiItem,DoneItem], animated: true)
        Toolbar.isUserInteractionEnabled = true
        HiddenTxt.inputView = PackageSelectPicker;
        HiddenTxt.inputAccessoryView = Toolbar;
    }
    
    var SelectedIndex = 0
    
    func PickselectAction() {
        PackageSelected = PackageDetailsArr[SelectedIndex]
        HiddenTxt.resignFirstResponder()
        self.AddVehicleTypeView()
    }
    
    func PickCancelAction() {
        HiddenTxt.resignFirstResponder()
    }
    
    // MARK: - }
    
    
    
    // MARK: - Coupon and Coupon confirm view {
    
    @IBOutlet var CouponViewObj:UIView!
    
    @IBOutlet var CouponTxtFld:UITextField!

    var InitialPostion:CGFloat = 0.0
    
    func CouponViewMake() {
//        InitialPostion
        
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        
        BackView.center = (window?.center)!
        
        CouponViewObj.frame.size.width = self.view.frame.size.width

        window?.addSubview(BackView)
        CouponViewObj.center = BackView.center
        
        CouponViewObj.layer.cornerRadius = 3
        CouponViewObj.clipsToBounds = true
        
        BackView.addSubview(CouponViewObj!)
        
        InitialPostion = CouponViewObj.frame.origin.y
        
        CouponTxtFld.text = ""
        
        CouponViewObj.alpha = 0
        
        UIView.animate(withDuration: 0.5) {
            self.CouponViewObj.alpha = 1
        }
        
    }
    
    func CloseCouponView() {
        
        UIView.animate(withDuration: 0.3, animations: {
            self.CouponViewObj.alpha = 0
        }) { (yes) in
            if yes {
                self.CouponViewObj.alpha = 1
                self.CouponViewObj.superview?.removeFromSuperview()
            }
        }
    }
    
    @IBAction func CouponApplyBtnPressed(_ sender:UIButton) {
        
        CouponViewObj.endEditing(true)
        
        if (Reachability()?.isReachable)! {
            
            UIApplication.shared.keyWindow?.StartLoading()
            
            let Dict = ["MobileNo":"\(DriveBookingResponce.PhoneNo!)","EmpId":"\(DriveBookingResponce.EmpId!)","CouponCode":"\(CouponTxtFld.text!)","VehicleCategory":"\(CarTypeMainArr[CarType.currentItemIndex].CategoryTypeId!)","BookingType":"\(RideTypeArr[RideLaterType.currentItemIndex].RideTypeName!)","VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveCheckCouponCode, parameterDict: Dict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (ResponceDict, responceCode, success) in
                UIApplication.shared.keyWindow?.StopLoading()
                if success {
                    
                    if let Table = ((ResponceDict as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                        print(Table)

                        if "\(Table["Status"]!)" == "true" || "\(Table["Status"]!)" == "1" {
                            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "\(Table["Response"]!)", Interval: 3)
                            self.CloseCouponView()
                            self.CouponAppliedView()
                            self.LoaderStopTimer = Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(self.CloseCouponAppledView), userInfo: nil, repeats: false)
                            self.IsCouponAvailable = true
                            self.HaveACouponChange()

                        }
                        else {
                            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "\(Table["Response"]!)", Interval: 3)
                        }
                        
                    }
                    else {
                        UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message:Constants.InternalError, Interval: 3)
                    }
                    
                }
                else {
                    UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message:Constants.InternalError, Interval: 3)
                }
            })
        }
        else {
            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Constants.NetErrorMsg, Interval: 2)
        }
    }
    
    
    @IBAction func CouponCloseBtnPressed(_ sender:UIButton) {
        CloseCouponView()
    }
    
    func BookForOthers(notification: Notification){
//        self.view.ShowBlackTostWithText(message: "Now You Can Book For Others", Interval: 4)
        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "NOT AVAILABLE", Interval: 2)

        ResetAllToDefaults()
        BookingPhNo = notification.userInfo!["Number"]! as! String
        BookingName = notification.userInfo!["Name"]! as! String
    }
    
    func NoShowTost() {
        
    }
    
    func BookOWN(){
        ResetAllToDefaults()
    }
//    func callCustomerSupportTapped() {
//        ResetAllToDefaults()
//        //        let msg = "\(DriveBookingResponce.CustomerCareNo!)"
//        Message.shared.Alert(Title: "Customer Support", Message: "\(DriveBookingResponce.CustomerCareNo!)", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithSelector(Title: "CANCEL", Selector: #selector(customerCareCancelTapped), Controller: self),Message.AlertActionWithSelector(Title: "CALL", Selector: #selector(customerCareCallTapped), Controller: self)], Controller: self)
//        return
//
//    }
    
//    func customerCareCancelTapped (){
//        print("customerCare CancelTapped")
//    }
//    func customerCareCallTapped () {
//        print("customerCare CallTapped")
//        if((NSString.init(string:self.DriveBookingResponce.CustomerCareNo!)).rangeOfCharacter(from: CharacterSet.decimalDigits.inverted)).location == NSNotFound {
//            UIApplication.shared.openURL(URL.init(string: "tel://\(self.DriveBookingResponce.CustomerCareNo!)")!)
//        }
//        else {
//            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Invalid Helpdesk Number", Interval: 3)
//        }
//    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        NotificationCenter.default.addObserver(self, selector: #selector(BookForOthers), name: NSNotification.Name(rawValue: "BOF"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(NoShowTost), name: NSNotification.Name(rawValue: "NOSHOW"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(BookOWN), name: NSNotification.Name(rawValue: "NOW"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(callCustomerSupportTapped), name:NSNotification.Name(rawValue:"CUSTOMERSUPPORT"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(customAlertTapped(_:)), name: NSNotification.Name(rawValue:"CUSTOMALERT"), object: nil)

        NotificationCenter.default.addObserver(self, selector: #selector(keyboardShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardHide(_:)), name: .UIKeyboardWillHide, object: nil)
        
        sideMenuController?.isLeftViewEnabled = true
        
        Timer.scheduledTimer(timeInterval: 0.2, target: self, selector: #selector(TimerForLocaccess), userInfo: nil, repeats: false)
    }
    
    func TimerForLocaccess() {
        if CLLocationManager.authorizationStatus() != .authorizedWhenInUse && CLLocationManager.authorizationStatus() != .authorizedAlways {
            ShowLocationDenied(controller: self)
            LocationManager.startUpdatingLocation()
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
        
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "CUSTOMERSUPPORT"), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "CUSTOMALERT"), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "NOSHOW"), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "NOW"), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "BOF"), object: nil)

        sideMenuController?.isLeftViewEnabled = false

    }
    
    func keyboardShow(_ notification : NSNotification) {
        
        if CouponTxtFld.isFirstResponder {
            let info = notification.userInfo
            let keyboardframe = (info![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size
            var phoneframe = CGRect.init()
            phoneframe = CouponTxtFld.frame
            
            phoneframe.origin.y += (CouponTxtFld.superview?.frame.origin.y)!
            phoneframe.origin.y += (CouponTxtFld.superview?.superview?.frame.origin.y)!
            
            var actualframe = self.view.frame
            actualframe.size.height -= keyboardframe.height
            actualframe.size.height -= (phoneframe.size.height)
            
            if !actualframe.contains((phoneframe.origin)) {
                let yfinal = (phoneframe.origin.y) - actualframe.size.height
                
                UIView.animate(withDuration: 0.3, animations: { () -> Void in
                    
                    self.CouponViewObj.frame.origin.y -= yfinal
                })
                
            }
        }
    }
    
    func keyboardHide(_ notification : NSNotification)
    {
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.CouponViewObj.frame.origin.y = self.InitialPostion
        })
    }
    
    
    
    @IBOutlet var CouponViewAppliedObj:UIView!
    
    var LoaderStopTimer = Timer()
    
    func CouponAppliedView() {
        
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        
        BackView.center = (window?.center)!
        
        CouponViewAppliedObj.frame.size.width = self.view.frame.size.width

        window?.addSubview(BackView)
        CouponViewAppliedObj.center = BackView.center
        
        CouponViewAppliedObj.layer.cornerRadius = 3
        CouponViewAppliedObj.clipsToBounds = true
        
        BackView.addSubview(CouponViewAppliedObj!)
        
        CouponViewAppliedObj.alpha = 0
        
        UIView.animate(withDuration: 0.5) {
            self.CouponViewAppliedObj.alpha = 1
        }
    }
    
    func CloseCouponAppledView() {
        
        UIView.animate(withDuration: 0.3, animations: {
            self.CouponViewAppliedObj.alpha = 0
        }) { (yes) in
            if yes {
                self.CouponViewAppliedObj.alpha = 1
                self.CouponViewAppliedObj.superview?.removeFromSuperview()
                self.LoaderStopTimer.invalidate()
            }
        }
    }
    
    @IBAction func CouponAppliedCloseBtnPressed(_ sender:UIButton) {
        CloseCouponAppledView()
    }

    // MARK: - }
    

    
    // MARK: -  Reset Things Done {
    
    func ResetAllToDefaults() {
        
        if !LocationSelectView.isHidden {
            let animationVeh = CATransition()
            animationVeh.duration = 0.6
            animationVeh.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
            animationVeh.fillMode = kCAFillModeForwards
            animationVeh.isRemovedOnCompletion = false
            animationVeh.type = kCATransitionPush
            animationVeh.subtype = kCATransitionFromRight
            VehicleSelectView.layer.add(animationVeh, forKey: "animation")
            
            let animationTrip = CATransition()
            animationTrip.duration = 0.6
            animationTrip.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
            animationTrip.fillMode = kCAFillModeForwards
            animationTrip.isRemovedOnCompletion = false
            animationTrip.type = kCATransitionPush
            animationTrip.subtype = kCATransitionFromRight
            TripTypeView.layer.add(animationTrip, forKey: "animation")
            
            let animationLoc = CATransition()
            animationLoc.duration = 0.6
            animationLoc.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
            animationLoc.fillMode = kCAFillModeForwards
            animationLoc.isRemovedOnCompletion = false
            animationLoc.type = kCATransitionPush
            animationLoc.subtype = kCATransitionFromRight
            LocationSelectView.layer.add(animationLoc, forKey: "animation")
        }
        else if !VehicleSelectView.isHidden {
            let animationVeh = CATransition()
            animationVeh.duration = 0.6
            animationVeh.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
            animationVeh.fillMode = kCAFillModeForwards
            animationVeh.isRemovedOnCompletion = false
            animationVeh.type = kCATransitionPush
            animationVeh.subtype = kCATransitionFromRight
            VehicleSelectView.layer.add(animationVeh, forKey: "animation")
            
            let animationTrip = CATransition()
            animationTrip.duration = 0.6
            animationTrip.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
            animationTrip.fillMode = kCAFillModeForwards
            animationTrip.isRemovedOnCompletion = false
            animationTrip.type = kCATransitionPush
            animationTrip.subtype = kCATransitionFromRight
            TripTypeView.layer.add(animationTrip, forKey: "animation")
        }
        else if !TripTypeView.isHidden {
            let animation = CATransition()
            animation.duration = 0.6
            animation.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
            animation.fillMode = kCAFillModeForwards
            animation.isRemovedOnCompletion = false
            animation.type = kCATransitionPush
            animation.subtype = kCATransitionFromRight
            TripTypeView.layer.add(animation, forKey: "animation")
        }
        
        TripTypeView.isHidden = true
        VehicleSelectView.isHidden = true
        LocationSelectView.isHidden = true
        
        IsCouponAvailable = false
        
        LoadTitles()
        
        TripTypeView.isHidden = true
        VehicleSelectView.isHidden = true
        LocationSelectView.isHidden = true
        
        if !BookConfirmView.isHidden {
            CloseBookConfirmation()
            JobIdMain = ""
        }
        
        
        BookingPhNo = nil
        BookingName = nil
        
        paymentMode = "SELECT PAYMENT"
//        selectPaymentBtn.titleLabel?.text = paymentMode
        selectPaymentBtn.setTitle(paymentMode, for: .normal)
//        self.selectPaymentBtn.contentHorizontalAlignment = .center
        
    }
    
    // MARK: - }
    
    
    // MARK: - ####### Book Now ####### {
    
    var BookNowSelectedIndex = 0
    
    var BookNowText = UITextField()
    var BookNowSelectPicker = UIPickerView()
    
    var BookNowPaymentModeArr = [String]()
    
    func BookNowHiddenTxtMake() {
        
        BookNowPaymentModeArr.append("Pay with Cash")
        
        BookNowText.frame = CGRect.init(x: 1000, y: 1000, width: 10, height: 10)
        self.view.addSubview(BookNowText)
        BookNowSelectPicker.dataSource = self
        BookNowSelectPicker.delegate = self
        
        let Toolbar = UIToolbar()
        Toolbar.barStyle = .default
        Toolbar.isTranslucent = true
        Toolbar.tintColor = UIColor.blue
        Toolbar.sizeToFit()
        let DoneItem = UIBarButtonItem.init(title: "Book", style: .done, target: self, action: #selector(BookNowPickDoneAction))
        let FlexiItem = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let TitleItem = UIBarButtonItem.init(title: "Select Mode of Payment", style: .done, target: nil, action: nil)
        let FlexiItem2 = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let CancelItem = UIBarButtonItem.init(title: "Cancel", style: .done, target: self, action: #selector(BookNowPickCancelAction))
        Toolbar.setItems([CancelItem,FlexiItem,TitleItem,FlexiItem2,DoneItem], animated: true)
        Toolbar.isUserInteractionEnabled = true
        BookNowText.inputView = BookNowSelectPicker;
        BookNowText.inputAccessoryView = Toolbar;
    }
    
    func BookNowPickDoneAction() {
        
//        if paymentMode == "SELECT PAYMENT" {
//            print("Select payment....")
//            return
//        }
        
        
//        guard paymentMode != nil else {
//            BookNowText.resignFirstResponder()
//            print("Select payment....")
//            self.view.ShowWhiteTostWithText(message: "Select Payment", Interval: 3)
//            return
//        }
//        
//        let SelectedPaymentMode = BookNowPaymentModeArr[BookNowSelectedIndex]
        
        
//        if SelectedPaymentMode == "Pay with Cash" {
            BookNowText.resignFirstResponder()
            if (Reachability()?.isReachable)! {
                
                UIApplication.shared.keyWindow?.StartLoading()
                
                var PickLat = 0.0
                var PickLon = 0.0
                var DropLat = 0.0
                var DropLon = 0.0
                
                var PickLocation = "N/A"
                var DropLocation = "N/A"
                
                var SelectedTarrif = "N/A"
                
                switch SelectedTripType! {
                case .airport:
                    if IsGoingToAirport {
                        PickLat = LocationViewStruct.Latitude!
                        PickLon = LocationViewStruct.Longitude!
                        PickLocation = "\(LocationViewStruct.Location!)"
                        
                        DropLocation = "Airport"
                    }
                    else {
                        DropLat = LocationViewStruct.Latitude!
                        DropLon = LocationViewStruct.Longitude!
                        DropLocation = "\(LocationViewStruct.Location!)"
                        
                        PickLocation = "Airport"
                    }
                    SelectedTarrif = "Airport"
                    break
                case .outstation:
                    
                    PickLat = LocationViewStruct.Latitude!
                    PickLon = LocationViewStruct.Longitude
                    PickLocation = "\(LocationViewStruct.Location!)"
                    
                    DropLat = OutStationFav.Latitude!
                    DropLon = OutStationFav.Longitude!
                    DropLocation = "\(OutStationFav.Location!)"
                    
                    SelectedTarrif = "Outstation"
                    
                    break
                case .package:
                    PickLat = LocationViewStruct.Latitude!
                    PickLon = LocationViewStruct.Longitude!
                    PickLocation = "\(LocationViewStruct.Location!)"
//                    DropLocation = "Package"
                    SelectedTarrif = "\(PackageSelected["TariffName"]!)"
                    break
                }
                
                let PickUpDate = TripDateTime.components(separatedBy: " ")[0]
                let PickUpTime = TripDateTime.components(separatedBy: " ")[1]
                
                let CityArr = DriveBookingResponce.CityDetails.sorted(by: {$0.0.CityName.localizedCaseInsensitiveCompare($0.1.CityName) == ComparisonResult.orderedAscending})
                
                
                let NameBooking = BookingName ?? DriveBookingResponce.Name!
                let PhBooking = BookingPhNo ?? DriveBookingResponce.PhoneNo!

                
                let BookingData = ["UserName":NameBooking,
                    "EmailId":"\(DriveBookingResponce.Email!)",
                    "MobileNo":PhBooking,
                    "PickUpLat":"\(PickLat)",
                    "PickUpLon":"\(PickLon)",
                    "DropLat":"\(DropLat)",
                    "DropLon":"\(DropLon)",
                    "PickUpLoc":"\(PickLocation)",
                    "DropLoc":"\(DropLocation)",
                    "TripType":"\(RideTypeArr[RideLaterType.currentItemIndex].RideTypeName!)",
                    "PickUpDate":"\(PickUpDate)",
                    "PickUpTime":"\(PickUpTime)",
                    "VehicleType":"\(CarTypeMainArr[CarType.currentItemIndex].CategoryTypeId!)",
                    "VehicleModel":"\(vehicleTypeArr[2].Desc!)",
                    "JobType":"Advance",
                    "Tariff":"\(SelectedTarrif)",
//                    "BookingType":"Own",
                    "BookingType":"\(corporate_personal!)",
                    "EmpId":"\(DriveBookingResponce.EmpId!)",
                    "CouponCode":"\(CouponCode)",
                    "NoOfDays":"\(NumberOfDays)",
                    "City":"\(CityName == "" ? CityArr[0].CityName! : CityName.contains(" ") ? CityName.components(separatedBy: " ")[0]: CityName)",
                    "VendorId":"\(LoginRequest.LoginCreds.VendorId!)",
                    "CorporateId":"\(corporate_ID!)",
                    "AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)",
                    "PaymentType":"\(paymentMode!)",// "PaymentType":"Cash",
                    "PaytmBalance":"0"]
                print("Booking Input = ",BookingData)
                WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveBookingWithWallets, parameterDict: BookingData, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (BookingResponce, responceCode, success) in
                    
                    UIApplication.shared.keyWindow?.StopLoading()
                    
                    if success {
                        print(BookingResponce)
                        
                        if let Table = ((BookingResponce as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                            
                            if "\(Table["Status"]!)" == "true" && Table.keys.contains(where: {$0 == "JobNo"}) && "\(Table["JobNo"]!)" != ""  {
                                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(Table["Message"]!)", Interval: 4)
                                
                                self.JobIdMain = "\(Table["JobNo"]!)"
                                self.BookConfirmationView()
                            }
                            else {
                                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(Table["Message"]!)", Interval: 4)
                            }
                            
                        }
                        else {
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                        }
                        
                    }
                    else {
                        print("error")
                    }
                    
                })
                
            }
            else {
                self.view.ShowBlackTostWithText(message: "No Active Internet Connection Found", Interval: 2)
            }
//        }
    }
    func BookNowPickCancelAction() {
        BookNowText.resignFirstResponder()
    }
    
    
    
    @IBAction func BookNowBtnAction(_ sender:UIButton) {


//        if self.payment

//        BookNowText.becomeFirstResponder()
//        BookNowSelectPicker.reloadAllComponents()
        
        if paymentMode! == "SELECT PAYMENT" {
            self.view.ShowBlackTostWithText(message: "Please select payment mode", Interval: 3)
            return
        }
        
        BookNowPickDoneAction()
    }
    
    @IBAction func selectPaymentBtnAction(_ sender: UIButton) {
    
        let paymentModeDetailsObj = self.storyboard?.instantiateViewController(withIdentifier: "PaymentModeDetailsSelectClassSBID") as! PaymentModeDetailsSelectClass
        paymentModeDetailsObj.corpOrPersonalType = corporate_personal
        
        paymentModeDetailsObj.myDelegateRef = self
        self.navigationController?.pushViewController(paymentModeDetailsObj, animated: true)
        
//        self.present(paymentModeDetailsObj, animated: true, completion: nil)
    }
    
    // MARK: - }
    
    // MARK: - Book Confirmation View {
    

    var JobIdMain = ""
    
    var CancelBookingText = UITextField()
    var CancelSelectPicker = UIPickerView()

    func BookConfirmationView() {
        
        BookConfirmView.removeFromSuperview()
        
        BookConfirmView.isHidden = false
        
        BookConfirmView.frame = CGRect.init(x: 0, y: 0, width: self.view.frame.width, height: RefreshAllBtn.frame.minY-10)
        
        BookConfirmText.text = "Your booking Id " + JobIdMain + " has been confirmed. You will be able to track the vehicle 30min before your pickup time."
        
        let animation = CATransition()
        animation.duration = 0.8
        animation.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
        animation.fillMode = kCAFillModeForwards
        animation.isRemovedOnCompletion = false
        animation.type = kCATransitionPush
        animation.subtype = kCATransitionFromBottom
        BookConfirmView.layer.add(animation, forKey: "animation")
        self.view.addSubview(BookConfirmView)
    }
    
    func CloseBookConfirmation() {
        
        let animation = CATransition()
        animation.duration = 0.6
        animation.timingFunction = CAMediaTimingFunction.init(name: kCAMediaTimingFunctionEaseInEaseOut)
        animation.fillMode = kCAFillModeForwards
        animation.isRemovedOnCompletion = false
        animation.type = kCATransitionPush
        animation.subtype = kCATransitionFromTop
        BookConfirmView.layer.add(animation, forKey: "animation")
    
        BookConfirmView.isHidden = true
    }
    
    @IBAction func ViewDetailsBookingBtnPressed(_ sender:UIButton) {
        
        ResetAllToDefaults()
        
        let MyridesObj = self.storyboard?.instantiateViewController(withIdentifier: "MyTripsVC") as! MyTripsVC
        self.navigationController?.pushViewController(MyridesObj, animated: true)
    }
    
    var CancelReasonsArr = [String]()
    
    @IBAction func CancelBookingBtnPressed(_ sender:UIButton) {
        // action for cancel booking
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            let CancelReasonsDict = ["EmpId":"\(DriveBookingResponce.EmpId!)",
                                        "VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveCancellationReasons, parameterDict: CancelReasonsDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (CancelReasonsDict, responceCode, success) in
                self.view.StopLoading()
                if success {
                    if let Table = ((CancelReasonsDict as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                        
                        if "\(Table["Status"]!)" == "true" && Table.keys.contains(where: {$0 == "Reasons"}) && "\(Table["Reasons"]!)" != ""  {
                            let Reasons = "\(Table["Reasons"]!)".components(separatedBy: "|")
                            self.CancelReasonsArr.removeAll()
                            for i in 0..<Reasons.count-1 {
                                self.CancelReasonsArr.append(Reasons[i])
                            }
                            self.CancelBookingText.becomeFirstResponder()
                            self.CancelSelectPicker.reloadAllComponents()
                        }
                        else {
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                        }
                        
                    }
                    else {
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                    }
                }
                else {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                }
            })
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.NetErrorMsg, Interval: 2)
        }
    }
    
    func CancelBookingHiddenTxt() {
        
        CancelBookingText.frame = CGRect.init(x: 1000, y: 1000, width: 10, height: 10)
        self.view.addSubview(CancelBookingText)
        CancelSelectPicker.dataSource = self
        CancelSelectPicker.delegate = self
        
        let Toolbar = UIToolbar()
        Toolbar.barStyle = .default
        Toolbar.isTranslucent = true
        Toolbar.tintColor = UIColor.blue
        Toolbar.sizeToFit()
        let DoneItem = UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(cancelBookingPickDoneAction))
        let FlexiItem = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let TitleItem = UIBarButtonItem.init(title: "Select Reason to Cancel", style: .done, target: nil, action: nil)
        let FlexiItem2 = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let CancelItem = UIBarButtonItem.init(title: "Cancel", style: .done, target: self, action: #selector(cancelBookingPickCancelAction))
        Toolbar.setItems([CancelItem,FlexiItem,TitleItem,FlexiItem2,DoneItem], animated: true)
        Toolbar.isUserInteractionEnabled = true
        CancelBookingText.inputView = CancelSelectPicker;
        CancelBookingText.inputAccessoryView = Toolbar;
    }
    
    
    var CancelBookingSelectedIndex = 0
    
    func cancelBookingPickDoneAction() {
        let ReasonSelected = CancelReasonsArr[CancelBookingSelectedIndex]
        CancelBookingText.resignFirstResponder()
        CancelTrip(Reason: ReasonSelected)
    }
    
    func CancelTrip(Reason:String) {
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            let CancelRequestDict = ["JobNo":"\(JobIdMain)","JobType":"Advance","CancelReason":"\(Reason)","EmpId":"\(DriveBookingResponce.EmpId!)","VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveCancelBooking, parameterDict: CancelRequestDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (CancelDict, responceCode, success) in
                self.view.StopLoading()
                if success {
                    if let Table = ((CancelDict as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                        
                        if "\(Table["Status"]!)" == "true" {
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(Table["Response"]!)", Interval: 2)
                            
                            self.ResetAllToDefaults()
                            
                        }
                        else {
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(Table["Response"]!)", Interval: 2)
                        }
                    }
                }
                else {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                }
            })
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.NetErrorMsg, Interval: 2)
        }
    }
    
    
    func cancelBookingPickCancelAction() {
        CancelBookingText.resignFirstResponder()
    }
    
    // MARK: - }

    // MARK: - picker {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if pickerView == BookNowSelectPicker {
            return BookNowPaymentModeArr.count
        }
        else if pickerView == CancelSelectPicker {
            return CancelReasonsArr.count
        }
        else {
            return PackageDetailsArr.count
        }
        
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if pickerView == BookNowSelectPicker {
            return "\(BookNowPaymentModeArr[row])"
        }
        else if pickerView == CancelSelectPicker {
            return "\(CancelReasonsArr[row])"
        }
        else {
            return "\(PackageDetailsArr[row]["TariffName"]!)"
        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == BookNowSelectPicker {
            BookNowSelectedIndex = row
        }
        else if pickerView == CancelSelectPicker {
            CancelBookingSelectedIndex = row
        }
        else {
            SelectedIndex = row
        }
    }
    
    // MARK: - }
    
}

extension DriveBookingVC:iShowcaseDelegate {
    
    func iShowcaseDismissed(_ number: Int, _ showcase: iShowcase) {
    
        if number == 0 {
            ShowcaseForRideType(forView: CarType, Type: 1, Title: "Please scroll right or left and select center icon for Vehicle Category", ButtonTitle: "NEXT", Tag: 1)
        }
        else if number == 1 {
            ShowcaseForRideType(forView: LocationType, Type: 1, Title: "Please scroll right or left and select center icon for Pickup Address", ButtonTitle: "NEXT", Tag: 2)
        }
        else if number == 2 {
            ShowcaseForRideType(forView: RefreshAllBtn, Type: 0, Title: "Please Click on icon to Refresh all details", ButtonTitle: "DONE", Tag: 3)
        }
        else if number == 3 {
            
            UserDefaults.standard.set(true, forKey: "RideLaterViewBool")
            UserDefaults.standard.synchronize()
//            ShowcaseForRideType(forView: RideNowBtn, Type: 0, Title: "Please Click on RideNow button for current booking", ButtonTitle: "CLOSE", Tag: 4)
        }
        else if number == 4 {
            UserDefaults.standard.set(true, forKey: "RideLaterViewBool")
            UserDefaults.standard.synchronize()
        }
        
    }
    
    func ShowTripTypeShowcase() {
        if UserDefaults.standard.bool(forKey: "RideLaterViewBool") == false {
            ShowcaseForRideType(forView: RideLaterType, Type: 1, Title: "Please scroll right or left and select center icon for Trip Type", ButtonTitle: "NEXT", Tag: 0)
        }
    }
    
    func ShowcaseForRideType(forView:UIView,Type:Int,Title:String,ButtonTitle:String,Tag:Int) {
        let showview = iShowcase()
        showview.delegate = self
        showview.setupShowcaseForView(forView)
        showview.type = iShowcase.TYPE(rawValue: Type)
        showview.titleLabel.text = Title
        showview.detailsLabel.text = ButtonTitle
        showview.coverColor = UtilitiesClassSub.color(fromHexString: "#dd335075")
        showview.highlightColor = UIColor.clear
        showview.radius = 32
        showview.Number = Tag
        showview.show()
    }
    
}


extension DriveBookingVC:iCarouselDelegate,iCarouselDataSource,FavoriteLocSelectDelegate {
    func DidSelectChooseOnMap(_ controller: FavoriteLocationSelectVC) {
        
    }
    
    
    func LoadTitles() {
        
        RideLaterType.isHidden = true
        CarType.isHidden = true
        LocationType.isHidden = true
        
        RideLaterTitle.text = RideTypeArr[1].RideTypeName.uppercased()
        CarTitle.text = CarTypeMainArr[1].CategoryTypeName.uppercased()
        LocationTitle.text = LocationTypeArr[1].LocationTypeImageName.uppercased()
        
        RideLaterType.delegate = self
        CarType.delegate = self
        LocationType.delegate = self
        
        RideLaterType.dataSource = self
        CarType.dataSource = self
        LocationType.dataSource = self
        
        RideLaterType.reloadData()
        CarType.reloadData()
        LocationType.reloadData()
        
        Timer.scheduledTimer(timeInterval: 0.2, target: self, selector: #selector(hideRemainingHeaders), userInfo: nil, repeats: false)
        
        self.view.StopLoading()
    }
    
    func hideRemainingHeaders() {
        RideLaterType.scrollToItem(at: 1, animated: false)
        CarType.scrollToItem(at: 1, animated: false)
        LocationType.scrollToItem(at: 1, animated: false)
        TripTypeHide()
        VehicleTypeHide()
        LocationTypeHide()
        
        RideLaterType.isHidden = false
        CarType.isHidden = false
        LocationType.isHidden = false
        
        ShowTripTypeShowcase()

    }
    
    func TripTypeHide() {
        
        if RideLaterType.numberOfItems > 2 {
            
            for i in 0..<3 {
                RideLaterType.itemView(at: i)?.isHidden = false;
            }
            
            for i in 3..<RideLaterType.numberOfItems {
                RideLaterType.itemView(at: i)?.isHidden = true;
            }
        }
        else {
            for i in 0..<RideLaterType.numberOfItems {
                RideLaterType.itemView(at: i)?.isHidden = false;
            }
        }
    }
    
    func VehicleTypeHide() {
        
        if CarType.numberOfItems > 2 {
            
            for i in 0..<3 {
                CarType.itemView(at: i)?.isHidden = false;
            }
            
            for i in 3..<CarType.numberOfItems {
                CarType.itemView(at: i)?.isHidden = true;
            }
        }
        else {
            for i in 0..<CarType.numberOfItems {
                CarType.itemView(at: i)?.isHidden = false;
            }
        }
    }
    
    func LocationTypeHide() {
        
        if LocationType.numberOfItems > 2 {
            
            for i in 0..<3 {
                LocationType.itemView(at: i)?.isHidden = false;
            }
            
            for i in 3..<LocationType.numberOfItems {
                LocationType.itemView(at: i)?.isHidden = true;
            }
        }
        else {
            for i in 0..<LocationType.numberOfItems {
                LocationType.itemView(at: i)?.isHidden = false;
            }
        }
    }
    
    
    func numberOfItems(in carousel: iCarousel) -> Int {
        if carousel.tag == 100 {
            return RideTypeArr.count
        }
        else if carousel.tag == 200 {
            return CarTypeMainArr.count
        }
        else {
            return LocationTypeArr.count
        }
    }
    
    func carousel(_ carousel: iCarousel, viewForItemAt index: Int, reusing view: UIView?) -> UIView {
        
        var itemView: UIImageView
        
        if let view = view as? UIImageView {
            itemView = view
        } else {
            
            let frameHeight = carousel.frame.size.height
            
            itemView = UIImageView(frame: CGRect(x: 0, y: 0, width: frameHeight, height: frameHeight * 0.7))
            itemView.contentMode = .scaleAspectFit
            itemView.clipsToBounds = true
        }
        
        if carousel.tag == 100 {
            
            //temporary Image or Static Image
//            if index == 0{
//                itemView.image = UIImage(named:"ylw_Airport")
//            }else if index == 1{
//                itemView.image = UIImage(named:"Ylw_Package")
//            }else{
//                itemView.image = UIImage(named:"Ylw_Package")
//            }
            
            if self.RideTypeArr[index].RideTypeImage == nil {

                itemView.ImageLoaderStart()

                itemView.af_setImage(withURL: URL.init(string: RideTypeArr[index].rideTypeImagerStr!)!, placeholderImage: nil, filter: nil, progress: nil, progressQueue: DispatchQueue.main, imageTransition: .noTransition, runImageTransitionIfCached: true, completion: { (imageResponce) in

                    if imageResponce.data != nil {
                        let image = UIImage.init(data: imageResponce.data!)!
                        itemView.image = image
                        self.RideTypeArr[index].RideTypeImage = image
                    }

                    itemView.ImageLoaderStop()
                })
            }
            else {
                itemView.image = RideTypeArr[index].RideTypeImage!
            }
            
            

        }
        else if carousel.tag == 200 {
            
            if self.CarTypeMainArr[index].CategoryTypeImage == nil {
                
                itemView.ImageLoaderStart()
                print("ImageUrl = ",CarTypeMainArr[index].CategoryTypeImageUrl!)
                itemView.af_setImage(withURL: URL.init(string: CarTypeMainArr[index].CategoryTypeImageUrl!)!, placeholderImage: nil, filter: nil, progress: nil, progressQueue: DispatchQueue.main, imageTransition: .noTransition, runImageTransitionIfCached: true, completion: { (imageResponce) in
                    
                    if imageResponce.data != nil {
                        let image = UIImage.init(data: imageResponce.data!)!
                        itemView.image = image
                        self.CarTypeMainArr[index].CategoryTypeImage = image
                    }
                    
                    itemView.ImageLoaderStop()
                })
            }
            else {
                itemView.image = CarTypeMainArr[index].CategoryTypeImage!
            }
            
        }
        else {
            if self.LocationTypeArr[index].LocationTypeImage == nil {
                itemView.ImageLoaderStart()
                
                itemView.af_setImage(withURL: URL.init(string: LocationTypeArr[index].LocationTypeImageStr!)!, placeholderImage: nil, filter: nil, progress: nil, progressQueue: DispatchQueue.main, imageTransition: .noTransition, runImageTransitionIfCached: true, completion: { (imageResponce) in
                    
                    if imageResponce.data != nil{
                        let image = UIImage.init(data: imageResponce.data!)!
                        itemView.image = image
                        self.LocationTypeArr[index].LocationTypeImage = image
                    }
                    itemView.ImageLoaderStop()
                })
            }else {
                    itemView.image = LocationTypeArr[index].LocationTypeImage
            }
            
        }
        
        return itemView
    }
    
    func carouselCurrentItemIndexDidChange(_ carousel: iCarousel) {
        if carousel.tag == 100 {
            RideLaterTitle.text = RideTypeArr[carousel.currentItemIndex].RideTypeName
        }
        else if carousel.tag == 200 {
            CarTitle.text = CarTypeMainArr[carousel.currentItemIndex].CategoryTypeName
        }
        else {
            LocationTitle.text = LocationTypeArr[carousel.currentItemIndex].LocationTypeImageName
        }
        
        
        if carousel.currentItemIndex == 0 {
            if carousel.numberOfItems > 2
            {
                for i in 0..<2 {
                    carousel.itemView(at: i)?.isHidden = false;
                }
                
                for i in 2..<carousel.numberOfItems {
                    carousel.itemView(at: i)?.isHidden = true;
                }
            }
            else {
                for i in 0..<carousel.numberOfItems {
                    carousel.itemView(at: i)?.isHidden = false;
                }
            }
        }
        else if carousel.currentItemIndex == 1 {
            
            if carousel.numberOfItems > 2 {
                
                for i in 0..<3 {
                    carousel.itemView(at: i)?.isHidden = false;
                }

                for i in 3..<carousel.numberOfItems {
                    carousel.itemView(at: i)?.isHidden = true;
                }
            }
            else {
                for i in 0..<carousel.numberOfItems {
                    carousel.itemView(at: i)?.isHidden = false;
                }
            }

        }
        else if carousel.currentItemIndex == 2 {
            carousel.itemView(at: 0)?.isHidden = true;
            carousel.itemView(at: 1)?.isHidden = false;
            carousel.itemView(at: 2)?.isHidden = false;

            if carousel.numberOfItems > 2 {
                
                for i in 3..<carousel.numberOfItems {
                    carousel.itemView(at: i)?.isHidden = true;
                }
                
                carousel.itemView(at: 3)?.isHidden = false;

            }
            
        }
        else {
            
            for i in 0..<carousel.currentItemIndex - 1 {
                carousel.itemView(at: i)?.isHidden = true;
            }
            
            for i in carousel.currentItemIndex+1..<carousel.numberOfItems {
                carousel.itemView(at: i)?.isHidden = true;
            }
            
            carousel.itemView(at: carousel.currentItemIndex)?.isHidden = false;
            carousel.itemView(at: carousel.currentItemIndex-1)?.isHidden = false;

            if carousel.numberOfItems >= carousel.currentItemIndex+1 {
                carousel.itemView(at: carousel.currentItemIndex+1)?.isHidden = false;
            }
        }
    
    }
    
    
    func carousel(_ carousel: iCarousel, valueFor option: iCarouselOption, withDefault value: CGFloat) -> CGFloat {
        if (option == .spacing) {
            
//            if carousel.tag == 200 {
//
//                if carousel.numberOfItems>3 {
//                    return value * 2.2
//                }
//
//            }
    
//            return value * 3.2
            return value

        }
        
        if (option == .wrap)
        {
            return 0;
        }
        
        if (option == .showBackfaces) {
            return 0
        }
        return value
    }
    
    func carousel(_ carousel: iCarousel, itemTransformForOffset offset: CGFloat, baseTransform transform: CATransform3D) -> CATransform3D {
        let val = M_PI/8
        let transform2 = CATransform3DRotate(transform, CGFloat(val), 0.0, 1.0, 0.0)
        return CATransform3DTranslate(transform2, 0.0, 0.0, offset * carousel.itemWidth)
    }
    
    func carousel(_ carousel: iCarousel, didSelectItemAt index: Int) {
        
        if carousel.tag == 100 {
            
            let DetailsObj = self.storyboard?.instantiateViewController(withIdentifier: "DetailsSelectClass") as! DetailsSelectClass
            if index == 0 {
                DetailsObj.TripTypeSelect = .airport
            }
            else if index == 1 {
                DetailsObj.TripTypeSelect = .outstation
            }
            else {
                DetailsObj.TripTypeSelect = .package
            }
            DetailsObj.Delegate = self
            self.present(DetailsObj, animated: true, completion: nil)
            
        }
        else if carousel.tag == 200 {
            
  
            if TripTypeView.isHidden {
                Message.shared.Alert(Title: "Select Trip Type", Message: "\nPlease select Trip Type to get Model details", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            
            VehicleTypeSelect(index: CarTypeMainArr[index].CategoryTypeId!)
        }
        else {
            if TripTypeView.isHidden {
                Message.shared.Alert(Title: "Select Trip Type", Message: "\nPlease select Trip Type to get Model details", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            
            if VehicleSelectView.isHidden {
                Message.shared.Alert(Title: "Select Category", Message: "\nPlease select Category to get location", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            
            switch index {
            case 0:
                let SearchController = FavoriteLocationSelectVC()
                SearchController.Delegate = self
                SearchController.IsSearchNeeded = true
                self.present(SearchController, animated: true, completion: nil)
                return
            case 1:
                
                
                guard (LocationManager.location != nil) else {
                    ShowLocationDenied(controller: self)
                    return
                }
                
                self.view.StartLoading()
                let LocationDe = LocationManager.location!
                
                CLGeocoder().reverseGeocodeLocation(LocationDe) { (places, error) in
                    self.view.StopLoading()
                    
                    if error == nil {
                        if (places?.count)! > 0 {
                            let place = places?.last
                            
                            var addStr = "Not available"
                            let DictPlaces = UtilitiesClassSub.getLocationDetails(fromCLPlaceMark: place!)!
                            
                            if "\(DictPlaces[LocationParserFullAddress]!)" != "" {
                                addStr = DictPlaces[LocationParserFullAddress]! as! String
                            }
                            
                            if self.FavLocArr.contains(where: {$0.Location! == addStr}) {
                                self.isFavLocation = true
                            }
                            else {
                                self.isFavLocation = false
                            }
                            
                            var FavStruct = FavouritesLocationsStruct()
                            FavStruct.Location = addStr
                            FavStruct.Latitude = LocationDe.coordinate.latitude
                            FavStruct.Longitude = LocationDe.coordinate.longitude
                            self.LocationViewStruct = FavStruct
                            self.CallServiceForEstimationFetch()
                            
                        }
                    }
                }
                
                return
            case 2:
                let SearchController = FavoriteLocationSelectVC()
                SearchController.Delegate = self
                SearchController.IsSearchNeeded = false
                self.present(SearchController, animated: true, completion: nil)
                return
            default:
                break
            }
        }
    }
    
    
    func VehicleTypeSelect(index:String) {
        
        UIApplication.shared.keyWindow?.StartLoading()
        
        let VehicleDetailsDict = ["EmpId":"\(DriveBookingResponce.EmpId!)","TypeofTrip":"\(SelectedTripType == .airport ? "airport" : SelectedTripType == .outstation ? "outstation" : "package")","VehicleCategoryId":"\(index)","VendorId":"\(LoginRequest.LoginCreds.VendorId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)","BookingType":"\(corporate_personal!)",
            "CorporateId":"\(corporate_ID!)"]
        WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DrivePackageTariffs, parameterDict: VehicleDetailsDict, securityKey: DriveBookingResponce.AuthenticationToken!) { (ResponceDict, responceCode, success) in
            UIApplication.shared.keyWindow?.StopLoading()
            if success {
                
                if let Table = (ResponceDict as! [String:AnyObject])["Table"] {
                    print("From VehicleTypeSelect = ",Table)

                    if "\((Table as! [[String:AnyObject]])[0]["Status"]!)".toBool()! && "\((Table as! [[String:AnyObject]])[0]["Tariff"]!)" != "NA" && "\((Table as! [[String:AnyObject]])[0]["TariffName"]!)" != "NA" {
                        
                        if self.SelectedTripType == .package {
                            self.PackageDetailsArr = Table as! [[String:AnyObject]]
                            self.HiddenTxt.becomeFirstResponder()
                            self.PackageSelectPicker.reloadAllComponents()
                        }
                        else {
                            
                            let sub = Table as! [[String:AnyObject]]
                            
                            self.PackageSelected = sub[0]
                            
                            self.AddVehicleTypeView()
                        }
                    }
                    else {
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Model Details are not available", Interval: 2)
//                         UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\((Table as! [[String:AnyObject]])[0]["Response"]!)", Interval: 2)
                    }
                    
                }
                else {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                }
                
            }
            else {
                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
            }
        }
    }
    
    func DidCancelPicking(_ controller: FavoriteLocationSelectVC) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    func DidSelect(_ FavObj: FavouritesLocationsStruct, _ isfavorite: Bool, _ controller: FavoriteLocationSelectVC) {
        
        LocationViewStruct = FavObj
        isFavLocation = isfavorite
        
        CallServiceForEstimationFetch()
        controller.dismiss(animated: true, completion: nil)
    }
    
}

extension DriveBookingVC: CLLocationManagerDelegate,UITextFieldDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        CLGeocoder().reverseGeocodeLocation(locations.last!, completionHandler: { (Locations, error) in
            if error == nil {
                let Dict = UtilitiesClassSub.getLocationDetails(fromCLPlaceMark: Locations?.last!)
                if "\((Dict?[LocationParserCity]!)!)" != "" {
                    self.CityName = "\((Dict?[LocationParserCity]!)!)"
                }
                else {
                    
                }
            }
            else {
                
            }
        })
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedWhenInUse || status == .authorizedAlways {
            LocationManager.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("LocationError:===:", error.localizedDescription)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
}

extension DriveBookingVC: DetailsSelectDelegate {
    func DidCancelPressed(_ controller: DetailsSelectClass) {
        controller.dismiss(animated: true, completion: nil)
    }
    func DidSelectAirport(_ FormatedDate: String, _ IsGoingTo: Bool, _ controller: DetailsSelectClass) {
        IsGoingToAirport = IsGoingTo
        TripDateTime = FormatedDate
        SelectedTripType = .airport
        controller.dismiss(animated: true, completion: nil)
        TripTypeArr.removeAll()
        AddTripView()
    }
    func DidSelectOutStation(_ FormatedDate: String, _ numberOfDays: String!, _ DestinationLoc: FavouritesLocationsStruct, _ controller: DetailsSelectClass) {
        SelectedTripType = .outstation
        TripDateTime = FormatedDate
        OutStationFav = DestinationLoc
        NumberOfDays = numberOfDays
        controller.dismiss(animated: true, completion: nil)
        TripTypeArr.removeAll()
        AddTripView()
    }
    func DidSelectPackage(_ FormatedDate: String, _ controller: DetailsSelectClass) {
        SelectedTripType = .package
        TripDateTime = FormatedDate
        controller.dismiss(animated: true, completion: nil)
        TripTypeArr.removeAll()
        AddTripView()
    }
}
extension DriveBookingVC : PaymentModeDetailsSelectDelegate{
    func DidOKTapped(_ selectedPaymentMode: String!, _ controller: PaymentModeDetailsSelectClass) {
        self.paymentMode = selectedPaymentMode
//        self.selectPaymentBtn.titleLabel?.text = selectedPaymentMode
        self.selectPaymentBtn.setTitle(selectedPaymentMode, for: .normal)
//        self.selectPaymentBtn.contentHorizontalAlignment = .center
        controller.navigationController?.popViewController(animated: true)
//        controller.dismiss(animated: true, completion: nil)
    }
    
    
}

extension DriveBookingVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == TripTypeCollectionView {
            return TripTypeArr.count
        }
        else if collectionView == VehicleSelectCollectionView {
            return vehicleTypeArr.count
        }
        return 0
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == TripTypeCollectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Tripcell", for: indexPath) as! TripTypeSelectCell
            cell.TypeTitle.text = TripTypeArr[indexPath.row].Title
            cell.TypeDesc.text = TripTypeArr[indexPath.row].Desc
            cell.TypeImage.image = TripTypeArr[indexPath.row].Image
            return cell
        }
        else if collectionView == VehicleSelectCollectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Vehiclecell", for: indexPath) as! TripTypeSelectCell
            cell.TypeTitle.text = vehicleTypeArr[indexPath.row].Title
            cell.TypeDesc.text = vehicleTypeArr[indexPath.row].Desc
            cell.TypeImage.image = vehicleTypeArr[indexPath.row].Image
            return cell
        }
        else {
            return UICollectionViewCell()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == TripTypeCollectionView {
            return CGSize.init(width: (TripTypeCollectionView.frame.width/2) - 5, height: 60)
        }
        else if collectionView == VehicleSelectCollectionView {
            return CGSize.init(width: (VehicleSelectCollectionView.frame.width/2) - 5, height: 60)
        }
        else {
            return CGSize.zero
        }
    }
}




public enum TripType : UInt {
    
    case airport
    
    case outstation
    
    case package
}

class TripTypeSelectCell: UICollectionViewCell {
    @IBOutlet var TypeImage: UIImageView!
    @IBOutlet var TypeTitle: UILabel!
    @IBOutlet var TypeDesc: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }
}



public enum PaymentMode : UInt {
    case cash
    case card
    case billToCompany
}

