//
//  RateCardRideNow.swift
//  Drive Booking
//
//  Created by Raja Bhuma on 13/04/17.
//  Copyright © 2017 suntelematics. All rights reserved.
//

import UIKit

class RateCardRideLater: UIViewController {
    
    @IBOutlet var CitySelectTxt:UITextField!
    @IBOutlet var TripSelectTxt:UITextField!
    @IBOutlet var ModelSelectTxt:UITextField!
    @IBOutlet var PackageTxt:UITextField!
    @IBOutlet var CarSelectTxt:UITextField!
    @IBOutlet var BookTypeSelectTxt:UITextField!

    @IBOutlet weak var Label5: UILabel!
    @IBOutlet weak var Label4: UILabel!
    @IBOutlet weak var Label3: UILabel!
    @IBOutlet weak var Lable1: UILabel!
    @IBOutlet weak var Label2: UILabel!
    
    
    @IBOutlet var BookTypeView: UIView!

    @IBOutlet var CityView: UIView!
    @IBOutlet var TripSelectView:UIView!
    @IBOutlet var CarTypeView: UIView!
    @IBOutlet var PackageView:UIView!
    @IBOutlet var CarModelView: UIView!

    @IBOutlet var PackageHiddenView:UIView!
    @IBOutlet var PackageConstraint:NSLayoutConstraint!
    
    @IBOutlet var StandaredBaseFare: UILabel!
    @IBOutlet var StandaredMinimumKms: UILabel!
    @IBOutlet var StandaredMinimumHrs: UILabel!
    
    @IBOutlet var ExtraPerKm: UILabel!
    @IBOutlet var ExtraPerHr: UILabel!
    
    @IBOutlet var ExtraFareView: UIView!
    @IBOutlet var ExtraFareHeightConstriant: NSLayoutConstraint!

    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!

    var CorpoTypeStruc : BooktypeStruct!
    var Corpo2TypeStruc : BooktypeStruct!
    
    var PackageHeight:CGFloat = 0
    var ExtraFareHeight:CGFloat = 0
//    var BookTypeArray = [["CORPORATE","PERSONAL"]]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.white
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
        self.navigationItem.leftBarButtonItem = BackBtnItem
        
        self.navigationItem.title = "RATE CARD"
        self.LoginRequest = FetchDriveRequest()
        self.DriveBookingResponce = FetchDriveResponce()
        
        CorpoTypeStruc = BooktypeStruct()
        Corpo2TypeStruc = BooktypeStruct()

        CorpoTypeStruc.Corporate_Type = "CORPORATE"
        CorpoTypeStruc.Corporate_ID = "\(DriveBookingResponce.CorporateId2!)"
        BTypeArray.append(CorpoTypeStruc)
        Corpo2TypeStruc.Corporate_Type = "PERSONAL"
        Corpo2TypeStruc.Corporate_ID = "\(DriveBookingResponce.CorporateId!)"
        BTypeArray.append(Corpo2TypeStruc)

        
        // Do any additional setup after loading the view.
        self.StandaredBaseFare.text = nil
        self.StandaredMinimumHrs.text = nil
        self.StandaredMinimumKms.text = nil
        
        
        BookTypeView.layer.shadowColor = UIColor.darkGray.cgColor
        BookTypeView.layer.shadowRadius = 2;
        BookTypeView.layer.shadowOpacity = 0.4
        BookTypeView.layer.shadowOffset = CGSize.zero
        
        CityView.layer.shadowColor = UIColor.darkGray.cgColor
        CityView.layer.shadowRadius = 2;
        CityView.layer.shadowOpacity = 0.4
        CityView.layer.shadowOffset = CGSize.zero
        
        CarTypeView.layer.shadowColor = UIColor.darkGray.cgColor
        CarTypeView.layer.shadowRadius = 2;
        CarTypeView.layer.shadowOpacity = 0.4
        CarTypeView.layer.shadowOffset = CGSize.zero
        
        CarModelView.layer.shadowColor = UIColor.darkGray.cgColor
        CarModelView.layer.shadowRadius = 2;
        CarModelView.layer.shadowOpacity = 0.4
        CarModelView.layer.shadowOffset = CGSize.zero

        TripSelectView.layer.shadowColor = UIColor.darkGray.cgColor
        TripSelectView.layer.shadowRadius = 2;
        TripSelectView.layer.shadowOpacity = 0.4
        TripSelectView.layer.shadowOffset = CGSize.zero
        
        PackageView.layer.shadowColor = UIColor.darkGray.cgColor
        PackageView.layer.shadowRadius = 2;
        PackageView.layer.shadowOpacity = 0.4
        PackageView.layer.shadowOffset = CGSize.zero
        
        
        PickerViewMake(1)
        PickerViewMake(2)
        PickerViewMake(3)
        PickerViewMake(4)
        PickerViewMake(5)
        PickerViewMake(7)
        
        PackageHeight = PackageConstraint.constant
        PackageConstraint.constant = 0
        PackageHiddenView.isHidden = true
        
        
        ExtraFareHeight = ExtraFareHeightConstriant.constant
        ExtraFareHeightConstriant.constant = 0
        ExtraFareView.isHidden = true
        
        self.LoginRequest = FetchDriveRequest()
        self.DriveBookingResponce = FetchDriveResponce()
        
        GetCities()
        GetModels()
        FetchTripTypeArr()
        
        if CityArr.count>0 {
            CitySelectTxt.text = CityArr[0].CityName!
        }else{
            self.view.ShowBlackTostWithText(message: "No Cities Available", Interval: 3)
            return
        }
        
        if TripTypeArr.count > 0 {
            TripSelectTxt.text = TripTypeArr[0].TripName!
        }
        else {
            self.view.ShowBlackTostWithText(message: "No Trip Types Available", Interval: 3)
            return
        }
        
        
        if ModelsArr.count>0 {
            ModelSelectTxt.text = ModelsArr[0].CategoryName
        }else{
            
            self.view.ShowBlackTostWithText(message: "No Models are  Available", Interval: 3)
             return
        }

        
        getvehicleModelDetails(CityIndex: 0, ModelIndex: 0, CorpoType: 0)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func BackAction(_ sender: UIButton) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    var TripTypeArr = [TripTypeStruct]()
    
    func FetchTripTypeArr() {
        TripTypeArr = DriveBookingResponce.TripType
    }

    var PackageDetailsArr = [[String:AnyObject]]()

    
    var CityArr = [CityStru]()
    
    struct CityStru {
        var CityName:String!
        var CityId:String!
    }
    
    
    var BTypeArray = [BooktypeStruct]()
    struct BooktypeStruct {
        var Corporate_Type:String!
        var Corporate_ID:String!
    }

    
    func GetCities() {
        CityArr.removeAll()
        for CityDetailsObj in DriveBookingResponce.CityDetails{
            var City = CityStru()
            City.CityId = CityDetailsObj.CityId!
            City.CityName = CityDetailsObj.CityName!
            CityArr.append(City)
        }
        
        let sortedArray = CityArr.sorted{ $0.CityName.localizedCaseInsensitiveCompare($1.CityName) == ComparisonResult.orderedAscending }
        CityArr.removeAll()
        CityArr.append(contentsOf: sortedArray)
    }
    
    struct ModelsStru {
        var CategoryId: String!
        var CategoryName: String!
    }
    var ModelsArr = [ModelsStru]()

    func GetModels() {
        ModelsArr.removeAll()
        for CategoryDetailsObj in DriveBookingResponce.CategoryType {
            var Category = ModelsStru()
            Category.CategoryId = CategoryDetailsObj.CategoryId! //"\(CategoryDetailsObj["CategoryId"]!)"
            Category.CategoryName = CategoryDetailsObj.CategoryName! //"\(CategoryDetailsObj["CategoryName"]!)"
            ModelsArr.append(Category)
        }
    }
    
    struct CarTypeStru {
        var ModelDescription: String!
        var ModelId: String!
        var ModelName: String!
        var Status: String!
    }
    var CarTypesArr = [CarTypeStru]()
    
    func GetSubModels(VehArr:[[String:AnyObject]]) {
        CarTypesArr.removeAll()
        for VehicleObj in VehArr {
            var Vehicle = CarTypeStru()
            Vehicle.ModelDescription = "\(VehicleObj["ModelDescription"]!)"
            Vehicle.ModelId = "\(VehicleObj["ModelId"]!)"
            Vehicle.ModelName = "\(VehicleObj["ModelName"]!)"
            Vehicle.Status = "\(VehicleObj["Status"]!)"
            CarTypesArr.append(Vehicle)
        }
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    func ParserFunc(Suffix:String,Body:[String:String]) -> String {
        var ParamsStr = "<ns1:\(Suffix)>"
        
        for (key,value) in Body {
            ParamsStr.append("<ns1:\(key)>\(value)</ns1:\(key)>")
        }
        
        ParamsStr.append("</ns1:\(Suffix)>")
        return ParamsStr
    }
    
    func getvehicleModelDetails(CityIndex:Int,ModelIndex:Int,CorpoType:Int) {
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            let RequestDict = ["EmpId":"\(DriveBookingResponce.EmpId!)",
                                "TripType":"\(self.TripSelectTxt.text!)",
                                "VehicleCategory":"\(ModelsArr[ModelIndex].CategoryId!)",
                                "City":"\(CityArr[CityIndex].CityName!)",
                                "BookingType":"\(BTypeArray[CorpoType].Corporate_Type!)",
                                "VendorId":"\(LoginRequest.LoginCreds.VendorId!)",
                                "CorporateId":"\(BTypeArray[CorpoType].Corporate_ID!)",
                                "AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
            
            print(RequestDict)
            
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveVehicleModelDetails, parameterDict: RequestDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (responce, ErrorCode, success) in
 
                
                if success{
                
//                    let value = data as! [String:AnyObject]
                    let TableArray = (responce as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
                    print(TableArray)
                    let tabledata = TableArray[0]
                     self.view.StopLoading()
                    if "\(tabledata["Status"]!)" == "true"{
                        self.GetSubModels(VehArr: TableArray)
                        if self.CarTypesArr.count>0 {
                            self.CarSelectTxt.text = self.CarTypesArr[0].ModelName!
                        }
                        self.CallForRateItem(vehicleIndex: 0, CityIndex: CityIndex, ModelIndex: ModelIndex, CorpoType: self.BookingTypeSelectIndex)
                    }else{
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(tabledata["Response"]!)", Interval: 2)
                        
                        self.StandaredBaseFare.text = nil
                        self.StandaredMinimumHrs.text = nil
                        self.StandaredMinimumKms.text = nil
                        self.ExtraPerKm.text = nil
                        self.ExtraPerHr.text = nil
                        self.CarSelectTxt.isUserInteractionEnabled = false
                        return
                    }

                
                }else{
                    Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    return
                }
                
            })
        }
        else{
            Message.shared.Alert(Title: "Alert", Message: "Please Check Your Internet Connection", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            
            return
        }

//
//        
//                    if success{
//                    print(data)
//                    let value = data as! [String:AnyObject]
//                    let TableArray = value["Table"] as! [[String:AnyObject]]
//                    print(TableArray)
//                    let tabledata = TableArray[0]
//                    if "\(tabledata["Status"]!)" == "true"{
//                        self.GetSubModels(VehArr: TableArray)
//                        if self.CarTypesArr.count>0 {
//                            self.CarSelectTxt.text = self.CarTypesArr[0].ModelName!
//                        }
//                        self.CallForRateItem(vehicleIndex: 0, CityIndex: CityIndex, ModelIndex: ModelIndex)
//                    }else{
//                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(tabledata["Response"]!)", Interval: 2)
//                        
//                        self.StandaredBaseFare.text = nil
//                        self.StandaredMinimumHrs.text = nil
//                        self.StandaredMinimumKms.text = nil
//                        self.ExtraPerKm.text = nil
//                        self.ExtraPerHr.text = nil
//                        self.CarSelectTxt.isUserInteractionEnabled = false
//                        return
//                    }
//                }
////                    break
//                case .failed(let responcecode):
                
//                    print(responcecode.GetResponceCode())
////                
//                    switch responcecode {
//                    case .NoInternet:
//                        self.view.ShowBlackTostWithText(message: Constants.NetErrorMsg, Interval: 3)
//                        break
//                    default:
//                        self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
//                        break
//                    }
//                }
                
                self.view.StopLoading()
                
//            })
//            
//         }
//        else{
//            Message.shared.Alert(Title: "Alert", Message: "Please Check Your Internet Connection", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
//            
//             return
//        }
    }
    
    func CallForRateItem(vehicleIndex:Int,CityIndex:Int,ModelIndex:Int, CorpoType:Int) {
        
          if (Reachability()?.isReachable)! {
            self.view.StartLoading()

            let VehicleObj = CarTypesArr[vehicleIndex]
            let CityObj = CityArr[CityIndex]
            let ModelObj = ModelsArr[ModelIndex]
            
            let RequestDict = ["VehicleCategoryId":"\(ModelObj.CategoryId!)",
                                "VehicleModelId":"\(VehicleObj.ModelName!)",
                                "City":"\(CityObj.CityName!)",
                                "EmpId":DriveBookingResponce.EmpId!,
                                "TypeofTrip": "\(self.TripSelectTxt.text!)",
                                "Type":"Advance",
                                "VendorId":"\(LoginRequest.LoginCreds.VendorId!)",
                                "CorporateId":"\(BTypeArray[CorpoType].Corporate_ID!)",
                                "BookingType":"\(BTypeArray[CorpoType].Corporate_Type!)",
                                "AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
            
           
            
            print(RequestDict)
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveRateCard, parameterDict: RequestDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (responce, ErrorCode, success) in

                
                if success{
                    
                    let TableArray = (responce as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
                    self.view.StopLoading()
                    if TableArray.count>0 {
                        let Object = TableArray[0]
                        print(Object)
                        if "\(Object["Status"]!)" == "true" {
                            self.StandaredBaseFare.text = "\(Object["BaseFare"]!)"
                            self.StandaredMinimumHrs.text = "\(Object["MinimumHrs"]!)"
                            self.StandaredMinimumKms.text = "\(Object["MinimumKms"]!)"
                            self.ExtraPerKm.text = "\(Object["ExtraPerKm"]!)"
                            self.ExtraPerHr.text = "\(Object["ExtraPerHr"]!)"
                        }
                        else{
                            self.StandaredBaseFare.text = nil
                            self.StandaredMinimumHrs.text = nil
                            self.StandaredMinimumKms.text = nil
                            self.ExtraPerKm.text = nil
                            self.ExtraPerHr.text = nil
                        }
                    }
                    
                    
                }else{
                    Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    return
                }
                
            })
          }
          else{
            Message.shared.Alert(Title: "Alert", Message: "Please Check Your Internet Connection", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            
            return
        }

                
    }
    
    @IBAction func corpoTypeSelect(_ sender:UIButton) {
        BookTypeSelectTxt.becomeFirstResponder()
    }

    
    @IBAction func CitySelect(_ sender:UIButton) {
        CitySelectTxt.becomeFirstResponder()
    }
    @IBAction func CarTypeSelect(_ sender:UIButton) {
        CarSelectTxt.becomeFirstResponder()
    }
    
    @IBAction func CarModelSelect(_ sender:UIButton) {
        ModelSelectTxt.becomeFirstResponder()
    }
    
    
    @IBAction func TripTypeSelect(_ sender:UIButton) {
        TripSelectTxt.becomeFirstResponder()
    }
    
    @IBAction func PackageSelect(_ sender:UIButton) {
        PackageTxt.becomeFirstResponder()
    }
    
    
    func FetchPackages(CorpoType:Int) {
        
        if (Reachability()?.isReachable)! {
            
            let ModelObj = ModelsArr[ModelSelectIndex]
            
            let VehicleDetailsDict = ["EmpId":"\(DriveBookingResponce.EmpId!)","TypeofTrip":"\(TripTypeArr.count == 0 && self.TripSelectTxt.text! == "" ? "Airport" : self.TripSelectTxt.text! )","VehicleCategoryId":"\(ModelObj.CategoryId!)","VendorId":"\(LoginRequest.LoginCreds.VendorId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)", "BookingType":"\(BTypeArray[CorpoType].Corporate_Type!)",
                "CorporateId":"\(BTypeArray[CorpoType].Corporate_ID!)"]
            
            print(VehicleDetailsDict)
            
            
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DrivePackageTariffs, parameterDict: VehicleDetailsDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (responce, ErrorCode, success) in

                if success{
                    let value = responce as! [String:AnyObject]
                    
                    if let Table = value["Table"] {
                        print(Table)
                        
                        if (self.TripSelectTxt.text?.localizedCaseInsensitiveContains("package"))! {
                            self.PackageDetailsArr = Table as! [[String:AnyObject]]
                            self.PackageTxt.text = self.PackageDetailsArr[0]["TariffName"]! as? String ?? "NA"
                        }
                        self.getvehicleModelDetails(CityIndex: self.CitySelectIndex, ModelIndex: self.ModelSelectIndex, CorpoType: self.BookingTypeSelectIndex)
                        
                    }
                    else {
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                    }
                }else{
                    Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    return
                }
                
            })
        }
        else{
            Message.shared.Alert(Title: "Alert", Message: "Please Check Your Internet Connection", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            
            return
        }

}
    
    
    // MARK: - Make Picker based on View Position {
    
    func PickerViewMake(_ TypeId:Int) {
        
        let PickerViewSelection = UIPickerView()
        PickerViewSelection.backgroundColor = UIColor.white
        PickerViewSelection.tag = TypeId
        PickerViewSelection.delegate = self
        PickerViewSelection.dataSource = self
        PickerViewSelection.showsSelectionIndicator = true
        
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.darkGray
        toolBar.sizeToFit()
        
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: #selector(pickerDoneAction(_sender:)))
        doneButton.tag = TypeId
        
        toolBar.setItems([spaceButton,doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        
        if TypeId == 1 {
            CitySelectTxt.inputView = PickerViewSelection
            CitySelectTxt.inputAccessoryView = toolBar
        }
        else if TypeId == 2 {
            TripSelectTxt.inputView = PickerViewSelection
            TripSelectTxt.inputAccessoryView = toolBar
        }
        else if TypeId == 3 {
            ModelSelectTxt.inputView = PickerViewSelection
            ModelSelectTxt.inputAccessoryView = toolBar
        }
        else if TypeId == 4 {
            PackageTxt.inputView = PickerViewSelection
            PackageTxt.inputAccessoryView = toolBar
        }
        else if TypeId == 7 {
            BookTypeSelectTxt.inputView = PickerViewSelection
            BookTypeSelectTxt.inputAccessoryView = toolBar
        }
        else {
            CarSelectTxt.inputView = PickerViewSelection
            CarSelectTxt.inputAccessoryView = toolBar
        }
    }
    
    func pickerDoneAction(_sender:UIBarButtonItem) {
        self.view.endEditing(true)
        if _sender.tag == 7{
            if BookTypeSelectTxt.text! != BTypeArray[BookingTypeSelectIndex].Corporate_Type! {
                BookTypeSelectTxt.text = BTypeArray[BookingTypeSelectIndex].Corporate_Type
                BookPrevTypeSelectIndex = BookingTypeSelectIndex
                getvehicleModelDetails(CityIndex: CitySelectIndex, ModelIndex: ModelSelectIndex, CorpoType: BookPrevTypeSelectIndex)
            }
        }
        else if _sender.tag == 1 {
            if CitySelectTxt.text! != CityArr[CitySelectIndex].CityName! {
                CitySelectTxt.text = CityArr[CitySelectIndex].CityName
                CityPrevSelectIndex = CitySelectIndex
                getvehicleModelDetails(CityIndex: CityPrevSelectIndex, ModelIndex: ModelSelectIndex, CorpoType: BookPrevTypeSelectIndex)
            }
        }
            
        else if _sender.tag == 2 {
            
            if TripSelectTxt.text! != TripTypeArr[TripTypeSelectIndex].TripName! {
                TripSelectTxt.text = TripTypeArr[TripTypeSelectIndex].TripName!
                TripTypePrevSelectIndex = TripTypeSelectIndex
//                getvehicleModelDetails(CityIndex: CityPrevSelectIndex, ModelIndex: ModelSelectIndex)
                
                if (TripSelectTxt.text?.localizedCaseInsensitiveContains("Airport"))! {
                    ExtraFareHeightConstriant.constant = 0
                    ExtraFareView.isHidden = true
                }
                else {
                    ExtraFareHeightConstriant.constant = ExtraFareHeight
                    ExtraFareView.isHidden = false
                }
                
                
                if (TripSelectTxt.text?.localizedCaseInsensitiveContains("Package"))! {
                    PackageHiddenView.isHidden = false
                    PackageConstraint.constant = PackageHeight

                    FetchPackages(CorpoType: BookPrevTypeSelectIndex)
                }
                else {
                    PackageHiddenView.isHidden = true
                    PackageConstraint.constant = 0
                    PackageDetailsArr = [[String:AnyObject]]()
                    
                    self.getvehicleModelDetails(CityIndex: self.CitySelectIndex, ModelIndex: self.ModelSelectIndex, CorpoType: BookingTypeSelectIndex)
                }
                
            }
        }
            
        else if _sender.tag == 3 {
            if ModelSelectTxt.text! != ModelsArr[ModelSelectIndex].CategoryName! {
                ModelSelectTxt.text = ModelsArr[ModelSelectIndex].CategoryName
                ModelPrevSelectIndex = ModelSelectIndex
                getvehicleModelDetails(CityIndex: CityPrevSelectIndex, ModelIndex: ModelSelectIndex, CorpoType: BookPrevTypeSelectIndex)
            }
        }
            
            
        else if _sender.tag == 4 {
            if PackageTxt.text! != String(describing: PackageDetailsArr[PackageSelectIndex]["TariffName"]!) {
                PackageTxt.text = "\(PackageDetailsArr[PackageSelectIndex]["TariffName"]!)"
                PackagePrevSelectIndex = PackageSelectIndex
                getvehicleModelDetails(CityIndex: CityPrevSelectIndex, ModelIndex: ModelSelectIndex, CorpoType: BookPrevTypeSelectIndex)
            }
        }
            
        else {
            if CarSelectTxt.text != CarTypesArr[CarSelectIndex].ModelName {
                CarSelectTxt.text = CarTypesArr[CarSelectIndex].ModelName
                self.CallForRateItem(vehicleIndex: CarSelectIndex, CityIndex: CityPrevSelectIndex, ModelIndex: ModelSelectIndex, CorpoType: BookPrevTypeSelectIndex)
            }
        }
        
    }
    
    // MARK: - }
    var BookPrevTypeSelectIndex = 0
    var CityPrevSelectIndex = 0
    var ModelPrevSelectIndex = 0
    
    var TripTypePrevSelectIndex = 0
    var PackagePrevSelectIndex = 0
    
    var CitySelectIndex = 0
    var ModelSelectIndex = 0
    var CarSelectIndex = 0
    var BookingTypeSelectIndex = 0
    
    var TripTypeSelectIndex = 0
    var PackageSelectIndex = 0
}

extension RateCardRideLater: UIPickerViewDelegate,UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView.tag == 7 {
            return BTypeArray.count
        }
        else if pickerView.tag == 1 {
            return CityArr.count
        }
        else if pickerView.tag == 2 {
            return TripTypeArr.count
        }
        else if pickerView.tag == 3 {
            return ModelsArr.count
        }
        else if pickerView.tag == 4 {
            return PackageDetailsArr.count
        }
        else {
            return CarTypesArr.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView.tag == 7 {
            return BTypeArray[row].Corporate_Type!
        }else
        if pickerView.tag == 1 {
            return CityArr[row].CityName!
        }
        else if pickerView.tag == 2 {
            return TripTypeArr[row].TripName!
        }
        else if pickerView.tag == 3 {
            return ModelsArr[row].CategoryName!
        }
        else if pickerView.tag == 4 {
            return PackageDetailsArr[row]["TariffName"] as? String ?? "NA"
        }
        else {
            return CarTypesArr[row].ModelName!
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView.tag == 7 {
            BookingTypeSelectIndex = row
        }else
        if pickerView.tag == 1 {
            CitySelectIndex = row
        }
        else if pickerView.tag == 2 {
            TripTypeSelectIndex = row
        }
        else if pickerView.tag == 3 {
            ModelSelectIndex = row
        }
        else if pickerView.tag == 4 {
            PackageSelectIndex = row
        }
        else {
            CarSelectIndex = row
        }
    }
}
