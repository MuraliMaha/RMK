//
//  MyEventsVCNew.swift
//  DriveFindMyCab
//
//  Created by SunTelematics on 11/05/18.
//  Copyright © 2018 Suntelematics. All rights reserved.
//

import UIKit

class MyEventsVCNew: UIViewController {

    var LoginResponce:LoginResponce!
    var LoginDetails:LoginDetails!
    
    @IBOutlet weak var datetextfield: UITextField!
    
    var datepicker: UIDatePicker!
    var dateComponents : NSDateComponents!
    var dateFormatter = DateFormatter()
    var dateString : String!
    
    @IBOutlet weak var eventsTV: UITableView!
    
    var eventsArr = [EventsStruct]()
    
    @IBOutlet weak var plusBtn: UIButton!
    @IBOutlet weak var noDataLabel: UILabel!
    var currentDateStr : String!
    
    
    var dateSelectIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.noDataLabel.isHidden = true
        
        self.LoginDetails = FetchLoginDetails()
        self.LoginResponce = FetchLoginResponce()
        
        datepicker = UIDatePicker()
        dateFormatter.dateFormat = "dd-MMM-yyyy"
        dateString = dateFormatter.string(from: Date())
        
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.blue
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action:#selector(donePicker))
        
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.plain, target: self, action:#selector(cancelPicker))
        
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        datepicker.datePickerMode = UIDatePickerMode.date
        datetextfield.inputView = datepicker
        datetextfield.inputAccessoryView = toolBar
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.white
        self.navigationItem.leftBarButtonItem = BackBtnItem
        
        let currentDate = Date()
        currentDateStr = dateFormatter.string(from: currentDate)
        self.datetextfield.text = currentDateStr
        
        self.eventsTV.delegate = self
        self.eventsTV.dataSource = self
        
        let selector = #selector(callEventsService)
        Timer.scheduledTimer(timeInterval: 0.1, target: self, selector:selector , userInfo: nil, repeats: false)
        
//        self.perform(selector, with: nil, afterDelay: 0.2)
    }

    func callEventsService() {
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            let RwquestDict = ["TripDate":self.datetextfield.text!,"UserId":LoginDetails.UserID!]
            
            print(RwquestDict)
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.GetEventDetails, parameterDict: RwquestDict as! [String : String], completion: { (responceDict, success) in
                
                self.view.StopLoading()
                
                if success {

                    self.noDataLabel.isHidden = true
                    self.eventsTV.isHidden = false
//                    self.plusBtn.isHidden = false
                    self.eventsArr.removeAll()
                    
                    if let Sub = responceDict {
                        let Arr = Sub["data"] as! [[String:AnyObject]]
                        if Arr.count > 0{
                            for aDict in Arr {
                                var aStruct = EventsStruct()
                                let fullStr : String = aDict["Content"] as! String
                                let splittedArr = fullStr.components(separatedBy: "~")
                                aStruct.ETA = splittedArr[0]
                                aStruct.shiftTime = splittedArr[1]
                                aStruct.VehicleNo = splittedArr[2]
                                aStruct.shiftType = splittedArr[3]
                                self.eventsArr.append(aStruct)
                            }
                            
                            self.eventsTV.reloadData()
                        }else{
                            print("No data in arr")
                            
                            self.noDataLabel.isHidden = false
                            self.eventsTV.isHidden = true

                            
                            
                         /*
                            //                    static data code
                            self.eventsArr.removeAll()
                            let staticDict = ["data": [["Content": "ETA : May 11 2018 11:56AM~ShiftTime : 12:00~VehicleNo : KA01AA4322~ShiftType : Pickup"],["Content": "ETA : May 11 2018 12:40PM~ShiftTime : 12:45~VehicleNo : KA01AA4322~ShiftType : Drop"],["Content": "ETA : May 11 2018 12:45PM~ShiftTime : 12:45~VehicleNo : KA01AA4322~ShiftType : Pickup"],["Content": "ETA : May 11 2018 12:51PM~ShiftTime : 12:45~VehicleNo : KA01AA4322~ShiftType : Pickup"],["Content": "ETA : May 11 2018 12:56AM~ShiftTime : 12:50~VehicleNo : KA01AA4323~ShiftType : Pickup"]]]
                            let Arr = staticDict["data"] as! [[String:String]]
                            if Arr.count > 0{
                                for aDict in Arr {
                                    var aStruct = EventsStruct()
                                    let fullStr : String = aDict["Content"] as! String
                                    let splittedArr = fullStr.components(separatedBy: "~")
                                    aStruct.ETA = splittedArr[0]
                                    aStruct.shiftTime = splittedArr[1]
                                    aStruct.VehicleNo = splittedArr[2]
                                    aStruct.shiftType = splittedArr[3]
                                    self.eventsArr.append(aStruct)
                                }
                            }
                            self.eventsTV.reloadData()
                            
                            self.noDataLabel.isHidden = true
                            self.eventsTV.isHidden = false
                            
                            */
                        }
                    }


                }
                else {
                    
                    


                    
//                    self.DetailsText.text = ""
//                    self.DetailsText.isHidden = true
//                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                    
//                    self.plusBtn.isHidden = true

                    self.noDataLabel.isHidden = true
                    self.eventsTV.isHidden = true
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)


                }
            })
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Check for Internet Conenction", Interval: 3)
//            DetailsText.text = ""
//            self.DetailsText.isHidden = true
            self.noDataLabel.isHidden = true
            self.eventsTV.isHidden = true
//            self.plusBtn.isHidden = true
        }
        
    }
    
    func BackAction() {
        self.navigationController?.popViewController(animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func donePicker(sender : UIBarButtonItem) {
        datetextfield.text = dateString
        self.datetextfield.resignFirstResponder()
        
        self.callEventsService()
    }
    
    func cancelPicker(sender : UIBarButtonItem ){
        self.datetextfield.resignFirstResponder()
    }

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func plusBtnTapped(_ sender: UIButton) {
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "PlanURTripVCSBID") as! PlanURTripVC
        ctrl.selectedDateStr = self.datetextfield.text
        self.navigationController?.pushViewController(ctrl, animated: true)
    }
}

extension MyEventsVCNew : UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == datetextfield {
//            dateString = dateFormatter.string(from: Date())
            datepicker.minimumDate = NSDate() as Date
            
            
//            let calendar:NSCalendar = NSCalendar.current as NSCalendar
//            let components = calendar.components([NSCalendar.Unit.year, NSCalendar.Unit.month, NSCalendar.Unit.day, NSCalendar.Unit.hour, NSCalendar.Unit.minute], from: NSDate() as Date)
//            let date = calendar.date(from: components)!
 
            
            let selectedDateStr = datetextfield.text!
            let myDate = dateFormatter.date(from: selectedDateStr)
            datepicker.setDate(myDate!, animated: true)
            dateString = selectedDateStr
            datepicker.addTarget(self, action: #selector(handleDatePicker), for: UIControlEvents.valueChanged)
            
        }
    }
    
    func handleDatePicker(sender: UIDatePicker) {
        dateString = dateFormatter.string(from: sender.date)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
}
extension MyEventsVCNew : UITableViewDelegate , UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.eventsArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EventsTableViewCellID", for: indexPath) as! EventsTableViewCell
        
        cell.ETALabel.text = self.eventsArr[indexPath.row].ETA
        cell.shiftTimeLabel.text = self.eventsArr[indexPath.row].shiftTime
        cell.vehicleNoLabel.text = self.eventsArr[indexPath.row].VehicleNo
        cell.shiftTypeLabel.text = self.eventsArr[indexPath.row].shiftType
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 124
    }
    
}
class EventsTableViewCell : UITableViewCell {
    @IBOutlet weak var ETALabel: UILabel!
    @IBOutlet weak var shiftTimeLabel: UILabel!
    @IBOutlet weak var vehicleNoLabel: UILabel!
    @IBOutlet weak var shiftTypeLabel: UILabel!
}
struct  EventsStruct {
    var ETA : String!
    var shiftTime : String!
    var VehicleNo : String!
    var shiftType : String!
}
