//
//  CalenderVCTemp2.swift
//  DriveFindMyCab
//
//  Created by SunTelematics on 20/06/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit

class CalenderVC: UIViewController {

    @IBOutlet weak var myCalenderView: FSCalendar!
    @IBOutlet var DetailsText : UITextView!
    
//    var CalenderView = FSCalendar()
    
    var LoginResponce:LoginResponce!
    var LoginDetails:LoginDetails!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.LoginDetails = FetchLoginDetails()
        self.LoginResponce = FetchLoginResponce()
        
        Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(LoadCalender), userInfo: nil, repeats: false)
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.white
        self.navigationItem.leftBarButtonItem = BackBtnItem
        
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName : UIColor.white]
    }

    func BackAction() {
        self.navigationController?.popViewController(animated: true)
    }
    
    func LoadCalender() {
//        CalenderView = FSCalendar(frame: CGRect(x: 0, y: 0, width: Calender.bounds.width, height: Calender.bounds.height))
//        CalenderView.dataSource = self
//        CalenderView.delegate = self
//        CalenderView.backgroundColor = UIColor.clear
//        self.Calender.addSubview(CalenderView)
        
        let MyDate = Date()
        
        let gregCal:NSCalendar = NSCalendar(calendarIdentifier: NSCalendar.Identifier.gregorian)!
        let gregTime:NSDateComponents = gregCal.components(([.year, .month, .day, .hour, .minute]), from: MyDate as Date) as NSDateComponents
        
        let Day = gregTime.day
        let Month = gregTime.month
        
        let FilteredDay : String = {
            let Str = "\(Day)".characters.count == 1 ? "0\(Day)" : "\(Day)"
            return Str
        }()
        let FilteredMonth : String = {
            let Str = "\(Month)".characters.count == 1 ? "0\(Month)" : "\(Month)"
            return Str
        }()
        
        GetDetails(DateStr: "\(gregTime.year)" + "-" + FilteredMonth + "-" + FilteredDay)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func GetDetails(DateStr:String) {
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            let RwquestDict = ["TripDate":DateStr,"UserId":LoginDetails.UserID!]
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.GetEventDetails, parameterDict: RwquestDict, completion: { (responceDict, success) in
                
                self.view.StopLoading()
                
                if success {
                    
                    if let Sub = responceDict {
                        let Arr = Sub["data"] as! [[String:AnyObject]]
                        
                        self.DetailsText.text = ""
                        var AppendStr = ""
                        for Data in Arr {
                            
                            let Str = Data["Content"]!
                            let splitArr = Str.components(separatedBy: "~")
                            for strSubbbb in splitArr {
                                AppendStr.append(strSubbbb)
                                AppendStr.append("\n")
                            }
                            
                            AppendStr.append("\n")
                        }
                        
                        let SubFilter = UtilitiesClassSub.removeLeadingandTralingSpace(AppendStr)
                        
                        if SubFilter == ""
                        {
                            self.DetailsText.isHidden = true
                        }
                        else {
                            self.DetailsText.text = SubFilter
                            self.DetailsText.isHidden = false
                        }
                    }
                    else {
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                        self.DetailsText.isHidden = true
                        self.DetailsText.text = ""
                    }
                }
                else {
                    self.DetailsText.text = ""
                    self.DetailsText.isHidden = true
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                }
            })
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Check for Internet Conenction", Interval: 3)
            DetailsText.text = ""
            self.DetailsText.isHidden = true
        }
    }

}
extension CalenderVC:FSCalendarDelegate,FSCalendarDataSource,FSCalendarDelegateAppearance {
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {

        if monthPosition == .previous || monthPosition == .next {
            myCalenderView.setCurrentPage(date, animated: true)
        }
        else {

            let gregCal:NSCalendar = NSCalendar(calendarIdentifier: NSCalendar.Identifier.gregorian)!
            let gregTime:NSDateComponents = gregCal.components(([.year, .month, .day, .hour, .minute]), from: date as Date) as NSDateComponents


            let Day = gregTime.day
            let Month = gregTime.month

            let FilteredDay : String = {
                let Str = "\(Day)".characters.count == 1 ? "0\(Day)" : "\(Day)"
                return Str
            }()
            let FilteredMonth : String = {
                let Str = "\(Month)".characters.count == 1 ? "0\(Month)" : "\(Month)"
                return Str
            }()

            GetDetails(DateStr: "\(gregTime.year)" + "-" + FilteredMonth + "-" + FilteredDay)
        }
    }
    
    func minimumDate(for calendar: FSCalendar) -> Date {
        return Date()
    }
}
