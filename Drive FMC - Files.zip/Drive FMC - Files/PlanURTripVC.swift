//
//  PlanURTripVC.swift
//  DriveFindMyCab
//
//  Created by SunTelematics on 14/05/18.
//  Copyright © 2018 Suntelematics. All rights reserved.
//

import UIKit

class PlanURTripVC: UIViewController {
    @IBOutlet weak var dateLbl: UILabel!
    var selectedDateStr : String!
    
    @IBOutlet weak var loginTxtField: UITextField!
    @IBOutlet weak var logoutTxtField: UITextField!
    
    var loginArr = [TestStruct]()
    var logoutArr = [TestStruct]()
    
    var loginSelectIndex = 0
    var logoutSelectIndex = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

//     static Data
       createStaticData()
        
        loginTxtField.delegate = self
        logoutTxtField.delegate = self
        
        
        
        self.dateLbl.text = selectedDateStr
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.white
        self.navigationItem.leftBarButtonItem = BackBtnItem
        
        pickerViewMake(typeId: 1)
        pickerViewMake(typeId: 2)
    }
    
    func createStaticData() {
        var aStruct1 = TestStruct()
        aStruct1.loginoutTime = "7.30am"
        
        var aStruct2 = TestStruct()
        aStruct2.loginoutTime = "8.30am"
        
        var aStruct3 = TestStruct()
        aStruct3.loginoutTime = "9.30am"
        
        var aStruct4 = TestStruct()
        aStruct4.loginoutTime = "10.30am"
        
        
        loginArr.append(aStruct1)
        loginArr.append(aStruct2)
        loginArr.append(aStruct3)
        loginArr.append(aStruct4)
        
        var aStruct5 = TestStruct()
        aStruct5.loginoutTime = "5.30pm"
        
        var aStruct6 = TestStruct()
        aStruct6.loginoutTime = "6.30pm"
        
        var aStruct7 = TestStruct()
        aStruct7.loginoutTime = "7.00pm"
        
        logoutArr.append(aStruct5)
        logoutArr.append(aStruct6)
        logoutArr.append(aStruct7)
    }

    //MARK : Making Picker
    func pickerViewMake(typeId : Int){
        let PickerViewSelection = UIPickerView.init()
        PickerViewSelection.backgroundColor = UIColor.white
        PickerViewSelection.tag = typeId
        PickerViewSelection.delegate = self
        PickerViewSelection.dataSource = self
        //        PickerViewSelection.showsSelectionIndicator = true
        
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.darkGray
        toolBar.sizeToFit()
        
        let cancelButton = UIBarButtonItem.init(title: "Cancel", style: .done, target: self, action: #selector(pickerCancelAction(_sender:)))
        cancelButton.tag = typeId
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: #selector(pickerDoneAction(_sender:)))
        doneButton.tag = typeId
        
        toolBar.setItems([cancelButton,spaceButton,doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        
        if typeId == 1 {
            loginTxtField.inputView = PickerViewSelection
            loginTxtField.inputAccessoryView = toolBar
        } else {
            logoutTxtField.inputView = PickerViewSelection
            logoutTxtField.inputAccessoryView = toolBar
        }
    }
    func BackAction() {
        self.navigationController?.popViewController(animated: true)
    }
    func pickerCancelAction(_sender:UIBarButtonItem){
        
        if _sender.tag == 1{
            loginTxtField.resignFirstResponder()
        }else {
            logoutTxtField.resignFirstResponder()
        }
        
        
    }
    func pickerDoneAction(_sender:UIBarButtonItem) {
        self.view.endEditing(true)
        
        if _sender.tag == 1 {
            if loginTxtField.text != loginArr[loginSelectIndex].loginoutTime {
                loginTxtField.text = loginArr[loginSelectIndex].loginoutTime
            }
        }else{
            if logoutTxtField.text != logoutArr[logoutSelectIndex].loginoutTime {
                logoutTxtField.text = logoutArr[logoutSelectIndex].loginoutTime
            }
        }
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func submitBtnTapped(_ sender: UIButton) {
    }
   
}
extension PlanURTripVC : UITextFieldDelegate {
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        if textField == self.loginTxtField {
            let pickerView : UIPickerView = self.loginTxtField.inputView as! UIPickerView
            
                if self.loginArr.count == 0 {
                    return false
                }
                loginSelectIndex = 0
                pickerView.selectRow(loginSelectIndex, inComponent: 0, animated: true)
            
            
        }else {
            let pickerView : UIPickerView = self.logoutTxtField.inputView as! UIPickerView
            
                if self.logoutArr.count == 0 {
                    return false
                }
                
                logoutSelectIndex = 0
                pickerView.selectRow(logoutSelectIndex, inComponent: 0, animated: true)
            
            
        }
        return true
        
    }
}
extension PlanURTripVC: UIPickerViewDelegate,UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if pickerView.tag == 1 {
            return loginArr.count
        }
        else {
            return logoutArr.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if pickerView.tag == 1 {
            return loginArr[row].loginoutTime
        }else {
            return logoutArr[row].loginoutTime
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        
//        if pickerView.tag == 1 {
//            routeNameSelectIndexPickup = row
//        }
//        else {
//            shiftSelectIndexPickup = row
//        }
    }
}
struct TestStruct {
    var loginoutTime : String!
}
