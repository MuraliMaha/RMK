//
//  BiddingView.swift
//  Drive Booking
//
//
//  Created by Amar on 18/04/17.
//  Copyright © 2017 suntelematics. All rights reserved.
//


import UIKit
import CoreLocation
import MapKit

protocol BiddingDelegate {
    func BiddingDidCancelled(controller:BiddingView, isFrom:String)
    func BiddingDidCompleteBooking(JobID:String, controller:BiddingView)
}
class BiddingView: UIViewController {

    @IBOutlet weak var LoadingTextLabel: UILabel!
    @IBOutlet var Progress:MBCircularProgressBarView!
    @IBOutlet var imageShow:UIImageView!
    
    var JobNo: String!
    var PickUpCoordinates: CLLocationCoordinate2D!
    
    var Timerrrr = Timer()
    var ServiceTimer = Timer()
    
    var Delegate: BiddingDelegate!
    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!
 
    var biddingInitial_Retry : String! = "0"

    override func viewDidLoad() {
        super.viewDidLoad()
        
         self.LoginRequest = FetchDriveRequest()
        self.DriveBookingResponce = FetchDriveResponce()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        //set circular progress max value
        Progress.maxValue = CGFloat(Float("\(DriveBookingResponce.RetryInterval!)")!)
        
        //run countdown timer.
        Timerrrr = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(CountAdd), userInfo: nil, repeats: true)
        
        //every 10secs fetching booking details from backend
        ServiceTimer = Timer.scheduledTimer(timeInterval: 10, target: self, selector: #selector(FetchDetailsFromService), userInfo: nil, repeats: true)
        
        //initially fetching booking details from backend
        FetchDetailsFromService()
        
//        show greenMArker on the googlemaps
        renderSnapshot(PickUpCoordinates!, CGSize.init(width: 200, height: 200), self.ReduceImageSize(UIImage.init(named:"GreenTrack")!, CGSize.init(width: 25, height: 25))) { (imageout, errorstr) in
            if (errorstr == nil) {
                self.imageShow.image = imageout!
            }
            else {
                
            }
        }
        
//        initial text of label before starting animation
        LoadingTextLabel.text = "Contacting Cabs around you..."
        
        //circular image animation calling
        Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(loadonce), userInfo: nil, repeats: false)
        
        //start text animation
        updateLoadingLabel()
        
       //text animation logic calls
       LoadingtextTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateLoadingLabel), userInfo: nil, repeats: true)

    }
    var LoadingtextTimer : Timer!
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        //if view disappears invalidate all timers.
        Timerrrr.invalidate()
        ServiceTimer.invalidate()
        LoadingtextTimer.invalidate()
    }
    
    //text aniamtion logic

    func updateLoadingLabel() {
 
//print( Progress.value)
        if Progress.value <= CGFloat(Float("\(DriveBookingResponce.BiddingInterval!)")!) {
            //print(LoadingTextLabel.text!)
            if (LoadingTextLabel.text! == "Contacting Cabs around you...") {
                LoadingTextLabel.text = "Contacting Cabs around you"
            }
            else {
                LoadingTextLabel.text = "\(LoadingTextLabel.text!)."
            }
            //each second
        }else{
        
        }
    }
    
    
    @IBAction func CancelTopBtnPressed(_ sender:UIButton) {
//        Booking Confirmation screen “Click on into Mark “
        
        
//        CleverTap.sharedInstance()?.recordEvent("Click on into Mark")

        Delegate.BiddingDidCancelled(controller: self, isFrom: "0")
        Timerrrr.invalidate()
        ServiceTimer.invalidate()
        CancelBookingUser()
    }
    
    
    func loadonce() {
        imageShow.layer.cornerRadius = imageShow.frame.width/2
    }
    
    
//    circular animation countdown timer function
    func CountAdd() {
        
        if Progress.value == CGFloat(Float("\(DriveBookingResponce.RetryInterval!)")!) {
            Delegate.BiddingDidCancelled(controller: self, isFrom: "1")
            Timerrrr.invalidate()
            ServiceTimer.invalidate()
            CancelBooking()
           
        }
        else {
//            biddingInitial_Retry == "0" means first coming inside the loop. shows alert message  for first time
//            biddingInitial_Retry == "1" means when user clicks retry then coming inside loop. if retry button clicked we will not show alert message again
            if self.biddingInitial_Retry == "0"{
                if Progress.value == CGFloat(Float("\(DriveBookingResponce.BiddingInterval!)")!){
                    self.Timerrrr.invalidate()
                    self.ServiceTimer.invalidate()
                    
                    Message.shared.Alert(Title: "", Message: "\(DriveBookingResponce.BiddingRetryMsg!)", TitleAlign: .normal , MessageAlign: .normal, Actions: [Message.AlertActionWithSelector(Title: "Cancel", Selector: #selector(self.biddingCancelled), Controller: self),Message.AlertActionWithSelector(Title: "Retry", Selector: #selector(self.retryBidding), Controller: self)], Controller: self)
                    return
                }
                
            }
//            increase progess value
            Progress.value = Progress.value + 1
        }
    }
    func biddingCancelled(){
//    call cancel booking if user selected cancel from alert
        CancelBooking()
    }
    
//    if user selects retry from alertview calls below function
    func retryBidding(){
        self.Progress.value = 0.0
        if (Reachability()?.isReachable)! {
            
            let FetchDict = ["BookingId":"\(JobNo!)","EmpId":"\(DriveBookingResponce.EmpId!)","VendorId":LoginRequest.LoginCreds.VendorId!,"CorporateId":LoginRequest.LoginCreds.CorporateId!,"AppCustomerType":LoginRequest.LoginCreds.AppCustomerType!]
            
            
            
            //print(FetchDict)
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveReDispatch, parameterDict: FetchDict, securityKey: DriveBookingResponce.AuthenticationToken, completion: { (dataDict, ErrorCode, success) in
                
                if success{
                    let TableArray = (dataDict as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
                    let tableData = TableArray[0]
                    
                    let responseStatus = tableData["Status"] as! String
                    
                    if responseStatus == "true"{
//                       initially biddingInitial_Retry = "0" it means it shows alert if user clicks retry biddingInitial_Retry becmoes "1" so for next time alert will not been shown
                        self.biddingInitial_Retry = "1"
                        self.view.ShowBlackTostWithText(message: "\(tableData["Response"]!)", Interval: 3)
                        
                        //restart  countdown timer
                        self.Timerrrr = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.CountAdd), userInfo: nil, repeats: true)
                        //restart function calling every 10secs
                        self.ServiceTimer = Timer.scheduledTimer(timeInterval: 10, target: self, selector: #selector(self.FetchDetailsFromService), userInfo: nil, repeats: true)

                    }
                    else {
                        self.CancelBooking()
                    }
                }else{
                    
                    
                    //self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                    return
                    
                }
            })
            
        }
        else {
            
            self.view.ShowBlackTostWithText(message: "Please Check your Internet Connection", Interval: 3)
        }
    
    }
    
    //fetching booking details from server
    func FetchDetailsFromService() {
       if (Reachability()?.isReachable)! {
        
            let FetchDict = ["MobileNo":"\(DriveBookingResponce.PhoneNo!)","JobNo":"\(JobNo!)","EmpId":"\(DriveBookingResponce.EmpId!)","VendorId":LoginRequest.LoginCreds.VendorId!,"CorporateId":LoginRequest.LoginCreds.CorporateId!,"AppCustomerType":LoginRequest.LoginCreds.AppCustomerType!]
        
        
        
        //print(FetchDict)
        WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveGetBookingDetails, parameterDict: FetchDict, securityKey: DriveBookingResponce.AuthenticationToken, completion: { (dataDict, ErrorCode, success) in

              if success{
            let TableArray = (dataDict as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
                let tableData = TableArray[0]
            
                let responseStatus = tableData["Status"] as! String
                
                if responseStatus == "true"{
//                    //print(tableData)
                    
                    if (tableData["VehicleNo"] as! String) == "N/A" || (tableData["VehicleNo"] as! String) == "NA" || (tableData["VehicleNo"] as! String) == "0" || (tableData["VehicleNo"] as! String) == "" {
                        
                        
                    }
                    else {
                        self.Delegate.BiddingDidCompleteBooking(JobID:self.JobNo!, controller: self)
                    }
                 }
                else {
                    
                }
            }else{
                
 
//                self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                return
            
            }
        })
            
        }
        else {
            
            self.view.ShowBlackTostWithText(message: "Please Check your Internet Connection", Interval: 3)
        }
    }
    
// no cabs available even after bidding call this function
    
    func CancelBooking() {
        
        if (Reachability()?.isReachable)! {
            
//            showLoading()
            self.view.StartLoading()
            let CancelRequestDict = ["JobNo":"\(JobNo!)","JobType":"Current","CancelReason":"Time Out","EmpId":"\(DriveBookingResponce.EmpId!)","VendorId":LoginRequest.LoginCreds.VendorId!,"CorporateId":LoginRequest.LoginCreds.CorporateId!,"AppCustomerType":LoginRequest.LoginCreds.AppCustomerType!]
            
            //print(CancelRequestDict)
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveCancelBooking, parameterDict: CancelRequestDict, securityKey: DriveBookingResponce.AuthenticationToken, completion: { (dataDict, ErrorCode, success) in
            
            
//            let ParseStr = SoapPerser(dict: CancelRequestDict, Suffix: "CancelBooking")
//            
//            
//            callSoapAPI(parameters: ParseStr, completion: { (dataDict) in
                
//                hideLoading()
                
                
                self.dismiss(animated: true, completion: nil)
                if success{
                    

                    
                    
                let TableArray = (dataDict as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
                let tableData = TableArray[0]
                
                if "\(tableData["Status"]!)" == "true" {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "No cabs available", Interval: 3)
                    
                }
                else {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "No cabs available", Interval: 3)
                }
                }else{
                    self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                    return

                }
            })

        }
        
    }
    
    //user cancels booking when its in bidding
    func CancelBookingUser() {
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            let CancelRequestDict = ["JobNo":"\(JobNo!)","JobType":"Current","CancelReason":"Booking Cancled","EmpId":"\(DriveBookingResponce.EmpId!)","VendorId":LoginRequest.LoginCreds.VendorId!,"CorporateId":LoginRequest.LoginCreds.CorporateId!,"AppCustomerType":LoginRequest.LoginCreds.AppCustomerType!]
            
            //print(CancelRequestDict)
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveCancelBooking, parameterDict: CancelRequestDict, securityKey: DriveBookingResponce.AuthenticationToken, completion: { (dataDict, ErrorCode, success) in
 
 
                self.view.StopLoading()
                if success{
 
                let TableArray = (dataDict as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
                let tableData = TableArray[0]
                
                if "\(tableData["Status"]!)" == "true" {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(tableData["Response"]!)", Interval: 3)
                }
                else {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(tableData["Response"]!)", Interval: 3)
                }
                }else{
                    self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                    return

                }
            })
            
        }
        
    }
    
//    func SoapPerser(dict:[String:String],Suffix:String) -> String {
//        var ParamsStr = "<ns1:\(Suffix)>"
//        
//        for (key,value) in dict {
//            ParamsStr.append("<ns1:\(key)>\(value)</ns1:\(key)>")
//        }
//        ParamsStr.append("</ns1:\(Suffix)>")
//        
//        return ParamsStr
//    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // screenshot of googlemaps image.
    
    func renderSnapshot(_ Location:CLLocationCoordinate2D,_ size:CGSize,_ OverLay:UIImage, completion: @escaping (_ image:UIImage?,_ error:String?) -> Void) {
        let MapSnapShot = MKMapSnapshotOptions()
        MapSnapShot.size = size
        MapSnapShot.scale = UIScreen.main.scale
        
        let Span = MKCoordinateSpanMake(0.01, 0.01)
        MapSnapShot.region = MKCoordinateRegionMake(Location, Span)
        
        let Snapshotter = MKMapSnapshotter.init(options: MapSnapShot)
        Snapshotter.start { (snapshot, error) in
            if (error == nil) {
                let imageBack = (snapshot?.image)!
                let MarkImage = OverLay
                
                UIGraphicsBeginImageContextWithOptions(imageBack.size, false, 0.0)
                imageBack.draw(in: CGRect.init(x: 0, y: 0, width: imageBack.size.width, height: imageBack.size.height))
                MarkImage.draw(in: CGRect.init(x: (imageBack.size.width/2) - (OverLay.size.width/2) , y: (imageBack.size.height/2) - (OverLay.size.height/2), width: OverLay.size.width, height: OverLay.size.height))
                let finalimage = UIGraphicsGetImageFromCurrentImageContext()
                UIGraphicsEndImageContext()
                completion(finalimage,nil)
            }
            else {
                completion(nil,"Error rendering snapshot for map at: (\(MapSnapShot.region.center.latitude), \(MapSnapShot.region.center.longitude)) with Error:\(String(describing: error?.localizedDescription))");
            }
        }
        
    }
    
    func ReduceImageSize(_ originalImg:UIImage,_ size:CGSize) -> UIImage {
        
        let canvasSize = CGSize.init(width: size.width , height:(size.width/originalImg.size.width) * originalImg.size.height)
        UIGraphicsBeginImageContextWithOptions(originalImg.size, false, originalImg.scale)
        originalImg.draw(in: CGRect.init(x: 0, y: 0, width: canvasSize.width, height: canvasSize.height))
        let img = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return img!
    }
    
}
