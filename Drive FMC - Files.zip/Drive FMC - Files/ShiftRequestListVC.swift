//
//  ShiftRequestListVC.swift
//  DriveFindMyCab
//
//  Created by SunTelematics on 30/03/18.
//  Copyright © 2018 Suntelematics. All rights reserved.
//

import UIKit

class ShiftRequestListVC: UIViewController {

    @IBOutlet weak var shiftChangeRequestTableView: UITableView!
    
    @IBOutlet weak var noRequestFoundLbl: UILabel!
    @IBOutlet weak var clickPlusLbl: UILabel!
    
    var ShiftRequestListArr = [[String:AnyObject]]()
    
    var loginResponse:LoginResponce!
    var loginDetail:LoginDetails!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        shiftChangeRequestTableView.delegate = self
        shiftChangeRequestTableView.dataSource = self
        
        loginDetail = FetchLoginDetails()
        loginResponse = FetchLoginResponce()
        
//        shiftChangeRequestTableView.tableFooterView = UIView.init(frame: CGRect.zero)
        
        let RightItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "ic_add"), to: CGSize.init(width: 30, height: 30)), style: .done, target: self, action: #selector(RightBarItem))
        RightItem.tintColor = UIColor.white
        self.navigationItem.rightBarButtonItem = RightItem
        
    }

    func RightBarItem() {
        let request = self.storyboard?.instantiateViewController(withIdentifier: "ShiftRequestVCSBID") as! ShiftRequestVC
        self.navigationController?.pushViewController(request, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        Timer.scheduledTimer(timeInterval: 0.2, target: self, selector: #selector(CallServiceToFetchShiftRequestList), userInfo: nil, repeats: false)
    }
    
    func CallServiceToFetchShiftRequestList () {
        if (Reachability()?.isReachable)! {
            UIApplication.shared.keyWindow?.StartLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.DriveShiftChangeList, parameterDict: ["EmpId":"\(loginResponse.Employeeid!)"], completion: { (responceDict, success) in
                UIApplication.shared.keyWindow?.StopLoading()
                if success {
                    
                    if let Dict = responceDict {
                        let Arr = Dict["data"] as! [[String:AnyObject]]
                        if Arr.count > 0 {
                            self.ShiftRequestListArr = Arr
                            self.shiftChangeRequestTableView.isHidden = false
                        }
                        else {
                            print("Error")
                            self.view.ShowWhiteTostWithText(message: "No Requests found", Interval: 2)
                            self.shiftChangeRequestTableView.isHidden = true
                        }
                        self.shiftChangeRequestTableView.reloadData()
                    }
                    else {
                        self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                        
                        print("Error")
                    }
                }
                else {
                    self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                    
                    print("Error")
                }
            })
            
        }
        else {
            self.view.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
            
            print("Net Error")
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
extension ShiftRequestListVC : UITableViewDelegate , UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ShiftRequestListArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ShiftRequestCellID", for: indexPath) as! ShiftChangeListCellClass
        
        cell.shiftDateLbl.text = "\(ShiftRequestListArr[indexPath.row]["Date"]!)"
//        cell.shiftTimeLbl.text = "\(ShiftRequestListArr[indexPath.row]["Shifttime"]!)"
        
        cell.statusLbl.text = "\(ShiftRequestListArr[indexPath.row]["Status"]!)"
        
        cell.selectionStyle = .none
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 124
    }
    
}
//class ShiftChangeListCellClass : UITableViewCell {
//
//    @IBOutlet weak var shiftDateLbl: UILabel!
//    @IBOutlet weak var shiftTimeLbl: UILabel!
//    @IBOutlet weak var statusLbl: UILabel!
//}
