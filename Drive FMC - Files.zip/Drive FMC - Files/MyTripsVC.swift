//
//  MyTripsVC.swift
//  DriveBooking
//
//  Created by Raja Bhuma on 13/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit

class MyTripsVC: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {
    
    @IBOutlet var PersonalTB: UITableView!
    
    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        PersonalTB.tableFooterView = UIView.init(frame: CGRect.zero)
        
        
        self.LoginRequest = FetchDriveRequest()
        self.DriveBookingResponce = FetchDriveResponce()
        
        CancelBookingHiddenTxt()
        
        
        
        self.title = "MY TRIPS"
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.white
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
        self.navigationItem.leftBarButtonItem = BackBtnItem
        
    }
    
    func BackAction() {
        self.navigationController?.popToRootViewController(animated: true)
//        self.navigationController?.popViewController(animated: true)
    }

    
    func GetPersonRides() {
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            let RequestDict = ["MobileNo":"\(DriveBookingResponce.PhoneNo!)","EmpId":"\(DriveBookingResponce.EmpId!)","VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
            print("DriveBookingsHistory Service MyTripsVC Input =",RequestDict)
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveBookingsHistory, parameterDict: RequestDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (ResponceDict, responceCode, success) in
                print(ResponceDict,responceCode)
                self.view.StopLoading()
                
                if success {
                    
                    if let TableArr = ((ResponceDict as! [String:AnyObject])["Table"] as? [[String:AnyObject]]) {
                        
                        if TableArr.count > 0 && "\(TableArr[0]["Status"]!)".toBool()! {
                            self.ParseData(DataArr: TableArr)
                            self.PersonalTB.isHidden = false
                        }
                        else {
                            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "\(TableArr[0]["Response"]!)", Interval: 2)
                            
                            if self.PersonalRidesArr.count == 0 {
                                self.PersonalTB.isHidden = true
                            }
                        }
                    }
                    else {
                        UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                        if self.PersonalRidesArr.count == 0 {
                            self.PersonalTB.isHidden = true
                        }
                    }
                }
                else {
                    UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
                    if self.PersonalRidesArr.count == 0 {
                        self.PersonalTB.isHidden = true
                    }
                }
            })
            
        }
        else {
            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Constants.NetErrorMsg, Interval: 2)
            if self.PersonalRidesArr.count == 0 {
                self.PersonalTB.isHidden = true
            }
        }
    }
    
    var PersonalRidesArr = [PersonalRides]()
    
    func ParseData(DataArr:[[String:AnyObject]]) {
        PersonalRidesArr.removeAll()
        for Obj in DataArr {
            PersonalRidesArr.append(AddDataObj(Obj: Obj))
            print(PersonalRidesArr[0].PaymentType)
        }
        PersonalTB.reloadData()
    }
    
    func AddDataObj(Obj:[String:AnyObject]) -> PersonalRides {
        var PersonalObj = PersonalRides()
        
        PersonalObj.Callerid = "\(Obj["Callerid"]!)"
        
        PersonalObj.Status = "\(Obj["Status"]!)"
        
        PersonalObj.JobType = "\(Obj["JobType"]!)"
        PersonalObj.JobStatus = "\(Obj["JobStatus"]!)"
        
        PersonalObj.Tariff = "\(Obj["Tariff"]!)"
        
        PersonalObj.TripType = "\(Obj["TripType"]!)"
        PersonalObj.VehicleCategory = "\(Obj["VehicleCategory"]!)"
        PersonalObj.VehicleModel = "\(Obj["VehicleModel"]!)"
        
        PersonalObj.JobCreationTime = "\(Obj["JobCreationTime"]!)"
        PersonalObj.RequestedPickUpTime = "\(Obj["RequestedPickUpTime"]!)"
        PersonalObj.PickupDatetime = "\(Obj["PickupDatetime"]!)"
        
        PersonalObj.VehicleLat = "\(Obj["VehicleLat"]!)"
        PersonalObj.VehicleLon = "\(Obj["VehicleLon"]!)"
        
        PersonalObj.Pickuplon = "\(Obj["Pickuplon"]!)"
        PersonalObj.Pickuplat = "\(Obj["Pickuplat"]!)"
        PersonalObj.PickupAddress = "\(Obj["PickupAddress"]!)".trimmingCharacters(in: .newlines)
        
        PersonalObj.DropOfflat = "\(Obj["DropOfflat"]!)"
        PersonalObj.DropOfflon = "\(Obj["DropOfflon"]!)"
        PersonalObj.DropAddress = "\(Obj["DropAddress"]!)".trimmingCharacters(in: .newlines)
        
        PersonalObj.Jobno = "\(Obj["Jobno"]!)"
        
        PersonalObj.ComponentA = "\(Obj["ComponentA"]!)"
        PersonalObj.ComponentB = "\(Obj["ComponentB"]!)"
        PersonalObj.ComponentC = "\(Obj["ComponentC"]!)"
        
        PersonalObj.TotalTripAmount = "\(Obj["TotalTripAmount"]!)"
        
        PersonalObj.CustomerRating = "\(Obj["CustomerRating"]!)"
        
        PersonalObj.PaymentType = "\(Obj["PaymentType"]!)"
        PersonalObj.PaymentStatus = "\(Obj["PaymentStatus"]!)"
        
        PersonalObj.VehicleNo = "\(Obj["VehicleNo"]!)"
        PersonalObj.TripMessage = "\(Obj["TripMessage"]!)"
        PersonalObj.JobMessage = "\(Obj["JobMessage"]!)"

        return PersonalObj
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    
    var CancelBookingText = UITextField()
    var CancelSelectPicker = UIPickerView()
    
    var CancelReasonsArr = [String]()
    
    var CancelBookingSelectedIndex = 0
    
    func CancelBookingBtnPressed() {
        // action for cancel booking
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            let CancelReasonsDict = ["EmpId":"\(DriveBookingResponce.EmpId!)",
                "VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveCancellationReasons, parameterDict: CancelReasonsDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (CancelReasonsDict, responceCode, success) in
                self.view.StopLoading()
                if success {
                    if let Table = ((CancelReasonsDict as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                        
                        if "\(Table["Status"]!)" == "true" && Table.keys.contains(where: {$0 == "Reasons"}) && "\(Table["Reasons"]!)" != ""  {
                            let Reasons = "\(Table["Reasons"]!)".components(separatedBy: "|")
                            self.CancelReasonsArr.removeAll()
                            for i in 0..<Reasons.count-1 {
                                self.CancelReasonsArr.append(Reasons[i])
                            }
                            self.CancelBookingText.becomeFirstResponder()
                            self.CancelSelectPicker.reloadAllComponents()
                        }
                        else {
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                        }
                        
                    }
                    else {
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                    }
                }
                else {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                }
            })
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.NetErrorMsg, Interval: 2)
        }
    }
    
    func CancelBookingHiddenTxt() {
        
        CancelBookingText.frame = CGRect.init(x: 1000, y: 1000, width: 10, height: 10)
        self.view.addSubview(CancelBookingText)
        CancelSelectPicker.dataSource = self
        CancelSelectPicker.delegate = self
        
        let Toolbar = UIToolbar()
        Toolbar.barStyle = .default
        Toolbar.isTranslucent = true
        Toolbar.tintColor = UIColor.blue
        Toolbar.sizeToFit()
        let DoneItem = UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(cancelBookingPickDoneAction))
        let FlexiItem = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let TitleItem = UIBarButtonItem.init(title: "Select Reason to Cancel", style: .done, target: nil, action: nil)
        let FlexiItem2 = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let CancelItem = UIBarButtonItem.init(title: "Cancel", style: .done, target: self, action: #selector(cancelBookingPickCancelAction))
        Toolbar.setItems([CancelItem,FlexiItem,TitleItem,FlexiItem2,DoneItem], animated: true)
        Toolbar.isUserInteractionEnabled = true
        CancelBookingText.inputView = CancelSelectPicker;
        CancelBookingText.inputAccessoryView = Toolbar;
    }
    
    var CancelIndex = 0
    
    func cancelBookingPickDoneAction() {
        let ReasonSelected = CancelReasonsArr[CancelBookingSelectedIndex]
        CancelBookingText.resignFirstResponder()
        let perObj = PersonalRidesArr[CancelIndex]
        CancelTrip(Reason: ReasonSelected, JobNO: perObj.Jobno!)
    }
    
    func CancelTrip(Reason:String, JobNO:String) {
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            let CancelRequestDict = ["JobNo":"\(JobNO)","JobType":"Advance","CancelReason":"\(Reason)","EmpId":"\(DriveBookingResponce.EmpId!)","VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveCancelBooking, parameterDict: CancelRequestDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (CancelDict, responceCode, success) in
                self.view.StopLoading()
                if success {
                    if let Table = ((CancelDict as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                        
                        if "\(Table["Status"]!)" == "true" {
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(Table["Response"]!)", Interval: 2)
                            
                            self.GetPersonRides()
                        }
                        else {
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(Table["Response"]!)", Interval: 2)
                        }
                    }
                }
                else {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                }
            })
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.NetErrorMsg, Interval: 2)
        }
    }
    
    
    func cancelBookingPickCancelAction() {
        CancelBookingText.resignFirstResponder()
    }
    
    // MARK: - }
    
    // MARK: - picker {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return CancelReasonsArr.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return "\(CancelReasonsArr[row])"
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        CancelBookingSelectedIndex = row
    }
    
    // MARK: - }
    
    
    // MARK: - Email Item {
    @IBOutlet var EmailView: UIView!
    @IBOutlet var EmailTxt: UITextField!
    
    var SelectedJobId = ""
    
    var ActualY:CGFloat = 0
    
    func EmailViewMakeWith() {
        
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        
        BackView.center = (window?.center)!
        
        window?.addSubview(BackView)
        self.EmailView.center = BackView.center
        
        self.EmailTxt.text = DriveBookingResponce.Email!
        
        BackView.addSubview(self.EmailView!)
        
        ActualY = self.EmailView.frame.origin.y
        
        self.EmailView.alpha = 0
        UIView.animate(withDuration: 0.5) {
            self.EmailView.alpha = 1
        }
    }
    
    @IBAction func SendEmailBtnPressed(_ sender:UIButton) {
        // email validate
        self.EmailView.endEditing(true)
        
        if (self.EmailTxt.text?.isEmpty)! {
            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Please enter email Address", Interval: 3)
        }
        else if !(self.EmailTxt.text?.isValidEmail())! {
            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Invalid email Address", Interval: 3)
        }
        else {
            if (Reachability()?.isReachable)! {
                
                UIApplication.shared.keyWindow?.StartLoading()
                
                let Dict = ["EmpId":"\(DriveBookingResponce.EmpId!)","EmailId":"\(self.EmailTxt.text!)","BookingId":SelectedJobId,"VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
                WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveRequestInvoice, parameterDict: Dict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (ResponceDict, responceCode, success) in
                    UIApplication.shared.keyWindow?.StopLoading()
                    if success {
                        if let Table = ((ResponceDict as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                            print(Table)
                            if "\(Table["Status"]!)" == "true" || "\(Table["Status"]!)" == "1" {
                                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(Table["Response"]!)", Interval: 2)
                                self.CloseEmailView()
                            }
                            else {
                                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(Table["Response"]!)", Interval: 3)
                            }
                        }
                        else {
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                        }
                    }
                    else {
                        UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 3)
                    }
                })
            }
            else {
                UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Constants.NetErrorMsg, Interval: 3)
            }
        }
        
    }
    
    @IBAction func CancelEmailBtnPressed(_ sender:UIButton) {
        CloseEmailView()
    }
    
    func CloseEmailView() {
        UIView.animate(withDuration: 0.3, animations: {
            self.EmailView.alpha = 0
        }) { (yes) in
            if yes {
                self.EmailView.alpha = 1
                self.EmailView.superview?.removeFromSuperview()
            }
        }
    }
    
    // MARK: - }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardHide(_:)), name: .UIKeyboardWillHide, object: nil)
        
        
            GetPersonRides()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    //MARK: - Keyboard show
    
    
    
    func keyboardShow(_ notification : NSNotification){
        
        if EmailTxt.isFirstResponder {
            
            let info = notification.userInfo
            let keyboardframe = (info![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size
            var frame = CGRect.init()
            
            frame = EmailTxt.frame
            
            frame.origin.y += EmailView.frame.origin.y
            
            var actualframe = EmailView.superview?.frame
            actualframe?.size.height -= keyboardframe.height
            actualframe?.size.height -= (frame.size.height)
            
            if !(actualframe?.contains((frame.origin)))! {
                let yfinal = (frame.origin.y) - (actualframe?.size.height)!
                
                UIView.animate(withDuration: 0.3, animations: { () -> Void in
                    self.EmailView.frame.origin.y -= yfinal
                })
                
            }
        }
        
    }
    // MARK: - keyboard hide
    
    func keyboardHide(_ notification : NSNotification)
    {
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.EmailView.frame.origin.y = self.ActualY
        })
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    
    // MARK: - }
}


extension MyTripsVC:UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return PersonalRidesArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PersonalRidesCell", for: indexPath) as! PersonalRidesCell
        
        let perObj = PersonalRidesArr[indexPath.row]
        
        if indexPath.row == 6 {
            print(perObj.Jobno!,perObj.TripType!,perObj.JobStatus!)
        }
        
        if perObj.JobType! == "Current" {
            cell.AdvanceView.isHidden = true
            cell.RunningView.isHidden = false
            ConfigCurrentCell(cell: cell, perObj: perObj)
        }
        else {
            cell.AdvanceView.isHidden = false
            cell.RunningView.isHidden = true
            ConfigAdvanceCell(cell: cell, perObj: perObj)
        }
       
        cell.JobnoLbl.text = perObj.Jobno!
        
        cell.FareLbl.text = perObj.ComponentA!
        cell.ExtrasLbl.text = perObj.ComponentB!
        cell.DiscountsLbl.text = perObj.ComponentC!
        
        cell.TotalLbl.text = perObj.TotalTripAmount!
        
        cell.RatingView.rating = Float(perObj.CustomerRating!)!
        
        
        let JobStatus = Int("\(perObj.JobStatus!)")
        
        
        
        if (JobStatus == 0 || JobStatus == 13) {                                                                //Vehicel not assigned , Trip created
            cell.mailButton.isSelected = false
            HideStatusLabels(cell: cell, IsMainHidden: false, perObj: perObj)
            ChangeColor(cell: cell, IsToRed: false)
            CancelButtonVisible(cell: cell, IsVisible: true)
            ButtonActions(cell: cell, IndexRow: indexPath.row, IsCancelNeeded: true)
        } else if (JobStatus == 11) {                                                                           //Trip Cancelled
            cell.mailButton.isSelected = false
            HideStatusLabels(cell: cell, IsMainHidden: false, perObj: perObj)
            ChangeColor(cell: cell, IsToRed: true)
            CancelButtonVisible(cell: cell, IsVisible: false)
            ButtonActions(cell: cell, IndexRow: indexPath.row, IsCancelNeeded: false)
        } else if (JobStatus == 1 || JobStatus == 3 || JobStatus == 7 || JobStatus == 14 || JobStatus == 6) {   //Vehicle assigned , Track vehicle,No SOS
            cell.mailButton.isSelected = false
            HideStatusLabels(cell: cell, IsMainHidden: true, perObj: perObj)
            ChangeColor(cell: cell, IsToRed: false)
            CancelButtonVisible(cell: cell, IsVisible: true)
            ButtonActions(cell: cell, IndexRow: indexPath.row, IsCancelNeeded: true)
        } else if (JobStatus == 5) {                                                                            //On Trip,SOS enable
            cell.mailButton.isSelected = false
            HideStatusLabels(cell: cell, IsMainHidden: true, perObj: perObj)
            ChangeColor(cell: cell, IsToRed: false)
            CancelButtonVisible(cell: cell, IsVisible: false)
            ButtonActions(cell: cell, IndexRow: indexPath.row, IsCancelNeeded: false)
        } else if (JobStatus == 4 || JobStatus == 6 || JobStatus == 9 || JobStatus == 12) {                     //Trip Completed
            cell.mailButton.isSelected = true
            HideStatusLabels(cell: cell, IsMainHidden: true, perObj: perObj)
            ChangeColor(cell: cell, IsToRed: false)
            CancelButtonVisible(cell: cell, IsVisible: false)
            ButtonActions(cell: cell, IndexRow: indexPath.row, IsCancelNeeded: false)
        } else {                                                                                                //Vehicel not assigned , Trip created
            cell.mailButton.isSelected = false
            HideStatusLabels(cell: cell, IsMainHidden: false, perObj: perObj)
            ChangeColor(cell: cell, IsToRed: false)
            CancelButtonVisible(cell: cell, IsVisible: true)
            ButtonActions(cell: cell, IndexRow: indexPath.row, IsCancelNeeded: true)
        }
        
        cell.selectionStyle = .none
        return cell
    }
    
    func CancelButtonVisible(cell:PersonalRidesCell, IsVisible:Bool) {
        cell.CancelBookingBtn.isHidden = !IsVisible
    }
    
    func HideStatusLabels(cell:PersonalRidesCell,IsMainHidden:Bool,perObj:PersonalRides
        ) {
        cell.MainStatusLbl.isHidden = IsMainHidden
        cell.VehicleNoLbl.isHidden = !IsMainHidden
        cell.VehicleStatusLbl.isHidden = !IsMainHidden
        
        
        if IsMainHidden {
            cell.VehicleNoLbl.text = "\(perObj.VehicleNo!)"
            cell.VehicleStatusLbl.text = "\(perObj.JobMessage!)"
        }
        else {
            cell.MainStatusLbl.text = "\(perObj.JobMessage!)"
        }
        
    }
    
    func ChangeColor(cell:PersonalRidesCell,IsToRed:Bool) {
        cell.MainStatusLbl.backgroundColor = IsToRed ? UIColor.red : UtilitiesClassSub.color(fromHexString: "#008000")
    }
    
    func ConfigCurrentCell(cell:PersonalRidesCell,perObj:PersonalRides) {
        
        cell.RunningTripTypeLbl.text = perObj.TripType!
        
        let data = DriveBookingResponce.TripType.filter({$0.TripName.caseInsensitiveCompare("Package") == .orderedSame})

        if data.count > 0 {
            cell.RunningTripTypeImage.af_setImage(withURL: URL.init(string: (data.first?.TripImage)!)!, placeholderImage: #imageLiteral(resourceName: "Clock"), filter: nil, progress: nil, progressQueue: DispatchQueue.main, imageTransition: .noTransition, runImageTransitionIfCached: true) { (imageData) in
                
                if (imageData.data != nil) {
                    cell.RunningTripTypeImage.image = UIImage.init(data: imageData.data!)
                }
            }
        }
        
        cell.RunningdateandtimeLabel.text = perObj.PickupDatetime!
        
        cell.RunningdropAddressLabel.text = perObj.DropAddress!
        cell.RunningpickupAddressLabel.text = perObj.PickupAddress!
        
        cell.RunningVehicleCategoryLbl.text = perObj.VehicleCategory!
        

        let Catdata:[CategoryTypeStruct]? = DriveBookingResponce.CategoryType.filter({$0.CategoryName.caseInsensitiveCompare(perObj.VehicleCategory!) == .orderedSame})
        if Catdata == nil || Catdata?.count == 0 {
            cell.RunningVehicleCategoryImage.image = #imageLiteral(resourceName: "RHatchback")
        }else{
            cell.RunningVehicleCategoryImage.ImageLoaderStart()

            cell.RunningVehicleCategoryImage.af_setImage(withURL: URL.init(string: (Catdata?.first?.CategoryImage2)!)!, placeholderImage: #imageLiteral(resourceName: "RHatchback"), filter: nil, progress: nil, progressQueue: DispatchQueue.main, imageTransition: .noTransition, runImageTransitionIfCached: true) { (imageData) in
                cell.RunningVehicleCategoryImage.ImageLoaderStop()
                if (imageData.data != nil) {
                    cell.RunningVehicleCategoryImage.image = UIImage.init(data: imageData.data!)
                }
            }
        }
        if (perObj.JobStatus! == "4" || perObj.JobStatus! == "6" || perObj.JobStatus! == "9" || perObj.JobStatus! == "12"){
       
            cell.RunningTotalTripAmountLabel.text = perObj.TotalTripAmount! + " Paid by \(perObj.PaymentType!)"
        }else{
            cell.RunningTotalTripAmountLabel.text = perObj.TotalTripAmount!
        }
    }
    
    func ConfigAdvanceCell(cell:PersonalRidesCell,perObj:PersonalRides) {
        
        cell.AdvanceTripTypeLbl.text = perObj.TripType!
        
        let data = DriveBookingResponce.TripType.filter({$0.TripName.caseInsensitiveCompare(perObj.TripType!) == .orderedSame})
        
        if data.count > 0 {
            cell.AdvanceTripTypeImage.af_setImage(withURL: URL.init(string: (data.first?.TripImage)!)!, placeholderImage: #imageLiteral(resourceName: "Clock"), filter: nil, progress: nil, progressQueue: DispatchQueue.main, imageTransition: .noTransition, runImageTransitionIfCached: true) { (imageData) in
                
                if (imageData.data != nil) {
                    cell.AdvanceTripTypeImage.image = UIImage.init(data: imageData.data!)
                }
            }
        }
        else {
            cell.AdvanceTripTypeImage.image = #imageLiteral(resourceName: "Clock")
        }
        
        cell.AdvancedateandtimeLabel.text = perObj.PickupDatetime!
        
        cell.AdvancepickupAddressLabel.text = perObj.PickupAddress!
        
        cell.AdvanceVehicleCategoryLbl.text = perObj.VehicleCategory!
        
        
        let Catdata:[CategoryTypeStruct]? = DriveBookingResponce.CategoryType.filter({$0.CategoryName.caseInsensitiveCompare(perObj.VehicleCategory!) == .orderedSame})
        if Catdata == nil || Catdata?.count == 0 {
            cell.AdvanceVehicleCategoryImage.image = #imageLiteral(resourceName: "RHatchback")
        }else{
            cell.AdvanceVehicleCategoryImage.ImageLoaderStart()

            cell.AdvanceVehicleCategoryImage.af_setImage(withURL: URL.init(string: (Catdata?.first?.CategoryImage2)!)!, placeholderImage: #imageLiteral(resourceName: "RHatchback"), filter: nil, progress: nil, progressQueue: DispatchQueue.main, imageTransition: .noTransition, runImageTransitionIfCached: true) { (imageData) in
                cell.AdvanceVehicleCategoryImage.ImageLoaderStop()
                if (imageData.data != nil) {
                    cell.AdvanceVehicleCategoryImage.image = UIImage.init(data: imageData.data!)
                }
            }
        }        
        cell.AdvanceTotalTripAmountLabel.text = perObj.TotalTripAmount!
    }
    
    func ButtonActions(cell:PersonalRidesCell,IndexRow:Int, IsCancelNeeded:Bool) {
        
        if IsCancelNeeded {
            cell.CancelBookingBtn.addTarget(self, action: #selector(CancelTripActiom(_:)), for: .touchUpInside)
            cell.CancelBookingBtn.tag = IndexRow
        }
        cell.faqButton.addTarget(self, action: #selector(InfoTripActiom(_:)), for: .touchUpInside)
        cell.mailButton.addTarget(self, action: #selector(EmailTripActiom(_:)), for: .touchUpInside)
        
        cell.faqButton.tag = IndexRow
        cell.mailButton.tag = IndexRow
        
    }
    
    func CancelTripActiom(_ sender:UIButton) {
        CancelIndex = sender.tag
        CancelBookingBtnPressed()
    }
    
    func EmailTripActiom(_ sender:UIButton) {
        
        let perObj = PersonalRidesArr[sender.tag]
        let JobStatus = Int("\(perObj.JobStatus!)")
        if (JobStatus == 4 || JobStatus == 6 || JobStatus == 9 || JobStatus == 12) {                     //Trip Completed
            print("send invoice")
            
            SelectedJobId = perObj.Jobno!
            EmailViewMakeWith()
        }
        
    }
    
    func InfoTripActiom(_ sender:UIButton) {
        self.view.ShowBlackTostWithText(message: "FAQ", Interval: 3)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 300
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let perObj = PersonalRidesArr[indexPath.row]
        let Track = self.storyboard?.instantiateViewController(withIdentifier: "DriveTrackVC") as! DriveTrackVC
        Track.TrackDetails = perObj
        self.navigationController?.pushViewController(Track, animated: true)
    }
    
}


class PersonalRidesCell: UITableViewCell {
    
    // MARK: - Right Part Advance
    
    @IBOutlet weak var AdvanceView: UIView!
    
    @IBOutlet weak var AdvancedateandtimeLabel: UILabel!
    
    @IBOutlet weak var AdvanceTripTypeImage: UIImageView!
    @IBOutlet weak var AdvanceTripTypeLbl: UILabel!
    
    @IBOutlet weak var AdvanceVehicleCategoryImage: UIImageView!
    @IBOutlet weak var AdvanceVehicleCategoryLbl: UILabel!
    
    @IBOutlet weak var AdvancepickupAddressLabel: UILabel!
    
    @IBOutlet weak var AdvanceTotalTripAmountLabel: UILabel!
    
    // MARK: - Right Part Running
    
    @IBOutlet weak var RunningView: UIView!
    
    @IBOutlet weak var RunningdateandtimeLabel: UILabel!
    
    @IBOutlet weak var RunningTripTypeImage: UIImageView!
    @IBOutlet weak var RunningTripTypeLbl: UILabel!
    
    @IBOutlet weak var RunningVehicleCategoryImage: UIImageView!
    @IBOutlet weak var RunningVehicleCategoryLbl: UILabel!
    
    @IBOutlet weak var RunningpickupAddressLabel: UILabel!
    @IBOutlet weak var RunningdropAddressLabel: UILabel!
    
    @IBOutlet weak var RunningTotalTripAmountLabel: UILabel!
    
    // MARK: - Right Part
    
    @IBOutlet weak var JobnoLbl: UILabel!
    
    @IBOutlet weak var FareLbl: UILabel!
    @IBOutlet weak var ExtrasLbl: UILabel!
    @IBOutlet weak var DiscountsLbl: UILabel!
    
    @IBOutlet weak var TotalLbl: UILabel!
    
    @IBOutlet weak var RatingView: FloatRatingView!
    
    @IBOutlet weak var CancelBookingBtn: UIButton!
    @IBOutlet weak var mailButton: UIButton!
    @IBOutlet weak var faqButton: UIButton!
    
    
    // MARK: - Status Lbls
    
    @IBOutlet weak var MainStatusLbl: UILabel!
    @IBOutlet weak var VehicleNoLbl: UILabel!
    @IBOutlet weak var VehicleStatusLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
}

struct PersonalRides {
    
    var Callerid: String!               // is a mobile number
    
    var Status: String!
    
    var JobType: String!                // for show hide for advance and Current rides
    var JobStatus: String!
    
    var Tariff: String!                 // no use in MyTripsVC
    
    var TripType: String!               // show as TripType in cell
    var VehicleCategory: String!        // show as VehicleCategory in cell
    var VehicleModel: String!
    
    var JobCreationTime: String!
    var RequestedPickUpTime: String!
    var PickupDatetime: String!
    
    var VehicleLat: String!
    var VehicleLon: String!
    
    var Pickuplon: String!
    var Pickuplat: String!
    var PickupAddress: String!          // For pickup address
    
    var DropOfflat: String!
    var DropOfflon: String!
    var DropAddress: String!            // For Drop address
    
    var Jobno: String!
    
    var ComponentA: String!             // Fare - for now may be changable
    var ComponentB: String!             // Extra - for now may be changable
    var ComponentC: String!             // Discount - for now may be changable
    
    var TotalTripAmount: String!        // This is total trip amount
    
    var CustomerRating: String!         // This was the customer rating
    
    var PaymentType: String!
    var PaymentStatus: String!
    
    var VehicleNo: String!          // for vehicle no in status
    var TripMessage: String!        // status message
    var JobMessage: String!         // status message
}
