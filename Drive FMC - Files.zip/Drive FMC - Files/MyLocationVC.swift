//
//  MyLocationVC.swift
//  DriveFindMyCab
//
//  Created by Admin on 01/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit
import GoogleMaps
class MyLocationVC: UIViewController {

    @IBOutlet var MapView : GMSMapView!
    @IBOutlet var AddressTxt : UILabel!
    
    var LocationManager = CLLocationManager()
    
    var LoginResponce:LoginResponce!
    var LoginDetails:LoginDetails!
    
    
    @IBOutlet weak var myLocationTitleBtn: UIButton!
    @IBOutlet weak var locationsContainerView: UIView!
    
   
    @IBAction func myLocationTitleBtnTapped(_ sender: UIButton) {
        if self.locationsContainerView.isHidden{
            self.locationsContainerView.isHidden = false
        }else{
            self.locationsContainerView.isHidden = true
        }
        
    }
    
    @IBAction func myLocation1BtnTapped(_ sender: UIButton) {
        self.locationsContainerView.isHidden = true
        self.myLocationTitleBtn.setTitle("PickupLocation1", for: .normal)
        FetchMyLocationNew(pickupLocationType: "1")
    }
    
    @IBAction func myLocation2BtnTapped(_ sender: UIButton) {
        self.locationsContainerView.isHidden = true
        self.myLocationTitleBtn.setTitle("PickupLocation2", for: .normal)
        FetchMyLocationNew(pickupLocationType: "2")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.locationsContainerView.isHidden = true

        LoginDetails = FetchLoginDetails()
        LoginResponce = FetchLoginResponce()
        
        LocationManager.requestWhenInUseAuthorization()
        LocationManager.delegate = self;
        // Do any additional setup after loading the view.
        MapView.isMyLocationEnabled = true
        
//        FetchMyLocation()
        FetchMyLocationNew(pickupLocationType: "1")
    }
    
    /*
    func FetchMyLocation() {
        
        if (Reachability()?.isReachable)! {
            
            UIApplication.shared.keyWindow?.StartLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.FetchAddress, parameterDict: ["UserId":LoginDetails.UserID!], completion: { (Reponcedict, success) in
                
                UIApplication.shared.keyWindow?.StopLoading()

                if success {
//                    {"Status":"True","lat":"12.939978048392405","lon":"77.6258174702525","address":"1st Main Road, Venkappa Garden, EjipuraBengaluru, Karnataka 560095"}
                    
                    if let Dict = Reponcedict {
                        
                        if "\(Dict["Status"]!)".toBool()! {
                            let Lat = Double("\(Dict["lat"]!)")!
                            let Lon = Double("\(Dict["lon"]!)")!

                            self.LoadAddress(Lat: Lat, Lon: Lon)
                            self.Marker(with: CLLocationCoordinate2DMake(Lat, Lon))
                        }
                        else {
                            UtilitiesClass.Alert(Title: "Alert!!", Message: "Do you want to set Pickup Location", Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "NO"),UtilitiesClass.AlertActionWithSelector(Title: "YES", Selector: #selector(self.GoToChangeAddress), Controller: self)], Controller: self)
                        }
                        
                    }
                    else {
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                    }
                    
                }
                else {
//                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Address not set for employee...", Interval: 3)
                }
                
            })
            
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "No Internet Connection", Interval: 3)
        }
        
    } */
    
    
    func FetchMyLocationNew(pickupLocationType : String) {
        
        if (Reachability()?.isReachable)! {
            
            UIApplication.shared.keyWindow?.StartLoading()
            
            WebService().callAutoAPI(Suffix: WebServicesUrl.FetchAddress, parameterDict: ["UserId":LoginDetails.UserID!,"PickuplocationType":pickupLocationType], completion: { (Reponcedict, success) in
                
                UIApplication.shared.keyWindow?.StopLoading()
                
                if success {
                    //                    {"Status":"True","lat":"12.939978048392405","lon":"77.6258174702525","address":"1st Main Road, Venkappa Garden, EjipuraBengaluru, Karnataka 560095"}
                    
//                    {"Status":"True","lat":"12.9400162795261","lon":"77.6258349046111","address":"Karunamoyee Bus Terminal, Central Park, Sector III, Salt Lake City, Kolkata, West Bengal 700064, India"}
                    
                    if let Dict = Reponcedict {
                        
                        if "\(Dict["Status"]!)".toBool()! {
                            let Lat = Double("\(Dict["lat"]!)")!
                            let Lon = Double("\(Dict["lon"]!)")!
                            
                            self.LoadAddress(Lat: Lat, Lon: Lon)
                            self.Marker(with: CLLocationCoordinate2DMake(Lat, Lon))
                        }
                        else {
                            UtilitiesClass.Alert(Title: "Alert!!", Message: "Do you want to set Pickup Location", Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "NO"),UtilitiesClass.AlertActionWithSelector(Title: "YES", Selector: #selector(self.GoToChangeAddress), Controller: self)], Controller: self)
                        }
                        
                    }
                    else {
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                    }
                    
                }
                else {
                    //                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Address not set for employee...", Interval: 3)
                }
                
            })
            
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "No Internet Connection", Interval: 3)
        }
        
    }
    
    
    
    func GoToChangeAddress() {
        let ChangeAddress = self.storyboard?.instantiateViewController(withIdentifier: "UpdateLocationVC") as! UpdateLocationVC
        self.navigationController?.pushViewController(ChangeAddress, animated: true)
    }
    
    func LoadAddress(Lat:Double,Lon:Double) {
        
        fetchAddressFromLatLon(Lati: Lat, Long: Lon, { (Address, error) in
            if error == nil {
                
                var AddressFilter = ""
                
                for AddObj in Address! {
                    AddressFilter.append("\(AddObj)" + ("\(AddObj)".isEmpty ? "" : ", "))
                }
                
                var FilterAdd = ""
                if AddressFilter != "" && AddressFilter.characters.count > 2 {
                    FilterAdd = AddressFilter.substring(to: AddressFilter.index(AddressFilter.endIndex, offsetBy: -2))
                }
                else {
                    FilterAdd = AddressFilter
                }
                
                self.AddressTxt.text = FilterAdd
            }
            else {
                print(error!)
                self.AddressTxt.text = ""
            }
        })
    }
    
    
    var PinMarker: GMSMarker?
    
    func Marker(with Corordinates:CLLocationCoordinate2D?) {
        
        if PinMarker == nil {
            PinMarker = GMSMarker.init(position: Corordinates!)
            PinMarker?.icon = UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "markernew"), to: CGSize.init(width: 22, height: 22))
            PinMarker?.isDraggable = true
            PinMarker?.groundAnchor = CGPoint(x: 0.5, y: 1)
            PinMarker?.appearAnimation = GMSMarkerAnimation.pop
            PinMarker?.map = MapView
            
        }
        else {
            PinMarker?.position = Corordinates!
        }
        
        let Position = GMSCameraPosition.camera(withTarget: (PinMarker?.position)!, zoom: 15)
        MapView.animate(to: Position)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func ChangeAddressBtnAction(_ sender:UIButton) {
        GoToChangeAddress()
    }
    
    @IBAction func MyLocationBtnAction(_ sender:UIButton) {
        
        if (LocationManager.location != nil) {
            let Position = GMSCameraPosition.camera(withTarget: (LocationManager.location?.coordinate)!, zoom: 15)
            MapView.animate(to: Position)
        }
    }
}

extension MyLocationVC:CLLocationManagerDelegate , GMSMapViewDelegate {
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("LocationError:===:", error.localizedDescription)
    }
    
}
