//
//  LoginVC22.swift
//  DriveFindMyCab
//
//  Created by SunTelematics on 02/05/18.
//  Copyright © 2018 Suntelematics. All rights reserved.
//

import UIKit
import OneSignal
import FirebaseInstanceID

class LoginVC22: UIViewController {

    @IBOutlet var UserIDTxt : UITextField!
    @IBOutlet var PasswordTxt : UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func loginBtnTapped(_ sender: UIButton) {
        if UtilitiesClassSub.removeLeadingandTralingSpace(UserIDTxt.text!).count == 0 {
            UtilitiesClass.Alert(Title: "Alert!", Message: "UserId should not be empty", Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
        }
        else if UtilitiesClassSub.removeLeadingandTralingSpace(PasswordTxt.text!).count == 0 {
            UtilitiesClass.Alert(Title: "Alert!", Message: "Password should not be empty", Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
        }
        else {
            
            if (Reachability()?.isReachable)! {
                self.view.StartLoading()
                
//                var OneSignalID = ""
//                let State = OneSignal.getPermissionSubscriptionState()
//                if State?.permissionStatus.status == .authorized {
//                    if State?.subscriptionStatus.userId != nil {
//                        OneSignalID = "\((State?.subscriptionStatus.userId!)!)"
//                        print("OnesignalID::::",OneSignalID)
//                    }
//                }
//                
//                let RequestDict = ["EmpCode":UserIDTxt.text!,"EmpPassword":PasswordTxt.text!,"DeviceType":UIDevice.current.systemName,"DeviceIMEI":UIDevice.current.identifierForVendor!.uuidString,"DeviceToken":"\(OneSignalID)"]
                
                
                
                let fcmDeviceToken = InstanceID.instanceID().token()
                print("FCM token: \(fcmDeviceToken ?? "")")
                let RequestDict : [String:String] = ["EmpCode":UserIDTxt.text!,"EmpPassword":PasswordTxt.text!,"DeviceType":UIDevice.current.systemName,"DeviceIMEI":UIDevice.current.identifierForVendor!.uuidString,"DeviceToken":fcmDeviceToken!]
                
                WebService().callAutoAPI(Suffix: WebServicesUrl.LoginApi, parameterDict: RequestDict, completion: { (dataDict, success) in
                    
                    self.view.StopLoading()
                    
                    if success {
                        // handel of data
                        if let Dict = dataDict {
                            let Arr = Dict["data"] as! [[String:AnyObject]]
                            let ResponceData = Arr[0]
                            if ResponceData.keys.contains("Response") {
                                UtilitiesClass.Alert(Title: "Alert!", Message: ResponceData["Response"] as! NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                            }
                            else {
                                SaveLoginDetails(LoginDetailsdict: RequestDict)
                                SaveLoginResponce(Responcedict: ResponceData)
                                
                                let lgCtrl = self.storyboard?.instantiateViewController(withIdentifier: "LGSideMenuControllerSBID22")
                                self.present(lgCtrl!, animated: true, completion: nil)
                            }
                        }
                        else {
                            UtilitiesClass.Alert(Title: "Alert!", Message: Constants.InternalError as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                        }
                    }
                    else {
                        UtilitiesClass.Alert(Title: "Alert!", Message: Constants.InternalError as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                })
                
            }
            else {
                UtilitiesClass.Alert(Title: "Alert!", Message: Constants.NetErrorMsg as NSString, Actions: [UtilitiesClass.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            }
            
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension LoginVC22:UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
}
