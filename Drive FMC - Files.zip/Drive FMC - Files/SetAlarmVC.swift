//
//  SetAlarmVC.swift
//  DriveFindMyCab
//
//  Created by Admin on 01/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit

class SetAlarmVC: UIViewController {

    @IBOutlet var ClockViewObj:ClockView!
    @IBOutlet var AlaramTB:UITableView!
    
    @IBOutlet var HintView:UIView!
    @IBOutlet var HintCheck:UIButton!

    @IBAction func HintCheckTapped(_ responder:UITapGestureRecognizer) {
        if HintCheck.isSelected {
            HintCheck.isSelected = false
        }
        else {
            HintCheck.isSelected = true
        }
    }
    
    @IBAction func HintOkAction(_ responder:UIButton) {
        
        UIView.animate(withDuration: 0.3, animations: { 
            self.HintView.alpha = 0.0

        }) { (success) in
            if success {
                self.HintView.alpha = 1.0
                self.HintView.removeFromSuperview()
                
                if self.HintCheck.isSelected {
                    UserDefaults.standard.set(true, forKey: "ISHintDontPermanently")
                    UserDefaults.standard.synchronize()
                }
            }
        }
    }
    
    struct AlarmStruct {
        var ActiveTxt:Bool?
        var Txtval:String!
        var Title:String!
        var SwitchState:Bool?
        var SelectPrompt:String!
    }
    
    var AlarmArr = [AlarmStruct]()
    
    var LoginResponce:LoginResponce!
    var LoginDetails:LoginDetails!
    
    var ETAPicker = UIPickerView()
    var SHIFTPicker = UIPickerView()

    var ETAPickedItem = ""
    var SHIFTPickedItem = ""
    
    var ETAPickerArr = [String]()
    var SHIFTPickerArr = [String]()

    let Toolbar = UIToolbar()

    func CheckHintViewState() -> Bool {
        
        let Defaults = UserDefaults.standard
        
        if Defaults.bool(forKey: "ISHintDontPermanently") {
            return true
        }
        else {
            return Defaults.bool(forKey: "ISHintDontPermanently")
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if !CheckHintViewState() {
            
            let window = UIApplication.shared.keyWindow
            HintView.frame = (window?.frame)!
            HintView.backgroundColor = UIColor.black.withAlphaComponent(0.9)
            window?.addSubview(HintView)
            HintView.alpha = 0
            UIView.animate(withDuration: 0.3) {
                self.HintView.alpha = 1.0
            }
            
        }
        
        
        LoginDetails = FetchLoginDetails()
        LoginResponce = FetchLoginResponce()

        ETAPickerArr = ["~select~","15","30","45","60"]
        SHIFTPickerArr = ["~select~","1","2","3","4"]
        
        
        Toolbar.barStyle = .default
        Toolbar.isTranslucent = true
        Toolbar.tintColor = UIColor.blue
        Toolbar.sizeToFit()
        
        ETAPicker.delegate = self;
        ETAPicker.dataSource = self;
        
        SHIFTPicker.delegate = self;
        SHIFTPicker.dataSource = self;
        
        let DoneItem = UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(PickDoneBtn))
        let FlexiItem = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let CancelItem = UIBarButtonItem.init(title: "Cancel", style: .done, target: self, action: #selector(PickCancelBtn))
        
        
        Toolbar.setItems([CancelItem,FlexiItem,DoneItem], animated: true)
        Toolbar.isUserInteractionEnabled = true
        
        
        ClockViewObj.start()
        ClockViewObj.setClockBackgroundImage(UIImage.init(named: "clockface.png")?.cgImage)
        ClockViewObj.setMinHand(UIImage.init(named:"clock-min-background.png" )?.cgImage)
        ClockViewObj.setHourHand(UIImage.init(named: "clock-hour-background.png")?.cgImage)
        ClockViewObj.secHandContinuos = true
        
        ClockViewObj.layer.cornerRadius = 50
        ClockViewObj.start()

        for i in 0..<4 {
            switch i {
            case 0:
                
                var Str = AlarmStruct()
                Str.ActiveTxt = true
                Str.Title = "ETA"
                Str.SelectPrompt = "minutes before the ETA of cab"
                
                if LoginResponce.ETAFlag!.toBool()! {
                   Str.SwitchState = true
                }
                else {
                    Str.SwitchState = false
                }
                
                if LoginResponce.ETAAssignNotificationTime! == "0" {
                    Str.Txtval = ""
                    ETAPickedItem = "~select~"
                }
                else {
                    Str.Txtval = "\(LoginResponce.ETAAssignNotificationTime!)"
                    ETAPickedItem = "\(LoginResponce.ETAAssignNotificationTime!)"
                }
                
                AlarmArr.append(Str)
                
                break
            case 1:
                
                var Str = AlarmStruct()
                Str.ActiveTxt = true
                Str.Title = "Shift"
                Str.SelectPrompt = "hours before the shift starting time"
                
                if LoginResponce.ShiftFlag!.toBool()! {
                    Str.SwitchState = true
                }
                else {
                    Str.SwitchState = false
                }
                
                if LoginResponce.ShiftNotificationTime! == "0" {
                    Str.Txtval = ""
                    SHIFTPickedItem = "~select~"
                }
                else {
                    Str.Txtval = "\(LoginResponce.ShiftNotificationTime!)"
                    SHIFTPickedItem = "\(LoginResponce.ShiftNotificationTime!)"
                }
                
                AlarmArr.append(Str)

                break
            case 2:
                
                var Str = AlarmStruct()
                Str.ActiveTxt = false
                Str.Title = "Cab Assignment"
                Str.SelectPrompt = ""
                
                if LoginResponce.CabAssignFlag!.toBool()! {
                    Str.SwitchState = true
                }
                else {
                    Str.SwitchState = false
                }
                
                AlarmArr.append(Str)

                
                break
            case 3:
                
                AlaramTB.reloadData()
                
                break
            default:
                break
            }
        }
        
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    func PickDoneBtn() {
        
        let cell = self.AlaramTB.cellForRow(at: IndexPath.init(row: 0, section: 0)) as! AlarmCell

        if cell.CountTxt.isFirstResponder {
            if ETAPickedItem == "~select~" {
                cell.CountTxt.text = ""
                cell.Switch.setOn(false, animated: true)
            }
            else {
                cell.CountTxt.text = ETAPickedItem
                cell.Switch.setOn(true, animated: true)
            }
        }
        else {
            let cell2 = self.AlaramTB.cellForRow(at: IndexPath.init(row: 1, section: 0)) as! AlarmCell
            if SHIFTPickedItem == "~select~" {
                cell2.CountTxt.text = ""
                cell2.Switch.setOn(false, animated: true)
            }
            else {
                cell2.CountTxt.text = SHIFTPickedItem
                cell2.Switch.setOn(true, animated: true)
            }
        }
        
        self.view.endEditing(true)
    }
    
    func PickCancelBtn() {
        self.view.endEditing(true)
    }
    
    @IBAction func SaveBtnPressed(_ sender:UIButton) {
        
        let ETACell = self.AlaramTB.cellForRow(at: IndexPath.init(row: 0, section: 0)) as! AlarmCell
        let SHIFTCell = self.AlaramTB.cellForRow(at: IndexPath.init(row: 1, section: 0)) as! AlarmCell
        let CABCell = self.AlaramTB.cellForRow(at: IndexPath.init(row: 2, section: 0)) as! AlarmCell

        let LoginId = LoginDetails.UserID!
        var nETAFlag = "0"
        var nShiftFlag = "0"
        var nCabAssignFlag = "0"
        var nShiftNotificationTime = "0"
        var nETAAssignNotificationTime = "0"
        
        if ETACell.Switch.isOn {
            nETAFlag = "1"
            nETAAssignNotificationTime = "\(ETACell.CountTxt.text!)"
        }
        
        if SHIFTCell.Switch.isOn {
            nShiftFlag = "1"
            nShiftNotificationTime = "\(SHIFTCell.CountTxt.text!)"
        }
        
        if CABCell.Switch.isOn {
            nCabAssignFlag = "1"
        }
        
        let Dict = ["LoginId":LoginId,"nETAFlag":nETAFlag,"nShiftFlag":nShiftFlag,"nCabAssignFlag":nCabAssignFlag,"nShiftNotificationTime":nShiftNotificationTime,"nETAAssignNotificationTime":nETAAssignNotificationTime]
        
        if (Reachability()?.isReachable)! {
            LoginResponce.ETAFlag = nETAFlag
            LoginResponce.ShiftFlag = nShiftFlag
            LoginResponce.CabAssignFlag = nCabAssignFlag
            LoginResponce.ShiftNotificationTime = nShiftNotificationTime
            LoginResponce.ETAAssignNotificationTime = nETAAssignNotificationTime

            Callservice(RequestDict: Dict)
        }
        else {
            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Check for Internet Conenction", Interval: 3)
        }
    }
    
    func GoBack() {
        SaveLoginResponceWithStruct(Struct: LoginResponce)
        self.navigationController?.popViewController(animated: true)
    }
    func Callservice(RequestDict:[String:String]) {
        
        UIApplication.shared.keyWindow?.StartLoading()
        
        WebService().callAutoAPI(Suffix: WebServicesUrl.InsEmployeeNotificationSettings, parameterDict: RequestDict, completion: { (dataDict, success) in
            
            UIApplication.shared.keyWindow?.StopLoading()
            
            if success {
                // handel of data
                if let ResponceDict = dataDict {
                    
                    print(ResponceDict)
                    
                    UtilitiesClass.Alert(Title: "Remainder set Successfully", Message: "" as NSString, Actions: [UtilitiesClass.AlertActionWithSelector(Title: "OK", Selector: #selector(self.GoBack), Controller: self)], Controller: self)
                    
                }
                else {
                    UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 3)
                }
            }
            else {
                UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 3)
            }
        })
        
    }
}

extension SetAlarmVC:UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        switch indexPath.row {
        case 0:
            
            let Cell = tableView.dequeueReusableCell(withIdentifier: "AlarmCell", for: indexPath) as! AlarmCell
            
            Cell.Switch.setOn(AlarmArr[0].SwitchState!, animated: true)
            Cell.Title.text = AlarmArr[0].Title!
            Cell.CountTxt.text = AlarmArr[0].Txtval!
            Cell.CountPrompt.text = AlarmArr[0].SelectPrompt!
            
            Cell.CountTxt.isHidden = false
            Cell.CountPrompt.isHidden = false
            
            Cell.CountTxt.tag = 0
            
            Cell.Switch.tag = 0

            Cell.Switch.addTarget(self, action: #selector(self.SwitchONOFF), for: .valueChanged)
            
            
            Cell.CountTxt.inputView = ETAPicker;
            Cell.CountTxt.inputAccessoryView = Toolbar;
            
            return Cell
            
        case 1:
            
            let Cell = tableView.dequeueReusableCell(withIdentifier: "AlarmCell", for: indexPath) as! AlarmCell
            
            Cell.Switch.setOn(AlarmArr[1].SwitchState!, animated: true)
            Cell.Title.text = AlarmArr[1].Title!
            Cell.CountTxt.text = AlarmArr[1].Txtval!
            Cell.CountPrompt.text = AlarmArr[1].SelectPrompt!
            
            Cell.CountTxt.isHidden = false
            Cell.CountPrompt.isHidden = false
            
            Cell.CountTxt.tag = 1
            
            Cell.Switch.tag = 1
            Cell.Switch.addTarget(self, action: #selector(self.SwitchONOFF), for: .valueChanged)

            
            Cell.CountTxt.inputView = SHIFTPicker;
            Cell.CountTxt.inputAccessoryView = Toolbar;
            
            return Cell
            
        case 2:
            
            let Cell = tableView.dequeueReusableCell(withIdentifier: "AlarmCell", for: indexPath) as! AlarmCell
            
            Cell.Switch.setOn(AlarmArr[2].SwitchState!, animated: true)
            Cell.Title.text = AlarmArr[2].Title!

            Cell.CountTxt.isHidden = true
            Cell.CountPrompt.isHidden = true

            Cell.Switch.tag = 2
            Cell.Switch.addTarget(self, action: #selector(self.SwitchONOFF), for: .valueChanged)

            return Cell
            
        default:
            break
        }
        
        return UITableViewCell()
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func SwitchONOFF(_ sender:UISwitch) {
        switch sender.tag {
        case 0:
            
            let cell = self.AlaramTB.cellForRow(at: IndexPath.init(row: 0, section: 0)) as! AlarmCell

            if sender.isOn {
                
                if cell.CountTxt.text! == "" {
                    sender.setOn(false, animated: false)
                    
                    UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Please select ETA time from dropdown", Interval: 3)
                }
            }
            else {
                ETAPickedItem = "~select~"
                cell.CountTxt.text = ""
            }

            break
        case 1:
            
            let cell = self.AlaramTB.cellForRow(at: IndexPath.init(row: 1, section: 0)) as! AlarmCell

            if sender.isOn {
                
                if cell.CountTxt.text! == "" {
                    sender.setOn(false, animated: false)
                    UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Please select SHIFT time from dropdown", Interval: 3)
                }
            }
            else {
                SHIFTPickedItem = "~select~"
                cell.CountTxt.text = ""
            }
            
            break
            
        case 2:
            
            print("CabSwitching")
            
            break
            
        default:
            break
        }
    }
    
}

extension SetAlarmVC:UIPickerViewDelegate,UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == ETAPicker {
            return ETAPickerArr.count
        }
        
        return SHIFTPickerArr.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == ETAPicker {
            return ETAPickerArr[row]
        }
        return SHIFTPickerArr[row]

    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if pickerView == ETAPicker {
            ETAPickedItem = ETAPickerArr[row]
            return
        }
        SHIFTPickedItem = SHIFTPickerArr[row]
    }
}
class AlarmCell:UITableViewCell {
    
    @IBOutlet var Title:UILabel!
    @IBOutlet var Switch:UISwitch!
    @IBOutlet var CountTxt:UITextField!
    @IBOutlet var CountPrompt:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
