//
//  ForgotPassVC.swift
//  DriveBooking
//
//  Created by Raja Bhuma on 17/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit

class ForgotPassVC: UIViewController {

    @IBOutlet weak var mobileLabel: UILabel!
    @IBOutlet weak var mobileTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        mobileLabel.isHidden = true
        
        self.title = "Forgot Password"
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.black
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
        self.navigationItem.leftBarButtonItem = BackBtnItem
        self.perform(#selector(updateTextFields), with: self, afterDelay: 0.1)
    }
    
    @objc func updateTextFields(){
        mobileTextField.BottomLine = UIColor.black
    }
    @objc func BackAction() {
        self.navigationController?.popViewController(animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func submitAction(_ sender: UIButton) {
        
        self.view.endEditing(true)
        
        if mobileTextField.text! == "" {
            Message.shared.Alert(Title: "Alert", Message: "Please Enter Mobile Number to send OTP", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            return
        }
        
        if !(mobileTextField.text?.isValidMobileNumber())! {
            Message.shared.Alert(Title: "Alert", Message: "Please enter valid mobile number", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            return
        }
        
        self.view.StartLoading()
        
        let Cred = FetchDriveCredentials()!
        
        let RegisterDict = [
            "OtpType":"FORGETPASSWORD",
            "EmailId":"0",
            "MobileNo":self.mobileTextField.text!,
            "VendorId":Cred.VendorId!,
            "CorporateId":Cred.CorporateId!,
            "AppCustomerType":Cred.AppCustomerType!
        ]
        
        WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveGetOtp, parameterDict: RegisterDict, securityKey: WebServicesUrl.DummySecurity) { (responce, responceCode, success) in
            
            self.view.StopLoading()
            
            if success {
                let Table = (responce as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
                
                if Table.count > 0 {
                    if "\(Table[0]["Status"]!)".toBool()! {
                        print("\(Table[0]["Otp"]!)")
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(Table[0]["Response"]!)", Interval: 3)
                        let Otp = self.storyboard?.instantiateViewController(withIdentifier: "OtpVerifyVC") as! OtpVerifyVC
                        Otp.RequestDict = ["EmpId":"\(Table[0]["EmpId"]!)","Mobile":self.mobileTextField.text!,"OTP":"\(Table[0]["Otp"]!)","OTPDuration":"\(Table[0]["OTPDuration"]!)"]
                        Otp.IsRegistration = false
                        Otp.isEmailLogin = "\(Table[0]["Response"]!)"
                        self.navigationController?.pushViewController(Otp, animated: true)
                    }
                    else {
                        Message.shared.Alert(Title: "Alert", Message: "\(Table[0]["Response"]!)", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
                else {
                    Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                }
            }
            else {
                if responceCode == .NoInternet {
                    Message.shared.Alert(Title: "Alert", Message: "Check the Internet connection and try again", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                }
                else {
                    Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                }
            }
        }
        
    }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        mobileLabel.isHidden = false
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if (mobileTextField.text?.isEmpty)! {
            mobileLabel.isHidden = true
        }
        else {
            mobileLabel.isHidden = false
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
}
