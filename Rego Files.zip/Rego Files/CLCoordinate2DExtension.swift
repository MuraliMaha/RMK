//
//  CLCoordinate2D.swift
//  DriveBooking
//
//  Created by Raja Bhuma on 12/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit
import GoogleMaps

extension CLLocationCoordinate2D {
    func fetchAddressFromLatLon(Completion:@escaping (GMSAddress,Bool) -> Void) {
        GMSGeocoder().reverseGeocodeCoordinate(self) { (ReverseGeoCodeResponce, error) in
            if error == nil {
                Completion((ReverseGeoCodeResponce?.results()?.last)!,true)
            }
            else {
                Completion(GMSAddress(),false)
            }
        }
    }
}
