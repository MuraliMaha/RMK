//
//  GStore.swift
//  GDirections
//
//  Created by Raja Bhuma on 16/09/17.
//  Copyright © 2017 MyFriends. All rights reserved.
//

import Foundation

public class GStore {
    
    static let Defaults: UserDefaults = UserDefaults.init(suiteName: "com.GDirections.Key")!
    
    public class func setApiKey(Key:String) {
        GStore.Defaults.set(Key as Any, forKey: GConstants.Store_Key)
        GStore.Defaults.synchronize()
    }
    
    
    class func getKey() -> GStoreData {
        
        guard let Key = GStore.Defaults.value(forKey: GConstants.Store_Key) else {
            return .failure(.null_key(error: "Use GStore.setApiKey(Key:<Google Api Key>) to initiate GDirections"))
        }
        
        return .success(Key as! String)
    }
    
}

struct GConstants {
    static let Store_Key = "GDirections_Key"
}

enum GStoreData {
    case success(String)
    case failure(GError)
}
