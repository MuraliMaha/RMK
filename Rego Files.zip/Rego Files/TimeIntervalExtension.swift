//
//  TimeIntervalExtension.swift
//  DriveFindMyCab
//
//  Created by Raja Bhuma on 26/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit

extension TimeInterval {
    func GetMinutes() -> Int {
        let Interval = Int(self)
        return (Interval / 60) % 60
    }
    func GetHours() -> Int {
        let Interval = Int(self)
        return (Interval / 3600)
    }
    func GetSeconds() -> Int {
        let Interval = Int(self)
        return Interval % 60
    }
}
