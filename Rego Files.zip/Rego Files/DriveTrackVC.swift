//
//  DriveTrackVC.swift
//  DriveFindMyCab
//
//  Created by Raja Bhuma on 21/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.

import UIKit
import GoogleMaps
import AVKit
import AVFoundation
import Messages
import MessageUI
class DriveTrackVC: UIViewController, CLLocationManagerDelegate, UIPickerViewDelegate, UIPickerViewDataSource, MFMessageComposeViewControllerDelegate {

    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!
    
    
    var TrackDetails: MyRides!
    
    var TrackTimer = Timer()
    
    var locationManager = CLLocationManager()
    
    var BackToParent = false
    
    @IBOutlet var TrackMapView: GMSMapView!
    @IBOutlet var ContactSupportBGView: UIView!
    
    
    var RoutePolyline: GMSPolyline!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.black
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
        self.navigationItem.leftBarButtonItem = BackBtnItem
        
        self.LoginRequest = FetchDriveRequest()
        self.DriveBookingResponce = FetchDriveResponce()
    
//         ContactSupportBGView.isHidden = true
        DriverDetailsView.isHidden = true
        BottomStatusView.isHidden = true
        SOSBtn.isHidden = true
        self.navigationItem.title = "DRIVE"
        
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        
        AddHiddenTextfld()
        
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error.localizedDescription)
    }
    
    func AddCancelButton() {
        let BackBtnItem = UIBarButtonItem.init(image:UIImage.init(named: "cancelTrack"), style: .done, target: self, action: #selector(CancellBookingPressed(_:)))
        BackBtnItem.tintColor = UIColor.red
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, 10, 0, 0)
        self.navigationItem.rightBarButtonItem = BackBtnItem
    }
    
    @objc func CancellBookingPressed(_ sender:UIBarButtonItem) {
        Message.shared.Alert(Title: "Alert!", Message: "Do you want to cancel the Drive", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "NO"),Message.AlertActionWithSelector(Title: "YES", Selector: #selector(CallCancellllll), Controller: self)], Controller: self)
    }
    
    @objc func CallCancellllll() {
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            let CancelReasonsDict = ["EmpId":"\(DriveBookingResponce.EmpId!)",
                "VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveCancellationReasons, parameterDict: CancelReasonsDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (CancelReasonsDict, responceCode, success) in
                self.view.StopLoading()
                if success {
                    if let Table = ((CancelReasonsDict as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                        
                        if "\(Table["Status"]!)" == "true" && Table.keys.contains(where: {$0 == "Reasons"}) && "\(Table["Reasons"]!)" != ""  {
                            let Reasons = "\(Table["Reasons"]!)".components(separatedBy: "|")
                            self.CancelReasonsArr.removeAll()
                            for i in 0..<Reasons.count-1 {
                                self.CancelReasonsArr.append(Reasons[i])
                            }
                            self.CancelBookingText.becomeFirstResponder()
                            self.CancelSelectPicker.reloadAllComponents()
                        }
                        else {
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                        }
                        
                    }
                    else {
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                    }
                }
                else {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                }
            })
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.NetErrorMsg, Interval: 2)
        }
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return CancelReasonsArr.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return CancelReasonsArr[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        SelectedIndex = row
    }
    
    var CancelBookingText = UITextField()
    var CancelSelectPicker = UIPickerView()
    var CancelReasonsArr = [String]()
    func AddHiddenTextfld() {
        
        CancelBookingText.frame = CGRect.init(x: 1000, y: 1000, width: 10, height: 10)
        self.view.addSubview(CancelBookingText)
        CancelSelectPicker.dataSource = self
        CancelSelectPicker.delegate = self
        
        let Toolbar = UIToolbar()
        Toolbar.barStyle = .default
        Toolbar.isTranslucent = true
        Toolbar.tintColor = UIColor.blue
        Toolbar.sizeToFit()
        let DoneItem = UIBarButtonItem.init(title: "SELECT", style: .done, target: self, action: #selector(PickselectAction))
        let FlexiItem = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let TitleItem = UIBarButtonItem.init(title: "Please select reason", style: .done, target: nil, action: nil)
        let FlexiItem2 = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let CancelItem = UIBarButtonItem.init(title: "CANCEL", style: .done, target: self, action: #selector(PickCancelAction))
        Toolbar.setItems([CancelItem,FlexiItem,TitleItem,FlexiItem2,DoneItem], animated: true)
        Toolbar.isUserInteractionEnabled = true
        CancelBookingText.inputView = CancelSelectPicker;
        CancelBookingText.inputAccessoryView = Toolbar;
    }
    
    var SelectedIndex = 0
    
    @objc func PickselectAction() {
        CancelBookingText.resignFirstResponder()

        CancelTrip(Reason:CancelReasonsArr[SelectedIndex] , JobNO: TrackDetails.Jobno!)
    }
    func CancelTrip(Reason:String, JobNO:String) {
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            let CancelRequestDict = ["JobNo":"\(JobNO)","JobType":"\(TrackDetails.JobType!)","CancelReason":"\(Reason)","EmpId":"\(DriveBookingResponce.EmpId!)","VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveCancelBooking, parameterDict: CancelRequestDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (CancelDict, responceCode, success) in
                self.view.StopLoading()
                if success {
                    if let Table = ((CancelDict as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                        
                        if "\(Table["Status"]!)" == "true" {
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(Table["Response"]!)", Interval: 2)
                            
                            self.view.StartLoading()
                            
                            self.TrackTimeBase()
                        }
                        else {
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(Table["Response"]!)", Interval: 2)
                        }
                    }
                }
                else {
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                }
            })
        }
        else {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.NetErrorMsg, Interval: 2)
        }
    }

    
    @objc func PickCancelAction() {
        CancelBookingText.resignFirstResponder()
    }
    
    // MARK: - }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.view.StartLoading()
        TrackTimeBase()
        TrackTimer = Timer.scheduledTimer(timeInterval: 8, target: self, selector: #selector(TrackTimeBase), userInfo: nil, repeats: true)
        
        Timer.scheduledTimer(timeInterval: 0.2, target: self, selector: #selector(TimerForLocaccess), userInfo: nil, repeats: false)
    }
    
    @objc func TimerForLocaccess() {
        if CLLocationManager.authorizationStatus() != .authorizedWhenInUse && CLLocationManager.authorizationStatus() != .authorizedAlways {
            ShowLocationDenied(controller: self)
        }

    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        TrackTimer.invalidate()
        CloseSos()
    }
    
    
    @objc func BackAction() {
        
        if BackToParent {
            let Track = self.storyboard?.instantiateViewController(withIdentifier: "MyTripsVC") as! MyTripsVC
            let transition = CATransition()
            transition.duration = 0.45
            transition.type = kCATransitionFromLeft
//            transition.subtype = kCATransitionFromTop;
            
            self.navigationController?.view.layer.add(transition, forKey: kCATransition)
            self.navigationController?.pushViewController(Track, animated: true)
        }
        else {
            self.navigationController?.popViewController(animated: true)
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - Initiating the States of Trip {
    
    @IBOutlet var BottomStatusView:UIView!
    @IBOutlet var BottomStatusLbl:UILabel!
    
    @IBOutlet var DriverDetailsView:UIView!
    @IBOutlet var DriverNameLbl:UILabel!
    @IBOutlet var DriverVehicleNumberLbl:UILabel!
    @IBOutlet var DriverVehicleTypeLbl:UILabel!
    @IBOutlet var DriverImage:UIImageView!
    @IBOutlet var DriverRating:UILabel!

    @IBOutlet var JobIdShow:UILabel!

    @IBOutlet var DriverSupportView:UIView!

    @IBAction func CallDriverBtnPressed(_ sender:UIButton) {
        if "\(TrackCabData.DriverDetails.DriverNo!)" == "" || "\(TrackCabData.DriverDetails.DriverNo!)" == "NA" || "\(TrackCabData.DriverDetails.DriverNo!)" == "N/A" || "\(TrackCabData.DriverDetails.DriverNo!)" == "0" {
            self.view.ShowBlackTostWithText(message: "Driver Number not available", Interval: 3)
        }
        else {
            let url = URL.init(string: "tel://" + TrackCabData.DriverDetails.DriverNo!)
            if UIApplication.shared.canOpenURL(url!) {
                UIApplication.shared.openURL(url!)
            }
            else {
                self.view.ShowBlackTostWithText(message: "Can not able to call " + TrackCabData.DriverDetails.DriverNo!, Interval: 3)
            }
        }
    }
    
    @IBOutlet var CurrentLocationBtn:UIButton!
    @IBAction func CurrentLocationBtnPressed(_ sender:UIButton) {
        
        if PreviousState != 100 {
            
            if PreviousState == 5 {
                self.ZoomToWithSingleMarker(Position: self.VehicleMarker.position)
            }
            else {
                
                if PickLocMarker != nil {
                    ZoomToWithSingleMarker(Position: PickLocMarker.position)
                }
                else if PikpuDisatanceMarker != nil {
                    ZoomToWithSingleMarker(Position: PikpuDisatanceMarker.position)
                }
                else if DropLocMarker != nil {
                    ZoomToWithSingleMarker(Position: DropLocMarker.position)
                }
                else {
                    guard (locationManager.location != nil) else {
                        ShowLocationDenied(controller: self)
                        return
                    }
                    ZoomToWithSingleMarker(Position: (locationManager.location?.coordinate)!)
                }
            }
        }
        else {
            guard (locationManager.location != nil) else {
                ShowLocationDenied(controller: self)
                return
            }
            ZoomToWithSingleMarker(Position: (locationManager.location?.coordinate)!)
        }
        
    }
    
    @IBOutlet var RequestCallBackBtn:UIButton!
    @IBAction func RequestCallBackBtnPressed(_ sender:UIButton) {
        Message.shared.Alert(Title: "Support!", Message: "Do you want to request callback", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "No"),Message.AlertActionWithSelector(Title: "Yes", Selector: #selector(CallSupportService), Controller: self)], Controller: self)
    }
    func showContactBGView(){
        
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        
        BackView.center = (window?.center)!
        
        window?.addSubview(BackView)
        self.ContactSupportBGView.center = BackView.center
        
//        self.LocationLbl.text = addStr
        
        BackView.addSubview(self.ContactSupportBGView!)
        
        self.ContactSupportBGView.alpha = 0
        UIView.animate(withDuration: 0.5) {
            self.ContactSupportBGView.alpha = 1
        }

    
    }
    @IBAction func closeSupportView(_ sender:UIButton) {
        CloseSupportView()
    }
    func CloseSupportView() {
        UIView.animate(withDuration: 0.3, animations: {
            self.ContactSupportBGView.alpha = 0
        }) { (yes) in
            if yes {
                self.ContactSupportBGView.alpha = 1
                self.ContactSupportBGView.superview?.removeFromSuperview()
              
            }
        }
    }
    @objc func CallSupportService() {
        
        guard (locationManager.location != nil) else {
            ShowLocationDenied(controller: self)
            return
        }
        
        if (Reachability()?.isReachable)! {
            
            let Locationdetails = locationManager.location!
            
            self.view.StartLoading()
            
            CLLocationCoordinate2DMake(Locationdetails.coordinate.latitude, Locationdetails.coordinate.longitude).fetchAddressFromLatLon(Completion: { (gmsAddress, success) in
                
                self.view.StopLoading()

                if success {
                
                    var AddStr = ""
                    for add in gmsAddress.lines! {
                        AddStr.append(add + ", ")
                    }
                    
                    if AddStr != "" {
                        
                        let addStr = AddStr.substring(to: AddStr.index(AddStr.endIndex, offsetBy: -2))

                        let ContactDict = ["EmpId":"\(self.DriveBookingResponce.EmpId!)","MobileNo":"\(self.DriveBookingResponce.PhoneNo!)","BookingId":"\(self.TrackDetails.Jobno!)","Latitude":"\(Locationdetails.coordinate.latitude)","Longitude":"\(Locationdetails.coordinate.longitude)","Location":addStr,"VendorId":"\(self.LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(self.LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(self.LoginRequest.LoginCreds.AppCustomerType!)"]
                        self.view.StartLoading()
                        WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveContactCustomerCare, parameterDict: ContactDict, securityKey: self.DriveBookingResponce.AuthenticationToken!, completion: { (ResponceDict, responceCode, success) in
                            self.view.StopLoading()
                            if success {
                                if let Table = ((ResponceDict as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                                    print(Table)
                                    if "\(Table["Status"]!)" == "true" || "\(Table["Status"]!)" == "1" {
//                                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(Table["Response"]!)", Interval: 4)
//                                        self.ContactSupportBGView.isHidden = false
                                        self.showContactBGView()
                                    }
                                    else {
                                        self.view.ShowBlackTostWithText(message: "\(Table["Response"]!)", Interval: 3)
                                    }
                                }
                                else {
                                    self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                                }
                            }
                            else {
                                self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                            }
                        })
                    }
                    else {
                        self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                    }
                }
                else {
                    self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                }
            })
            
            
        }
        else {
            self.view.ShowBlackTostWithText(message: Constants.NetErrorMsg, Interval: 2)
        }
    }
    
    @IBOutlet var SOSBtn:UIButton!
    
    var Location = CLLocation()
    
    @IBAction func SOSBtnPressed(_ sender:UIButton) {
        
        guard (locationManager.location != nil) else {
            ShowLocationDenied(controller: self)
            return
        }
        Location = locationManager.location!
        
        self.view.StartLoading()
        LoadAddress(Lat: Location.coordinate.latitude, Lon: Location.coordinate.longitude)
        CLGeocoder().reverseGeocodeLocation(Location) { (places, error) in
            self.view.StopLoading()
            let window = UIApplication.shared.keyWindow
            let BackView = UIView.init(frame: (window?.frame)!)
            BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
            
            BackView.center = (window?.center)!
            
            window?.addSubview(BackView)
            self.SOSView.center = BackView.center
            BackView.addSubview(self.SOSView!)
            self.SOSView.alpha = 0
            UIView.animate(withDuration: 0.5) {
                self.SOSView.alpha = 1
            }
            if error == nil {
                if (places?.count)! > 0 {
                    let place = places?.last
                    
                    var addStr = "Not available"
                    let DictPlaces = UtilitiesClassSub.getLocationDetails(fromCLPlaceMark: place!)!
                    
                    if "\(DictPlaces[LocationParserFullAddress]!)" != "" {
                        addStr = DictPlaces[LocationParserFullAddress]! as! String
                    }
                    
                    self.LocationLbl.text = addStr
         
                }
                else {
                    
                }
            }
            else {
                
            }
        }
        
//        Location.coordinate.fetchAddressFromLatLon(Completion: { (gmsAddress, success) in
//            
//            self.view.StopLoading()
//
//            var addStr = "Not available"
//            if success {
//                
//                var AddStr = ""
//                for add in gmsAddress.lines! {
//                    AddStr.append(add + ", ")
//                }
//                
//                if AddStr != "" {
//                    addStr = AddStr.substring(to: AddStr.index(AddStr.endIndex, offsetBy: -2))
//                }
//            }
//            
//            let window = UIApplication.shared.keyWindow
//            let BackView = UIView.init(frame: (window?.frame)!)
//            BackView.backgroundColor = UIColor.black.withAlphaComponent(0.8)
//            
//            BackView.center = (window?.center)!
//            
//            window?.addSubview(BackView)
//            self.SOSView.center = BackView.center
//            
//            self.LocationLbl.text = addStr
//            
//            BackView.addSubview(self.SOSView!)
//            
//            self.SOSView.alpha = 0
//            UIView.animate(withDuration: 0.5) {
//                self.SOSView.alpha = 1
//            }
//        })
        
    }
    func LoadAddress(Lat:Double,Lon:Double) {
        
        fetchAddressFromLatLon(Lati: Lat, Long: Lon, { (Address, error) in
            if error == nil {
                
                var AddressFilter = ""
                
                for AddObj in Address! {
                    AddressFilter.append("\(AddObj)" + ("\(AddObj)".isEmpty ? "" : ", "))
                }
                
                var FilterAdd = ""
                if AddressFilter != "" && AddressFilter.characters.count > 2 {
                    FilterAdd = AddressFilter.substring(to: AddressFilter.index(AddressFilter.endIndex, offsetBy: -2))
                }
                else {
                    FilterAdd = AddressFilter
                }
                self.LocationLbl.text = FilterAdd
                
            }
            else {
                print(error!)
                
                self.LocationLbl.text = "No Location"
            }
        })
    }
    func fetchAddressFromLatLon(Lati:Double,Long:Double,_ Completion:@escaping ([String]?,String?) -> Void) {
        GMSGeocoder().reverseGeocodeCoordinate(CLLocationCoordinate2DMake(Lati, Long)) { (ReverseGeoCodeResponce, error) in
            if error == nil {
                let address = ReverseGeoCodeResponce?.results()?[0].lines
                Completion(address,nil)
            }
            else {
                Completion(nil,error?.localizedDescription)
            }
        }
    }
    // MARK: - SOS New View {
    
    @IBOutlet var SOSView:UIView!

    @IBOutlet var LocationLbl:UILabel!
    @IBOutlet var PlaySiranBtn:UIButton!

    
    @IBAction func CallPoliceBtnPressed(_ sender:UIButton) {
        let url = URL.init(string: "tel://" + "100")
        if UIApplication.shared.canOpenURL(url!) {
            UIApplication.shared.openURL(url!)
        }
        
        FetchNumbers()

        if Numbers.count > 0 {
            if (MFMessageComposeViewController.canSendText()) {
                let controller = MFMessageComposeViewController()
                controller.body = "\(self.DriveBookingResponce.Name!)" + " is in an emergency situation and needs help immediately.\nLocation: "
                    + self.LocationLbl.text! + "\nhttp://maps.google.com/?q="
                    + "\(Location.coordinate.latitude)" + ","
                    + "\(Location.coordinate.longitude)"
                controller.recipients = self.Numbers
                controller.messageComposeDelegate = self
                self.present(controller, animated: true, completion: nil)
            }
        }
    }
    
    @IBAction func CallEmergencyBtnPressed(_ sender:UIButton) {
        
        CloseSos()
        
        FetchNumbers()
        
        if Numbers.count == 0 {
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Emergency contacts not available", Interval: 3)
        }
        else {
            
            if UIApplication.shared.canOpenURL(URL.init(string: "tel://" + Numbers[0])!) {
                
                UIApplication.shared.openURL(URL.init(string: "tel://" + Numbers[0])!)

            }
            else {
                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "We cannot able to call Emergency contacts", Interval: 3)
            }
            
            
            if (MFMessageComposeViewController.canSendText()) {
                let controller = MFMessageComposeViewController()
                controller.body = "\(self.DriveBookingResponce.Name!)" + " is in an emergency situation and needs help immediately.\nLocation: "
                    + self.LocationLbl.text! + "\nhttp://maps.google.com/?q="
                    + "\(Location.coordinate.latitude)" + ","
                    + "\(Location.coordinate.longitude)"
                controller.recipients = self.Numbers
                controller.messageComposeDelegate = self
                self.present(controller, animated: true, completion: nil)
            }
        }
        
    }
    var Numbers = [String]()
    
    func FetchNumbers() {
     
        if (GetEmergencyValue()?.count)! > 0 {
            Numbers.removeAll()
            
            for number in GetEmergencyValue()! {
                Numbers.append(number.MobileNumber!)
            }
        }
    }
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func PlayStopSiranBtnPressed(_ sender:UIButton) {
        
        if sender.isSelected {
            sender.isSelected = false
            stopSound()
        }
        else {
            sender.isSelected = true
            playSound()
        }
    }
    
    var player : AVAudioPlayer?
    
    func playSound() {
        let url = Bundle.main.url(forResource: "Siren", withExtension: "mp3")!
        
        do {
            player = try AVAudioPlayer(contentsOf: url)
            guard let player = player else { return }
            
            player.prepareToPlay()
            player.play()
        } catch let error as NSError {
            print(error.description)
        }
    }
    func stopSound(){
        player?.stop()
    }
    
    @IBAction func CloseSOSBtnPressed(_ sender:UIButton) {
        CloseSos()
    }
    
    func CloseSos() {
        UIView.animate(withDuration: 0.3, animations: {
            self.SOSView.alpha = 0
        }) { (yes) in
            if yes {
                self.SOSView.alpha = 1
                self.SOSView.superview?.removeFromSuperview()
//                self.stopSound()
//                self.PlaySiranBtn.isSelected = false
            }
        }
    }

    // MARK: - }
    
    
    var PreviousState = 100
    
    var TrackCabData:TrackVehicleStruct!

    var PickLocMarker: PickUpMaker!
    var DropLocMarker: DropMaker!
    var VehicleMarker: CabMarker!
    
    var PikpuDisatanceMarker: PickupDistanceMarker!

    var IsImageAssigned = false
    
    func VehicleNotAssignedState() {
        
        /*
         
         job state 13 , 21 , 0
         
         Request customer care to call back button on right top.
         
         Current Location Button
         
         Vehicle not assigned status on bottom with white View.
         
         Cancel buttin on navigation bar on right side
         
         navi Title Drive
         
         */
        
        if PreviousState == 100 {
            
            if PickLocMarker != nil {
                PickLocMarker.map = nil
                PickLocMarker = nil
            }
            if DropLocMarker != nil {
                DropLocMarker.map = nil
                DropLocMarker = nil
            }
            if VehicleMarker != nil {
                VehicleMarker.map = nil
                VehicleMarker = nil
            }
            
            if PikpuDisatanceMarker != nil {
                PikpuDisatanceMarker.map = nil
                PikpuDisatanceMarker = nil
            }
            
            PickLocMarker = PickUpMaker.init(Pickup: TrackCabData.PickupLoc!)
            PickLocMarker.map = TrackMapView
            ZoomToWithSingleMarker(Position: PickLocMarker.position)
            
            
            DriverDetailsView.isHidden = true
            SOSBtn.isHidden = true
            
            BottomStatusView.isHidden = false
        }
        else {
            
            if PreviousState == 13 || PreviousState == 21 || PreviousState == 0 {
                
                PickLocMarker.position = CLLocationCoordinate2DMake(TrackCabData.PickupLoc.Pickuplat!, TrackCabData.PickupLoc.Pickuplon!)
                
                ZoomToWithSingleMarker(Position: PickLocMarker.position)
                
            }
            else {
                
                if PickLocMarker != nil {
                    PickLocMarker.map = nil
                    PickLocMarker = nil
                }
                if DropLocMarker != nil {
                    DropLocMarker.map = nil
                    DropLocMarker = nil
                }
                if VehicleMarker != nil {
                    VehicleMarker.map = nil
                    VehicleMarker = nil
                }
                if PikpuDisatanceMarker != nil {
                    PikpuDisatanceMarker.map = nil
                    PikpuDisatanceMarker = nil
                }
                
                PickLocMarker = PickUpMaker.init(Pickup: TrackCabData.PickupLoc!)
                PickLocMarker.map = TrackMapView
                ZoomToWithSingleMarker(Position: PickLocMarker.position)
                
                DriverDetailsView.isHidden = true
                SOSBtn.isHidden = true
                
                BottomStatusView.isHidden = false
            }
        }
        
        self.CurrentLocationBtn.isHidden = false
        PreviousState = Int("\(TrackCabData.JobStatus!)")!
        
        self.navigationItem.title = "DRIVE"
        
        if self.navigationItem.rightBarButtonItem == nil {
            AddCancelButton()
        }
    }
    
 
    func VehicleAssignedState() {
        
//        .27 - pin y
        
//        0.068 x
//        0.49 width
        
//        0.21 - y
//        0.4 - height
        
        /*
         
         job state 14

         Request customer care to call back button on right top.
         
         Current Location Button
         
         Cancel buttin on navigation bar on right side
         
         Show vehicle aswell as pickup point
         
         show Cabdriver details and and Call Driver on bottom.
         
         change navigation bar Title to Vehicle assigned
         
         navi Title Vihicle assigned

         */
        
        
        LoadDistancefromCabToPickup(pickuplat: "\(TrackCabData.PickupLoc.Pickuplat!)", pickuplng: "\(TrackCabData.PickupLoc.Pickuplon!)", vehiclelat: "\(TrackCabData.DriverDetails.VehicleLat!)", vehiclelng: "\(TrackCabData.DriverDetails.VehicleLon!)", Completion: {(duration,success) in
            
            let font = UIFont.init(name: "Helvetica", size: 10)
            let Size = (duration as NSString).size(withAttributes: [NSAttributedStringKey.font: font!,
                                                                    NSAttributedStringKey.foregroundColor: UIColor.black])
            let image = UIImage.init(named: "TimerPin")!.ReduceImageSize(CGSize.init(width: 80, height: 80))
            
            let rect = CGRect(x: (0.235 * (image.size.width)) - (Size.width/2), y:(0.24 * (image.size.height)) - (Size.height/2), width: Size.width, height: Size.height)



            let RenderedImage = image.addText(duration as NSString, atRect: rect, textColor: UIColor.black, textFont: font)
            
            
            
            if self.PreviousState == 100 {
                
                if self.PickLocMarker != nil {
                    self.PickLocMarker.map = nil
                    self.PickLocMarker = nil
                }
                if self.DropLocMarker != nil {
                    self.DropLocMarker.map = nil
                    self.DropLocMarker = nil
                }
                if self.VehicleMarker != nil {
                    self.VehicleMarker.map = nil
                    self.VehicleMarker = nil
                }
                
                if self.PikpuDisatanceMarker != nil {
                    self.PikpuDisatanceMarker.map = nil
                    self.PikpuDisatanceMarker = nil
                }
                
                if success {
                    self.PikpuDisatanceMarker = PickupDistanceMarker.init(Pickup: self.TrackCabData.PickupLoc!)
                    self.PikpuDisatanceMarker.icon = RenderedImage
                    self.PikpuDisatanceMarker.map = self.TrackMapView
                    
                    self.VehicleMarker = CabMarker.init(Cab: self.TrackCabData.DriverDetails!)
                    self.VehicleMarker.map = self.TrackMapView
                    
                    self.ZoomToWithMultiMarker(Position1: self.PikpuDisatanceMarker.position, Position2: self.VehicleMarker.position)
                }
                else {
                    self.VehicleMarker = CabMarker.init(Cab: self.TrackCabData.DriverDetails!)
                    self.VehicleMarker.map = self.TrackMapView
                    self.ZoomToWithSingleMarker(Position: self.VehicleMarker.position)
                }
                
                
                
                self.DriverDetailsView.isHidden = false
                self.SOSBtn.isHidden = true
                
                self.BottomStatusView.isHidden = true
            }
            else {
                
                
                
                if self.PreviousState == 14 {
                    
                    if success {
                        
                        if self.PikpuDisatanceMarker == nil {
                            self.PikpuDisatanceMarker = PickupDistanceMarker.init(Pickup: self.TrackCabData.PickupLoc!)
                            self.PikpuDisatanceMarker.icon = RenderedImage
                            self.PikpuDisatanceMarker.map = self.TrackMapView
                            
                            self.VehicleMarker.position = CLLocationCoordinate2DMake(self.TrackCabData.DriverDetails.VehicleLat!, self.TrackCabData.DriverDetails.VehicleLon!)

                            self.ZoomToWithMultiMarker(Position1: self.PikpuDisatanceMarker.position, Position2: self.VehicleMarker.position)

                        }
                        else {
                            self.PikpuDisatanceMarker.position = CLLocationCoordinate2DMake(self.TrackCabData.PickupLoc.Pickuplat!, self.TrackCabData.PickupLoc.Pickuplon!)
                            self.PikpuDisatanceMarker.icon = RenderedImage
                            
                            self.VehicleMarker.position = CLLocationCoordinate2DMake(self.TrackCabData.DriverDetails.VehicleLat!, self.TrackCabData.DriverDetails.VehicleLon!)
                            
                            self.ZoomToWithMultiMarker(Position1: self.PikpuDisatanceMarker.position, Position2: self.VehicleMarker.position)
                        }
                        
                    }
                    else {
                        
                        if self.PikpuDisatanceMarker != nil {
                            self.PikpuDisatanceMarker.map = nil
                            self.PikpuDisatanceMarker = nil
                        }
                        
                        self.VehicleMarker.position = CLLocationCoordinate2DMake(self.TrackCabData.DriverDetails.VehicleLat!, self.TrackCabData.DriverDetails.VehicleLon!)
                        self.ZoomToWithSingleMarker(Position: self.VehicleMarker.position)
                    }
                    
                }
                else {
                    
                    if self.PickLocMarker != nil {
                        self.PickLocMarker.map = nil
                        self.PickLocMarker = nil
                    }
                    if self.DropLocMarker != nil {
                        self.DropLocMarker.map = nil
                        self.DropLocMarker = nil
                    }
                    if self.VehicleMarker != nil {
                        self.VehicleMarker.map = nil
                        self.VehicleMarker = nil
                    }
                    
                    if self.PikpuDisatanceMarker != nil {
                        self.PikpuDisatanceMarker.map = nil
                        self.PikpuDisatanceMarker = nil
                    }
                    
                    if success {
                        self.PikpuDisatanceMarker = PickupDistanceMarker.init(Pickup: self.TrackCabData.PickupLoc!)
                        self.PikpuDisatanceMarker.icon = RenderedImage
                        self.PikpuDisatanceMarker.map = self.TrackMapView
                        
                        self.VehicleMarker = CabMarker.init(Cab: self.TrackCabData.DriverDetails!)
                        self.VehicleMarker.map = self.TrackMapView
                        
                        self.ZoomToWithMultiMarker(Position1: self.PikpuDisatanceMarker.position, Position2: self.VehicleMarker.position)
                    }
                    else {
                        self.VehicleMarker = CabMarker.init(Cab: self.TrackCabData.DriverDetails!)
                        self.VehicleMarker.map = self.TrackMapView
                        self.ZoomToWithSingleMarker(Position: self.VehicleMarker.position)
                    }
                    
                    self.DriverDetailsView.isHidden = false
                    self.SOSBtn.isHidden = true
                    
                    self.BottomStatusView.isHidden = true
                }
            }
            
            self.CurrentLocationBtn.isHidden = false

            self.JobIdShow.isHidden = false

            self.DriverSupportView.isHidden = false
            
            
            self.PreviousState = Int("\(self.TrackCabData.JobStatus!)")!
            self.navigationItem.title = self.TrackCabData.JobMessage!
            if self.navigationItem.rightBarButtonItem == nil {
                self.AddCancelButton()
            }
            
        })
        

    }
    
    func VehicleOntheWayState() {
        /*
         
         job state 1
         
         Request customer care to call back button on right top.
         
         Current Location Button
         
         Cancel buttin on navigation bar on right side
         
         Show vehicle aswell as pickup point
         
         show Cabdriver details and and Call Driver on bottom.
         
         change navigation bar Title to Vehicle assigned
         
         navi Title on the way
         
         */
        LoadDistancefromCabToPickup(pickuplat: "\(TrackCabData.PickupLoc.Pickuplat!)", pickuplng: "\(TrackCabData.PickupLoc.Pickuplon!)", vehiclelat: "\(TrackCabData.DriverDetails.VehicleLat!)", vehiclelng: "\(TrackCabData.DriverDetails.VehicleLon!)", Completion: {(duration,success) in
            
            let font = UIFont.init(name: "Helvetica", size: 10)
            let Size = (duration as NSString).size(withAttributes: [NSAttributedStringKey.font: font!,
                                                                    NSAttributedStringKey.foregroundColor: UIColor.black])
            let image = UIImage.init(named: "TimerPin")!.ReduceImageSize(CGSize.init(width: 80, height: 80))
            
            let rect = CGRect(x: (0.235 * (image.size.width)) - (Size.width/2), y:(0.24 * (image.size.height)) - (Size.height/2), width: Size.width, height: Size.height)




            let RenderedImage = image.addText(duration as NSString, atRect: rect, textColor: UIColor.black, textFont: font)
            
            
            if self.PreviousState == 100 {
                
                if self.PickLocMarker != nil {
                    self.PickLocMarker.map = nil
                    self.PickLocMarker = nil
                }
                if self.DropLocMarker != nil {
                    self.DropLocMarker.map = nil
                    self.DropLocMarker = nil
                }
                if self.VehicleMarker != nil {
                    self.VehicleMarker.map = nil
                    self.VehicleMarker = nil
                }
                
                if self.PikpuDisatanceMarker != nil {
                    self.PikpuDisatanceMarker.map = nil
                    self.PikpuDisatanceMarker = nil
                }
                
                if success {
                    self.PikpuDisatanceMarker = PickupDistanceMarker.init(Pickup: self.TrackCabData.PickupLoc!)
                    self.PikpuDisatanceMarker.icon = RenderedImage
                    self.PikpuDisatanceMarker.map = self.TrackMapView
                    
                    self.VehicleMarker = CabMarker.init(Cab: self.TrackCabData.DriverDetails!)
                    self.VehicleMarker.map = self.TrackMapView
                    
                    self.ZoomToWithMultiMarker(Position1: self.PikpuDisatanceMarker.position, Position2: self.VehicleMarker.position)
                }
                else {
                    self.VehicleMarker = CabMarker.init(Cab: self.TrackCabData.DriverDetails!)
                    self.VehicleMarker.map = self.TrackMapView
                    self.ZoomToWithSingleMarker(Position: self.VehicleMarker.position)
                }
                
                self.DriverDetailsView.isHidden = false
                self.SOSBtn.isHidden = true
                
                self.BottomStatusView.isHidden = true
            }
            else {
                
                
                
                if self.PreviousState == 1 || self.PreviousState == 6 {
                    
                    if success {
                        
                        if self.PikpuDisatanceMarker == nil {
                            self.PikpuDisatanceMarker = PickupDistanceMarker.init(Pickup: self.TrackCabData.PickupLoc!)
                            self.PikpuDisatanceMarker.icon = RenderedImage
                            self.PikpuDisatanceMarker.map = self.TrackMapView
                            
                            self.VehicleMarker.position = CLLocationCoordinate2DMake(self.TrackCabData.DriverDetails.VehicleLat!, self.TrackCabData.DriverDetails.VehicleLon!)
                            
                            self.ZoomToWithMultiMarker(Position1: self.PikpuDisatanceMarker.position, Position2: self.VehicleMarker.position)
                            
                        }
                        else {
                            self.PikpuDisatanceMarker.position = CLLocationCoordinate2DMake(self.TrackCabData.PickupLoc.Pickuplat!, self.TrackCabData.PickupLoc.Pickuplon!)
                            self.PikpuDisatanceMarker.icon = RenderedImage
                            
                            self.VehicleMarker.position = CLLocationCoordinate2DMake(self.TrackCabData.DriverDetails.VehicleLat!, self.TrackCabData.DriverDetails.VehicleLon!)
                            
                            self.ZoomToWithMultiMarker(Position1: self.PikpuDisatanceMarker.position, Position2: self.VehicleMarker.position)
                        }
                        
                    }
                    else {
                        
                        if self.PikpuDisatanceMarker != nil {
                            self.PikpuDisatanceMarker.map = nil
                            self.PikpuDisatanceMarker = nil
                        }
                        
                        self.VehicleMarker.position = CLLocationCoordinate2DMake(self.TrackCabData.DriverDetails.VehicleLat!, self.TrackCabData.DriverDetails.VehicleLon!)
                        self.ZoomToWithSingleMarker(Position: self.VehicleMarker.position)
                    }
                    
                }
                else {
                    
                    if self.PickLocMarker != nil {
                        self.PickLocMarker.map = nil
                        self.PickLocMarker = nil
                    }
                    if self.DropLocMarker != nil {
                        self.DropLocMarker.map = nil
                        self.DropLocMarker = nil
                    }
                    if self.VehicleMarker != nil {
                        self.VehicleMarker.map = nil
                        self.VehicleMarker = nil
                    }
                    
                    if self.PikpuDisatanceMarker != nil {
                        self.PikpuDisatanceMarker.map = nil
                        self.PikpuDisatanceMarker = nil
                    }
                    
                    if success {
                        self.PikpuDisatanceMarker = PickupDistanceMarker.init(Pickup: self.TrackCabData.PickupLoc!)
                        self.PikpuDisatanceMarker.icon = RenderedImage
                        self.PikpuDisatanceMarker.map = self.TrackMapView
                        
                        self.VehicleMarker = CabMarker.init(Cab: self.TrackCabData.DriverDetails!)
                        self.VehicleMarker.map = self.TrackMapView
                        
                        self.ZoomToWithMultiMarker(Position1: self.PikpuDisatanceMarker.position, Position2: self.VehicleMarker.position)
                    }
                    else {
                        self.VehicleMarker = CabMarker.init(Cab: self.TrackCabData.DriverDetails!)
                        self.VehicleMarker.map = self.TrackMapView
                        self.ZoomToWithSingleMarker(Position: self.VehicleMarker.position)
                    }
                    
                    self.DriverDetailsView.isHidden = false
                    self.SOSBtn.isHidden = true
                    
                    self.BottomStatusView.isHidden = true
                }
            }
            self.JobIdShow.isHidden = false

            self.CurrentLocationBtn.isHidden = false

            self.DriverSupportView.isHidden = false

            self.PreviousState = Int("\(self.TrackCabData.JobStatus!)")!
            
            self.navigationItem.title = self.TrackCabData.JobMessage!

            if self.navigationItem.rightBarButtonItem == nil {
                self.AddCancelButton()
            }
            
        })
    }
    
    func VehicleReachedPickupState() {
        
        /*
         
         job state 3
         
         Request customer care to call back button on right top.
         
         Current Location Button
         
         Cancel buttin on navigation bar on right side
         
         Show vehicle aswell as pickup point
         
         show Cabdriver details and and Call Driver on bottom.
         
         change navigation bar Title to Vehicle assigned
         
         navi Title ReachedPickup
         
         */
        

        LoadDistancefromCabToPickup(pickuplat: "\(TrackCabData.PickupLoc.Pickuplat!)", pickuplng: "\(TrackCabData.PickupLoc.Pickuplon!)", vehiclelat: "\(TrackCabData.DriverDetails.VehicleLat!)", vehiclelng: "\(TrackCabData.DriverDetails.VehicleLon!)", Completion: {(duration,success) in
            
            let font = UIFont.init(name: "Helvetica", size: 10)
            let Size = (duration as NSString).size(withAttributes: [NSAttributedStringKey.font: font!,
                                                                    NSAttributedStringKey.foregroundColor: UIColor.black])
            
            let image = UIImage.init(named: "TimerPin")!.ReduceImageSize(CGSize.init(width: 80, height: 80))
            
            let rect = CGRect(x: (0.235 * (image.size.width)) - (Size.width/2), y:(0.24 * (image.size.height)) - (Size.height/2), width: Size.width, height: Size.height)

            
            let RenderedImage = image.addText(duration as NSString, atRect: rect, textColor: UIColor.black, textFont: font)
            
            if self.PreviousState == 100 {
                
                if self.PickLocMarker != nil {
                    self.PickLocMarker.map = nil
                    self.PickLocMarker = nil
                }
                if self.DropLocMarker != nil {
                    self.DropLocMarker.map = nil
                    self.DropLocMarker = nil
                }
                if self.VehicleMarker != nil {
                    self.VehicleMarker.map = nil
                    self.VehicleMarker = nil
                }
                
                if self.PikpuDisatanceMarker != nil {
                    self.PikpuDisatanceMarker.map = nil
                    self.PikpuDisatanceMarker = nil
                }
                
                if success {
                    self.PikpuDisatanceMarker = PickupDistanceMarker.init(Pickup: self.TrackCabData.PickupLoc!)
                    self.PikpuDisatanceMarker.icon = RenderedImage
                    self.PikpuDisatanceMarker.map = self.TrackMapView
                    
                    self.VehicleMarker = CabMarker.init(Cab: self.TrackCabData.DriverDetails!)
                    self.VehicleMarker.map = self.TrackMapView
                    
                    self.ZoomToWithMultiMarker(Position1: self.PikpuDisatanceMarker.position, Position2: self.VehicleMarker.position)
                }
                else {
                    self.VehicleMarker = CabMarker.init(Cab: self.TrackCabData.DriverDetails!)
                    self.VehicleMarker.map = self.TrackMapView
                    self.ZoomToWithSingleMarker(Position: self.VehicleMarker.position)
                }
                
                self.DriverDetailsView.isHidden = false
                self.SOSBtn.isHidden = true
                
                self.BottomStatusView.isHidden = true
            }
            else {
                
                
                
                if self.PreviousState == 3 {
                    
                    if success {
                        
                        if self.PikpuDisatanceMarker == nil {
                            self.PikpuDisatanceMarker = PickupDistanceMarker.init(Pickup: self.TrackCabData.PickupLoc!)
                            self.PikpuDisatanceMarker.icon = RenderedImage
                            self.PikpuDisatanceMarker.map = self.TrackMapView
                            
                            self.VehicleMarker.position = CLLocationCoordinate2DMake(self.TrackCabData.DriverDetails.VehicleLat!, self.TrackCabData.DriverDetails.VehicleLon!)
                            
                            self.ZoomToWithMultiMarker(Position1: self.PikpuDisatanceMarker.position, Position2: self.VehicleMarker.position)
                            
                        }
                        else {
                            self.PikpuDisatanceMarker.position = CLLocationCoordinate2DMake(self.TrackCabData.PickupLoc.Pickuplat!, self.TrackCabData.PickupLoc.Pickuplon!)
                            self.PikpuDisatanceMarker.icon = RenderedImage
                            
                            self.VehicleMarker.position = CLLocationCoordinate2DMake(self.TrackCabData.DriverDetails.VehicleLat!, self.TrackCabData.DriverDetails.VehicleLon!)
                            
                            self.ZoomToWithMultiMarker(Position1: self.PikpuDisatanceMarker.position, Position2: self.VehicleMarker.position)
                        }
                        
                    }
                    else {
                        
                        if self.PikpuDisatanceMarker != nil {
                            self.PikpuDisatanceMarker.map = nil
                            self.PikpuDisatanceMarker = nil
                        }
                        
                        self.VehicleMarker.position = CLLocationCoordinate2DMake(self.TrackCabData.DriverDetails.VehicleLat!, self.TrackCabData.DriverDetails.VehicleLon!)
                        self.ZoomToWithSingleMarker(Position: self.VehicleMarker.position)
                    }
                    
                }
                else {
                    
                    if self.PickLocMarker != nil {
                        self.PickLocMarker.map = nil
                        self.PickLocMarker = nil
                    }
                    if self.DropLocMarker != nil {
                        self.DropLocMarker.map = nil
                        self.DropLocMarker = nil
                    }
                    if self.VehicleMarker != nil {
                        self.VehicleMarker.map = nil
                        self.VehicleMarker = nil
                    }
                    
                    if self.PikpuDisatanceMarker != nil {
                        self.PikpuDisatanceMarker.map = nil
                        self.PikpuDisatanceMarker = nil
                    }
                    
                    if success {
                        self.PikpuDisatanceMarker = PickupDistanceMarker.init(Pickup: self.TrackCabData.PickupLoc!)
                        self.PikpuDisatanceMarker.icon = RenderedImage
                        self.PikpuDisatanceMarker.map = self.TrackMapView
                        
                        self.VehicleMarker = CabMarker.init(Cab: self.TrackCabData.DriverDetails!)
                        self.VehicleMarker.map = self.TrackMapView
                        
                        self.ZoomToWithMultiMarker(Position1: self.PikpuDisatanceMarker.position, Position2: self.VehicleMarker.position)
                    }
                    else {
                        self.VehicleMarker = CabMarker.init(Cab: self.TrackCabData.DriverDetails!)
                        self.VehicleMarker.map = self.TrackMapView
                        self.ZoomToWithSingleMarker(Position: self.VehicleMarker.position)
                    }
                    
                    self.DriverDetailsView.isHidden = false
                    self.SOSBtn.isHidden = true
                    
                    self.BottomStatusView.isHidden = true
                }
            }
            
            
            self.CurrentLocationBtn.isHidden = false

            self.JobIdShow.isHidden = false

            
            self.DriverSupportView.isHidden = false

            self.PreviousState = Int("\(self.TrackCabData.JobStatus!)")!
            
            self.navigationItem.title = self.TrackCabData.JobMessage!

            if self.navigationItem.rightBarButtonItem == nil {
                self.AddCancelButton()
            }
            
        })
    }
    
    func EnjoyYourDriveState() {
        
        /*
         
         job state 5
         
         Request customer care to call back button on right top.
         
         Current Location Button
         
         Show vehicle aswell as pickup point
         
         show Cabdriver details.
         
         change navigation bar Title to Vehicle assigned
         
         navi Title Enjoy your Drive
         
         */
        
        if PreviousState == 100 {
            
            if PickLocMarker != nil {
                PickLocMarker.map = nil
                PickLocMarker = nil
            }
            if DropLocMarker != nil {
                DropLocMarker.map = nil
                DropLocMarker = nil
            }
            if VehicleMarker != nil {
                VehicleMarker.map = nil
                VehicleMarker = nil
            }
            if PikpuDisatanceMarker != nil {
                PikpuDisatanceMarker.map = nil
                PikpuDisatanceMarker = nil
            }
            
            VehicleMarker = CabMarker.init(Cab: TrackCabData.DriverDetails!)
            VehicleMarker.map = TrackMapView
            
            ZoomToWithSingleMarker(Position: VehicleMarker.position)
            
//            if Double(TrackCabData.DropLoc.DropOfflat!) == 0  {
//                PickLocMarker = PickUpMaker.init(Pickup: TrackCabData.PickupLoc!)
//                PickLocMarker.map = TrackMapView
//            }
//            else {
//                PickLocMarker = PickUpMaker.init(Pickup: TrackCabData.PickupLoc!)
//                PickLocMarker.map = TrackMapView
            
                DropLocMarker = DropMaker.init(Drop: TrackCabData.DropLoc!)
                DropLocMarker.map = TrackMapView
//            }

            
            DriverDetailsView.isHidden = false
            SOSBtn.isHidden = false
            
            BottomStatusView.isHidden = true

        }
        else {
            
            if PreviousState == 5 {
                
                VehicleMarker.position = CLLocationCoordinate2DMake(TrackCabData.DriverDetails.VehicleLat!, TrackCabData.DriverDetails.VehicleLon!)

                ZoomToWithSingleMarker(Position: VehicleMarker.position)
                
//                if Double(TrackCabData.DropLoc.DropOfflat!) == 0  {
//                    PickLocMarker.position = CLLocationCoordinate2DMake(TrackCabData.PickupLoc.Pickuplat!, TrackCabData.PickupLoc.Pickuplon!)
//                }
//                else {
//
                    if DropLocMarker != nil {
//                        PickLocMarker.position = CLLocationCoordinate2DMake(TrackCabData.PickupLoc.Pickuplat!, TrackCabData.PickupLoc.Pickuplon!)
//                    }
//                    else {
//                        PickLocMarker.position = CLLocationCoordinate2DMake(TrackCabData.PickupLoc.Pickuplat!, TrackCabData.PickupLoc.Pickuplon!)
                        DropLocMarker.position = CLLocationCoordinate2DMake(TrackCabData.DropLoc.DropOfflat!, TrackCabData.DropLoc.DropOfflon!)
                    }
//                }

            }
            else {
                
                if PickLocMarker != nil {
                    PickLocMarker.map = nil
                    PickLocMarker = nil
                }
                if DropLocMarker != nil {
                    DropLocMarker.map = nil
                    DropLocMarker = nil
                }
                if VehicleMarker != nil {
                    VehicleMarker.map = nil
                    VehicleMarker = nil
                }
                
                if PikpuDisatanceMarker != nil {
                    PikpuDisatanceMarker.map = nil
                    PikpuDisatanceMarker = nil
                }
                
                VehicleMarker = CabMarker.init(Cab: TrackCabData.DriverDetails!)
                VehicleMarker.map = TrackMapView
                
                ZoomToWithSingleMarker(Position: VehicleMarker.position)

                if Double(TrackCabData.DropLoc.DropOfflat!) != 0  {
//                    PickLocMarker = PickUpMaker.init(Pickup: TrackCabData.PickupLoc!)
//                    PickLocMarker.map = TrackMapView
//                }
//                else {
//                    PickLocMarker = PickUpMaker.init(Pickup: TrackCabData.PickupLoc!)
//                    PickLocMarker.map = TrackMapView
                    
                    DropLocMarker = DropMaker.init(Drop: TrackCabData.DropLoc!)
                    DropLocMarker.map = TrackMapView
                }
                
                DriverDetailsView.isHidden = false
                SOSBtn.isHidden = false
                
                BottomStatusView.isHidden = true
            }
        }
        
        self.CurrentLocationBtn.isHidden = false

        self.JobIdShow.isHidden = true

        self.DriverSupportView.isHidden = true

        self.navigationItem.title = "ENJOY YOUR RIDE"

        PreviousState = Int("\(TrackCabData.JobStatus!)")!
        
        if self.navigationItem.rightBarButtonItem != nil {
            self.navigationItem.rightBarButtonItem = nil
        }

    }
    
    func TripCompleted() {
        /*
         
         job state 9 , 4 , 6 , 12
         
         Current Location Button
         
         Completed status on bottom with white View.
         
         show pickup and drop Loacation on map.
         
         navi Title Drive
         
         */
        
        if PreviousState == 100 {
            
            if PickLocMarker != nil {
                PickLocMarker.map = nil
                PickLocMarker = nil
            }
            if DropLocMarker != nil {
                DropLocMarker.map = nil
                DropLocMarker = nil
            }
            if VehicleMarker != nil {
                VehicleMarker.map = nil
                VehicleMarker = nil
            }
            if PikpuDisatanceMarker != nil {
                PikpuDisatanceMarker.map = nil
                PikpuDisatanceMarker = nil
            }
            
            
            if Double(TrackCabData.DropLoc.DropOfflat!) == 0  {
                PickLocMarker = PickUpMaker.init(Pickup: TrackCabData.PickupLoc!)
                PickLocMarker.map = TrackMapView
//                ZoomToWithSingleMarker(Position: PickLocMarker.position)
            }
            else {
                PickLocMarker = PickUpMaker.init(Pickup: TrackCabData.PickupLoc!)
                PickLocMarker.map = TrackMapView
                
                DropLocMarker = DropMaker.init(Drop: TrackCabData.DropLoc!)
                DropLocMarker.map = TrackMapView
                TrackTimer.invalidate()
//                TrackTimer = nil
                drawRoute()
//                ZoomToWithMultiMarker(Position1: PickLocMarker.position, Position2: DropLocMarker.position)
            }
            
            DriverDetailsView.isHidden = true
            SOSBtn.isHidden = true
            
            BottomStatusView.isHidden = false
        }
        else {
            
            if PreviousState == 9 || PreviousState == 4 || PreviousState == 12 || PreviousState == 6 {
                
                if Double(TrackCabData.DropLoc.DropOfflat!) == 0  {
                    PickLocMarker.position = CLLocationCoordinate2DMake(TrackCabData.PickupLoc.Pickuplat!, TrackCabData.PickupLoc.Pickuplon!)
//                    ZoomToWithSingleMarker(Position: PickLocMarker.position)
                }
                else {
                    
                    if DropLocMarker == nil {
                        PickLocMarker.position = CLLocationCoordinate2DMake(TrackCabData.PickupLoc.Pickuplat!, TrackCabData.PickupLoc.Pickuplon!)
//                        ZoomToWithSingleMarker(Position: PickLocMarker.position)
                    }
                    else {
                        PickLocMarker.position = CLLocationCoordinate2DMake(TrackCabData.PickupLoc.Pickuplat!, TrackCabData.PickupLoc.Pickuplon!)
                        DropLocMarker.position = CLLocationCoordinate2DMake(TrackCabData.DropLoc.DropOfflat!, TrackCabData.DropLoc.DropOfflon!)
                        TrackTimer.invalidate()
//                        TrackTimer = nil
                        drawRoute()
//                        ZoomToWithMultiMarker(Position1: PickLocMarker.position, Position2: DropLocMarker.position)
                    }
                }
                
            }
            else {
                
                if PickLocMarker != nil {
                    PickLocMarker.map = nil
                    PickLocMarker = nil
                }
                if DropLocMarker != nil {
                    DropLocMarker.map = nil
                    DropLocMarker = nil
                }
                if VehicleMarker != nil {
                    VehicleMarker.map = nil
                    VehicleMarker = nil
                }
                
                if PikpuDisatanceMarker != nil {
                    PikpuDisatanceMarker.map = nil
                    PikpuDisatanceMarker = nil
                }
                
                if Double(TrackCabData.DropLoc.DropOfflat!) == 0  {
                    PickLocMarker = PickUpMaker.init(Pickup: TrackCabData.PickupLoc!)
                    PickLocMarker.map = TrackMapView
//                    ZoomToWithSingleMarker(Position: PickLocMarker.position)
                }
                else {
                    PickLocMarker = PickUpMaker.init(Pickup: TrackCabData.PickupLoc!)
                    PickLocMarker.map = TrackMapView
                    
                    DropLocMarker = DropMaker.init(Drop: TrackCabData.DropLoc!)
                    DropLocMarker.map = TrackMapView
                    TrackTimer.invalidate()
//                    TrackTimer = nil
                    drawRoute()
//                    ZoomToWithMultiMarker(Position1: PickLocMarker.position, Position2: DropLocMarker.position)
                }
                
                DriverDetailsView.isHidden = true
                SOSBtn.isHidden = true
                
                BottomStatusView.isHidden = false
            }
        }
        
        self.CurrentLocationBtn.isHidden = true

        PreviousState = Int("\(TrackCabData.JobStatus!)")!

        self.navigationItem.title = "DRIVE"

        if self.navigationItem.rightBarButtonItem != nil {
            self.navigationItem.rightBarButtonItem = nil
        }
        
    }
    
    func drawRoute(){
        let originLat = Double(TrackCabData.PickupLoc.Pickuplat)
        let originLon = Double(TrackCabData.PickupLoc.Pickuplon)
        
        let originCoordinates = CLLocationCoordinate2D(latitude:originLat
            , longitude:originLon)
        
        let dropOffLat = Double(TrackCabData.DropLoc.DropOfflat)
        let dropOffLon = Double(TrackCabData.DropLoc.DropOfflon)
        
        let dropOffCoordinates = CLLocationCoordinate2D(latitude: dropOffLat, longitude: dropOffLon)
        
        
        let params = GParams.init(from: originCoordinates, to: dropOffCoordinates, waypoints: nil, travel_Mode: .default, alternatives: false, avoid: nil)
        
        GDirections.Directions(Params: params) { (reponse) in
            switch reponse.result {
            case .success(let directionData):
                
                
                
                let path = GMSPath.init(fromEncodedPath: (directionData.routes.first?.polyline)!)
                
                self.RoutePolyline = GMSPolyline.init(path: path)
                self.RoutePolyline.map = self.TrackMapView
                self.RoutePolyline.strokeWidth = 5
                self.RoutePolyline.strokeColor = UIColor.colorFromHexString("00B5F7")
                
                
                var coordinates = [CLLocationCoordinate2D]()
                coordinates.append(originCoordinates)
                for i in 0..<(path?.count())! {
                    coordinates.append((path?.coordinate(at: i))!)
                }
                coordinates.append(dropOffCoordinates)
                
                self.TrackMapView.ZoomtoMultiPositions(positions: coordinates, edges: UIEdgeInsetsMake(40, 40, 40, 40), animate: true)
                
                break
            case .failure(let error):
                print("Error from Direction = ",error)
                self.ZoomToWithMultiMarker(Position1: self.PickLocMarker.position, Position2: self.DropLocMarker.position)

                break
            }
        }
    }
    func TripCancellledState() {
        /*
         
         job state 11
         
         Request customer care to call back button on right top.
         
         Current Location Button
         
         Completed status on bottom with white View.
         
         navi Title Drive

         */
        
        
        if PreviousState == 100 {
            
            if PickLocMarker != nil {
                PickLocMarker.map = nil
                PickLocMarker = nil
            }
            if DropLocMarker != nil {
                DropLocMarker.map = nil
                DropLocMarker = nil
            }
            if VehicleMarker != nil {
                VehicleMarker.map = nil
                VehicleMarker = nil
            }
            if PikpuDisatanceMarker != nil {
                PikpuDisatanceMarker.map = nil
                PikpuDisatanceMarker = nil
            }
            
            PickLocMarker = PickUpMaker.init(Pickup: TrackCabData.PickupLoc!)
            PickLocMarker.map = TrackMapView
            
            DropLocMarker = DropMaker.init(Drop: TrackCabData.DropLoc!)
            DropLocMarker.map = TrackMapView
            
            ZoomToWithMultiMarker(Position1: PickLocMarker.position, Position2: DropLocMarker.position)
            
            
            DriverDetailsView.isHidden = true
            SOSBtn.isHidden = true
            
            BottomStatusView.isHidden = false
        }
        else {
            
            if PreviousState == 11 {
                
                PickLocMarker.position = CLLocationCoordinate2DMake(TrackCabData.PickupLoc.Pickuplat!, TrackCabData.PickupLoc.Pickuplon!)
                DropLocMarker.position = CLLocationCoordinate2DMake(TrackCabData.DropLoc.DropOfflat!, TrackCabData.DropLoc.DropOfflon!)
                ZoomToWithMultiMarker(Position1: PickLocMarker.position, Position2: DropLocMarker.position)
                
            }
            else {
                
                if PickLocMarker != nil {
                    PickLocMarker.map = nil
                    PickLocMarker = nil
                }
                if DropLocMarker != nil {
                    DropLocMarker.map = nil
                    DropLocMarker = nil
                }
                if VehicleMarker != nil {
                    VehicleMarker.map = nil
                    VehicleMarker = nil
                }
                if PikpuDisatanceMarker != nil {
                    PikpuDisatanceMarker.map = nil
                    PikpuDisatanceMarker = nil
                }
                
                PickLocMarker = PickUpMaker.init(Pickup: TrackCabData.PickupLoc!)
                PickLocMarker.map = TrackMapView
                
                DropLocMarker = DropMaker.init(Drop: TrackCabData.DropLoc!)
                DropLocMarker.map = TrackMapView
                
                ZoomToWithMultiMarker(Position1: PickLocMarker.position, Position2: DropLocMarker.position)
                
                DriverDetailsView.isHidden = true
                SOSBtn.isHidden = true
                
                BottomStatusView.isHidden = false
            }
        }
        
        self.CurrentLocationBtn.isHidden = true
        
        PreviousState = Int("\(TrackCabData.JobStatus!)")!

        self.navigationItem.title = "DRIVE"
        
        if self.navigationItem.rightBarButtonItem != nil {
            self.navigationItem.rightBarButtonItem = nil
        }

    }
    
    //MARK: - }
    
    func ZoomToWithSingleMarker(Position:CLLocationCoordinate2D) {
        let Camera = GMSCameraPosition.camera(withTarget: Position, zoom: 16.5)
        TrackMapView.animate(to: Camera)
    }
    
    func ZoomToWithMultiMarker(Position1:CLLocationCoordinate2D, Position2:CLLocationCoordinate2D) {
        
        var bounds = GMSCoordinateBounds()
        
        bounds = bounds.includingCoordinate(Position1)
        bounds = bounds.includingCoordinate(Position2)
        
        TrackMapView.animate(with: GMSCameraUpdate.fit(bounds, with: UIEdgeInsetsMake(40, 40, 120, 40)))
//        TrackMapView.animate(with: GMSCameraUpdate.fit(bounds, withPadding: 100))
    }
    
    @objc func TrackTimeBase() {
        
        if (Reachability()?.isReachable)! {
            let DriveRequest = ["MobileNo":"\(DriveBookingResponce.PhoneNo!)","JobNo":"\(TrackDetails.Jobno!)","EmpId":"\(DriveBookingResponce.EmpId!)","VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]

            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveGetBookingDetails, parameterDict: DriveRequest, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (TrackDict, responceCode, success) in
                
                if self.view.isLoading() {
                    self.view.StopLoading()
                }
                
                if success {
                    print("TrackDict = ",TrackDict)
                    if let Table = ((TrackDict as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                        
                        if "\(Table["Status"]!)" == "true" {
                            self.ParseVehicle(ResponceData: Table)
                        }
                        else {
//                            self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                        }
                    }
                    else {
//                        self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                    }
                }
                else {
                    self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                }
            })
        }
        else {
            
            if self.view.isLoading() {
                self.view.StopLoading()
            }
            
            self.view.ShowBlackTostWithText(message: Constants.NetErrorMsg, Interval: 2)
        }
        
    }
    
    
    func ParseVehicle(ResponceData:[String:AnyObject]) {
        
        TrackCabData = TrackVehicleStruct()
        print(TrackCabData)
        
        var Pickup = PickupLocStruct()
        
        Pickup.Pickuplat = Double("\(ResponceData["Pickuplat"]!)")!
        Pickup.Pickuplon = Double("\(ResponceData["Pickuplon"]!)")!
        Pickup.PickupAddress = "\(ResponceData["PickupAddress"]!)"
        
        TrackCabData.PickupLoc = Pickup
        
        
        var Drop = DropLocStruct()
        
        Drop.DropOfflat = Double("\(ResponceData["DropOfflat"]!)")!
        Drop.DropOfflon = Double("\(ResponceData["DropOfflon"]!)")!
        Drop.DropOffAddress = "\(ResponceData["DropOffAddress"]!)"
        
        TrackCabData.DropLoc = Drop
        
        
        var Driver = DriverDetailsStruct()
        
        Driver.VehicleLat = Double("\(ResponceData["VehicleLat"]!)")!
        Driver.VehicleLon = Double("\(ResponceData["VehicleLon"]!)")!
        Driver.DriverImage = "\(ResponceData["DriverImage"]!)"
        Driver.DriverName = "\(ResponceData["DriverName"]!)"
        Driver.DriverNo = "\(ResponceData["DriverNo"]!)"
        Driver.DriverRating = "\(ResponceData["DriverRating"]!)"
        Driver.ModelName = "\(ResponceData["ModelName"]!)"
        Driver.VehicleCategory = "\(ResponceData["VehicleCategory"]!)"
        Driver.VehicleIcon = "\(ResponceData["VehicleIcon"]!)"
        Driver.VehicleNo = "\(ResponceData["VehicleNo"]!)"
        
        TrackCabData.DriverDetails = Driver
        
        
        TrackCabData.Status = "\(ResponceData["Status"]!)"
        
        TrackCabData.PickupDatetime = "\(ResponceData["PickupDatetime"]!)"
        
        TrackCabData.PaymentStatus = "\(ResponceData["PaymentStatus"]!)"
        TrackCabData.PaymentType = "\(ResponceData["PaymentType"]!)"
        
        TrackCabData.JobMessage = "\(ResponceData["JobMessage"]!)"
        TrackCabData.JobStatus = "\(ResponceData["JobStatus"]!)"
        TrackCabData.Jobno = "\(ResponceData["Jobno"]!)"
        
        TrackCabData.Tariff = "\(ResponceData["Tariff"]!)"
        TrackCabData.TripFare = "\(ResponceData["TripFare"]!)"
        TrackCabData.TripMessage = "\(ResponceData["TripMessage"]!)"
        TrackCabData.TripType = "\(ResponceData["TripType"]!)"
        
        TrackCabData.AdvPaidAmount = "\(ResponceData["AdvPaidAmount"]!)"
        TrackCabData.AmountToBePaid = "\(ResponceData["AmountToBePaid"]!)"
        TrackCabData.OTP = "\(ResponceData["OTP"]!)"
        
        if "\(ResponceData["ReasonsForLowRating"]!)" != "" {
            var Reasons = "\(ResponceData["ReasonsForLowRating"]!)".components(separatedBy: "|")
            Reasons.removeLast()
            TrackCabData.ReasonsForLowRating = Reasons
        }
        TrackCabData.Rating = "\(ResponceData["Rating"]!)"

        TrackCabData.Callerid = "\(ResponceData["Callerid"]!)"
        
        TrackCabData.PaymentLink = ResponceData.keys.contains("PaymentLink") ? "\(ResponceData["PaymentLink"]!)" : "http://drivee.in/Merchantpay/Merchantcheckout.aspx?jobno=\(TrackCabData.Jobno!)"
        
        print(TrackCabData.JobStatus , TrackCabData.Jobno, TrackCabData.JobMessage, TrackCabData.AdvPaidAmount, TrackCabData.AmountToBePaid, TrackCabData.Rating, TrackCabData.TripMessage, TrackCabData.PaymentStatus,TrackCabData.PaymentType)
        
        AssignJobStates(JobStatus: Int("\(TrackCabData.JobStatus!)")!)
    }
    
    func AssignJobStates(JobStatus:Int) {
        
        BottomStatusLbl.text = TrackCabData.TripMessage!

        DriverNameLbl.text = TrackCabData.DriverDetails.DriverName!
        DriverVehicleNumberLbl.text = TrackCabData.DriverDetails.VehicleNo!
        DriverVehicleTypeLbl.text = TrackCabData.DriverDetails.VehicleCategory!
        
        let Rating = Double("\(TrackCabData.DriverDetails.DriverRating!)")
        DriverRating.text =  "\(round(Rating!))"
        
        JobIdShow.text = "OTP: " + TrackCabData.OTP!
        
        if !IsImageAssigned {
            if TrackCabData.DriverDetails.DriverImage != "" {
                DriverImage.af_setImage(withURL: URL.init(string: TrackCabData.DriverDetails.DriverImage!)!, placeholderImage: #imageLiteral(resourceName: "DriverProfile"), filter: nil, progress: nil, progressQueue: DispatchQueue.main, imageTransition: .noTransition, runImageTransitionIfCached: true, completion: { (ImageResponce) in
                    if ImageResponce.data != nil {
                        self.DriverImage.image = UIImage.init(data: ImageResponce.data!)
                        self.IsImageAssigned = true
                    }
                })
            }
        }
        
        if JobStatus == 13 || JobStatus == 21 || JobStatus == 0 {
            VehicleNotAssignedState()
        }
        else if JobStatus == 14 {
            VehicleAssignedState()
        }
        else if JobStatus == 1 || JobStatus == 6 {
            VehicleOntheWayState()
        }
        else if JobStatus == 3 {
            VehicleReachedPickupState()
        }
        else if JobStatus == 5 {
            EnjoyYourDriveState()
        }
        else if JobStatus == 9 || JobStatus == 4 || JobStatus == 12 || JobStatus == 6 {
            
            if TrackCabData.TripMessage!.caseInsensitiveCompare("completed") == .orderedSame /*&& TrackCabData.PaymentType == "Cash" && TrackCabData.TripFare! != "0" */{
                if !TrackCabData.Rating!.isEmpty {
                    if TrackCabData.Rating! == "0" {
                        GoToFeedbackPage(jobno: TrackCabData.Jobno!, Date: TrackCabData.PickupDatetime!, tripFare: TrackCabData.AmountToBePaid!, reasonsForLowRating: TrackCabData.ReasonsForLowRating, PaymentStatus: TrackCabData.PaymentStatus!, PaymentType: TrackCabData.PaymentType!, paymentLink: TrackCabData.PaymentLink!)
                    }
                    else {
                        TripCompleted()
                    }
                }
                else {
                    TripCompleted()
                }
            }
            else {
                
//                if (TrackCabData.TripMessage!.caseInsensitiveCompare("completed") == .orderedSame || TrackCabData.TripMessage!.caseInsensitiveCompare("pay") == .orderedSame) && (TrackCabData.Rating! == "0" || TrackCabData.PaymentStatus.toBool()!) && TrackCabData.TripFare != "0" {
//                    GoToFeedbackPage(jobno: TrackCabData.Jobno!, Date: TrackCabData.PickupDatetime!, tripFare: TrackCabData.AmountToBePaid!, reasonsForLowRating: TrackCabData.ReasonsForLowRating, PaymentStatus: TrackCabData.PaymentStatus!, PaymentType: TrackCabData.PaymentType!)
//                }
//                else {
                    TripCompleted()
//                }
            }
        }
        else if JobStatus == 11 {
            TripCancellledState()
        }
        else {
            VehicleNotAssignedState()
        }
    }
    
    func GoToFeedbackPage(jobno:String,Date:String,tripFare:String,reasonsForLowRating:[String],PaymentStatus:String,PaymentType:String, paymentLink: String) {
                
        let Feedback = self.storyboard?.instantiateViewController(withIdentifier: "DriveFeedbackVC") as! DriveFeedbackVC
        
        Feedback.jobno = jobno
        Feedback.Date = Date
        Feedback.tripFare = tripFare
        Feedback.reasonsForLowRating = reasonsForLowRating
        Feedback.PaymentStatus = PaymentStatus
        Feedback.PaymentType = PaymentType
        Feedback.PaymentLink = paymentLink
//        self.present(Feedback, animated: true, completion: nil)
        self.navigationController?.pushViewController(Feedback, animated: false)
    }
    
    struct TrackVehicleStruct {
        
        var Status:String!
        
        var PickupDatetime:String!
        
        var PaymentStatus:String!
        var PaymentType:String!
        
        var JobMessage:String!
        var JobStatus:String!
        var Jobno:String!
        
        var Tariff:String!
        var TripFare:String!
        var TripMessage:String!
        var TripType:String!
        
        var AdvPaidAmount:String!
        var AmountToBePaid:String!
        
        var Rating:String!
        var ReasonsForLowRating = [String]()
        
        var Callerid:String!
        var OTP: String!

        var PaymentLink: String!
        
        var PickupLoc: PickupLocStruct!
        var DropLoc: DropLocStruct!
        var DriverDetails: DriverDetailsStruct!
        
    }
    
    struct PickupLocStruct {
        var PickupAddress:String!
        var Pickuplat:Double!
        var Pickuplon:Double!
    }
    
    struct DropLocStruct {
        var DropOffAddress:String!
        var DropOfflat:Double!
        var DropOfflon:Double!
    }
    
    struct DriverDetailsStruct {
        
        var DriverNo:String!
        var DriverImage:String!
        var DriverName:String!
        var DriverRating:String!
        var VehicleNo:String!
        
        var VehicleCategory:String!
        var ModelName:String!
        var VehicleIcon:String!
        var VehicleLat:Double!
        var VehicleLon:Double!
        
    }
    
    class PickUpMaker:GMSMarker {
        init(Pickup: PickupLocStruct) {
            super.init()
            position = CLLocationCoordinate2DMake(Pickup.Pickuplat!,Pickup.Pickuplon!)
//            icon = UIImage.init(named: "GreenTrack")
            icon = UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "GreenTrack")!, to: CGSize.init(width: 34, height: 64))

            groundAnchor = CGPoint(x: 0.5, y: 1)
            appearAnimation = GMSMarkerAnimation.pop
        }
    }
    
    class DropMaker:GMSMarker {
        init(Drop: DropLocStruct) {
            super.init()
            position = CLLocationCoordinate2DMake(Drop.DropOfflat!,Drop.DropOfflon!)
//            icon = UIImage.init(named: "RedTrack")
            icon = UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "RedTrack")!, to: CGSize.init(width: 34, height: 64))

            groundAnchor = CGPoint(x: 0.5, y: 1)
            appearAnimation = GMSMarkerAnimation.pop
        }
    }
    
    class CabMarker: GMSMarker {
        init(Cab: DriverDetailsStruct) {
            super.init()
            position = CLLocationCoordinate2DMake(Cab.VehicleLat!,Cab.VehicleLon!)
            groundAnchor = CGPoint(x: 0.5, y: 1)
            appearAnimation = GMSMarkerAnimation.pop
            
            if "\(Cab.VehicleIcon!)" != "" && "\(Cab.VehicleIcon!)".contains("http") {
                DispatchQueue.global(qos: .userInteractive).async {
                    
                    if let url = URL.init(string: Cab.VehicleIcon.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!) {
                        if let ImgData = try? Data.init(contentsOf: url) {
                            DispatchQueue.main.async {
                                self.icon = UIImage.init(data: ImgData)
                            }
                        }
                        else {
                            self.icon = UIImage.init(named: "VehicleLocIcon")
                        }
                    }
                    
                }
            }
            else {
                self.icon = UIImage.init(named: "VehicleLocIcon")
            }
            
        }
        
    }

    class PickupDistanceMarker: GMSMarker {
        init(Pickup: PickupLocStruct) {
            super.init()
            position = CLLocationCoordinate2DMake(Pickup.Pickuplat!,Pickup.Pickuplon!)
            groundAnchor = CGPoint(x: 0.5, y: (1 * 0.27))
            appearAnimation = GMSMarkerAnimation.pop
        }
    }
    
    func LoadDistancefromCabToPickup(pickuplat:String,pickuplng:String,vehiclelat:String,vehiclelng:String, Completion: @escaping (String,Bool) -> Void) {
        
        if Double(pickuplat) == 0 {
            Completion("N/A",false)
        }
        else {
            if (Reachability()?.isReachable)! {
                
                DispatchQueue.global().async {
                    
                    let url = "https://maps.googleapis.com/maps/api/distancematrix/json?origins=" + pickuplat + "," + pickuplng + "&destinations=" + vehiclelat + "," + vehiclelng + "&sensor=false"
                    if let DistData = try? Data.init(contentsOf: URL.init(string: url)!) {
                        DispatchQueue.main.async {
                            if let DictJson = try? JSONSerialization.jsonObject(with: DistData, options: JSONSerialization.ReadingOptions.init(rawValue: 0)) as! [String:AnyObject] {

                                if "\(DictJson["status"]!)" == "OK" {
                                    let Rows = DictJson["rows"] as! [[String:AnyObject]]
                                    let Elements = Rows[0]["elements"] as! [[String:AnyObject]]
                                    let Element = Elements[0]
                                    
                                    if Element.keys.contains(where: {$0 == "status"}) {
                                        
                                        if "\(Element["status"]!)" == "OK" {
                                            let Duration = Element["duration"] as! [String:AnyObject]
                                            let DurationStr = "\(Duration["text"]!)"
                                            Completion(DurationStr,true)
                                        }
                                        else {
                                            Completion("N/A",true)
                                        }
                                    }
                                    else {
                                        let Duration = Element["duration"] as! [String:AnyObject]
                                        let DurationStr = "\(Duration["text"]!)"
                                        Completion(DurationStr,true)
                                    }
                                    
                                }
                                else {
                                    Completion("N/A",true)
                                }
                                
                            }
                            else {
                                Completion("N/A",true)
                            }
                        }
                    }
                    else {
                        Completion("N/A",true)
                    }
                    
                }
                
            }
            else {
                Completion("N/A",false)
            }
        }
        
    }
    
   
    
}
extension GMSMapView
{
    func ZoomtoMultiPositions(positions: [CLLocationCoordinate2D], edges: UIEdgeInsets, animate:Bool) {
        
        
        var bounds = GMSCoordinateBounds()
        
        for position in positions {
            bounds = bounds.includingCoordinate(position)
        }
        
        let CamUpdate = GMSCameraUpdate.fit(bounds, with: edges)
        
        if animate {
            self.animate(with: CamUpdate)
        }
        else {
            self.moveCamera(CamUpdate)
        }
    }
}


