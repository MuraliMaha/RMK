//
//  GLeg.swift
//  GDirections
//
//  Created by Raja Bhuma on 16/09/17.
//  Copyright © 2017 MyFriends. All rights reserved.
//

import UIKit
import CoreLocation

public struct GLeg {
    
    public let start_location: CLLocationCoordinate2D!
    
    public let end_location: CLLocationCoordinate2D!
    
    public let distance: (text:String,value:String)!
    
    public let duration: (text:String,value:String)!
    
    public let start_address: String!
    
    public let end_address: String!
    
    public let steps: [GStep]!
    
    public init(value: [String:Any]) {
        
        let Start = value["start_location"] as! [String:Any]
        
        let End = value["end_location"] as! [String:Any]
        
        start_location = CLLocationCoordinate2DMake(Double("\(Start["lat"]!)")!, Double("\(Start["lng"]!)")!)
        
        end_location = CLLocationCoordinate2DMake(Double("\(End["lat"]!)")!, Double("\(End["lng"]!)")!)
        
        
        let Dist = value["distance"] as! [String:Any]
        
        let Durat = value["duration"] as! [String:Any]
        
        distance = ("\(Dist["text"]!)","\(Dist["value"]!)")
        
        duration = ("\(Durat["text"]!)","\(Durat["value"]!)")
        
        start_address = value.keys.contains("start_address") ? "\(value["start_address"]!)" : "Invalid Location"
        
        end_address = value.keys.contains("end_address") ? "\(value["end_address"]!)" : "Invalid Location"
        
        steps = [GStep]()
        
        for step in (value["steps"] as! [[String:Any]]) {
            steps.append(GStep.init(value: step))
        }
    }
}

// MARK: - CustomStringConvertible & CustomDebugStringConvertible

extension GLeg: CustomStringConvertible, CustomDebugStringConvertible {
    
    public var description: String {
        return self.debugDescription
    }
    
    public var debugDescription: String {
        
        var Debug = [String]()
        
        Debug.append("start_location: \(start_location!), end_location: \(end_location!)")
        Debug.append("distance: \(distance!), duration: \(duration!)")
        Debug.append("[Steps]: \(steps!)")
        Debug.append("start_address: \(start_address!), end_address: \(end_address!)")
        
        return Debug.joined(separator: "\n")
    }
}

