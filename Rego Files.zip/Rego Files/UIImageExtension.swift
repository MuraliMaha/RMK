//
//  UIImageExtention.swift
//  DriveFindMyCab
//
//  Created by Raja Bhuma on 26/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

extension UIImage {
    
    func addText(_ drawText: NSString, atRect: CGRect, textColor: UIColor?, textFont: UIFont?) -> UIImage {
        
        // Setup the font specific variables
        var _textColor: UIColor
        if textColor == nil {
            _textColor = UIColor.white
        } else {
            _textColor = textColor!
        }
        
        var _textFont: UIFont
        if textFont == nil {
            _textFont = UIFont.systemFont(ofSize: 14)
        } else {
            _textFont = textFont!
        }
        
        // Setup the image context using the passed image
        UIGraphicsBeginImageContext(size)
        
        // Setup the font attributes that will be later used to dictate how the text should be drawn
        let textFontAttributes = [
            NSAttributedStringKey.font: _textFont,
            NSAttributedStringKey.foregroundColor: _textColor,
            ] as [NSAttributedStringKey : Any]
        
        // Put the image into a rectangle as large as the original image
        draw(in: CGRect(x: 0, y: 0, width: size.width, height: size.height))
        
        // Draw the text into an image
        drawText.draw(in: atRect, withAttributes: textFontAttributes)
        
        // Create a new image out of the images we have created
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        
        // End the context now that we have the image we need
        UIGraphicsEndImageContext()
        
        //Pass the image back up to the caller
        return newImage!
        
    }
    
    func MarkerByrenderSnapshot(_ Location:CLLocationCoordinate2D,_ size:CGSize, completion: @escaping (_ image:UIImage?,_ error:String?) -> Void) {
        let MapSnapShot = MKMapSnapshotOptions()
        MapSnapShot.size = size
        MapSnapShot.scale = UIScreen.main.scale
        
        let Span = MKCoordinateSpanMake(0.01, 0.01)
        MapSnapShot.region = MKCoordinateRegionMake(Location, Span)
        
        let Snapshotter = MKMapSnapshotter.init(options: MapSnapShot)
        Snapshotter.start { (snapshot, error) in
            if (error == nil) {
                let imageBack = (snapshot?.image)!
                let MarkImage = self
                
                UIGraphicsBeginImageContextWithOptions(imageBack.size, false, 0.0)
                imageBack.draw(in: CGRect.init(x: 0, y: 0, width: imageBack.size.width, height: imageBack.size.height))
                MarkImage.draw(in: CGRect.init(x: (imageBack.size.width/2) - (self.size.width/2) , y: (imageBack.size.height/2) - (self.size.height/2), width: self.size.width, height: self.size.height))
                let finalimage = UIGraphicsGetImageFromCurrentImageContext()
                UIGraphicsEndImageContext()
                completion(finalimage,nil)
            }
            else {
                completion(nil,"Error rendering snapshot for map at: (\(MapSnapShot.region.center.latitude), \(MapSnapShot.region.center.longitude)) with Error:\(String(describing: error?.localizedDescription))");
            }
        }
        
    }
    
    func ReduceImageSize(_ size:CGSize) -> UIImage {
        let canvasSize = CGSize.init(width: size.width , height:(size.width/self.size.width) * self.size.height)
        UIGraphicsBeginImageContextWithOptions(self.size, false, self.scale)
        self.draw(in: CGRect.init(x: 0, y: 0, width: canvasSize.width, height: canvasSize.height))
        let img = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return img!
    }
    
}

