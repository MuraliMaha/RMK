//
//  SuntelematicsWebViewVc.swift
//  DriveBooking
//
//  Created by SunTelematics on 25/09/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit
import Alamofire

protocol PaymentTransactionDelegate {
    func TransactionDidCancel(controller:PaymentPageVC)
    func TransactionDidComplete(Result:PaymentTransactionResult, controller:PaymentPageVC)
    
}
class PaymentPageVC: UIViewController {

    @IBOutlet weak var suntelematicsWebview: UIWebView!
    
    var RequestUrl: URL! = nil
    
    var paymentType : String!
    var JobNo : String!
    var amounttobepaid : String!
    
    var Delegate: PaymentTransactionDelegate!
    
    @IBOutlet weak var titleView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
//        BackBtnItem.tintColor = UIColor.black
//        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
//        self.navigationItem.leftBarButtonItem = BackBtnItem
        

        // Do any additional setup after loading the view.
        
        suntelematicsWebview.loadRequest(URLRequest.init(url: RequestUrl!))
        
    }
    
    @IBAction func backBtnTapped(_ sender: UIButton) {
        BackAction()
    }
    func BackAction() {
        self.Delegate.TransactionDidCancel(controller: self)
    }
        
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension PaymentPageVC : UIWebViewDelegate {
    
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        print(error.localizedDescription)
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        
        let Urls = ["http://drivee.in/Merchantpay/MobiKwikpaymentresponse.aspx",
                   "http://drivee.in/Merchantpay/Paytmpaymentresponse.aspx",
                   "http://drivee.in/Merchantpay/Payupaymentresponse.aspx"]
        
        if Urls.contains("\((webView.request?.url?.absoluteString)!)") {
            
            guard let finalstatus = webView.stringByEvaluatingJavaScript(from: "document.getElementById(\"finalstatus\").value") else {
                return
            }
            
            print(finalstatus)
            
            if finalstatus == "success" {
                let result = PaymentTransactionResult.success
                self.Delegate.TransactionDidComplete(Result: result, controller: self)
            }
            else {
                let result = PaymentTransactionResult.failure
                self.Delegate.TransactionDidComplete(Result: result, controller: self)
            }
            
        }
        
    }
    
}
enum PaymentTransactionResult {
    case success
    case failure
    
    public var isSuccess: Bool {
        switch self {
        case .success:
            return true
        case .failure:
            return false
        }
    }
    
    public var isFailure: Bool {
        return !isSuccess
    }
}
