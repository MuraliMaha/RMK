//
//  BookForOthers.swift
//  Drive Booking
//
//  Created by Amar on 19/04/17.
//  Copyright © 2017 suntelematics. All rights reserved.
//

import UIKit

class BookForOthers: UIViewController , UIGestureRecognizerDelegate {
    
    var sendBFOName : String! = ""
    var sendBFOMobile : String! = ""
    var sendBFO : String! = ""
    
    var previous: UINavigationController!
    
    @IBOutlet weak var mobileNumbertextField: UITextField!
    @IBOutlet weak var NametextField: UITextField!
    @IBOutlet weak var BookButton: UIButton!
    @IBOutlet weak var subview: UIView!
    
    @IBOutlet weak var bookNowBtn: UIButton!
    @IBOutlet weak var bookLaterBtn: UIButton!
    
    @IBOutlet weak var bookNowLaterView: UIView!
    
    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!
    
    var rideNowOrLater : String!
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.isNavigationBarHidden = true
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardHide(_:)), name: .UIKeyboardWillHide, object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        self.navigationController?.isNavigationBarHidden = false
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    
    @objc func keyboardShow(_ notification : NSNotification){
        self.view.frame.origin.y = 0
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            
            self.view.frame.origin.y -= 64
//            self.subview.frame.origin.y -= 64
            
        })
    }
    // MARK: - keyboard hide
    
    @objc func keyboardHide(_ notification : NSNotification)
    {
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.view.frame.origin.y = 0
//            self.subview.frame.origin.y = 64
        })
        
        
//        UIView.animate(withDuration: 0.3) {
//            self.view.frame.origin.y = 64
//        }
//
//        UIView.animate(withDuration: 0.3, animations: {
//            () -> Void in
//
//        })
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
         // Do any additional setup after loading the view.
        
//        self.navigationController?.isNavigationBarHidden = true
        self.LoginRequest = FetchDriveRequest()
        self.DriveBookingResponce = FetchDriveResponce()
        
         self.view.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.4)
        
        let gestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        gestureRecognizer.delegate = self
        self.view.addGestureRecognizer(gestureRecognizer)
        
        self.mobileNumbertextField.delegate = self
        self.NametextField.delegate = self
        
        
        if !(DriveBookingResponce.RideNowStatus?.toBool())! {
            self.bookNowLaterView.isHidden = true
        }
        else {
            self.bookNowLaterView.isHidden = false
        }
        
        
    }
    @objc func handleTap(_ responder: UITapGestureRecognizer){
        
        
        let Point = responder.location(in: self.view)
        let Frame = subview.frame
        
        if !Frame.contains(Point) {
             self.dismiss(animated: true, completion: nil)
        }

    }
    
    @IBAction func bookNowBtnTapped(_ sender: UIButton) {
        self.bookNowBtn.isSelected = true
        self.bookLaterBtn.isSelected = false
        resignTextFieldResponders()
        
    }
    
    @IBAction func bookLaterBtnTapped(_ sender: UIButton) {
        self.bookNowBtn.isSelected = false
        self.bookLaterBtn.isSelected = true
        resignTextFieldResponders()
    }
    
    @IBAction func bookAction(_ sender: UIButton) {
        resignTextFieldResponders()
        
        if mobileNumbertextField.text == ""{
            
        Message.shared.Alert(Title: "Alert", Message: "Please enter mobile number", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
  
        return
        }
        if !(mobileNumbertextField.text?.isValidMobileNumber())! {
 
            
          Message.shared.Alert(Title: "Alert", Message: "Please enter valid mobile number", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            
            return
        }
        if  mobileNumbertextField.text! == DriveBookingResponce.PhoneNo! {
            Message.shared.Alert(Title: "Alert", Message: "Login Number cannot be used for booking others", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            
             return
        
        }
        if NametextField.text == ""{
            Message.shared.Alert(Title: "Alert", Message: "Please enter Name", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            
             return
        }
        if !(NametextField.text?.isValidInput())!{
            Message.shared.Alert(Title: "Alert", Message: "Username should Contain Atleast 4 Characters", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            
              return
        }
        
        
        if !(DriveBookingResponce.RideNowStatus?.toBool())! {
            self.dismiss(animated: true, completion: nil)
            self.perform(#selector(Postnotif), with: nil, afterDelay: 0.5)
        }
        else {
            if !bookNowBtn.isSelected && !bookLaterBtn.isSelected {
                
                Message.shared.Alert(Title: "Alert", Message: "Please choose one option", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                
                return
            }
            //        self.dismiss(animated: true, completion: nil)
            
            self.dismiss(animated: true, completion: nil)
            
            if rideNowOrLater == "RideLater" {
                if bookNowBtn.isSelected {
                    let RideNow = self.storyboard?.instantiateViewController(withIdentifier: "RideNowVC") as! RideNowVC
                    let transition = CATransition()
                    transition.duration = 0.45
                    transition.type = kCATransitionFade;
                    transition.subtype = kCATransitionFromTop;
                    
                    previous.view.layer.add(transition, forKey: kCATransition)
                    previous.pushViewController(RideNow, animated: false)
                    
                    self.perform(#selector(Postnotif), with: nil, afterDelay: 1.5)
                    return
                }
                
                self.perform(#selector(Postnotif), with: nil, afterDelay: 0.5)
                
            }else{
                if !bookNowBtn.isSelected {
                    previous.popViewController(animated: true)
                    self.perform(#selector(Postnotif), with: nil, afterDelay: 1.5)
                    return
                }
                
                self.perform(#selector(Postnotif), with: nil, afterDelay: 0.5)
            }
        }
    }
    
    @objc func Postnotif() {
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "BOF"), object: nil, userInfo: ["Name":"\(NametextField.text!)","Number":"\(mobileNumbertextField.text!)"])
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    func resignTextFieldResponders(){
        NametextField.resignFirstResponder()
        mobileNumbertextField.resignFirstResponder()
    }
}

let ACCEPTABLE_CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"

extension BookForOthers : UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.resignFirstResponder()
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let cs = NSCharacterSet(charactersIn: ACCEPTABLE_CHARACTERS).inverted
        let filtered = string.components(separatedBy: cs).joined(separator: "")
        
        return (string == filtered)
    }
}
