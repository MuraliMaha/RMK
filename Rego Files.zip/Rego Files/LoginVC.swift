//
//  LoginVC.swift
//  DriveBooking
//
//  Created by Raja Bhuma on 13/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit
import OneSignal

class LoginVC: UIViewController, UITextFieldDelegate {

    @IBOutlet var MobileNoTxt: UITextField!
    @IBOutlet var PasswordTxt: UITextField!

    @IBOutlet var MobileNoLbl: UILabel!
    @IBOutlet var PasswordLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        MobileNoLbl.isHidden = true
        PasswordLbl.isHidden = true
//      self.view.updateFocusIfNeeded()
        
        
        
        self.navigationItem.backBarButtonItem?.title = " "
        self.navigationItem.leftBarButtonItem = UIBarButtonItem.init(title: " ", style: .done, target: nil, action: nil)
        
        
        self.perform(#selector(updateTextFields), with: self, afterDelay: 0.1)
    }
 
    @objc func updateTextFields(){
        MobileNoTxt.BottomLine = UIColor.black
        PasswordTxt.BottomLine = UIColor.black
     }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func LoginBtnPressed(_ sender:UIButton) {
        
        MobileNoTxt.resignFirstResponder()
        PasswordTxt.resignFirstResponder()

        var OneSignalID = ""
        let State = OneSignal.getPermissionSubscriptionState()
        if State?.permissionStatus.status == .authorized {
            if State?.subscriptionStatus.userId != nil {
                OneSignalID = "\((State?.subscriptionStatus.userId!)!)"
                print("OnesignalID::::",OneSignalID)
            }
        }
        
        if (MobileNoTxt.text?.isEmpty)! && (PasswordTxt.text?.isEmpty)! {
            self.view.ShowBlackTostWithText(message: "Please enter Mobile number and Password to Login", Interval: 3)
        }
            
        else if (MobileNoTxt.text?.isEmpty)! {
            self.view.ShowBlackTostWithText(message: "Please enter Mobile number", Interval: 3)
        }
            
        else if (PasswordTxt.text?.isEmpty)! {
            self.view.ShowBlackTostWithText(message: "Please enter Password", Interval: 3)
        }
            
        else if !(MobileNoTxt.text?.isValidMobileNumber())! {
            self.view.ShowBlackTostWithText(message: "Please enter valid Mobile number", Interval: 3)
        }
    
        else if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            let Cred = FetchDriveCredentials()!
            
            let version = "\(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString")!)"
            
            let Dict = ["UserName":self.MobileNoTxt.text!,
                        "Password":self.PasswordTxt.text!,
                        "VendorId":Cred.VendorId!,
                        "CorporateId":Cred.CorporateId!,
                        "AppCustomerType":Cred.AppCustomerType!,
                        "Version":version,
                        "DeviceToken":OneSignalID,
                        "DeviceIMEINO":UIDevice.current.identifierForVendor!.uuidString,
                        "DeviceType":UIDevice.current.systemName]
            
            print("LoginVC-LogininInput = ",Dict)
            
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveLogin, parameterDict: Dict, securityKey: WebServicesUrl.DummySecurity) { (value, responcecode, success) in
                print("LoginVC - Response",value,responcecode)
                self.view.StopLoading()

                if success {
                    let Table = (value as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
                    if "\(Table[0]["Status"]!)".toBool()! {
                        SaveDriveRequest(request: Dict)
                        SaveDriveResponce(DriveResponce: Table[0])
                        
                        let NavMain = self.storyboard?.instantiateViewController(withIdentifier: "LGSideMenu")
                        self.present(NavMain!, animated: true, completion: nil)
                    }
                    else {
                        print("LoginVC Status false =",value)
                        self.view.ShowBlackTostWithText(message: "\(Table[0]["Response"]!)", Interval: 3)
                    }
                    
                }
                else {
                    print("LoginVC failure =",responcecode.GetResponceCode())
                    self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                }
            }
        }
        else {
            self.view.ShowBlackTostWithText(message: "No Internet connection available", Interval: 3)
        }

    }
    
    @IBAction func ForgetBtnPressed(_ sender:UIButton) {
        DispatchQueue.main.async {
            let forgotpass = self.storyboard?.instantiateViewController(withIdentifier: "ForgotPassVC") as! ForgotPassVC
            self.navigationController?.pushViewController(forgotpass, animated: true)
        }
    }
    
    @IBAction func RegisterBtnPressed(_ sender:UIButton) {
        DispatchQueue.main.async {
            let REGISTER = self.storyboard?.instantiateViewController(withIdentifier: "RegisterVC") as! RegisterVC
            self.navigationController?.pushViewController(REGISTER, animated: true)
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == MobileNoTxt {
            MobileNoLbl.isHidden = false
            MobileNoTxt.placeholder = ""
        }
        else {
            PasswordLbl.isHidden = false
            PasswordTxt.placeholder = ""
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        CheckForLabels()
    }
    
    func CheckForLabels() {
        
        if !(MobileNoTxt.text?.isEmpty)! {
            MobileNoLbl.isHidden = false
        }
        else {
            MobileNoLbl.isHidden = true
        }
        
        if !(PasswordTxt.text?.isEmpty)! {
            PasswordLbl.isHidden = false
        }
        else {
            PasswordLbl.isHidden = true
        }
        
        MobileNoTxt.placeholder = "Mobile"
        PasswordTxt.placeholder = "Password"
    }
    
}
