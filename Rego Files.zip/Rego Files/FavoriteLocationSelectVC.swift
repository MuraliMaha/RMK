//
//  FavoriteLocationSelectVC.swift
//  DriveFindMyCab
//
//  Created by Amarnath B on 30/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit
import Alamofire

protocol FavoriteLocSelectDelegate {
    func DidCancelPicking(_ controller:FavoriteLocationSelectVC)
    func DidSelect(_ FavObj:FavouritesLocationsStruct,_ isfavorite:Bool,_ controller:FavoriteLocationSelectVC)
    func DidSelectChooseOnMap(_ controller:FavoriteLocationSelectVC)
}
class FavoriteLocationSelectVC: UIViewController {
    
    var IsSearchNeeded:Bool = true
    var isFavoritesNeeded : Bool = true
    
    var Delegate : FavoriteLocSelectDelegate!
    
    var SelectionDisable = false
    
    var SearchResultsArr = [PlacesStruct]()
    
    var FavoratesArr = [FavouritesLocationsStruct]()
    var DriveBookingResponce:DriveLoginResponce!
    var LoginRequest:DriveLoginRequest!
    var CurrentLocationDetails: CLLocationCoordinate2D!
    
    var isDrop = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        LoginRequest = FetchDriveRequest()
        DriveBookingResponce = FetchDriveResponce()
        // Do any additional setup after loading the view.
        
        //        first hit google Places API. If google api fails to give results or any error occurs while fetching googleplaces api hit local server API
        
        //        fetchFavorites()
        
        if IsSearchNeeded {
            ViewMakeWithSearch()
            
            SearchText.delegate = self
        }
        else {
            ViewMakeWithoutSearch()
        }
        
        SearchTable.estimatedRowHeight = 45
        SearchTable.rowHeight = UITableViewAutomaticDimension
        
        SearchTable.delegate = self
        SearchTable.dataSource = self
        SearchTable.reloadData()
    }
    func fetchFavorites() {
        guard FetchFavouritesLocation() != nil else {
            return
        }
        
        FavoratesArr = FetchFavouritesLocation()!
        print("******FAV******")
        print(FavoratesArr)
    }
    
    var SearchTable : UITableView!
    var SearchText: UITextField!
    
    
    //fetch places data from googlewebservice API
    
    let SelectOnMapButton = UIButton.init()
    
    func ViewMakeWithSearch() {
        
        let SearchView = UIView.init()
        SearchView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(SearchView)
        
        SearchTable = UITableView.init()
        SearchTable.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(SearchTable)
        
        
        let SelectPin = UIView.init()
        SelectPin.translatesAutoresizingMaskIntoConstraints = false
        SelectPin.backgroundColor = UIColor.white
        if isDrop {
            self.view.addSubview(SelectPin)
            
            SelectOnMapButton.translatesAutoresizingMaskIntoConstraints = false
            SelectOnMapButton.tintColor = UIColor.clear
            //            SelectOnMapButton.titleLabel?.textAlignment = .left
            SelectOnMapButton.contentHorizontalAlignment = .left
            
            SelectOnMapButton.setTitleColor(UIColor.black, for: .normal)
            SelectOnMapButton.setTitle("         Select Location On Map", for: .normal)
            SelectOnMapButton.backgroundColor = UIColor.white
            SelectOnMapButton.addTarget(self, action: #selector(SelectOnMapButtonAction(_:)), for: .touchUpInside)
            
            SelectPin.addSubview(SelectOnMapButton)
            
            let MapImg = UIImageView.init()
            MapImg.image = #imageLiteral(resourceName: "placeholder")
            MapImg.translatesAutoresizingMaskIntoConstraints = false
            MapImg.contentMode = .scaleAspectFit
            MapImg.backgroundColor = UIColor.clear
            SelectPin.addSubview(MapImg)
            
            let line = UIView.init()
            line.translatesAutoresizingMaskIntoConstraints = false
            line.backgroundColor = UIColor.init(hex: "AAAAAA", alpha: 0.5)
            SelectPin.addSubview(line)
            
            
            let InfoDict:[String:Any] = ["SelectOnMapButton":SelectOnMapButton,"line":line,"MapImg":MapImg]
            
            NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-6-[SelectOnMapButton]-6-|", options: .alignAllCenterX, metrics: nil, views: InfoDict))
            NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-12-[MapImg(30)]", options: .alignAllLeft, metrics: nil, views: InfoDict))
            NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[line]-0-|", options: .alignAllCenterX, metrics: nil, views: InfoDict))
            NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-6-[SelectOnMapButton]-6-[line(1)]-0-|", options: .alignAllCenterX, metrics: nil, views: InfoDict))
            NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-6-[MapImg(42)]", options: .alignAllCenterY, metrics: nil, views: InfoDict))
            
        }
        
        let InfoDict:[String:Any] = ["SearchView":SearchView,"SearchTable":SearchTable,"SelectPin":SelectPin,"self":self.view]
        
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[SearchView]-0-|", options: .alignAllCenterX, metrics: nil, views: InfoDict))
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[SearchTable]-0-|", options: .alignAllCenterX, metrics: nil, views: InfoDict))
        
        if isDrop {
            NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[SelectPin]-0-|", options: .alignAllCenterX, metrics: nil, views: InfoDict))
            NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[SearchView(75)]-0-[SelectPin(55)]-0-[SearchTable]-4-|", options: .alignAllCenterX, metrics: nil, views: InfoDict))
        }
        else {
            NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[SearchView(75)]-4-[SearchTable]-4-|", options: .alignAllCenterX, metrics: nil, views: InfoDict))
        }
        
        SearchTable.backgroundColor = UIColor.white
        SearchView.backgroundColor = UIColor.darkGray
        
        SearchTable.tableFooterView = UIView.init(frame: CGRect.zero)
        
        
        let BackButton = UIButton.init()
        BackButton.setImage(UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 24, height: 24)), for: .normal)
        BackButton.tintColor = UIColor.clear
        BackButton.addTarget(self, action: #selector(BackAction), for: .touchUpInside)
        BackButton.backgroundColor = UIColor.clear
        
        BackButton.translatesAutoresizingMaskIntoConstraints = false
        
        SearchView.addSubview(BackButton)
        
        
        let searchTextView = UIView.init()
        searchTextView.translatesAutoresizingMaskIntoConstraints = false
        
        searchTextView.backgroundColor = UIColor.white
        searchTextView.layer.shadowColor = UIColor.white.cgColor
        searchTextView.layer.shadowOffset = CGSize.zero
        searchTextView.layer.shadowRadius = 2
        searchTextView.layer.shadowOpacity = 0.4
        
        searchTextView.layer.cornerRadius = 3
        
        SearchView.addSubview(searchTextView)
        
        let InfoDict2 = ["SearchView":SearchView,"BackButton":BackButton,"searchTextView":searchTextView]
        
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-2-[BackButton]-2-[searchTextView]-8-|", options: [], metrics: nil, views: InfoDict2))
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-31-[BackButton]-4-|", options: [], metrics: nil, views: InfoDict2))
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-31-[searchTextView]-4-|", options: [], metrics: nil, views: InfoDict2))
        
        NSLayoutConstraint(item: BackButton, attribute: .width, relatedBy: .equal, toItem: nil, attribute:.notAnAttribute, multiplier: 1, constant:40).isActive = true
        
        
        
        
        SearchText = UITextField.init()
        SearchText.backgroundColor = UIColor.clear
        SearchText.translatesAutoresizingMaskIntoConstraints = false
        SearchText.placeholder = "Search Location"
        SearchText.font = UIFont.systemFont(ofSize: 15)
        
        SearchText.returnKeyType = .search
        SearchText.autocorrectionType = .no
        //        SearchText.DoneBtn = true
        searchTextView.addSubview(SearchText)
        let InfoDict3 = ["SearchText":SearchText,"searchTextView":searchTextView]
        
        
        
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-4-[SearchText]-4-|", options: [], metrics: nil, views: InfoDict3))
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-8-[SearchText]-8-|", options: [], metrics: nil, views: InfoDict3))
        
        
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        //        toolBar.tintColor = UIColor(red: 76/255, green: 217/255, blue: 100/255, alpha: 1)
        toolBar.tintColor = UIColor.blue
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action:#selector(donePicker))
        
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.plain, target: self, action:#selector(cancelPicker))
        
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        toolBar.sizeToFit()
        SearchText.delegate = self
        SearchText.inputAccessoryView = toolBar
        
        
        if isDrop {
            self.perform(#selector(LoadShadow), with: self, afterDelay: 0.2)
        }
        
        self.perform(#selector(footerview), with: self, afterDelay: 0.2)
    }
    
    @objc func footerview(){
        let footerview = UIView()
        footerview.frame = CGRect(x: 0, y: 0, width: SearchTable.frame.width, height: 45)
        footerview.backgroundColor = UIColor.clear
        
        let FooterImage     = UIImageView()
        FooterImage.frame   = CGRect(x: 0, y: 15, width: SearchTable.frame.width, height: 15)
        FooterImage.contentMode = .scaleAspectFit
        
        FooterImage.image   = #imageLiteral(resourceName: "pwdgoogle")
        footerview.addSubview(FooterImage)
        SearchTable.tableFooterView = footerview
        
        fetchFavorites()
        SearchTable.reloadData()
    }
    @objc func LoadShadow() {
        self.SelectOnMapButton.layer.masksToBounds = false
        self.SelectOnMapButton.layer.shadowColor = UIColor.black.cgColor
        self.SelectOnMapButton.layer.shadowOpacity = 0.35
        self.SelectOnMapButton.layer.shadowOffset = CGSize.zero
        self.SelectOnMapButton.layer.shadowRadius = 2
        
        self.SelectOnMapButton.layer.shadowPath = UIBezierPath(rect: self.SelectOnMapButton.bounds).cgPath
    }
    
    @objc func SelectOnMapButtonAction(_ sender:UIButton) {
        Delegate.DidSelectChooseOnMap(self)
    }
    
    @objc func donePicker(sender : UIBarButtonItem){
        var Struct = FavouritesLocationsStruct()
        Struct.Latitude = nil
        Struct.Longitude = nil
        Struct.Location = SearchText.text!
        self.Delegate.DidSelect(Struct, false, self)
        
    }
    
    @objc func cancelPicker(sender : UIBarButtonItem){
        SearchText.resignFirstResponder()
    }
    
    func ViewMakeWithoutSearch() {
        
        let SearchView = UIView.init()
        SearchView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(SearchView)
        
        SearchTable = UITableView.init()
        SearchTable.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(SearchTable)
        
        let InfoDict:[String:Any] = ["SearchView":SearchView,"SearchTable":SearchTable,"self":self.view]
        
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[SearchView]-0-|", options: .alignAllCenterX, metrics: nil, views: InfoDict))
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[SearchTable]-0-|", options: .alignAllCenterX, metrics: nil, views: InfoDict))
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[SearchView]-4-[SearchTable]-4-|", options: .alignAllCenterX, metrics: nil, views: InfoDict))
        
        NSLayoutConstraint(item: SearchView, attribute: .height, relatedBy: .equal, toItem: nil, attribute:.notAnAttribute, multiplier: 1, constant:75).isActive = true
        
        SearchTable.backgroundColor = UIColor.white
        SearchView.backgroundColor = UIColor.darkGray
        
        SearchTable.tableFooterView = UIView.init(frame: CGRect.zero)
        
        
        let BackButton = UIButton.init()
        BackButton.setImage(UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 24, height: 24)), for: .normal)
        BackButton.tintColor = UIColor.clear
        BackButton.addTarget(self, action: #selector(BackAction), for: .touchUpInside)
        BackButton.backgroundColor = UIColor.clear
        
        BackButton.translatesAutoresizingMaskIntoConstraints = false
        
        SearchView.addSubview(BackButton)
        
        
        let InfoDict2 = ["SearchView":SearchView,"BackButton":BackButton]
        
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-31-[BackButton]-4-|", options: .alignAllCenterY, metrics: nil, views: InfoDict2))
        
        NSLayoutConstraint(item: BackButton, attribute: .width, relatedBy: .equal, toItem: nil, attribute:.notAnAttribute, multiplier: 1, constant:40).isActive = true
        NSLayoutConstraint(item: BackButton, attribute: .leading, relatedBy: .equal, toItem: SearchView, attribute: .leading, multiplier: 1, constant:4).isActive = true
        
        self.perform(#selector(footerview), with: self, afterDelay: 0.2)
    }
    
    @objc func BackAction() {
        Delegate.DidCancelPicking(self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

extension FavoriteLocationSelectVC:UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if SearchResultsArr.count == 0 {
            return isFavoritesNeeded ? FavoratesArr.count : 0
        }
        else {
            return SearchResultsArr.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if SearchResultsArr.count == 0 {
            let cell = FavTBCell()
            cell.setupCell()
            cell.Title.text = "\(FavoratesArr[indexPath.row].Location!)"
            cell.selectionStyle = .none
            return cell
        }
        else {
            let cell = LocSearchTBCell()
            cell.setupCell()
            cell.Title.text = "\(SearchResultsArr[indexPath.row].Title!)"
            cell.selectionStyle = .none
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        if SearchResultsArr.count == 0 {
            return true
        }
        else {
            return false
        }
    }
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        if SearchResultsArr.count == 0 {
            let DeleteAction = UITableViewRowAction.init(style: .destructive, title: "Delete") { (action, DeleteIndex) in
                self.SearchTable.beginUpdates()
                self.FavoratesArr.remove(at: DeleteIndex.row)
                self.SearchTable.deleteRows(at: [DeleteIndex], with: .automatic)
                self.SearchTable.endUpdates()
                
                self.DeleteFavLocation()
            }
            return [DeleteAction]
        }
        
        return nil
    }
    
    //delete saved locations in favourates
    
    func DeleteFavLocation() {
        
        self.view.endEditing(true)
        
        UIApplication.shared.keyWindow?.StartLoading()
        
        var StringObj = ""
        for FavStrObj in self.FavoratesArr {
            let Str = "\(FavStrObj.Latitude!)" + "|" + "\(FavStrObj.Longitude!)" + "|" + "\(FavStrObj.Location!)" + "~"
            StringObj.append(Str)
        }
        
        let FavDict = ["EmpId":"\(DriveBookingResponce.EmpId!)","Favourites":StringObj,"VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
        
        WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveSetFavouritePlaces, parameterDict: FavDict, securityKey: DriveBookingResponce.AuthenticationToken!) { (ResponceDict, responceDoce, success) in
            
            UIApplication.shared.keyWindow?.StopLoading()
            
            if success {
                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Favorite location deleted successfully", Interval: 3)
                SaveFavoritesAs(FavoritesStructArr: self.FavoratesArr)
            }
            else {
                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if !SelectionDisable {
            
            if SearchResultsArr.count == 0 {
                Delegate.DidSelect(FavoratesArr[indexPath.row], true, self)
            }
            else {
                LoadFromSearch(SearchResultsArr[indexPath.row])
            }
        }
    }
    
    
    //    get lat and lon using placeID in googleplace details API
    func LoadFromSearch(_ Place:PlacesStruct) {
        
        self.view.StartLoading()
        //        AIzaSyAE5UblSko0JCqUC05-bag8gjZFpTAicuA
        
        
        
        if Place.isfromService == true{
            var Struct = FavouritesLocationsStruct()
            Struct.Latitude = Place.lat!
            Struct.Longitude = Place.lon!
            Struct.Location = Place.Title!
            self.Delegate.DidSelect(Struct, false, self)
        }else{
            var UrlStr = "https://maps.googleapis.com/maps/api/place/details/json?" + "placeid=\(Place.ID!)&key=\(DriveBookingResponce.MapApiKey!)"
            //        gme-suntelematicsprivate
            UrlStr = UrlStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
            
            let urlRequest  = URLRequest.init(url: URL.init(string: UrlStr)!)
            Alamofire.request(urlRequest)
                .responseJSON { (DataResponce) in
                    
                    self.view.StopLoading()
                    print(DataResponce)
                    switch DataResponce.result {
                    case .success(let value):
                        
                        let val = value as! [String:AnyObject]
                        if let result:[String:AnyObject] = val["result"] as? [String:AnyObject] {
                            if let geometry:[String:AnyObject] = result["geometry"] as? [String:AnyObject] {
                                if let Location:[String:AnyObject] = geometry["location"] as? [String:AnyObject] {
                                    
                                    var Lat:Double = 0
                                    var Lon:Double = 0
                                    
                                    if let latitude = Location["lat"],
                                        (latitude is NSNumber || latitude is String) {
                                        Lat = Double("\(latitude)")!
                                    }
                                    if let longitude = Location["lng"],
                                        (longitude is NSNumber || longitude is String) {
                                        Lon = Double("\(longitude)")!
                                    }
                                    
                                    var Struct = FavouritesLocationsStruct()
                                    Struct.Latitude = Lat
                                    Struct.Longitude = Lon
                                    Struct.Location = Place.Title!
                                    
                                    self.Delegate.DidSelect(Struct, false, self)
                                    
                                }
                            }
                        }
                        
                        break
                    case .failure(_):
                        self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                        break
                    }
                    
            }
        }
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let currentString: NSString = NSString.init(string: textField.text!)
        let searchTxt =
            currentString.replacingCharacters(in: range, with: string)
        if searchTxt.count == 0 {
            SearchResultsArr.removeAll()
            self.SearchTable.reloadData()
        }
        else if searchTxt.count >= 3{
            
            var UrlStr = "https://maps.googleapis.com/maps/api/place/autocomplete/json?" + "input=\(searchTxt.replacingOccurrences(of: " ", with: "+"))&sensor=true&key=\(DriveBookingResponce.MapApiKey!)&components=country:IN"
            
            UrlStr = UrlStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
            
            let urlRequest  = URLRequest.init(url: URL.init(string: UrlStr)!)
            Alamofire.request(urlRequest)
                .responseJSON { (DataResponce) in
                    
                    print(DataResponce)
                    
                    switch DataResponce.result {
                    case .success(let value):
                        self.SearchResultsArr.removeAll()
                        
                        let val = value as! [String:AnyObject]
                        if let dataarr:[[String:AnyObject]] = val["predictions"] as? [[String:AnyObject]] {
                            if dataarr.count > 0{
                                for dataObj in dataarr {
                                    var structobj = PlacesStruct()
                                    structobj.Title = dataObj["description"] as! String
                                    structobj.ID = dataObj["place_id"] as! String
                                    self.SearchResultsArr.append(structobj)
                                }
                            }
                        }
                        self.SearchTable.reloadData()
                        break
                    case .failure(_):
                        self.SearchResultsArr.removeAll()
                        self.SearchTable.reloadData()
                        break
                    }
            }
            //
        }
        
        
        return true
    }
    func FilterData(_ str:String) -> [String:AnyObject]? {
        let data = str.data(using: .utf8)
        if let dict:[String:AnyObject] = try? JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [String:AnyObject] {
            return dict
        }
        else {
            return nil
        }
    }
    
    
    //user entered text should be >=3 then only hit places API. if it is lessthan 3 charecters dont googlePLACES API
    func callGooglePlacesAPI(){
        
        //        let currentString: NSString = NSString.init(string: textStr)
        //        let searchTxt = currentString.replacingCharacters(in: range, with: string)
        
        if (SearchText.text?.count)! >= 3 {
            
            
            
            var UrlStr = "https://maps.googleapis.com/maps/api/place/autocomplete/json?" + "input=\(SearchText.text!)&sensor=true&key=\(DriveBookingResponce.MapApiKey!)&components=country:IN"
            
            //          var UrlStr = "http://192.168.1.30/GoogleLocation/GoogleLocation.asmx/getAutoComplete?searchString=\(searchTxt)"
            
            UrlStr = UrlStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
            
            let urlRequest  = URLRequest.init(url: URL.init(string: UrlStr)!)
            Alamofire.request(urlRequest)
                .responseJSON { (DataResponce) in
                    
                    print(DataResponce)
                    
                    switch DataResponce.result {
                    case .success(let value):
                        self.SearchResultsArr.removeAll()
                        
                        let val = value as! [String:AnyObject]
                        if let dataarr:[[String:AnyObject]] = val["predictions"] as? [[String:AnyObject]] {
                            if dataarr.count > 0{
                                for dataObj in dataarr {
                                    var structobj = PlacesStruct()
                                    structobj.Title = dataObj["description"] as! String
                                    structobj.ID = dataObj["place_id"] as! String
                                    self.SearchResultsArr.append(structobj)
                                }
                            }
                        }else{
                            //                            self.fetchGooglePlaces(textFieldText: searchTxt)
                        }
                        self.SearchTable.reloadData()
                        break
                    case .failure(_):
                        self.SearchResultsArr.removeAll()
                        self.SearchTable.reloadData()
                        break
                    }
            }
            //
        }
        if (SearchText.text!).characters.count == 0 {
            SearchResultsArr.removeAll()
            self.SearchTable.reloadData()
        }
        
    }
}

class FavTBCell:UITableViewCell {
    
    var Title:UILabel!
    var StarImg:UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    func setupCell()
    {
        Title = UILabel.init()
        Title.translatesAutoresizingMaskIntoConstraints = false
        Title.textColor = UIColor.black
        Title.backgroundColor = UIColor.clear
        Title.numberOfLines = 6
        self.contentView.addSubview(Title)
        
        StarImg = UIImageView.init()
        StarImg.translatesAutoresizingMaskIntoConstraints = false
        self.contentView.addSubview(StarImg)
        StarImg.contentMode = .scaleAspectFit
        StarImg.image = #imageLiteral(resourceName: "StarFilled")
        
        let InfoDict = ["Title":Title,"StarImg":StarImg,"self":self.contentView]
        
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-8-[Title]-8-[StarImg]-8-|", options: [], metrics: nil, views: InfoDict))
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-6-[Title]-6-|", options: [], metrics: nil, views: InfoDict))
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-6-[StarImg]-6-|", options: [], metrics: nil, views: InfoDict))
        
        NSLayoutConstraint(item: StarImg, attribute: .width, relatedBy: .equal, toItem: nil, attribute:.notAnAttribute, multiplier: 1, constant:30).isActive = true
    }
}

class LocSearchTBCell:UITableViewCell {
    
    var Title:UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    func setupCell()
    {
        Title = UILabel.init()
        Title.translatesAutoresizingMaskIntoConstraints = false
        Title.numberOfLines = 6
        Title.textColor = UIColor.black
        Title.backgroundColor = UIColor.clear
        
        self.contentView.addSubview(Title)
        
        
        let InfoDict = ["Title":Title,"self":self.contentView]
        
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "H:|-8-[Title]-8-|", options: [], metrics: nil, views: InfoDict))
        NSLayoutConstraint.activate(NSLayoutConstraint.constraints(withVisualFormat: "V:|-6-[Title]-6-|", options: [], metrics: nil, views: InfoDict))
        
        NSLayoutConstraint.init(item: Title, attribute: .height, relatedBy: .greaterThanOrEqual, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 40).isActive = true
        
    }
    
}

