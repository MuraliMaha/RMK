//
//  DriveFeedbackVC.swift
//  DriveFindMyCab
//
//  Created by Raja Bhuma on 26/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit
protocol feedbackdismiss {
    func dismiss(controller: DriveFeedbackVC)
}
class DriveFeedbackVC: UIViewController, FloatRatingViewDelegate, UIPickerViewDelegate,UIPickerViewDataSource {
    
    
    
    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!
    
    var jobno:String!
    var Date:String!
    var tripFare:String!
    var reasonsForLowRating = [String]()
    var PaymentStatus:String!
    var PaymentType:String!
    var AmountTobePaid:String!
    
    var PaymentLink: String!
    
    @IBOutlet var NameLbl:UILabel!
    
    @IBOutlet var DataLbl:UILabel!
    @IBOutlet var FareMoneyLbl:UILabel!
    @IBOutlet var ByCashLbl:UILabel!
    @IBOutlet var Rating:FloatRatingView!
    
    @IBOutlet var FeedbackTxt:UITextField!
    @IBOutlet weak var feedbackView: UIView!
    
    var feedbackdelegate : feedbackdismiss!
    
    @IBOutlet weak var pleaseRateurRideLabel: UILabel!
    @IBOutlet weak var payButton: UIButton!
    @IBAction func payButtonTapped(_ sender: UIButton) {
        
        func CallThisAfterThat() {
            let Appendstr = PaymentLink!
            let PaymentUrl = URL.init(string: Appendstr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!
            
            let paymentController = self.storyboard?.instantiateViewController(withIdentifier: "PaymentPageVC") as! PaymentPageVC
            
            paymentController.paymentType = PaymentType
            paymentController.JobNo = jobno
            paymentController.amounttobepaid = tripFare
            paymentController.RequestUrl = PaymentUrl
            paymentController.Delegate = self
            paymentController.modalTransitionStyle = .coverVertical
            
            self.present(paymentController, animated: true, completion: nil)
        }
        
        func MoveToHome() {
            self.DriveBookingResponce.RatingDetails = "NA"
            saveDriveResponceStuct(driveStruct: self.DriveBookingResponce!)
            let NavMain = self.storyboard?.instantiateViewController(withIdentifier: "LGSideMenu")
            self.present(NavMain!, animated: true, completion: nil)
        }
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            let DriveRequest = ["MobileNo":"\(DriveBookingResponce.PhoneNo!)","JobNo":"\(jobno!)","EmpId":"\(DriveBookingResponce.EmpId!)","VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
            
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveGetBookingDetails, parameterDict: DriveRequest, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (TrackDict, responceCode, success) in
                
                if self.view.isLoading() {
                    self.view.StopLoading()
                }
                
                if success {
                    print("Ratinng Track Trip = ",TrackDict)
                    if let Table = ((TrackDict as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                        
                        if "\(Table["Status"]!)" == "true" {
                            
                            let JobStatus = Int("\(Table["JobStatus"]!)")
                            
                            let TripMessage = "\(Table["TripMessage"]!)"
                            
                            let Rating = "\(Table["Rating"]!)"
                            
                            let newPaymentStatus = "\(Table["PaymentStatus"]!)"
                            
                            if JobStatus == 9 || JobStatus == 4 || JobStatus == 12 || JobStatus == 6 {
                                
                                if TripMessage.caseInsensitiveCompare("completed") == .orderedSame {
                                    
                                    if !Rating.isEmpty {
                                        
                                        if Rating == "0" {
                                            
                                            if !newPaymentStatus.toBool()! {
                                                self.ByCashLbl.isHidden = true
                                                self.pleaseRateurRideLabel.isHidden = true
                                                self.payButton.isHidden = false
                                                self.Rating.isHidden = true
                                                self.FeedbackTxt.isHidden = true
                                                self.feedbackView.isHidden = true
                                                CallThisAfterThat()
                                            }else {
                                                self.ByCashLbl.isHidden = false
                                                self.pleaseRateurRideLabel.isHidden = false
                                                self.payButton.isHidden = true
                                                self.Rating.isHidden = false
                                                self.FeedbackTxt.isHidden = false
                                                self.feedbackView.isHidden = false
                                            }
                                            
                                        }
                                        else {
                                            MoveToHome()
                                        }
                                    }
                                    else {
                                        MoveToHome()
                                    }
                                }
                                else {
                                    MoveToHome()
                                }
                            }
                            
                        }
                        else {
                            self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                        }
                    }
                    else {
                        self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                    }
                }
                else {
                    self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                }
            })
        }
        else {
            self.view.ShowBlackTostWithText(message: Constants.NetErrorMsg, Interval: 2)
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.LoginRequest = FetchDriveRequest()
        self.DriveBookingResponce = FetchDriveResponce()
        
        NameLbl.text = self.DriveBookingResponce.Name!.capitalized
        DataLbl.text = Date!
        FareMoneyLbl.text = "Rs " + String.init(format: "%.2f", Double(tripFare!) ?? 0.0)
        
        ByCashLbl.text = "Payable in " + PaymentType!.capitalized
        
        print(PaymentType! , PaymentStatus!)
        Rating.delegate = self
        // PaymentStatus false means,paying by card
        if PaymentStatus == "false" {
            ByCashLbl.isHidden = true
            pleaseRateurRideLabel.isHidden = true
            payButton.isHidden = false
            Rating.isHidden = true
            FeedbackTxt.isHidden = true
            feedbackView.isHidden = true
            
        }else {
            ByCashLbl.isHidden = false
            pleaseRateurRideLabel.isHidden = false
            payButton.isHidden = true
            Rating.isHidden = false
            FeedbackTxt.isHidden = false
            feedbackView.isHidden = false
        }
        
        //        if TripType!.contains("StreetJob"){
        //            if PaymentStatus! == "false"{
        //                ByCashLbl.isHidden = true
        //                pleaseRateurRideLabel.isHidden = true
        //                PayButton.isHidden = false
        //                Rating.isHidden = true
        //                feedbacktextView.isHidden = true
        //
        //            }else{
        //                pleaseRateurRideLabel.isHidden = false
        //                PayButton.isHidden = true
        //                Rating.isHidden = false
        //                FeedbackTxt.isHidden = false
        //            }
        //        }
        //        else{
        //            ByCashLbl.isHidden = false
        //            pleaseRateurRideLabel.isHidden = false
        //            PayButton.isHidden = true
        //            Rating.isHidden = false
        //            FeedbackTxt.isHidden = false
        //        }
        //        ByCashLbl.text = "Payable in " + PaymentType!.capitalized
        AddHiddenTextfld()
    }
    
    
    
    var HiddenTxt = UITextField()
    var PackageSelectPicker = UIPickerView()
    func AddHiddenTextfld() {
        
        HiddenTxt.frame = CGRect.init(x: 1000, y: 1000, width: 10, height: 10)
        self.view.addSubview(HiddenTxt)
        PackageSelectPicker.dataSource = self
        PackageSelectPicker.delegate = self
        
        let Toolbar = UIToolbar()
        Toolbar.barStyle = .default
        Toolbar.isTranslucent = true
        Toolbar.tintColor = UIColor.blue
        Toolbar.sizeToFit()
        let DoneItem = UIBarButtonItem.init(title: "SELECT", style: .done, target: self, action: #selector(PickselectAction))
        let FlexiItem = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let TitleItem = UIBarButtonItem.init(title: "Please select reason", style: .done, target: nil, action: nil)
        let FlexiItem2 = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let CancelItem = UIBarButtonItem.init(title: "CANCEL", style: .done, target: self, action: #selector(PickCancelAction))
        Toolbar.setItems([CancelItem,FlexiItem,TitleItem,FlexiItem2,DoneItem], animated: true)
        Toolbar.isUserInteractionEnabled = true
        HiddenTxt.inputView = PackageSelectPicker;
        HiddenTxt.inputAccessoryView = Toolbar;
    }
    
    var SelectedIndex = 0
    
    @objc func PickselectAction() {
        HiddenTxt.resignFirstResponder()
        RateYourRideWith(EmpId: self.DriveBookingResponce.EmpId!, BookingId: jobno!, Rating: String.init(format: "%.0f", self.Rating.rating), Reason: reasonsForLowRating[SelectedIndex])
    }
    
    @objc func PickCancelAction() {
        HiddenTxt.resignFirstResponder()
    }
    
    // MARK: - }
    
    func floatRatingView(_ ratingView: FloatRatingView, didUpdate rating: Float) {
        
        if rating <= 3 && rating != 0 {
            HiddenTxt.becomeFirstResponder()
        }
        else if rating == 0 {
            print("Zero Rating")
        }
        else {
            RateYourRideWith(EmpId: self.DriveBookingResponce.EmpId!, BookingId: jobno!, Rating: String.init(format: "%.0f", rating), Reason: "NA")
        }
    }
    func floatRatingView(_ ratingView: FloatRatingView, isUpdating rating: Float) {
        //        print(rating)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func RateYourRideWith(EmpId:String,BookingId:String,Rating:String,Reason:String) {
        
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
            
            let RateDict = ["EmpId":EmpId,"BookingId":BookingId,"Rating":Rating,"ReasonForLowRating":Reason,"VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)", "BookingDuration":"\(self.FeedbackTxt.text!)"]
            
            print("DriveRateYourRide input = ", RateDict)
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveRateYourRide, parameterDict: RateDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (ResponceDict, responceCode, success) in
                
                self.view.StopLoading()
                
                if success {
                    print("DriveRateYourRide Response =",ResponceDict)
                    if let Table = ((ResponceDict as! [String:AnyObject])["Table"] as? [[String:AnyObject]])?[0] {
                        
                        if "\(Table["Status"]!)" == "true" {
                            //                            RatingDetails
                            self.DriveBookingResponce.RatingDetails = "NA"
                            saveDriveResponceStuct(driveStruct: self.DriveBookingResponce!)
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(Table["Response"]!)", Interval: 4)
                            let NavMain = self.storyboard?.instantiateViewController(withIdentifier: "LGSideMenu")
                            self.present(NavMain!, animated: true, completion: nil)
                        }
                        else {
                            self.view.ShowBlackTostWithText(message: "\(Table["Response"]!)", Interval: 3)
                        }
                    }
                    else {
                        self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                    }
                }
                else {
                    self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 2)
                }
            })
            
        }
        else {
            self.view.ShowBlackTostWithText(message: Constants.NetErrorMsg, Interval: 2)
        }
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return reasonsForLowRating.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return reasonsForLowRating[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        SelectedIndex = row
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardHide(_:)), name: .UIKeyboardWillHide, object: nil)
        self.navigationController?.isNavigationBarHidden = true
        self.navigationItem.hidesBackButton = true
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
        
        self.navigationController?.isNavigationBarHidden = false
    }
    //MARK: - Keyboard show
    
    @objc func keyboardShow(_ notification : NSNotification){
        
        if FeedbackTxt.isFirstResponder {
            let info = notification.userInfo
            let keyboardframe = (info![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size
            var frame = FeedbackTxt.frame
            
            frame.origin.y += (FeedbackTxt.superview?.frame.origin.y)!
            
            var actualframe = self.view.frame
            actualframe.size.height -= keyboardframe.height
            actualframe.size.height -= (frame.size.height)
            
            if !actualframe.contains((frame.origin)) {
                let yfinal = (frame.origin.y) - (actualframe.size.height)
                
                UIView.animate(withDuration: 0.3, animations: { () -> Void in
                    self.view.frame.origin.y -= yfinal
                })
            }
        }
    }
    // MARK: - keyboard hide
    
    @objc func keyboardHide(_ notification : NSNotification)
    {
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.view.frame.origin.y = 0
        })
    }
    
    // MARK: - }
    
}

extension DriveFeedbackVC : PaymentTransactionDelegate {
    
    func TransactionDidCancel(controller: PaymentPageVC) {
        
        //        controller.navigationController?.popViewController(animated: true)
        controller.dismiss(animated: true, completion: nil)
        Message.shared.Alert(Title: "Transaction cancelled", Message: "", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
    }
    
    func TransactionDidComplete(Result: PaymentTransactionResult, controller: PaymentPageVC) {
        controller.dismiss(animated: true, completion: nil)
        switch Result {
        case .success:
            ByCashLbl.isHidden = true
            pleaseRateurRideLabel.isHidden = false
            payButton.isHidden = true
            Rating.isHidden = false
            FeedbackTxt.isHidden = false
            feedbackView.isHidden = false
            Message.shared.Alert(Title: "Transaction Complete", Message:"", TitleAlign: .normal, MessageAlign: .normal,Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
        case .failure:
            Message.shared.Alert(Title: "Transaction cancelled", Message: "", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
        }
        
    }
}


