//
//  RegisterVC.swift
//  DriveBooking
//
//  Created by Raja Bhuma on 13/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit

class RegisterVC: UIViewController, UITextFieldDelegate {

    
    @IBOutlet weak var NameLabel: UILabel!
    @IBOutlet weak var EmailLabel: UILabel!
    @IBOutlet weak var MobileLabel: UILabel!
    @IBOutlet weak var PasswordLabel: UILabel!
    @IBOutlet weak var ConfirmPasswordLabel: UILabel!
    @IBOutlet weak var ReferralCodeLabel: UILabel!

    @IBOutlet weak var NameTextField: UITextField!
    @IBOutlet weak var EmailTextField: UITextField!
    @IBOutlet weak var MobileTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    @IBOutlet weak var ConfirmTextField: UITextField!
//    @IBOutlet weak var ReferralCodeTextField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.title = "Register"
        CheckForLabels()
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.black
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
        self.navigationItem.leftBarButtonItem = BackBtnItem
        self.perform(#selector(updateTextFields), with: self, afterDelay: 0.1)
    }
    
    @objc func updateTextFields(){
        NameTextField.BottomLine = UIColor.black
        MobileTextField.BottomLine = UIColor.black
        PasswordTextField.BottomLine = UIColor.black
        ConfirmTextField.BottomLine = UIColor.black
        EmailTextField.BottomLine = UIColor.black
    }

    @objc func BackAction() {
        self.navigationController?.popViewController(animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func RegisterBtnPressed(_ sender:UIButton) {
        
        self.view.endEditing(true)
        
        if (Reachability()?.isReachable)! {
            if (NameTextField.text!.isEmpty) && (EmailTextField.text!.isEmpty) && (MobileTextField.text!.isEmpty) && (PasswordTextField.text!.isEmpty) && (ConfirmTextField.text!.isEmpty)  {
                
                Message.shared.Alert(Title: "Alert", Message: "All Fields are required to regsiter", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            if (NameTextField.text!.isEmpty) {
                Message.shared.Alert(Title: "Alert", Message: "Please Enter Your Name", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            
            if !(NameTextField.text?.isValidInput())!{
                Message.shared.Alert(Title: "Alert", Message: "Username should Contain Atleast 4 Characters", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)

                return
            }
            if (EmailTextField.text!.isEmpty){
                Message.shared.Alert(Title: "Alert", Message: "Please Enter Your Email", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            
            if !(EmailTextField.text?.isValidEmail())! {
                Message.shared.Alert(Title: "Alert", Message: "Please Enter a Valid Email", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            if (MobileTextField.text!.isEmpty){
                Message.shared.Alert(Title: "Alert", Message: "Please Enter a Your Mobile Number", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            if !(MobileTextField.text?.isValidMobileNumber())! {
                Message.shared.Alert(Title: "Alert", Message: "Please enter valid mobile number", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            if (PasswordTextField.text!.isEmpty){
                Message.shared.Alert(Title: "Alert", Message: "Please Enter your password", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            if (PasswordTextField.text!.count<5){
                Message.shared.Alert(Title: "Alert", Message: "Password should be minimum 5 characters", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            
            if (ConfirmTextField.text!.isEmpty){
                Message.shared.Alert(Title: "Alert", Message: "Please Re-Enter your password", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                return
            }
            
            if PasswordTextField.text! == ConfirmTextField.text! {
                RegisterAndGotoOtpPage()
            }else{
                Message.shared.Alert(Title: "Alert", Message: "Password and Confirm Password should be Same", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            }
        }
        else {
            Message.shared.Alert(Title: "Alert", Message: "Check the Internet connection and try again", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
        }
    }
    
    func RegisterAndGotoOtpPage() {
    
        self.view.StartLoading()
        
        let Cred = FetchDriveCredentials()!
        let ReferalCode = "0"
        let RegisterDict = [
                            "OtpType":"REGISTRTAION",
                            "EmailId":self.EmailTextField.text!,
                            "MobileNo":self.MobileTextField.text!,
                            "ReferralCode":ReferalCode,
                            "VendorId":Cred.VendorId!,
                            "CorporateId":Cred.CorporateId!,
                            "AppCustomerType":Cred.AppCustomerType!
                            ]
        
        WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveGetOtp, parameterDict: RegisterDict, securityKey: WebServicesUrl.DummySecurity) { (responce, responceCode, success) in
            
            self.view.StopLoading()
            
            if success {
                let Table = (responce as! [String:AnyObject])["Table"] as! [[String:AnyObject]]

                if Table.count > 0 {
                    if "\(Table[0]["Status"]!)".toBool()! {
                        print("\(Table[0]["Otp"]!)")
                        
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(Table[0]["Response"]!)", Interval: 3)
                        let Otp = self.storyboard?.instantiateViewController(withIdentifier: "OtpVerifyVC") as! OtpVerifyVC
                        Otp.RequestDict = ["Email":self.EmailTextField.text!,"Name":self.NameTextField.text!,"Mobile":self.MobileTextField.text!,"Password":self.PasswordTextField.text!,"OTP":"\(Table[0]["Otp"]!)","OTPDuration":"\(Table[0]["OTPDuration"]!)","ReferralCode":ReferalCode]
                        Otp.IsRegistration = true
                        Otp.isEmailLogin = "\(Table[0]["Response"]!)"
                        self.navigationController?.pushViewController(Otp, animated: true)
                    }
                    else {
                        Message.shared.Alert(Title: "Alert", Message: "\(Table[0]["Response"]!)", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
                else {
                    Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                }
            }
            else {
                if responceCode == .NoInternet {
                    Message.shared.Alert(Title: "Alert", Message: "Check the Internet connection and try again", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                }
                else {
                    Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                }
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    // MARK: - }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardHide(_:)), name: .UIKeyboardWillHide, object: nil)
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    //MARK: - Keyboard show
    
    
    
    @objc func keyboardShow(_ notification : NSNotification){
        
        let info = notification.userInfo
        let keyboardframe = (info![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size
        var frame = CGRect.init()
        
        var subView = UIView()
        if NameTextField.isFirstResponder {
            frame = NameTextField.frame
            subView = NameTextField
        }
        else if EmailTextField.isFirstResponder {
            frame = EmailTextField.frame
            subView = EmailTextField
        }
        else if MobileTextField.isFirstResponder {
            frame = MobileTextField.frame
            subView = MobileTextField
        }
        else if PasswordTextField.isFirstResponder {
            frame = PasswordTextField.frame
            subView = PasswordTextField
        }
        else if ConfirmTextField.isFirstResponder {
            frame = ConfirmTextField.frame
            subView = ConfirmTextField
        }
//        else if ReferralCodeTextField.isFirstResponder {
//            frame = ReferralCodeTextField.frame
//            subView = ReferralCodeTextField
//        }
        
        frame.origin.y += 64
        frame.origin.y += (subView.superview?.frame.origin.y)!
        
        var actualframe = self.view.frame
        actualframe.size.height -= keyboardframe.height
        actualframe.size.height -= (frame.size.height)
        
        if !actualframe.contains(frame.origin) {
            let yfinal = frame.origin.y - actualframe.size.height
            
            UIView.animate(withDuration: 0.3, animations: { () -> Void in
                self.view.frame.origin.y -= yfinal
            })
            
        }
        
    }
    // MARK: - keyboard hide
    
    @objc func keyboardHide(_ notification : NSNotification)
    {
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.view.frame.origin.y = +64
        })
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == NameTextField {
            NameLabel.isHidden = false
            NameTextField.placeholder = ""
        }
        else if textField == EmailTextField {
            EmailLabel.isHidden = false
            EmailTextField.placeholder = ""
        }
        else if textField == MobileTextField {
            MobileLabel.isHidden = false
            MobileTextField.placeholder = ""
        }
        else if textField == PasswordTextField {
            PasswordLabel.isHidden = false
            PasswordTextField.placeholder = ""
        }
        else if textField == ConfirmTextField {
            ConfirmPasswordLabel.isHidden = false
            ConfirmTextField.placeholder = ""
        }
//        else if textField == ReferralCodeTextField {
//            ReferralCodeLabel.isHidden = false
//            ReferralCodeTextField.placeholder = ""
//        }
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        CheckForLabels()
    }
    
    func CheckForLabels() {
        
        if !(NameTextField.text?.isEmpty)! {
            NameLabel.isHidden = false
        }
        else {
            NameLabel.isHidden = true
        }
        
        if !(EmailTextField.text?.isEmpty)! {
            EmailLabel.isHidden = false
        }
        else {
            EmailLabel.isHidden = true
        }
        
        if !(MobileTextField.text?.isEmpty)! {
            MobileLabel.isHidden = false
        }
        else {
            MobileLabel.isHidden = true
        }
        
        if !(PasswordTextField.text?.isEmpty)! {
            PasswordLabel.isHidden = false
        }
        else {
            PasswordLabel.isHidden = true
        }
        
        if !(ConfirmTextField.text?.isEmpty)! {
            ConfirmPasswordLabel.isHidden = false
        }
        else {
            ConfirmPasswordLabel.isHidden = true
        }
//        if !(ReferralCodeTextField.text?.isEmpty)! {
//            ReferralCodeLabel.isHidden = false
//        }
//        else {
//            ReferralCodeLabel.isHidden = true
//        }
        NameTextField.placeholder = "Name"
        EmailTextField.placeholder = "Email"
        MobileTextField.placeholder = "Mobile"
        PasswordTextField.placeholder = "Password"
        ConfirmTextField.placeholder = "Confirm Password"
//        ReferralCodeTextField.placeholder = "Referal Code (Optional)"
    }
    
    // MARK: - }
}

