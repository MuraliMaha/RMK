#if !os(watchOS)
    
    import Foundation
    import SystemConfiguration
    
    class NetworkReachabilityManager {
        
        public enum NetworkReachabilityStatus {
            case unknown
            case notReachable
            case reachable(ConnectionType)
        }
    
        public enum ConnectionType {
            case ethernetOrWiFi
            case wwan
        }
        
        public typealias Listener = (NetworkReachabilityStatus) -> Void
        
        // MARK: - Properties
        
        /// Whether the network is currently reachable.
        public var isReachable: Bool { return isReachableOnWWAN || isReachableOnEthernetOrWiFi }
        
        /// Whether the network is currently reachable over the WWAN interface.
        public var isReachableOnWWAN: Bool { return networkReachabilityStatus == .reachable(.wwan) }
        
        /// Whether the network is currently reachable over Ethernet or WiFi interface.
        public var isReachableOnEthernetOrWiFi: Bool { return networkReachabilityStatus == .reachable(.ethernetOrWiFi) }
        
        /// The current network reachability status.
        public var networkReachabilityStatus: NetworkReachabilityStatus {
            guard let flags = self.flags else { return .unknown }
            return networkReachabilityStatusForFlags(flags)
        }
        
        /// The dispatch queue to execute the `listener` closure on.
        public var listenerQueue: DispatchQueue = DispatchQueue.main
        
        /// A closure executed when the network reachability status changes.
        public var listener: Listener?
        
        private var flags: SCNetworkReachabilityFlags? {
            var flags = SCNetworkReachabilityFlags()
            
            if SCNetworkReachabilityGetFlags(reachability, &flags) {
                return flags
            }
            
            return nil
        }
        
        private let reachability: SCNetworkReachability
        private var previousFlags: SCNetworkReachabilityFlags
        
        // MARK: - Initialization
        
        public convenience init?(host: String) {
            guard let reachability = SCNetworkReachabilityCreateWithName(nil, host) else { return nil }
            self.init(reachability: reachability)
        }
        
        public convenience init?() {
            var address = sockaddr_in()
            address.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
            address.sin_family = sa_family_t(AF_INET)
            
            guard let reachability = withUnsafePointer(to: &address, { pointer in
                return pointer.withMemoryRebound(to: sockaddr.self, capacity: MemoryLayout<sockaddr>.size) {
                    return SCNetworkReachabilityCreateWithAddress(nil, $0)
                }
            }) else { return nil }
            
            self.init(reachability: reachability)
        }
        
        private init(reachability: SCNetworkReachability) {
            self.reachability = reachability
            self.previousFlags = SCNetworkReachabilityFlags()
        }
        
        deinit {
            stopListening()
        }
        
        // MARK: - Listening
        
        @discardableResult
        public func startListening() -> Bool {
            var context = SCNetworkReachabilityContext(version: 0, info: nil, retain: nil, release: nil, copyDescription: nil)
            context.info = Unmanaged.passUnretained(self).toOpaque()
            
            let callbackEnabled = SCNetworkReachabilitySetCallback(
                reachability,
                { (_, flags, info) in
                    let reachability = Unmanaged<NetworkReachabilityManager>.fromOpaque(info!).takeUnretainedValue()
                    reachability.notifyListener(flags)
            },
                &context
            )
            
            let queueEnabled = SCNetworkReachabilitySetDispatchQueue(reachability, listenerQueue)
            
            listenerQueue.async {
                self.previousFlags = SCNetworkReachabilityFlags()
                self.notifyListener(self.flags ?? SCNetworkReachabilityFlags())
            }
            
            return callbackEnabled && queueEnabled
        }
        
        /// Stops listening for changes in network reachability status.
        public func stopListening() {
            SCNetworkReachabilitySetCallback(reachability, nil, nil)
            SCNetworkReachabilitySetDispatchQueue(reachability, nil)
        }
        
        // MARK: - Internal - Listener Notification
        
        func notifyListener(_ flags: SCNetworkReachabilityFlags) {
            guard previousFlags != flags else { return }
            previousFlags = flags
            
            listener?(networkReachabilityStatusForFlags(flags))
        }
        
        // MARK: - Internal - Network Reachability Status
        
        func networkReachabilityStatusForFlags(_ flags: SCNetworkReachabilityFlags) -> NetworkReachabilityStatus {
            guard isNetworkReachable(with: flags) else { return .notReachable }
            
            var networkStatus: NetworkReachabilityStatus = .reachable(.ethernetOrWiFi)
            
            #if os(iOS)
                if flags.contains(.isWWAN) { networkStatus = .reachable(.wwan) }
            #endif
            
            return networkStatus
        }
        
        func isNetworkReachable(with flags: SCNetworkReachabilityFlags) -> Bool {
            let isReachable = flags.contains(.reachable)
            let needsConnection = flags.contains(.connectionRequired)
            let canConnectAutomatically = flags.contains(.connectionOnDemand) || flags.contains(.connectionOnTraffic)
            let canConnectWithoutUserInteraction = canConnectAutomatically && !flags.contains(.interventionRequired)
            
            return isReachable && (!needsConnection || canConnectWithoutUserInteraction)
        }
    }
    
    // MARK: -
    
    extension NetworkReachabilityManager.NetworkReachabilityStatus: Equatable {}
    
    func ==(
        lhs: NetworkReachabilityManager.NetworkReachabilityStatus,
        rhs: NetworkReachabilityManager.NetworkReachabilityStatus)
        -> Bool
    {
        switch (lhs, rhs) {
        case (.unknown, .unknown):
            return true
        case (.notReachable, .notReachable):
            return true
        case let (.reachable(lhsConnectionType), .reachable(rhsConnectionType)):
            return lhsConnectionType == rhsConnectionType
        default:
            return false
        }
    }
    
#endif
