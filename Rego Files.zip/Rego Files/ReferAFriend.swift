//
//  ReferAFriend.swift
//  DriveBooking
//
//  Created by Amarnath B on 22/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit
import MessageUI

class ReferAFriend: UIViewController {
    let MenusArray : [[String:String]] = {
        let Arr = [["Title":"WhatsApp","Image":"whatsapp"],
                   ["Title":"SMS","Image":"Messages"],
                   ["Title":"Email","Image":"Mail"]]
                return Arr
    }()
    
    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!

    @IBOutlet weak var referalCode: UILabel!

    @IBOutlet weak var ReferralHeaderLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "SHARE AND EARN"

//        self.referTableView.estimatedSectionHeaderHeight = 380
//        self.referTableView.sectionHeaderHeight = UITableViewAutomaticDimension
        
        
        self.LoginRequest = FetchDriveRequest()
        self.DriveBookingResponce = FetchDriveResponce()
        
        ReferralHeaderLabel.text = "\(DriveBookingResponce.ReferralHeader!)"
        referalCode.text = "\(DriveBookingResponce.ReferralCode!)"
                // Do any additional setup after loading the view.
    }
    @IBOutlet weak var referTableView: UITableView!

   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension ReferAFriend: UITableViewDelegate, UITableViewDataSource, MFMessageComposeViewControllerDelegate, MFMailComposeViewControllerDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 45
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return MenusArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuCell", for: indexPath) as! MenuCell
        
        cell.MenuImage.image = UIImage.init(named: MenusArray[indexPath.row]["Image"]!)
        cell.MenuName.text = MenusArray[indexPath.row]["Title"]!
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        if (DriveBookingResponce.ReferralCode!) != "NA"{
        switch MenusArray[indexPath.row]["Title"]! {
        case "WhatsApp":
            callwhatsApp()
            break
        case "Email":
            callEmail()
            break
            case "SMS":
                callSMS()
            break
        default:
            break
        }
        }else{
        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "No referral code to share", Interval: 2)
        }
    }
    func callwhatsApp(){
        let urlString = "\(DriveBookingResponce.ReferralMessage!)"
        //let urlStringEncoded = urlString.stringByAddingPercentEncodingWithAllowedCharacters(.URLHostAllowedCharacterSet())
        let urlStringEncoded = urlString.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)
        let url  = NSURL(string: "whatsapp://send?text=\(urlStringEncoded!)")
        
        if UIApplication.shared.canOpenURL(URL.init(string: "whatsapp://")!) {
            UIApplication.shared.openURL(url! as URL)
        } else {
            Message.shared.Alert(Title: "Cannot Send Message", Message: "Whatsapp is not installed", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
        }
    }
    func callSMS(){
        if (MFMessageComposeViewController.canSendText()) {
            let controller = MFMessageComposeViewController()
            controller.body = "\(DriveBookingResponce.ReferralMessage!)"
//            controller.recipients = [phoneNumber.text]
            controller.messageComposeDelegate = self
            self.present(controller, animated: true, completion: nil)
        }
    }
    
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        //... handle sms screen actions
        self.dismiss(animated: true, completion: nil)
    }
    
    func callEmail(){
        let mailComposeViewController = configuredMailComposeViewController()
        if MFMailComposeViewController.canSendMail() {
            self.present(mailComposeViewController, animated: true, completion: nil)
        } else {
            self.showSendMailErrorAlert()
        }
    
    }
    func configuredMailComposeViewController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self // Extremely important to set the --mailComposeDelegate-- property, NOT the --delegate-- property
        
//        mailComposerVC.setToRecipients(["nurdin@gmail.com"])
        mailComposerVC.setSubject("Aamchi Drive Invitation from " + "\(DriveBookingResponce.Name!)")
        mailComposerVC.setMessageBody("\(DriveBookingResponce.ReferralMessage!)", isHTML: false)
        
        return mailComposerVC
    }
    
    func showSendMailErrorAlert() {
        Message.shared.Alert(Title: "Could Not Send Email", Message: "Your device could not send e-mail. Please check e-mail configuration and try again.", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
    }
    
    // MARK: MFMailComposeViewControllerDelegate
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
        
    }

}
