//
//  OtpVerifyVC.swift
//  DriveBooking
//
//  Created by Raja Bhuma on 17/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit

class OtpVerifyVC: UIViewController, UITextFieldDelegate {
    
    var RequestDict = [String:String]()
    
    var IsRegistration = true
    var isEmailLogin = ""
    
    var resendotpButton: UIBarButtonItem!
    @IBOutlet var otpLabel: UILabel!
    @IBOutlet var OTPTextField: UITextField!
    @IBOutlet var countDowntextLabel: UILabel!

    @IBOutlet var OTPHeader: UILabel!
    var countTimer = 180
    var OtpStr : String!

    var MobileNumber: String!
    
    var CountDownTimer = Timer()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        OTPHeader.text = isEmailLogin
        
        self.title = "OTP"
        
        if IsRegistration {
            if let Duration = RequestDict["OTPDuration"], Duration != "" {
                countTimer =  Int(Duration)!
            }
        }
        else {
            if let Duration = RequestDict["OTPDuration"], Duration != "" {
                countTimer =  Int(Duration)!
            }
        }
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.black
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
        self.navigationItem.leftBarButtonItem = BackBtnItem
        
        resendotpButton = UIBarButtonItem.init(title: "RESEND", style: .done, target: self, action: #selector(ResendOtpPressed(_:)))
        resendotpButton.tintColor = UIColor.black
        self.navigationItem.rightBarButtonItem = resendotpButton
        
        self.OtpStr = "\(RequestDict["OTP"]!)"
        
        CountDownTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(update), userInfo: nil, repeats: true)

        otpLabel.isHidden = true
        self.perform(#selector(updateTextFields), with: self, afterDelay: 0.1)
    }
    
    @objc func BackAction() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func updateTextFields(){
        OTPTextField.BottomLine = UIColor.black
            }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func update() {
        if(countTimer > 0) {
            countTimer -= 1
            countDowntextLabel.text =  "OTP Expires in " + "\(FromTimeInterval(interval:TimeInterval(countTimer)))" + " Seconds"
        }
        else {
            CountDownTimer.invalidate()
        }
    }
    
    
    @IBAction func ResendOtpPressed(_ sender:UIBarButtonItem) {
        
        Message.shared.Alert(Title: "Alert", Message: isEmailLogin, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
        
        
        if IsRegistration {
            
            self.view.StartLoading()
            
            let Cred = FetchDriveCredentials()!
            
            let RegisterDict = [
                "OtpType":"REGISTRTAION",
                "EmailId":RequestDict["Email"]!,
                "MobileNo":RequestDict["Mobile"]!,
                "ReferralCode":RequestDict["ReferralCode"]!,
                "VendorId":Cred.VendorId!,
                "CorporateId":Cred.CorporateId!,
                "AppCustomerType":Cred.AppCustomerType!
            ]
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveGetOtp, parameterDict: RegisterDict, securityKey: WebServicesUrl.DummySecurity) { (responce, responceCode, success) in
                
                self.view.StopLoading()
                
                if success {
                    let Table = (responce as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
                    
                    if Table.count > 0 {
                        if "\(Table[0]["Status"]!)".toBool()! {
                            self.countTimer = 0
                            self.OtpStr = "\(Table[0]["Otp"]!)"
                            self.RequestDict["Otp"] = self.OtpStr
                            self.countTimer = Int("\(Table[0]["OTPDuration"]!)")!
                            print(self.OtpStr)
                            self.CountDownTimer.invalidate()
                            self.CountDownTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.update), userInfo: nil, repeats: true)
                        }
                        else {
                            Message.shared.Alert(Title: "Alert", Message: "\(Table[0]["Response"]!)", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
//                            Message.shared.Alert(Title: "Alert", Message: "\(Table[0]["Response"]!)", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                        }
                    }
                    else {
                        Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
                else {
                    if responceCode == .NoInternet {
                        Message.shared.Alert(Title: "Alert", Message: "Check the Internet connection and try again", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                    else {
                        Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
            }
        }
        else {
            self.view.StartLoading()
            
            let Cred = FetchDriveCredentials()!
            
            let RegisterDict = [
                "OtpType":"FORGETPASSWORD",
                "EmailId":"0",
                "MobileNo":RequestDict["Mobile"]!,
                "VendorId":Cred.VendorId!,
                "CorporateId":Cred.CorporateId!,
                "AppCustomerType":Cred.AppCustomerType!
            ]
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveGetOtp, parameterDict: RegisterDict, securityKey: WebServicesUrl.DummySecurity) { (responce, responceCode, success) in
                
                self.view.StopLoading()
                
                if success {
                    let Table = (responce as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
                    
                    if Table.count > 0 {
                        if "\(Table[0]["Status"]!)".toBool()! {
                            self.countTimer = 0
                            self.OtpStr = "\(Table[0]["Otp"]!)"
                            self.RequestDict["Otp"] = self.OtpStr
                            self.RequestDict["EmpId"] = "\(Table[0]["EmpId"]!)"
                            self.countTimer = Int("\(Table[0]["OTPDuration"]!)")!
                            print(self.OtpStr)
                            self.CountDownTimer.invalidate()
                            self.CountDownTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.update), userInfo: nil, repeats: true)
                        }
                        else {
                            Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                            //                            Message.shared.Alert(Title: "Alert", Message: "\(Table[0]["Response"]!)", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                        }
                    }
                    else {
                        Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
                else {
                    if responceCode == .NoInternet {
                        Message.shared.Alert(Title: "Alert", Message: "Check the Internet connection and try again", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                    else {
                        Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
            } 
        }
        
    }
    
    @IBAction func VerifyPressed(_ sender:UIButton) {
        
        if OTPTextField.text! == "" {
            Message.shared.Alert(Title: "Alert", Message: "Please Enter OTP to Verify", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            return
        }
        
        if OTPTextField.text! != self.OtpStr {
            Message.shared.Alert(Title: "Alert", Message: "Please Enter Valid OTP", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            return
        }
        
        
        if IsRegistration {
            
            self.view.StartLoading()
            
            let Cred = FetchDriveCredentials()!
            
            let version = "\(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString")!)"
            let Uuid = UIDevice.current.identifierForVendor!.uuidString
            let RegisterDict = [
                "UserName":RequestDict["Name"]!,
                "Password":RequestDict["Password"]!,
                "EmailId":RequestDict["Email"]!,
                "MobileNo":RequestDict["Mobile"]!,
                "ReferralCode":RequestDict["ReferralCode"]!,
                "VendorId":Cred.VendorId!,
                "CorporateId":Cred.CorporateId!,
                "AppCustomerType":Cred.AppCustomerType!,
                "Version":version,
                "DeviceToken":"323",
                "DeviceIMEINO":Uuid,
                "DeviceType":UIDevice.current.systemName]
            
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveRegisterUser, parameterDict: RegisterDict, securityKey: WebServicesUrl.DummySecurity, completion: { (responce, responceCode, success) in
                self.view.StopLoading()
                if success {
                    let Table = (responce as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
                    if Table.count > 0 {
                        if "\(Table[0]["Status"]!)".toBool()! {
                            
                            let version = "\(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString")!)"
                            
                            let Dict = ["UserName":self.RequestDict["Mobile"]!,
                                        "Password":self.RequestDict["Password"]!,
                                        "VendorId":Cred.VendorId!,
                                        "CorporateId":Cred.CorporateId!,
                                        "AppCustomerType":Cred.AppCustomerType!,
                                        "Version":version,
                                        "DeviceToken":"323",
                                        "DeviceIMEINO":Uuid,
                                        "DeviceType":UIDevice.current.systemName]
                            
                            SaveDriveRequest(request: Dict)
                            SaveDriveResponce(DriveResponce: Table[0])
                            
                            UserDefaults.standard.set(false, forKey: "RideLaterViewBool")
                            UserDefaults.standard.synchronize()
                            
                            let NavMain = self.storyboard?.instantiateViewController(withIdentifier: "LGSideMenu")
                            self.present(NavMain!, animated: true, completion: nil)
                        }
                        else {
                            Message.shared.Alert(Title: "Alert", Message: "\(Table[0]["Response"]!)", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                        }
                    }
                    else {
                        Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
                else {
                    if responceCode == .NoInternet {
                        Message.shared.Alert(Title: "Alert", Message: "Check the Internet connection and try again", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                    else {
                        Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
            })
            
        }
        else {
            let updatepass = self.storyboard?.instantiateViewController(withIdentifier: "UpdatePassVC") as! UpdatePassVC
            updatepass.EmpID = RequestDict["EmpId"]!
            updatepass.Mobile = RequestDict["Mobile"]!
            self.navigationController?.pushViewController(updatepass, animated: true)
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        otpLabel.isHidden = false
    }

    func textFieldDidEndEditing(_ textField: UITextField) {
        if (OTPTextField.text?.isEmpty)! {
            otpLabel.isHidden = true
        }
        else {
            otpLabel.isHidden = false
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        CountDownTimer.invalidate()
    }
    
    func FromTimeInterval(interval: TimeInterval) -> String {
        let interval = Int(interval)
        let seconds = interval % 60
        let minutes = (interval / 60) % 60
        let hours = (interval / 3600)
        var form = "\(hours):\(minutes):\(seconds)"
        
        if hours == 0{
            form = "\(minutes):\(seconds)"
        }
        if minutes == 0{
            form = "\(seconds)"
        }
        if seconds == 0 &&  minutes == 0 && hours == 0 {
            form = "OTP Time expired Please Click on Resend to send OTP again"
        }
        
        return String(format: form)
    }
}
