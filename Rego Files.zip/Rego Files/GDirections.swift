//
//  GMDirections.swift
//  GDirections
//
//  Created by Raja Bhuma on 16/09/17.
//  Copyright © 2017 MyFriends. All rights reserved.
//

import UIKit
import CoreLocation

public class GDirections {
    //    public class func Directions(from:CLLocationCoordinate2D, to:CLLocationCoordinate2D, paths: [CLLocationCoordinate2D]?, travel_Mode:GTravelMode?, PathToOptimise: Bool, alternatives: Bool, avoid: [String]?,_ completion: @escaping (GResponce<GDirectionsData>) -> ())  {
        
    public class func Directions(Params: GParams, _ completion: @escaping (GResponce<GDirectionsData>) -> ())  {
        
        if !(NetworkReachabilityManager()?.isReachable)! {
            completion(GResponce.init(gResult: GResult.failure(GError.unknown_error(error: "Not Reachable to internet. Try to connect to an active internet connection")), gData: nil))
        }
        
        var Key: String = ""
        
        switch GStore.getKey() {
        case .success(let keyGot):
            Key = keyGot
            break
        case .failure(let error):
            print(error.errorDescription)
            completion(GResponce.init(gResult: GResult.failure(error), gData: nil))
            return
        }
        
        let WayPoints = ParseWayPoints(Way: Params.Points)
        
        let TravelMode = GDirections.ParseTravelMode(travel_mode: Params.Mode)
        
        let Alternative = Params.Alternatives ? "&alternatives=true" : ""
        
        
        let ParamsStr = "https://maps.googleapis.com/maps/api/directions/json?" + "origin=\(Params.FromLocation.latitude),\(Params.FromLocation.longitude)" + "&destination=\(Params.ToLocation.latitude),\(Params.ToLocation.longitude)" + "&key=\(Key)" + TravelMode + Alternative + WayPoints
        
        print(ParamsStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)
        
        let url = URL.init(string: ParamsStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!
        
        DispatchQueue.global(qos: .background).async {
            
            guard let directionsData = try? Data.init(contentsOf: url) else {
                DispatchQueue.main.async {
                    completion(GResponce.init(gResult: GResult.failure(GError.unknown_error(error: "Unable to get Data")), gData: nil))
                }
                return
            }
            
            DispatchQueue.main.async {
                
                guard let JsonDict = try? JSONSerialization.jsonObject(with: directionsData, options: .allowFragments) else {
                    completion(GResponce.init(gResult: GResult.failure(GError.unknown_error(error: "JSON serialisation problem")), gData: nil))
                    return
                }
                
                let FinalData = JsonDict as! [String:Any]
                
                guard "\(FinalData["status"]!)" == "OK" else {
                    completion(GResponce.init(gResult: GResult.failure(GError.GetResponceError(errorMsg: "\(FinalData["status"]!)")), gData: nil))
                    return
                }
                
                completion(GResponce.init(gResult: GResult.success(GDirectionsData.init(value: FinalData)), gData: directionsData))
            }
            
        }
        
    }
    
    
    private class func ParseTravelMode(travel_mode:GTravelMode) -> String {
        
        switch travel_mode {
        case .default:
            return "&mode=driving"
        case .walking:
            return "&mode=walking"
        case .bicycling:
            return "&mode=bicycling"
        case .transit(let arrival_departure_time, let transit_modes, let transit_routing_preference):
            
            var arrival_time = ""
            
            if arrival_departure_time != nil {
                arrival_time = "&arrival_time=\(arrival_departure_time!)"
            }
            
            var transit_mode = ""
            
            if transit_modes != nil {
                
                let ModesList = (transit_modes?.joined(separator: "|"))!
                
                transit_mode = "&transit_mode=\(ModesList)"
            }
            
            var transit_routing = ""
            
            if transit_routing_preference != nil {
                transit_routing = "&transit_routing_preference=\(transit_routing_preference!)"
            }
            
            return "&mode=transit" + arrival_time + transit_mode + transit_routing
        }
    }
    
    private class func ParseWayPoints(Way:(WayPoints:[CLLocationCoordinate2D], Optimise:Bool)?) -> String {
        
        guard let WayPoints = Way else {
            return ""
        }
        
        var WayPointsStr = "&waypoints=" + (WayPoints.Optimise ? "optimize:true" : "optimize:false")
        
        for points in WayPoints.WayPoints {
            WayPointsStr += "|" + "\(points.latitude),\(points.longitude)"
        }
        
        return WayPointsStr
    }
    
}


public enum GTravelMode {
    
    case `default` // -> driving
    case walking
    case bicycling
    case transit(arrival_departure_time: String?, transit_modes:[String]?, transit_routing_preference:String?)
    
    /*  arrival_departure_time need to be in UInt or Int From Midnight Jan 1, 1970
     For transit_modes use GTransitMode
     For transit_routing_preference use GTransitRoutingPreference
     */
}


// MARK: - GTransitMode

public let GTransitModeBus = "bus"
public let GTransitModeSubway = "subway"
public let GTransitModeTrain = "train"
public let GTransitModeTram = "tram"
public let GTransitModeRail = "rail"



// MARK: - GTransitRoutingPreference

public let GTransitRoutingPreferenceLessWalking = "less_walking"
public let GTransitRoutingPreferenceFewerTransfers = "fewer_transfers"




// MARK: - GAvoid

public let GAvoidTolls = "tolls"
public let GAvoidHighways = "highways"
public let GAvoidFerries = "ferries"


