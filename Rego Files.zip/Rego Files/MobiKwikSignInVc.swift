//
//  MobiKwikSignInVc.swift
//  IBMBlueMix
//
//  Created by Raja Bhuma on 23/05/17.
//  Copyright © 2017 Raja Bhuma. All rights reserved.
//

import UIKit
import Alamofire

protocol MobiKwikSignInDelegate {
    func DidSignInComplete(controller:MobiKwikSignInVc)
    func DidSignInCancel(controller:MobiKwikSignInVc)
}

class MobiKwikSignInVc: UIViewController, UITextFieldDelegate {

    @IBOutlet var OTPView: UIView!
    @IBOutlet var OTPTxt: UITextField!
    
    @IBOutlet var MobileNumberTxt: UITextField!

    var Delegate: MobiKwikSignInDelegate!
    
    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.LoginRequest = FetchDriveRequest()
        self.DriveBookingResponce = FetchDriveResponce()
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.black
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
        self.navigationItem.leftBarButtonItem = BackBtnItem

        MobileNumberTxt.text = self.DriveBookingResponce.PhoneNo!
        MobileNumberTxt.isEnabled = false
    }
    
    @objc func BackAction() {
        Delegate.DidSignInCancel(controller: self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func RequestOtpBtn(_ sender:UIButton) {
        
        self.view.endEditing(true)
        
        if (MobileNumberTxt.text?.isEmpty)! {
            
            self.view.ShowBlackTostWithText(message: "Please enter mobile number", Interval: 3)
            
            return
        }
        else if !(MobileNumberTxt.text?.isValidMobileNumber())! {
            
            self.view.ShowBlackTostWithText(message: "Please valid mobile number", Interval: 3)

            return
        }
        
        self.view.StartLoading()
       
        let cell            = MobileNumberTxt.text!
        let msgcode         = "500"
        let action          = "existingusercheck"
        let mid             = MobiCreds.MID
        let merchantname    = MobiCreds.MerchentName
        
        let VariableFormat  = "'\(action)''\(cell)''\(merchantname)''\(mid)''\(msgcode)'" // ‘action’‘cell’‘merchantname’‘mid’‘msgcode’
        
        let checksum        = VariableFormat.hmac(algorithm: .SHA256, key: MobiCreds.Secret)
        
        let parserStr       = Parser(dict: ["cell":cell,"msgcode":msgcode,"action":action,"mid":mid,"merchantname":merchantname,"checksum":checksum])
        
        let UrlFormat       =  MobiCreds.BaseUrl + "/" + MobiCreds.CheckUSer + "?" + parserStr
        
        let url             = URL.init(string: UrlFormat.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!
        
        var Request         = URLRequest.init(url: url)
        Request.httpMethod  = "GET"
        Request.allHTTPHeaderFields = ["payloadtype":"json"]
        
        Alamofire.request(Request)
            .responseJSON { (responce) in
                
                self.view.StopLoading()

                switch responce.result {
                case .success(let Value):
                    print(Value)
                    
                    let ResponceDict = Value as! [String:AnyObject]
                    
                    if "\(ResponceDict["status"]!)" == "SUCCESS" {
                        self.OTPSendAll()
                        

                    }
                    else {
                        Message.shared.Alert(Title: "Create wallet", Message: "\(ResponceDict["statusdescription"]!)" + ".\nWould to like to create a new account", TitleAlign: .left, MessageAlign: .left, Actions: [Message.AlertActionWithOutSelector(Title: "No"),Message.AlertActionWithSelector(Title: "Yes", Selector: #selector(self.DontHAveAccountCreate), Controller: self)], Controller: self)
                    }
                    
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    break
                }
        }
        
    }
    
    var IsNewWalletUSer = false
    
    @objc func DontHAveAccountCreate() {
        IsNewWalletUSer = true
        self.OTPSendAll()
    }
    
    func OTPSendAll() {
        
        UIApplication.shared.keyWindow?.StartLoading()
        
        let amount          = MobiCreds.MaxAmount
        let cell            = MobileNumberTxt.text!
        let tokentype       = "1"
        let msgcode         = "504"
        let mid             = MobiCreds.MID
        let merchantname    = MobiCreds.MerchentName
        
        let VariableFormat  = "'\(amount)''\(cell)''\(merchantname)''\(mid)''\(msgcode)''\(tokentype)'" // ‘amount’‘cell’‘merchantname’‘mid’‘msgcode’‘tokentype’
        
        let checksum        = VariableFormat.hmac(algorithm: .SHA256, key: MobiCreds.Secret)
        
        let parserStr       = Parser(dict: ["amount":amount,"cell":cell,"tokentype":tokentype,"msgcode":msgcode,"mid":mid,"merchantname":merchantname,"checksum":checksum])
        
        let UrlFormat       =  MobiCreds.BaseUrl + "/" + MobiCreds.OtpGeneration + "?" + parserStr
        
        let url             = URL.init(string: UrlFormat.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!
        
        var Request         = URLRequest.init(url: url)
        Request.httpMethod = "GET"
        Request.allHTTPHeaderFields = ["payloadtype":"json"]
        
        Alamofire.request(Request)
            .responseJSON { (responce) in
                
                UIApplication.shared.keyWindow?.StopLoading()
                
                switch responce.result {
                case .success(let Value):
                    print(Value)
                    
                    let ResponceDict = Value as! [String:AnyObject]
                    
                    if "\(ResponceDict["status"]!)" == "SUCCESS" {
                        self.ShowOtpView()
                    }
                    else {
                        
                    }
                    
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    break
                }
        }
    }
    
    func Resend() {
        
        UIApplication.shared.keyWindow?.StartLoading()
        
        let amount          = MobiCreds.MaxAmount
        let cell            = MobileNumberTxt.text!
        let tokentype       = "1"
        let msgcode         = "504"
        let mid             = MobiCreds.MID
        let merchantname    = MobiCreds.MerchentName
        
        let VariableFormat  = "'\(amount)''\(cell)''\(merchantname)''\(mid)''\(msgcode)''\(tokentype)'" // ‘amount’‘cell’‘merchantname’‘mid’‘msgcode’‘tokentype’
        
        let checksum        = VariableFormat.hmac(algorithm: .SHA256, key: MobiCreds.Secret)
        
        let parserStr       = Parser(dict: ["amount":amount,"cell":cell,"tokentype":tokentype,"msgcode":msgcode,"mid":mid,"merchantname":merchantname,"checksum":checksum])
        
        let UrlFormat       =  MobiCreds.BaseUrl + "/" + MobiCreds.OtpGeneration + "?" + parserStr
        
        let url             = URL.init(string: UrlFormat.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!
        
        var Request         = URLRequest.init(url: url)
        Request.httpMethod = "GET"
        Request.allHTTPHeaderFields = ["payloadtype":"json"]
        
        Alamofire.request(Request)
            .responseJSON { (responce) in
                
                UIApplication.shared.keyWindow?.StopLoading()
                
                switch responce.result {
                case .success(let Value):
                    print(Value)
                    
                    let ResponceDict = Value as! [String:AnyObject]
                    
                    if "\(ResponceDict["status"]!)" == "SUCCESS" {
                        
                    }
                    else {
                        
                    }
                    
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    break
                }
        }
    }
    
    func CloseOtpView() {
        UIView.animate(withDuration: 0.3, animations: {
            self.OTPView.alpha = 0
        }) { (yes) in
            if yes {
                self.OTPView.alpha = 1
                self.OTPView.superview?.removeFromSuperview()
            }
        }
    }
    
    
    @IBAction func EditNumber(_ sender:UIButton) {
        
        MobileNumberTxt.isEnabled = true
        MobileNumberTxt.becomeFirstResponder()
    }
    
    @objc func TapOTPReturn(_ responder:UITapGestureRecognizer) {
        let Point = responder.location(in: OTPView.superview!)
        let Frame = OTPView.frame
        
        if !Frame.contains(Point) {
            
            CloseOtpView()
        }
    }
    
    var ActualX:CGFloat = 0
    
    func ShowOtpView() {
        
        let window = UIApplication.shared.keyWindow
        let BackView = UIView.init(frame: (window?.frame)!)
        BackView.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        
        BackView.center = (window?.center)!
        
        window?.addSubview(BackView)
        OTPView.center = BackView.center
        
        BackView.addSubview(OTPView!)
        
        OTPTxt.text = ""
        
        ActualX = OTPView.frame.origin.y
        
        let GuardianTap = UITapGestureRecognizer.init(target: self, action: #selector(TapOTPReturn(_:)))
        GuardianTap.numberOfTapsRequired = 1
        BackView.addGestureRecognizer(GuardianTap)
        
        OTPView.alpha = 0
        
        UIView.animate(withDuration: 0.5) {
            self.OTPView.alpha = 1
            self.OTPTxt.becomeFirstResponder()
        }
    }
    
    @IBAction func VeryfyOtp(_ sender:UIButton) {
        self.OTPView.endEditing(true)
        
        if (OTPTxt.text?.isEmpty)! {
            
            self.view.ShowBlackTostWithText(message: "Please enter OTP", Interval: 3)
            
            return
        }
        
        
        GenerateToken()
    }
    
    func GenerateToken() {
        
        UIApplication.shared.keyWindow?.StartLoading()
        
        let amount          = MobiCreds.MaxAmount
        let cell            = MobileNumberTxt.text!
        let otp             = OTPTxt.text!
        let tokentype       = "1"
        let msgcode         = "507"
        let mid             = MobiCreds.MID
        let merchantname    = MobiCreds.MerchentName
        
        let VariableFormat  = "'\(amount)''\(cell)''\(merchantname)''\(mid)''\(msgcode)''\(otp)''\(tokentype)'" // ‘amount’‘cell’‘merchantname’‘mid’‘msgcode’‘otp’‘tokentype’
        
        let checksum        = VariableFormat.hmac(algorithm: .SHA256, key: MobiCreds.Secret)
        
        let parserStr       = Parser(dict: ["amount":amount,"cell":cell,"otp":otp,"msgcode":msgcode,"mid":mid,"merchantname":merchantname,"tokentype":tokentype,"checksum":checksum])
        
        let UrlFormat       =  MobiCreds.BaseUrl + "/" + MobiCreds.Tokengenerate + "?" + parserStr
        
        let url             = URL.init(string: UrlFormat.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!
        
        var Request         = URLRequest.init(url: url)
        Request.httpMethod = "POST"
        Request.allHTTPHeaderFields = ["payloadtype":"json"]
        
        Alamofire.request(Request)
            .responseJSON { (responce) in
                UIApplication.shared.keyWindow?.StopLoading()

                switch responce.result {
                case .success(let Value):
                    print(Value)
                    
                    let responceData = Value as! [String:AnyObject]
                    if "\(responceData["status"]!)" == "SUCCESS" {
                        let Token = "\(responceData["token"]!)"
                        self.RegenerateToken(Token: Token)
                    }
                    else {
                        UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(responceData["statusdescription"]!)", Interval: 2)
                    }
                    
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    break
                }
        }
    }
    
    func RegenerateToken(Token:String) {
        
        UIApplication.shared.keyWindow?.StartLoading()

        let tokentype       = "1"
        let cell            = self.MobileNumberTxt.text!
        let msgcode         = "507"
        let mid             = MobiCreds.MID
        let merchantname    = MobiCreds.MerchentName
        
        let SecretKey = MobiCreds.RegenrationSecurity
        
        let VariableFormat  = "'\(cell)''\(merchantname)''\(mid)''\(msgcode)''\(Token)''\(tokentype)'" // ‘cell’‘merchantname’‘mid’‘msgcode’'Token''tokentype'
        
        let checksum        = VariableFormat.hmac(algorithm: .SHA256, key: SecretKey)
        
        let parserStr       = Parser(dict: ["cell":cell,"msgcode":msgcode,"mid":mid,"merchantname":merchantname,"tokentype":tokentype,"token":Token,"checksum":checksum])
        
        let UrlFormat       =  MobiCreds.BaseUrl + "/" + MobiCreds.Tokenregenerate + "?" + parserStr
        
        let url             = URL.init(string: UrlFormat.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!
        
        var Request         = URLRequest.init(url: url)
        Request.httpMethod  = "GET"
        Request.allHTTPHeaderFields = ["payloadtype":"json"]
        
        Alamofire.request(Request)
            .responseJSON { (responce) in
                UIApplication.shared.keyWindow?.StopLoading()

                switch responce.result {
                case .success(let Value):
                    print(Value)
                    let responceData = Value as! [String:AnyObject]
                    if "\(responceData["status"]!)" == "SUCCESS" {
                        let Token = "\(responceData["token"]!)"
                        self.DriveBookingResponce.WalletMobileNo = self.MobileNumberTxt.text!
                        self.DriveBookingResponce.WalletToken = Token
                        saveDriveResponceStuct(driveStruct: self.DriveBookingResponce!)
                        
                        UpdatePaymentModes(WalletType_Paytm_MobiKwik: "MobiKwik", MobileNo: self.DriveBookingResponce.WalletMobileNo!, Token: Token, ExpData_oMobi_Paytmdate: "0", CompletionAuthError: { (isauth) in
                            if isauth {
                                authenticationCheck(controller: self)
                            }
                        })
                        if self.IsNewWalletUSer {
                            self.CreateWalletUser()
                        }
                        else {
                            self.CloseOtpView()
                            self.Delegate.DidSignInComplete(controller: self)
                        }
                        
                    }
                    else {

                    }
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    break
                }
        }
    }
    
    func CreateWalletUser() {
        
        UIApplication.shared.keyWindow?.StartLoading()
        
        let cell            = MobileNumberTxt.text!
        let Token           = DriveBookingResponce.WalletToken!
        let msgcode         = "502"
        let mid             = MobiCreds.MID
        let merchantname    = MobiCreds.MerchentName
        
        let VariableFormat  = "'\(cell)''\(merchantname)''\(mid)''\(msgcode)''\(Token)'" // ‘cell’‘merchantname’‘mid’‘msgcode’‘otp’
        
        let checksum        = VariableFormat.hmac(algorithm: .SHA256, key: MobiCreds.Secret)
        
        let parserStr       = Parser(dict: ["cell":cell,"token":Token,"msgcode":msgcode,"mid":mid,"merchantname":merchantname,"checksum":checksum])
        
        let UrlFormat       =  MobiCreds.BaseUrl + "/" + MobiCreds.createwalletuser + "?" + parserStr
        
        let url             = URL.init(string: UrlFormat.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)!
        
        var Request         = URLRequest.init(url: url)
        Request.httpMethod  = "GET"
        Request.allHTTPHeaderFields = ["payloadtype":"json"]
        
        Alamofire.request(Request)
            .responseJSON { (responce) in
                
                UIApplication.shared.keyWindow?.StopLoading()
                
                switch responce.result {
                case .success(let Value):
                    print(Value)
                    let responceData = Value as! [String:AnyObject]
                    if "\(responceData["status"]!)" == "SUCCESS" {
                        self.DriveBookingResponce.WalletMobileNo = self.MobileNumberTxt.text!
                        saveDriveResponceStuct(driveStruct: self.DriveBookingResponce!)
                        self.view.ShowBlackTostWithText(message: "Account Created and Linked successfully", Interval: 5)
                        self.CloseOtpView()
                        self.Delegate.DidSignInComplete(controller: self)
                    }
                    else {
                        
                    }
                    
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    break
                }
        }
    }
    
    
    @IBAction func ResendOtp(_ sender:UIButton) {
        self.OTPView.endEditing(true)
        self.Resend()
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardHide(_:)), name: .UIKeyboardWillHide, object: nil)
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    //MARK: - Keyboard show
    
    
    
    @objc func keyboardShow(_ notification : NSNotification){
        
        if MobileNumberTxt.isFirstResponder {
            
            let info = notification.userInfo
            let keyboardframe = (info![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size
            var frame = CGRect.init()
            
            frame = MobileNumberTxt.frame
            frame.origin.y += (MobileNumberTxt.superview?.frame.origin.y)!
            frame.origin.y += 64
            
            var actualframe = self.view.frame
            actualframe.size.height -= keyboardframe.height
            actualframe.size.height -= (frame.size.height)
            
            if !actualframe.contains(frame.origin) {
                let yfinal = frame.origin.y - actualframe.size.height
                
                UIView.animate(withDuration: 0.3, animations: { () -> Void in
                    self.view.frame.origin.y -= yfinal
                })
            }
        }
        else if OTPTxt.isFirstResponder {
            
            let info = notification.userInfo
            let keyboardframe = (info![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size
            var frame = CGRect.init()
            
            frame.origin.y += (OTPTxt.superview?.frame.origin.y)!
            
            var actualframe = (UIApplication.shared.keyWindow?.frame)!
            actualframe.size.height -= keyboardframe.height
            actualframe.size.height -= (frame.size.height)
            
            if !actualframe.contains(frame.origin) {
                let yfinal = frame.origin.y - actualframe.size.height
                
                UIView.animate(withDuration: 0.3, animations: { () -> Void in
                    self.OTPView.frame.origin.y -= yfinal
                })
                
            }
        }
        
    }
    // MARK: - keyboard hide
    
    @objc func keyboardHide(_ notification : NSNotification)
    {
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.view.frame.origin.y = +64
            self.OTPView.frame.origin.y = self.ActualX
        })
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
