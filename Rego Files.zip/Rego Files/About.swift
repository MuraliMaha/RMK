//
//  About.swift
//  Drive Booking
//
//  Created by Amar on 14/03/17.
//  Copyright © 2017 suntelematics. All rights reserved.
//

import UIKit
 
class About: UIViewController {

    @IBOutlet var VersionLbl: UILabel!
    @IBOutlet weak var aboutUsTableView: UITableView!
    
    var aboutUsLinkArr = [AboutUsLinkStruct]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.black
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
        self.navigationItem.leftBarButtonItem = BackBtnItem
        self.navigationItem.title = "ABOUT"
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor : UIColor.black]
        
        self.VersionLbl.text = "V " + "\(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString")!)"
        
        self.aboutUsTableView.delegate = self
        self.aboutUsTableView.dataSource = self
        
        self.aboutUsTableView.tableFooterView = UIView.init(frame: CGRect.zero)
        self.aboutUsTableView.isScrollEnabled = false
        self.aboutUsTableView.rowHeight = 50
        createTempTitles()
    }
    func createTempTitles(){
     
        aboutUsLinkArr.append(AboutUsLinkStruct.init(title: "Rate us on iTunes", url: ""))
//        aboutUsLinkArr.append(AboutUsLinkStruct.init(title: "Like us on Facebook", url: ""))
//        aboutUsLinkArr.append(AboutUsLinkStruct.init(title: "Terms And Conditions", url: ""))
//        aboutUsLinkArr.append(AboutUsLinkStruct.init(title: "Privacy Policy", url: ""))
        
    }

    @objc func BackAction(_ sender: UIButton) {
//        self.navigationController?.popToRootViewController(animated: true)
        self.navigationController?.popViewController(animated: true)
    }
//    @IBAction func backACtion(_ sender: UIButton) {
//        self.navigationController?.popToRootViewController(animated: true)
//    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
extension About : UITableViewDelegate , UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aboutUsLinkArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "AboutUsCell", for: indexPath) as! CellClass
        cell.titleLabel.text = aboutUsLinkArr[indexPath.row].title
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        switch indexPath.row {
        case 0:
            if #available(iOS 10, *){
                UIApplication.shared.open(URL.init(string: "itms-apps://itunes.apple.com/us/app/apple-store/id1352933482")!, options: [:], completionHandler: nil)
            }else{
                UIApplication.shared.openURL(URL.init(string: "itms-apps://itunes.apple.com/us/app/apple-store/id1352933482")!)
            }
            
            break
            
        default:
            break
            
        }
    }
    
}
class CellClass : UITableViewCell {
    @IBOutlet weak var titleLabel: UILabel!
}

struct AboutUsLinkStruct{
    var title : String!
    var url : String!
}
