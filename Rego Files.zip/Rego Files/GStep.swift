//
//  GStep.swift
//  GDirections
//
//  Created by Raja Bhuma on 16/09/17.
//  Copyright © 2017 MyFriends. All rights reserved.
//

import UIKit
import CoreLocation

public struct GStep {
    
    public let start_location: CLLocationCoordinate2D!
    
    public let end_location: CLLocationCoordinate2D!
    
    public let distance: (text:String,value:String)!
    
    public let duration: (text:String,value:String)!
    
    public let html_instructions: NSAttributedString!
    
    public let polyline: String!
    
    public let travel_mode: String!
    
    public init(value: [String:Any]) {
        
        let Start = value["start_location"] as! [String:Any]
        
        let End = value["end_location"] as! [String:Any]
        
        start_location = CLLocationCoordinate2DMake(Double("\(Start["lat"]!)")!, Double("\(Start["lng"]!)")!)
        
        end_location = CLLocationCoordinate2DMake(Double("\(End["lat"]!)")!, Double("\(End["lng"]!)")!)
        
        let Dist = value["distance"] as! [String:Any]
        
        let Durat = value["duration"] as! [String:Any]
        
        distance = ("\(Dist["text"]!)","\(Dist["value"]!)")
        
        duration = ("\(Durat["text"]!)","\(Durat["value"]!)")
        
        polyline = "\((value["polyline"] as! [String:Any])["points"]!)"
        
        travel_mode = "\(value["travel_mode"]!)"
        
        html_instructions = try? NSAttributedString.init(data: "\(value["html_instructions"]!)".data(using: .unicode)!, options: [NSAttributedString.DocumentReadingOptionKey.documentType : NSAttributedString.DocumentType.html], documentAttributes: nil)
                
    }
    
}


// MARK: - CustomStringConvertible & CustomDebugStringConvertible

extension GStep: CustomStringConvertible, CustomDebugStringConvertible {
    
    public var description: String {
       return self.debugDescription
    }

    public var debugDescription: String {
        
        var Debug = [String]()
        
        Debug.append("start_location: \(start_location!), end_location: \(end_location!)")
        Debug.append("distance: \(distance!), duration: \(duration!)")
        Debug.append("html_instructions: \(html_instructions.string)")
        Debug.append("polyline: \(polyline!), travel_mode: \(travel_mode!)")

        return Debug.joined(separator: "\n")
    }
}

