//
//  Offers.swift
//  Drive Booking
//
//  Created by Amar on 14/03/17.
//  Copyright © 2017 suntelematics. All rights reserved.
//

import UIKit

class Offers: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var collectionView: UICollectionView! //img: 77
    
    @IBOutlet weak var pageControl: UIPageControl!
    
    
    var OfferImagesarray = NSMutableArray()
    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!
    
    var navigationBarHeight : CGFloat!
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.delegate = self
        collectionView.dataSource = self
        pageControl.hidesForSinglePage = true
        pageControl.currentPage = 0
        self.LoginRequest = FetchDriveRequest()
        self.DriveBookingResponce = FetchDriveResponce()
        offersAPI()
        
        print("self.navigationBarHeight = ",self.navigationBarHeight)
    }
   
    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func offersAPI(){
    
        if (Reachability()?.isReachable)! {
            
            self.view.StartLoading()
        let DriveDict = ["EmpId":"\(DriveBookingResponce.EmpId!)",
            "MobileNo":"\(DriveBookingResponce.PhoneNo!)",
            "VendorId":"\(LoginRequest.LoginCreds.VendorId!)",
            "CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)",
            "AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)"]
            print(DriveDict)
 
        WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveGetOffers, parameterDict: DriveDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (response, responceCode, success) in
                        
                print("*******\(response)")
                //            hideLoading()
            self.view.StopLoading() 
                if success{
                    let ResponceArr = (response as! NSDictionary).object(forKey: "Table") as! NSArray
 
                var data = [String:AnyObject]()
                if ResponceArr.count > 0{
                for i in 0..<ResponceArr.count{
                
                    data  = ResponceArr.object(at: i) as! [String : AnyObject]
                    self.OfferImagesarray.add(data)
                    
                  }
                    if self.OfferImagesarray.count == 0{
                        UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "No Offers Found", Interval: 2)
                    }
                }else{
                
                 UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "No Offers Found", Interval: 2)
                    
                    return
                }
 
                self.pageControl.numberOfPages = self.OfferImagesarray.count
                self.collectionView.reloadData()
                 
                }
                else{
             UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)
            
            }
                })
            }else{
         
            self.view.ShowBlackTostWithText(message: "please Check your Internet Connection", Interval: 3)
            return
            
        }

    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return OfferImagesarray.count
    }
    
 
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath)
            as! OffersCell
 
 
        if (((self.OfferImagesarray.object(at: indexPath.row) as! NSDictionary).object(forKey: "Status") as! String)) == "true"{
//            let url : NSURL = NSURL.init(string: "\((((self.OfferImagesarray.object(at: indexPath.row) as! NSDictionary).object(forKey: "ImageURL") as! String)))" )!
//            let urldata = NSData(contentsOf: url as URL)
//            cell.offersImage.image = UIImage.init(data:urldata! as Data)
            
            cell.offersImage.af_setImage(withURL: URL(string: "\((((self.OfferImagesarray.object(at: indexPath.row) as! NSDictionary).object(forKey: "ImageURL") as! String)))")!, placeholderImage: UIImage(named: "Launch"), filter: nil, progress: nil, progressQueue: DispatchQueue.main, imageTransition: .noTransition, runImageTransitionIfCached: true, completion: { (imageData) in
                if imageData.data != nil{
                cell.offersImage.image = UIImage.init(data: imageData.data!)!
                }
            })
            
            
                }
        
        cell.offersImage.contentMode = .scaleAspectFit
        cell.offersImage.clipsToBounds = true
        
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
//        print(indexPath.row)
        self.pageControl.currentPage = indexPath.row
      }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
       
        return CGSize(width: self.collectionView.frame.width, height: self.collectionView.frame.height)
    }
    
    @IBAction func backAction(_ sender: UIButton) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    

}
