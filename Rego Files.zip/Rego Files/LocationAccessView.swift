//
//  LocationAccessView.swift
//  
//
//  Created by Raja Bhuma on 06/05/17.
//
//

import UIKit

class LocationAccessView: UIViewController {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(CallDissmiss), name: NSNotification.Name(rawValue: "LocationDenied"), object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "LocationDenied"), object: nil)
    }
    
    @objc func CallDissmiss() {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func SettingsBtnPressed(_ sender:UIButton) {
       
        let url = URL.init(string: UIApplicationOpenSettingsURLString)!
        
        if UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.openURL(url)
        }
    }
    
}
