//
//  UtilitiesClass.swift
//  WannaHelp
//
//  Created by Raja Bhuma on 30/03/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit
import CoreLocation
import GoogleMaps
import Alamofire

class UtilitiesClass: NSObject
{
    
    
    
}

func ShowLocationDenied(controller:UIViewController) {
    let Location = LocationAccessView.init(nibName: "LocationAccessView", bundle: Bundle.main)
    
    let transition = CATransition()
    transition.duration = 0.45
    transition.type = kCATransitionFade;
    transition.subtype = kCATransitionFromTop;
    
    Location.view.layer.add(transition, forKey: kCATransition)
    
    controller.present(Location, animated: true, completion: nil)
}

// MARK: - Distance Calculater

func getDistanceFromLatLonInKm(lat1:Double,lon1:Double,lat2:Double,lon2:Double) -> Double {
    let R = 6371.0
    let dLat = deg2rad(deg: lat2-lat1)
    let dLon = deg2rad(deg: lon2-lon1)
    let a =
        sin(dLat/2) * sin(dLat/2) +
            cos(deg2rad(deg: lat1)) * cos(deg2rad(deg: lat2)) *
            sin(dLon/2) * sin(dLon/2)
    ;
    let c = 2 * atan2(sqrt(a), sqrt(1-a))
    let d = R * c
    return d;
}

func deg2rad(deg:Double) -> Double {
    let Div = Double.pi / 180
    
    return deg * Div
}


func authenticationCheck(controller: UIViewController){
    UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
    UserDefaults.standard.synchronize()
    
    let RegisterView = controller.storyboard?.instantiateViewController(withIdentifier: "navigation")
    controller.present(RegisterView!, animated: true, completion: nil)

}
