//
//  AppDelegate.swift
//  DriveBooking
//
//  Created by Raja Bhuma on 12/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit
import CoreData
import AlamofireImage
import GoogleMaps
import OneSignal
@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    
    
    ///
    ///
    ///
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        GMSServices.provideAPIKey(GOOGLEKeys.MainKey)
//        Direction Key AIzaSyD1zadZ__YSJ0QovvhjqkRUF6y5Rts7E60
        GStore.setApiKey(Key: GOOGLEKeys.DirectionKey)

        let onesignalInitSettings = [kOSSettingsKeyAutoPrompt: false, kOSSettingsKeyInAppLaunchURL: true, ]
        
        OneSignal.initWithLaunchOptions(launchOptions, appId: "631631c3-0755-4642-9daf-a179183236d5", handleNotificationReceived: { (notification) in                      //self.ShowPayLoad(with: (notification?.payload.body)!)
            print((notification?.payload)!)
            let payload = notification?.payload
            _ = payload?.body
            
        }, handleNotificationAction: { (result) in
            //app in background state
            // This block gets called when the user reacts to a notification received
            let payload = result?.notification.payload
            var fullMessage = payload?.body
            if let additionalData = payload?.additionalData, let actionSelected = additionalData["actionSelected"] as? String {
                fullMessage =  fullMessage! + "\nPressed ButtonId:\(actionSelected)"
                
            }
            print((result?.notification?.payload)!)
            
        }, settings: onesignalInitSettings)
        //[kOSSettingsKeyAutoPrompt : false , kOSSettingsKeyInAppAlerts : false , kOSSettingsKeyInFocusDisplayOption : OSNotificationDisplayType.none.rawValue]        OneSignal.inFocusDisplayType = OSNotificationDisplayType.notification
        OneSignal.promptForPushNotifications { (success) in
            print("Notif State", success)
            
        }
        
        var OneSignalID = ""
        let State = OneSignal.getPermissionSubscriptionState()
        if State?.permissionStatus.status == .authorized {
            if State?.subscriptionStatus.userId != nil {
                OneSignalID = "\((State?.subscriptionStatus.userId!)!)"
                print("OnesignalID::::",OneSignalID
                )
                
            }
            
        }
        return true
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        
        if CLLocationManager.authorizationStatus() == .authorizedWhenInUse || CLLocationManager.authorizationStatus() == .authorizedAlways {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "LocationDenied"), object: nil)
        }
        
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
        // Saves changes in the application's managed object context before the application terminates.
        AutoPurgingImageCache().removeAllImages()
        self.saveContext()
    }
    
    

    // MARK: - Core Data stack

    let storeName = "DriveBooking"
    let storeFilename = "DriveBooking.sqlite"
    
    @available(iOS 10.0, *)
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: self.storeName)
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    
    lazy var managedObjectContext: NSManagedObjectContext = {
        // Returns the managed object context for the application (which is already bound to the persistent store coordinator for the application.) This property is optional since there are legitimate error conditions that could cause the creation of the context to fail.
        let coordinator = self.persistentStoreCoordinator
        var managedObjectContext = NSManagedObjectContext(concurrencyType: .mainQueueConcurrencyType)
        managedObjectContext.persistentStoreCoordinator = coordinator
        return managedObjectContext
    }()
    
    lazy var applicationDocumentsDirectory: NSURL = {
        // The directory the application uses to store the Core Data store file. This code uses a directory named "me.iascchen.MyTTT" in the application's documents Application Support directory.
        let urls = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return urls.last! as NSURL
    }()
    
    lazy var managedObjectModel: NSManagedObjectModel = {
        let modelURL = Bundle.main.url(forResource: self.storeName, withExtension: "momd")!
        return NSManagedObjectModel(contentsOf: modelURL)!
    }()
    
    lazy var persistentStoreCoordinator: NSPersistentStoreCoordinator = {
        let coordinator = NSPersistentStoreCoordinator(managedObjectModel: self.managedObjectModel)
        let url = self.applicationDocumentsDirectory.appendingPathComponent(self.storeFilename)
        var failureReason = "There was an error creating or loading the application's saved data."
        do {
            try coordinator.addPersistentStore(ofType: NSSQLiteStoreType, configurationName: nil, at: url, options: nil)
        } catch {
            // Report any error we got.
            var dict = [String: AnyObject]()
            dict[NSLocalizedDescriptionKey] = "Failed to initialize the application's saved data" as AnyObject
            dict[NSLocalizedFailureReasonErrorKey] = failureReason as AnyObject
            
            dict[NSUnderlyingErrorKey] = error as NSError
            let wrappedError = NSError(domain: "YOUR_ERROR_DOMAIN", code: 9999, userInfo: dict)
            NSLog("Unresolved error \(wrappedError), \(wrappedError.userInfo)")
            abort()
        }
        
        return coordinator
    }()

    // MARK: - Core Data Saving support

    func saveContext () {
        
        var context = self.managedObjectContext
        
        if #available(iOS 10.0, *) {
            context = persistentContainer.viewContext
        }
        
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }

    // MARK: - Vendar Config
    
    func application(_ app: UIApplication, open url: URL, options: [UIApplicationOpenURLOptionsKey : Any] = [:]) -> Bool {
        
        return DriveConfigVender.shared.CheckVendear(UrlScheme: url, application: app, window: window!)
    }
    
    func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
        
        return DriveConfigVender.shared.CheckVendear(UrlScheme: url, application: application, window: window!)
    }
    
    func application(_ application: UIApplication, handleOpen url: URL) -> Bool {
        
        return DriveConfigVender.shared.CheckVendear(UrlScheme: url, application: application, window: window!)
    }
    
    func application(_ application: UIApplication, performActionFor shortcutItem: UIApplicationShortcutItem, completionHandler: @escaping (Bool) -> Void) {
        print(shortcutItem.localizedTitle)
    }
}

