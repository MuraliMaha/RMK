//
//  DriveConfigVender.swift
//  OpenProject
//
//  Created by Raja Bhuma on 26/05/17.
//  Copyright © 2017 Raja Bhuma. All rights reserved.
//

import UIKit

class DriveConfigVender {
    static let shared = DriveConfigVender()
    
    open func CheckVendear(UrlScheme:URL, application:UIApplication, window: UIWindow) -> Bool {
        let query = (UrlScheme.query?.removingPercentEncoding)!
        if UrlScheme.host! == "ConfigureScheme" {
            if UrlScheme.lastPathComponent == "VenderConfig" {
                print(query)
                ConfigVender(UrlScheme: UrlScheme, application: application, window: window)
                return true
            }
            else {
                return false
            }
        }
        else {
            return false
        }
    }
    
    static let Security = "SunTelematicsRideNowApp123123123"

    open func ConfigVender(UrlScheme:URL,application:UIApplication, window: UIWindow) {
        let query = (UrlScheme.query?.removingPercentEncoding)!
        let Decripted = CocoaSecurity.aesDecrypt(withBase64: query, key: DriveConfigVender.Security).utf8String!
        let QuiryData = Decripted.data(using: .utf8)!
        let Dict = try? JSONSerialization.jsonObject(with: QuiryData, options: .allowFragments)
        
        if Dict is [String:AnyObject] {
            
            let SchemeDict = Dict as! [String:AnyObject]

            if SchemeDict.keys.contains("VendorId") && SchemeDict.keys.contains("CorporateId") && SchemeDict.keys.contains("AppCustomerType") {
                
                var VenderDict = [String:String]()
                VenderDict["VendorId"] = "\(SchemeDict["VendorId"]!)"
                VenderDict["CorporateId"] = "\(SchemeDict["CorporateId"]!)"
                VenderDict["AppCustomerType"] = "\(SchemeDict["AppCustomerType"]!)"
                
                UserDefaults.standard.set(VenderDict, forKey: "NewAppConfig")
                UserDefaults.standard.synchronize()
                
                let approot = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "navigation")
                window.rootViewController?.present(approot, animated: false, completion: nil)
            }
        }
    }
}
