//
//  DetailsSelectClass.swift
//  DriveFindMyCab
//
//  Created by Appsraise on 08/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit

protocol DetailsSelectDelegate {
    func DidCancelPressed(_ controller:DetailsSelectClass)
    func DidSelectAirport(_ FormatedDate:String,_ IsGoingTo:Bool,_ controller:DetailsSelectClass)
    func DidSelectOutStation(_ FormatedDate:String,_ numberOfDays:String!,_ DestinationLoc:FavouritesLocationsStruct,_ controller:DetailsSelectClass)
    func DidSelectPackage(_ FormatedDate:String,_ controller:DetailsSelectClass)
}

class DetailsSelectClass: UIViewController,UITextFieldDelegate {
    
    @IBOutlet var RemovableView:UIView!
    @IBOutlet var RemovebleviewHeight:NSLayoutConstraint!
    
    var TripTypeSelect:TripType!
    
    var Delegate:DetailsSelectDelegate!
    
    var AdvanceBookingDuration = 60
    
    var DriveBookingResponce:DriveLoginResponce!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        DriveBookingResponce = FetchDriveResponce()
        
        DatePicker.setValue(UIColor.white, forKey: "textColor")
        TimePicker.setValue(UIColor.white, forKey: "textColor")
        
        
        var DateComponets = Date().GregDateComponents(([.year,.month,.day]))
        
        var months = DateComponets.month
        var Year = DateComponets.year
        
        months! += 2
        
        if months! > 12 {
            months! -= 12
            Year! += 1
        }
        
        DateComponets.setValue(months!, for: .month)
        DateComponets.setValue(Year!, for: .year)
        
        let TwoMonthsDate = GregCalender().date(from: DateComponets)
        
        
        DatePicker.minimumDate = Date()
        DatePicker.maximumDate = TwoMonthsDate
        
        TimePicker.date = Date().addingTimeInterval(TimeInterval((60 * Float(AdvanceBookingDuration))))
        print("Time From viewDidLoad = ",Date().addingTimeInterval(TimeInterval((60 * Float(AdvanceBookingDuration)))))
        
        DatePicker.contentVerticalAlignment = .center
        DatePicker.contentHorizontalAlignment = .center
        
        TimePicker.contentVerticalAlignment = .center
        TimePicker.contentHorizontalAlignment = .center
        
        
        if TripTypeSelect == .package {
            RemovebleviewHeight.constant = 0;
            RemovableView.isHidden = true
        }
        else {
            if TripTypeSelect == .airport {
                AirportView.isHidden = false
                OutStationView.isHidden = true
            }else {
                AirportView.isHidden = true
                OutStationView.isHidden = false
            }
        }
        
        
        let donetoolbar = UIToolbar(frame : CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        
        donetoolbar.barStyle = UIBarStyle.default
        donetoolbar.backgroundColor = UIColor.black
        let flexspace = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let done = UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(DoneReturn))
        
        donetoolbar.tintColor = UIColor.blue
        donetoolbar.items = [flexspace,done]
        donetoolbar.sizeToFit()
        
        NumberOfDaysTxt.inputAccessoryView = donetoolbar
        
    }
    
    @objc func DoneReturn() {
        NumberOfDaysTxt.resignFirstResponder()
        //        DestinationTxt.becomeFirstResponder()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Date Pickers Handle {
    
    @IBOutlet var DatePicker:UIDatePicker!
    @IBOutlet var TimePicker:UIDatePicker!
    
    @IBAction func DatePickerPicked(_ DatePicker:UIDatePicker) {
        
        if DatePicker.date.compare(Date()) == .orderedAscending {
            let date = Date().addingTimeInterval(TimeInterval((60 * Float(AdvanceBookingDuration))))
            TimePicker.date = date
            TimePicker.minimumDate = date
        }
        else {
            var TimeComponets = Date().GregDateComponents(([.minute,.hour,.second]))
            TimeComponets.setValue(0, for: .minute)
            TimeComponets.setValue(0, for: .hour)
            TimePicker.date = GregCalender().date(from: TimeComponets)!
            TimePicker.minimumDate = nil
        }
        //
    }
    
    @IBAction func TimePickerPicked(_ TimePicker:UIDatePicker) {
        
    }
    
    
    // MARK: - }
    
    // MARK: - AirPort Handle {
    
    @IBOutlet var AirportView:UIView!
    @IBOutlet var GoingToAirportBtn:UIButton!
    @IBOutlet var CommingFromAirportBtn:UIButton!
    
    @IBAction func GoingToAirportBtnPressed(_ sender:UIButton) {
        self.GoingToAirportBtn.isSelected = true
        self.CommingFromAirportBtn.isSelected = false
    }
    
    @IBAction func CommingFromAirportBtnPressed(_ sender:UIButton) {
        self.GoingToAirportBtn.isSelected = false
        self.CommingFromAirportBtn.isSelected = true
    }
    
    // MARK: - }
    
    
    // MARK: - OutStation Handle {
    @IBOutlet var OutStationView:UIView!
    @IBOutlet var NumberOfDaysTxt:UITextField!
    @IBOutlet var DestinationTxt:UITextField!
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == DestinationTxt {
            
            let SearchController = FavoriteLocationSelectVC()
            SearchController.Delegate = self
            SearchController.IsSearchNeeded = true
            SearchController.isFavoritesNeeded = false
            self.present(SearchController, animated: true, completion: nil)
            return false
        }
        return true
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == NumberOfDaysTxt {
            
            let aSet = NSCharacterSet(charactersIn:"0123456789").inverted
            let compSepByCharInSet = string.components(separatedBy: aSet)
            let numberFiltered = compSepByCharInSet.joined(separator: "")
            return string == numberFiltered
        }
        else {
            return true
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardShow(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardHide(_:)), name: .UIKeyboardWillHide, object: nil)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: .UIKeyboardWillHide, object: nil)
    }
    
    @objc func keyboardShow(_ notification : NSNotification){
        
        if NumberOfDaysTxt.isFirstResponder {
            let info = notification.userInfo
            let keyboardframe = (info![UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.size
            var phoneframe = CGRect.init()
            phoneframe = NumberOfDaysTxt.frame
            
            phoneframe.origin.y += (NumberOfDaysTxt.superview?.frame.origin.y)!
            phoneframe.origin.y += (NumberOfDaysTxt.superview?.superview?.frame.origin.y)!
            phoneframe.origin.y += (NumberOfDaysTxt.superview?.superview?.superview?.frame.origin.y)!
            
            var actualframe = self.view.frame
            actualframe.size.height -= keyboardframe.height
            actualframe.size.height -= (phoneframe.size.height)
            
            if !actualframe.contains((phoneframe.origin)) {
                let yfinal = (phoneframe.origin.y) - actualframe.size.height
                
                UIView.animate(withDuration: 0.3, animations: { () -> Void in
                    
                    self.view.frame.origin.y -= yfinal
                })
                
            }
        }
    }
    
    @objc func keyboardHide(_ notification : NSNotification)
    {
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            self.view.frame.origin.y = 0
        })
    }
    
    // MARK: - }
    
    // MARK: - Action Buttons {
    
    @IBAction func SelectBtnPressed(_ sender:UIButton) {
        
        
        if TripTypeSelect! == .outstation && NumberOfDaysTxt.text == "" {
            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Enter Number of Days", Interval: 3)
        }
        else if TripTypeSelect! == .outstation && NumberOfDaysTxt.text != "" && DestinationTxt.text == "" {
            DestinationTxt.becomeFirstResponder()
        }
        else {
            
            let SelectedGregTime = DatePicker.date.GregDateComponents(([.year,.month,.day,.hour,.minute,.second]))
            let TodayComponents = Date().GregDateComponents(([.year,.year,.day,.month,.hour,.second]))
            
            var FilterSelectedGreg = SelectedGregTime
            FilterSelectedGreg.setValue(TimePicker.countDownDuration.GetHours(), for: .hour)
            FilterSelectedGreg.setValue(TimePicker.countDownDuration.GetMinutes(), for: .minute)
            FilterSelectedGreg.setValue(TimePicker.countDownDuration.GetSeconds(), for: .second)
            
            let InterValChange = GregCalender().date(from: FilterSelectedGreg)?.timeIntervalSince(Date())
            
            let Typederror = TypedErrors()
            
            if ((SelectedGregTime.year)! == (TodayComponents.year)! && (SelectedGregTime.month)! == (TodayComponents.month)! && (SelectedGregTime.day)! == (TodayComponents.day)!) && (Int(InterValChange!) < ((AdvanceBookingDuration * 60) - 30))
            {
                let advanceMin = Int(AdvanceBookingDuration)
                
                var finalAdvanceTime = ""
                
                if (advanceMin/60) != 0 {
                    finalAdvanceTime = "\(advanceMin/60) hour "
                }
                
                if (advanceMin % 60) > 0 {
                    finalAdvanceTime = finalAdvanceTime + "\(advanceMin % 60) Minute"
                }
                
                UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Select minimum \(finalAdvanceTime) advance time", Interval: 3)
            }
            else if Typederror != "" {
                UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Typederror, Interval: 2)
            }
            else {
                
                let Format = DateFormatter()
                Format.dateFormat = "dd-MMM-yyyy"
                Format.locale = NSLocale.current
                Format.timeZone = NSTimeZone.local
                
                var FormatedDateStr = Format.string(from: DatePicker.date)
                
                FormatedDateStr.append("\((FilterSelectedGreg.hour)!)".count == 1 ? " 0\((FilterSelectedGreg.hour)!):" : " \((FilterSelectedGreg.hour)!):")
                FormatedDateStr.append("\((FilterSelectedGreg.minute)!)".count == 1 ? "0\((FilterSelectedGreg.minute)!)" : "\((FilterSelectedGreg.minute)!)")
                
                switch TripTypeSelect! {
                case .airport:
                    Delegate.DidSelectAirport(FormatedDateStr, GoingToAirportBtn.isSelected, self)
                    break
                case .outstation:
                    Delegate.DidSelectOutStation(FormatedDateStr, NumberOfDaysTxt.text!, SelectedFav!, self)
                    break
                case .package:
                    Delegate.DidSelectPackage(FormatedDateStr, self)
                    break
                }
            }
            
        }
        
    }
    
    func TypedErrors() -> String {
        
        switch TripTypeSelect! {
        case .airport:
            if !CommingFromAirportBtn.isSelected && !GoingToAirportBtn.isSelected {
                return "Please choose one option"
            }
            else {
                return ""
            }
        case .outstation:
            if NumberOfDaysTxt.text == "" // || NumberOfDaysTxt.text == "0"
            {
                return "Enter No of Days"
            }
            else if Int(NumberOfDaysTxt.text!)! <= 0 {
                return "Please select minumum 1 day"
            }
            else {
                return ""
            }
        case .package:
            return ""
        }
        
    }
    
    @IBAction func CancelBtnPressed(_ sender:UIButton) {
        Delegate.DidCancelPressed(self)
    }
    // MARK: - }
    
    var isFavorite = false
    var SelectedFav:FavouritesLocationsStruct!
}

extension DetailsSelectClass:FavoriteLocSelectDelegate {
    
    func DidSelectChooseOnMap(_ controller: FavoriteLocationSelectVC) {
        
    }
    func DidCancelPicking(_ controller: FavoriteLocationSelectVC) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    func DidSelect(_ FavObj: FavouritesLocationsStruct, _ isfavorite: Bool, _ controller: FavoriteLocationSelectVC) {
        SelectedFav = FavObj
        isFavorite = isfavorite
        DestinationTxt.text = SelectedFav.Location!
        controller.dismiss(animated: true, completion: nil)
    }
    
}

