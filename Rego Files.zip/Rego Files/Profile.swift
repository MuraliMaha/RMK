//
//  Profile.swift
//  Drive Booking
//
//  Created by Amar on 14/03/17.
//  Copyright © 2017 suntelematics. All rights reserved.
//

import UIKit

class Profile: UIViewController, UITextFieldDelegate, UIGestureRecognizerDelegate {

    @IBOutlet weak var mobileTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    @IBOutlet weak var NameTextField: UITextField!

    let bottomLine = CALayer()
    let bottomLine1 = CALayer()
    let bottomLine2 = CALayer()
    let bottomLine3 = CALayer()
    
    
    @IBOutlet weak var updatePasswordBgView: UIView!
    
    @IBOutlet weak var oldPasswordtextField: UITextField!
    @IBOutlet weak var newPasswordtextField: UITextField!
    @IBOutlet weak var confirmpasswordTextField: UITextField!
    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.isNavigationBarHidden = false
    }

    
    @IBOutlet weak var updatepasswdView: UIView!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.isNavigationBarHidden = true
        self.LoginRequest = FetchDriveRequest()
        self.DriveBookingResponce = FetchDriveResponce()

        // Do any additional setup after loading the view.
        oldPasswordtextField.delegate = self
        newPasswordtextField.delegate = self
        confirmpasswordTextField.delegate = self
        updatePasswordBgView.isHidden = true
        
        mobileTextField.delegate = self
        emailTextField.delegate = self
        PasswordTextField.delegate = self
        NameTextField.delegate = self
        
        mobileTextField.isUserInteractionEnabled = false
        emailTextField.isUserInteractionEnabled = false
        PasswordTextField.isUserInteractionEnabled = false
        NameTextField.isUserInteractionEnabled = false
        
         
        bottomLine.frame = CGRect(x :0.0, y: NameTextField.frame.height - 1, width: NameTextField.frame.width, height: 1.0)
        bottomLine.backgroundColor = UIColor.black.cgColor
        NameTextField.borderStyle = UITextBorderStyle.none
        NameTextField.layer.addSublayer(bottomLine)
        
        bottomLine1.frame = CGRect(x :0.0, y: emailTextField.frame.height - 1, width: emailTextField.frame.width, height: 1.0)
        bottomLine1.backgroundColor = UIColor.black.cgColor
        emailTextField.borderStyle = UITextBorderStyle.none
        emailTextField.layer.addSublayer(bottomLine1)
        
        
        bottomLine2.frame = CGRect(x :0.0, y: mobileTextField.frame.height - 1, width: mobileTextField.frame.width, height: 1.0)
        bottomLine2.backgroundColor = UIColor.black.cgColor
        mobileTextField.borderStyle = UITextBorderStyle.none
        mobileTextField.layer.addSublayer(bottomLine2)
        
        bottomLine3.frame = CGRect(x :0.0, y: PasswordTextField.frame.height - 1, width: PasswordTextField.frame.width, height: 1.0)
        bottomLine3.backgroundColor = UIColor.black.cgColor
        PasswordTextField.borderStyle = UITextBorderStyle.none
        PasswordTextField.layer.addSublayer(bottomLine3)

        
        let gestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        gestureRecognizer.delegate = self
        updatePasswordBgView.addGestureRecognizer(gestureRecognizer)
        
        
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        //        toolBar.tintColor = UIColor(red: 76/255, green: 217/255, blue: 100/255, alpha: 1)
        toolBar.tintColor = UIColor.blue
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action:#selector(donePicker))
        
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        //        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.plain, target: self, action:#selector(cancelPicker))
        
        toolBar.setItems([spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
         NameTextField.inputAccessoryView = toolBar
     
        emailTextField.text! =  "\(DriveBookingResponce.Email!)"
        NameTextField.text! =   "\(DriveBookingResponce.Name!)"
        mobileTextField.text! = "\(DriveBookingResponce.PhoneNo!)"
        PasswordTextField.text! =  LoginRequest.Password!//UserDefaults.standard.object(forKey: "Gpassword") as? String ?? ""
        
     }
    @objc func handleTap(gestureRecognizer: UIGestureRecognizer) {
        
        
        let Point = gestureRecognizer.location(in: self.updatePasswordBgView)
        let Frame = updatepasswdView.frame
        
        if !Frame.contains(Point) {
            updatePasswordBgView.isHidden = true
            self.oldPasswordtextField.resignFirstResponder()
            self.newPasswordtextField.resignFirstResponder()
            self.confirmpasswordTextField.resignFirstResponder()
        }
 
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func saveAction(_ sender: UIButton) {
           if (Reachability()?.isReachable)! {

        if NameTextField.text! == ""{
            print("please enter Name")
            self.view.ShowBlackTostWithText(message: "Enter Username", Interval: 3)
             return
         }
        UpdateProfile(UserName: NameTextField.text!)
        }else{
        self.view.ShowBlackTostWithText(message: "please Check your Internet Connection", Interval: 3)
             return
            
        }
    }
    @IBAction func updatePasswordAction(_ sender: UIButton) {
        self.view.endEditing(true)
          if (Reachability()?.isReachable)! {
        if oldPasswordtextField.text! == ""{
            self.view.ShowBlackTostWithText(message: "Please Enter your Old Password", Interval: 3)
             return
        }
        if oldPasswordtextField.text! != LoginRequest.Password! {
            self.view.ShowBlackTostWithText(message: "Old Password is not Matching with Records", Interval: 3)

             return
        }
        if newPasswordtextField.text! == ""{
            self.view.ShowBlackTostWithText(message: "Please Enter your New Password", Interval: 3)
            
             return
        }
        if newPasswordtextField.text!.characters.count < 5{
        self.view.ShowBlackTostWithText(message: "Password should be atleast 5 characters", Interval: 3)
            
             return
        }
        if confirmpasswordTextField.text! == ""{
             self.view.ShowBlackTostWithText(message: "Please Confirm Your Password", Interval: 3)
            
             return
        }
        if oldPasswordtextField.text! == confirmpasswordTextField.text!{
            self.view.ShowBlackTostWithText(message: "Old password and New password should not be same", Interval: 3)
                return
        }
        if newPasswordtextField.text! == confirmpasswordTextField.text! {
            postupdatepasswordForm(password: newPasswordtextField.text!)
        }else{
            self.view.ShowBlackTostWithText(message: "New password and Confirm password should be same", Interval: 3)
             return
        
        }
          }else{
            self.view.ShowBlackTostWithText(message: "please Check your Internet Connection", Interval: 3)
            
             return
            
        }
    }
    
    @IBAction func backAction(_ sender: UIButton) {
//        self.navigationController?.popToRootViewController(animated: true)
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func LogoutAction(_ sender: UIButton) {
        let alert = UIAlertController(title: "Alert", message: "Are you sure you want to logout?", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
        
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { action in
            switch action.style{
            case .default:
                print("default")
//                var arr = [[String:String]]()
//                if (UserDefaults.standard.object(forKey: "EmegencyContactUserDefaults") as? [[String:String]]) != nil {
//                    arr = (UserDefaults.standard.object(forKey: "EmegencyContactUserDefaults") as? [[String:String]])!
//                }
            let RideLaterViewBool = UserDefaults.standard.bool(forKey: "RideLaterViewBool")

                
            UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
            UserDefaults.standard.synchronize()
                
            UserDefaults.standard.set(RideLaterViewBool, forKey: "RideLaterViewBool")
            UserDefaults.standard.synchronize()
//                UserDefaults.standard.set(arr, forKey: "EmegencyContactUserDefaults")
//                UserDefaults.standard.synchronize()

                
                let RegisterView = self.storyboard?.instantiateViewController(withIdentifier: "navigation")
                self.present(RegisterView!, animated: true, completion: nil)
                
            case .cancel:
                print("cancel")
                
            case .destructive:
                print("destructive")
            
            }}))


    }
    @IBAction func passwordEditAction(_ sender: UIButton) {
        self.oldPasswordtextField.text = nil
        self.newPasswordtextField.text = nil
        self.confirmpasswordTextField.text = nil
        updatePasswordBgView.isHidden = false
    }
    @IBAction func NameEditAction(_ sender: UIButton) {
        
        NameTextField.isUserInteractionEnabled = true
        NameTextField.becomeFirstResponder()
        UITextField.appearance().tintColor = UIColor.black
    
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool      {
        return textField.resignFirstResponder()
     }
    func textFieldDidEndEditing(_ textField: UITextField){
    
        
        if textField.tag == 10{
            PasswordTextField.isUserInteractionEnabled = false
        }
        if textField.tag == 20{
            NameTextField.isUserInteractionEnabled = false
        }
        
    }

    @objc func donePicker(sender : UIBarButtonItem){
    
        self.NameTextField.resignFirstResponder()
     
    }

func cancelPicker(sender : UIBarButtonItem ){
    
        self.NameTextField.resignFirstResponder()
     
}
 func postupdatepasswordForm(password: String){
        if (Reachability()?.isReachable)! {
 self.view.StartLoading()
            
            let DriveDict = ["MobileNo":"\(DriveBookingResponce.PhoneNo!)","Password":"\(password)","VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)","Version":"\(LoginRequest.Version!)","EmpId":"\(DriveBookingResponce.EmpId!)"]
            print(DriveDict)
WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveGetUpdatedPassword, parameterDict: DriveDict, securityKey: WebServicesUrl.DummySecurity, completion: { (response, ErrorCode, success) in
 
                print("*******\(response)")
                //
                if success{
                    let TableArray = (response as! NSDictionary).object(forKey: "Table") as! NSArray
                     let tableData = TableArray.object(at: 0) as! NSDictionary
                    print("LoopTableArray::::\(tableData)")
                    
                    let verifyUser = tableData.object(forKey: "Status") as! String
                    let Response = tableData.object(forKey: "Response") as! String
                    if verifyUser == "false"{
                        self.view.StopLoading()
                        Message.shared.Alert(Title: "Alert", Message: Response, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                        
                         return
                    }
                    else if verifyUser == "true"{
                        self.updatePasswordBgView.isHidden = true
                        self.PasswordTextField.text =  self.confirmpasswordTextField.text!
                        
 
                        
                        self.LoginRequest.Password = self.confirmpasswordTextField.text!
                        SaveDriveRequestStruct(Request: self.LoginRequest!)
                        
                        self.oldPasswordtextField.resignFirstResponder()
                        self.newPasswordtextField.resignFirstResponder()
                        self.confirmpasswordTextField.resignFirstResponder()
                        self.view.StopLoading()
                        Message.shared.Alert(Title: "Alert", Message: Response, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }

                }
                else{
                    self.view.StopLoading()
                    Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    
                    
                     return
                }
            })
        }else{
            
        Message.shared.Alert(Title: "Alert", Message: "Please Check your Internet Connection", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
             return
        }
    }
    var updateprofileResponse : String!
    func UpdateProfile(UserName: String){
        if (Reachability()?.isReachable)! {
            
self.view.StartLoading()
            let DriveDict = ["UserName":"\(UserName)","EmailId":"\(DriveBookingResponce.Email!)","MobileNo":"\(DriveBookingResponce.PhoneNo!)","VendorId":"\(LoginRequest.LoginCreds.VendorId!)","CorporateId":"\(LoginRequest.LoginCreds.CorporateId!)","AppCustomerType":"\(LoginRequest.LoginCreds.AppCustomerType!)","EmpId":"\(DriveBookingResponce.EmpId!)","Status":"0"]
            print(DriveDict)
            
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveSetUpdatedName, parameterDict: DriveDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (response, ErrorCode, success) in
 
                print("*******\(response)")
                
                self.view.StopLoading()
                if success{
                    let TableArray = (response as! NSDictionary).object(forKey: "Table") as! NSArray
                    
                    let tableData = TableArray.object(at: 0) as! NSDictionary
                    print("LoopTableArray::::\(tableData)")
                    
                    let verifyUser = tableData.object(forKey: "Status") as! String
                    let Response = tableData.object(forKey: "Response") as! String
                    self.updateprofileResponse = Response
                    if verifyUser == "false"{
                        Message.shared.Alert(Title: "Alert", Message: Response, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                         return
                    }
                    else if verifyUser == "true"{
                        self.view.StartLoading()
                         self.ApppostUpdateForm()
                    }
                    
                }else{
                    
                     Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                        
                    return
                }

             
            })
        }else{
            
            
            Message.shared.Alert(Title: "Alert", Message: "Please Check your Internet Connection", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            
            
             return
        }
        
    }
    
    
    func ApppostUpdateForm() {
       UIApplication.shared.keyWindow?.StartLoading() // self.view.StartLoading()
        let DriveRequest = FetchDriveRequest()!
        //        let DriveResponce = FetchDriveResponce()!
        
        let Dict = ["UserName":DriveRequest.UserName!,
                    "Password":DriveRequest.Password!,
                    "VendorId":DriveRequest.LoginCreds.VendorId!,
                    "CorporateId":DriveRequest.LoginCreds.CorporateId!,
                    "AppCustomerType":DriveRequest.LoginCreds.AppCustomerType!,
                    "Version":DriveRequest.Version!,
                    "DeviceToken":DriveRequest.DeviceToken!,
                    "DeviceIMEINO":DriveRequest.DeviceIMEINO!,
                    "DeviceType":DriveRequest.DeviceType!]
        
        WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveLogin, parameterDict: Dict, securityKey: WebServicesUrl.DummySecurity) { (value, responcecode, success) in
            if success {
                let Table = (value as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
                if "\(Table[0]["Status"]!)".toBool()! {
                    SaveDriveResponce(DriveResponce: Table[0])
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: self.updateprofileResponse, Interval: 2)
                    self.navigationController?.popToRootViewController(animated: true)
                }
                else {
                    print(value)
                }
            }
            else {
                print(responcecode.GetResponceCode())
            }
            UIApplication.shared.keyWindow?.StopLoading()
        }
    }

    
    

    

    override func viewDidDisappear(_ animated: Bool) {
       
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
