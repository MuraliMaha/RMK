//
//  SplashScreenVC.swift
//  DriveBooking
//
//  Created by Raja Bhuma on 12/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.

import UIKit

class SplashScreenVC: UIViewController {
    
    @IBOutlet var Activity: UIActivityIndicatorView!
    
    var Credentials: DriveCredentials!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        CLLocationManager().requestWhenInUseAuthorization()
        CLLocationManager().requestAlwaysAuthorization()
        self.perform(#selector(PerformAction), with: self, afterDelay: 0.4)
    }
    
    @objc func PerformAction() {
        
        FetchCredentials()
        
        if (UserDefaults.standard.value(forKey: "NewAppConfig") != nil) {
            
            let Data = UserDefaults.standard.value(forKey: "NewAppConfig") as! [String:String]
            
            if Credentials != nil {
                
                if !(Data["VendorId"]! == Credentials.VendorId! && Data["CorporateId"]! == Credentials.CorporateId! && Data["AppCustomerType"]! == Credentials.AppCustomerType!) {
                    
                    UIApplication.shared.keyWindow?.ShowBlackTostWithText(message:"New Configuration. Please wait while we configure", Interval: 3)
                    
                    UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
                    UserDefaults.standard.synchronize()
                    
                    var CredentialsNew = DriveCredentials()
                    CredentialsNew.VendorId = Data["VendorId"]!
                    CredentialsNew.CorporateId = Data["CorporateId"]!
                    CredentialsNew.AppCustomerType = Data["AppCustomerType"]!
                    SaveDriveCredentials(Credentails: CredentialsNew)
                    
                    Credentials = CredentialsNew
                }
            }
            else {
                
                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message:"New Configuration. Please wait while we configure", Interval: 3)
                
                UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
                UserDefaults.standard.synchronize()
                
                var CredentialsNew = DriveCredentials()
                CredentialsNew.VendorId = Data["VendorId"]!
                CredentialsNew.CorporateId = Data["CorporateId"]!
                CredentialsNew.AppCustomerType = Data["AppCustomerType"]!
                SaveDriveCredentials(Credentails: CredentialsNew)
                
                Credentials = CredentialsNew
                
            }
            
        }
        else {
            
            if (Credentials == nil) {
                Credentials = DriveCredentials()
                Credentials.VendorId = StaticCredentials.VendorId
                Credentials.CorporateId = StaticCredentials.CorporateId
                Credentials.AppCustomerType = StaticCredentials.AppCustomerType
                SaveDriveCredentials(Credentails: Credentials!)
            }
        }
        
        DoneAfterConfiguration()
    }
    
    func DoneAfterConfiguration() {
        
        guard FetchDriveRequest() != nil  else {
            GoToLogin()
            return
        }
        
        guard FetchDriveResponce() != nil  else {
            GoToLogin()
            return
        }
        
        if (Reachability()?.isReachable)! {
            FetchLoginResponce()
        }
        else {
            Message.shared.Alert(Title: "NetworkAlert", Message: "Internet connection seems to be down. Please check and try again", TitleAlign: .left, MessageAlign: .left, Actions: [Message.AlertActionWithSelector(Title: "Close", Selector: #selector(DieTheApplication), Controller: self),Message.AlertActionWithSelector(Title: "Settings", Selector: #selector(GoToSettings), Controller: self)], Controller: self)
        }
    }
    
    @objc func GoToSettings() {
        UIApplication.shared.openURL(URL.init(string: UIApplicationOpenSettingsURLString)!)
    }
    
    @objc func DieTheApplication() {
        exit(0)
    }
    
    func FetchCredentials() {
        guard (FetchDriveCredentials() != nil) else {
            return
        }
        Credentials = FetchDriveCredentials()!
    }
    
    func GoToLogin() {
        let Login = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        self.navigationController?.pushViewController(Login, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func FetchLoginResponce() {
        
        let DriveRequest = FetchDriveRequest()!
        //        let DriveResponce = FetchDriveResponce()!
        
        let Dict = ["UserName":DriveRequest.UserName!,
                    "Password":DriveRequest.Password!,
                    "VendorId":DriveRequest.LoginCreds.VendorId!,
                    "CorporateId":DriveRequest.LoginCreds.CorporateId!,
                    "AppCustomerType":DriveRequest.LoginCreds.AppCustomerType!,
                    "Version":DriveRequest.Version!,
                    "DeviceToken":DriveRequest.DeviceToken!,
                    "DeviceIMEINO":DriveRequest.DeviceIMEINO!,
                    "DeviceType":DriveRequest.DeviceType!]
        
        print("SplashScreenVC-LogininInput = ",Dict)
        
        WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveLogin, parameterDict: Dict, securityKey: WebServicesUrl.DummySecurity) { (value, responcecode, success) in
            
            print("SplashScreenVC-LoginResponse = ",value)
            if success {
                let Table = (value as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
                if "\(Table[0]["Status"]!)".toBool()! {
                    SaveDriveResponce(DriveResponce: Table[0])
                    let NavMain = self.storyboard?.instantiateViewController(withIdentifier: "LGSideMenu")
                    self.present(NavMain!, animated: true, completion: nil)
                }
                else {
                    print("SplashScreenVC - Table[0]Status is false....",value)
                    self.GoToLogin()
                }
            }
            else {
                print("SplashScreenVC-LoginResponse failure =",responcecode.GetResponceCode())
                if responcecode == .authError{
                    self.GoToLogin()
                }else{
                    Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal , MessageAlign: .normal, Actions: [Message.AlertActionWithSelector(Title: "Close", Selector: #selector(self.DieTheApplication), Controller: self),Message.AlertActionWithSelector(Title: "Retry", Selector: #selector(self.retry), Controller: self)], Controller: self)
                }
                
            }
        }
    }
    @objc func retry(){
        FetchLoginResponce()
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        Activity.stopAnimating()
        self.navigationController?.isNavigationBarHidden = false
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}





