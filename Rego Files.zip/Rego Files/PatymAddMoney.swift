//
//  PatymAddMoney.swift
//  DriveBooking
//
//  Created by Raja Bhuma on 30/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit
import Alamofire
protocol PaytmAddMoneyDelegate {
    func PaytmDidCompleteAddMoney(controller:PatymAddMoney)
    func PaytmDidcancelAddMoney(controller:PatymAddMoney)
}

class PatymAddMoney: UIViewController, UITextFieldDelegate {

 
    var HideDelink = false
    
    @IBOutlet var AddmoneyTxt: UITextField!
    @IBOutlet var WalletBalanceLbl: UILabel!
    
    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!
    
    var Delegate: PaytmAddMoneyDelegate!
    
    var userEmail: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.LoginRequest = FetchDriveRequest()
        self.DriveBookingResponce = FetchDriveResponce()
        
        self.navigationItem.title = "PAYTM ADD MONEY"
        // Do any additional setup after loading the view.
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.black
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
        self.navigationItem.leftBarButtonItem = BackBtnItem
        
        WalletBalanceLbl.text = "₹" + FetchPaytmBalance()
        
        if !HideDelink {
            let rightItm = UIBarButtonItem.init(image: UIImage.init(named: "MenuDelete"), style: .done, target: self, action: #selector(DelinkAccountBtnPressed))
            rightItm.tintColor = UIColor.black
            self.navigationItem.rightBarButtonItem = rightItm
        }
        
        GetUserDetails()
    }
    
    @objc func BackAction() {
        self.Delegate.PaytmDidcancelAddMoney(controller: self)
    }
    
    @objc func DelinkAccountBtnPressed(_ sender:UIBarButtonItem) {
        
        let button = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 180, height: 44))
        button.setTitle("DeLink Account   ", for: .normal)
        button.backgroundColor = UIColor.black
        button.tintColor = UIColor.clear
        button.addTarget(self, action: #selector(DeleteAccount(_:)), for: .touchUpInside)
        
        let Layout = KLCPopupLayout.init(horizontal: .right, vertical: .custom64)
        let viewLay = KLCPopup.init(contentView: button, showType: .bounceInFromRight, dismissType: .fadeOut, maskType: .dimmed, dismissOnBackgroundTouch: true, dismissOnContentTouch: false)
        viewLay?.show(with: Layout)
    }
    
    @objc func DeleteAccount(_ sender:UIButton) {
        sender.dismissPresentingPopup()
        Message.shared.Alert(Title: "DeLink Paytm!", Message: "Do you want to DeLink account", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "No"),Message.AlertActionWithSelector(Title: "Yes", Selector: #selector(ConfirmDelink), Controller: self)], Controller: self)
    }
    
    @objc func ConfirmDelink() {
        print("Action for delink account")
        UpdatePaymentModes(WalletType_Paytm_MobiKwik: "Paytm", MobileNo: DriveBookingResponce.PaytmWalletNo!, Token: "NA", ExpData_oMobi_Paytmdate: "0") { (isauth) in
            if isauth {
                authenticationCheck(controller: self)
            }
            else {
                self.Delegate.PaytmDidCompleteAddMoney(controller: self)
            }
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func AddMoneyToWalletBtnPreesed(_ sender:UIButton) {
        
        self.view.endEditing(true)
        
        if (AddmoneyTxt.text?.isEmpty)! {
            self.view.ShowBlackTostWithText(message: "Amount should not be empty", Interval: 3)
            return
        }
        else  {
            
            let Amount = Int(AddmoneyTxt.text!)!
            if Amount == 0 {
                self.view.ShowBlackTostWithText(message: "Amount need to be morethan 0", Interval: 3)
                return
            }
            else {
                
                let mc: PGMerchantConfiguration = PGMerchantConfiguration.default()
                 mc.checksumGenerationURL           = PaytmCreds.checksumGenerationURL
                 mc.checksumValidationURL           = PaytmCreds.checksumValidationURL
                
                var orderDict: [AnyHashable: Any]   = NSMutableDictionary() as! [AnyHashable: Any]
                
                let postAccess_Token                = DriveBookingResponce.SSOToken!
                
                orderDict["THEME"]                  = "merchant"
                orderDict["SSO_TOKEN"]              = "\(postAccess_Token)"
                orderDict["MID"]                    = PaytmCreds.ClintMID
                orderDict["CHANNEL_ID"]             = "WAP"
                orderDict["INDUSTRY_TYPE_ID"]       = "Travel"
                orderDict["WEBSITE"]                = PaytmCreds.WEBSITE
                orderDict["TXN_AMOUNT"]             = self.AddmoneyTxt.text!
                orderDict["ORDER_ID"]               = generateOrderIDWithPrefix(prefix: "_" + self.DriveBookingResponce.EmpId!)
                orderDict["REQUEST_TYPE"]           = "ADD_MONEY"
                orderDict["CUST_ID"]                = "1234567890"
                orderDict["EMAIL"]                  = self.userEmail!
                orderDict["MOBILE_NO"]              = self.DriveBookingResponce.PaytmWalletNo!
                orderDict["CALLBACK_URL"]           = PaytmCreds.callbackURL
                
                let order: PGOrder = PGOrder(params: orderDict)
                
                let txnController = PGTransactionViewController.init(transactionFor: order)
                
                txnController?.delegate = self
                txnController?.serverType = eServerTypeProduction
                txnController?.merchant = mc
                self.showController(txnController!)
                

            }
            
        }
        
    }
    
    func GetUserDetails() {
        let postAccess_Token = DriveBookingResponce.SSOToken!
        
        var Request = URLRequest.init(url: URL.init(string: "https://accounts.paytm.com/user/details")!)
        Request.httpMethod = "GET"
        Request.allHTTPHeaderFields = ["session_token":"\(postAccess_Token)"]
        Alamofire.request(Request)
            .responseJSON { (responce) in
                self.view.StopLoading()
                switch responce.result {
                case .success(let Value):
                    print(Value)
                    let Data = Value as! [String:AnyObject]
                    self.userEmail = "\(Data["email"]!)"
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    break
                }
                
        }
    }
    
    func showController(_ controller: PGTransactionViewController) {
        
        if self.navigationController != nil {
            self.navigationController!.pushViewController(controller, animated: true)
        }
        else {
            self.present(controller, animated: true, completion: {() -> Void in
            })
        }
        //        condissmiss = controller
    }
    
    func removeController(_ controller: PGTransactionViewController) {
        if self.navigationController != nil {
            self.navigationController!.popViewController(animated: true)
        }
        else {
            controller.dismiss(animated: true, completion: {() -> Void in
            })
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    
    @IBAction func Money200Btn(_ sender:UIButton) {
        
        var InitalAmount:Int = 0
        
        if AddmoneyTxt.text! == "" {
            InitalAmount = 200
            AddmoneyTxt.text = String.init(format: "%ld", InitalAmount)
        }
        else {
            let Amount = Int(AddmoneyTxt.text!)! + 200
            
            if Amount >= Int(MobiCreds.MaxAmount)! {
                self.view.ShowBlackTostWithText(message: "Amount should be lessthan ₹ " + MobiCreds.MaxAmount, Interval: 3)
            }
            else {
                InitalAmount = Int(AddmoneyTxt.text!)! + 200
                
                AddmoneyTxt.text = String.init(format: "%ld", InitalAmount)
            }
        }
        
        
    }
    
    @IBAction func Money500Btn(_ sender:UIButton) {
        
        var InitalAmount:Int = 0
        
        if AddmoneyTxt.text! == "" {
            InitalAmount = 500
            AddmoneyTxt.text = String.init(format: "%ld", InitalAmount)
        }
        else {
            let Amount = Int(AddmoneyTxt.text!)! + 500
            
            if Amount >= Int(MobiCreds.MaxAmount)! {
                self.view.ShowBlackTostWithText(message: "Amount should be lessthan ₹ " + MobiCreds.MaxAmount, Interval: 3)
            }
            else {
                InitalAmount = Int(AddmoneyTxt.text!)! + 500
                
                AddmoneyTxt.text = String.init(format: "%ld", InitalAmount)
            }
        }
    }
    
    @IBAction func Money1000Btn(_ sender:UIButton) {
        
        var InitalAmount:Int = 0
        
        if AddmoneyTxt.text! == "" {
            InitalAmount = 1000
            AddmoneyTxt.text = String.init(format: "%ld", InitalAmount)
        }
        else {
            let Amount = Int(AddmoneyTxt.text!)! + 1000
            
            if Amount >= Int(MobiCreds.MaxAmount)! {
                self.view.ShowBlackTostWithText(message: "Amount should be lessthan ₹ " + MobiCreds.MaxAmount, Interval: 3)
            }
            else {
                InitalAmount = Int(AddmoneyTxt.text!)! + 1000
                
                AddmoneyTxt.text = String.init(format: "%ld", InitalAmount)
            }
        }
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let set = CharacterSet.init(charactersIn: "1234567890")
        
        if string == "" {
            return true
        }
        else {
            if string.rangeOfCharacter(from: set) != nil {
                
                let text = textField.text!
                
                let OldLenght = text.characters.count
                let newLength = text.characters.count + string.characters.count - range.length
                
                var Number = 0
                
                if OldLenght < newLength {
                    let str = text + string
                    Number = Int(str)!
                }
                else {
                    let str = text.substring(to: text.index(text.endIndex, offsetBy: -1))
                    Number = Int(str)!
                }
                
                if Number >= Int(MobiCreds.MaxAmount)! {
                    self.view.endEditing(true)
                    self.view.ShowBlackTostWithText(message: "Amount should be lessthan ₹ " + MobiCreds.MaxAmount, Interval: 3)
                    return false
                }
                else {
                    return true
                    
                }
            }
            else {
                return false
            }
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    
}

extension PatymAddMoney: PGTransactionDelegate {
    func didSucceedTransaction(_ controller: PGTransactionViewController!, response: [AnyHashable : Any]!) {
        self.removeController(controller)
        Message.shared.Alert(Title: "Transaction Successful", Message: "\(response["RESPMSG"]!)", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithSelector(Title: "Ok", Selector: #selector(SuccessfullTrasaction), Controller: self)], Controller: self)

    }
    func didFinishCASTransaction(_ controller: PGTransactionViewController!, response: [AnyHashable : Any]!) {
        
    }
    func didFailTransaction(_ controller: PGTransactionViewController!, error: Error!, response: [AnyHashable : Any]!) {
        self.removeController(controller)
        if response != nil{
        Message.shared.Alert(Title: "Transaction Failed", Message: "\(response["RESPMSG"]!)", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
        }else{
            Message.shared.Alert(Title: "Transaction Failed", Message: "", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)

        }
    }
    func didCancelTransaction(_ controller: PGTransactionViewController!, error: Error!, response: [AnyHashable : Any]!) {
        self.removeController(controller)
        Message.shared.Alert(Title: "Transaction Cancelled", Message: "", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
    }
    
    @objc func SuccessfullTrasaction() {
        self.Delegate.PaytmDidCompleteAddMoney(controller: self)
    }
}



    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

