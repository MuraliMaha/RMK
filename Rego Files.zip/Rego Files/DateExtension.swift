//
//  DateExtension.swift
//  DriveFindMyCab
//
//  Created by Raja Bhuma on 26/04/17.
//  Copyright © 2017 Suntelematics. All rights reserved.
//

import UIKit

extension Date {
    func GregDateComponents(_ units:NSCalendar.Unit) -> DateComponents {
        let gregTime = GregCalender().components(([.year, .month, .day, .hour, .minute]), from: self)
        return gregTime
    }
}

func GregCalender() -> NSCalendar {
    let gregCal:NSCalendar = NSCalendar(calendarIdentifier: NSCalendar.Identifier.gregorian)!
    return gregCal
}
