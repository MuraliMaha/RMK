//
//  GParams.swift
//  GDirections
//
//  Created by Raja Bhuma on 16/09/17.
//  Copyright © 2017 MyFriends. All rights reserved.
//

import UIKit
import CoreLocation

public struct GParams {
    
    private(set) var FromLocation: CLLocationCoordinate2D
    private(set) var ToLocation: CLLocationCoordinate2D
    private(set) var Points: (WayPoints:[CLLocationCoordinate2D], Optimise:Bool)?
    private(set) var Mode:GTravelMode
    private(set) var Alternatives: Bool
    private(set) var Avoid: [String]?
    
    public init(from:CLLocationCoordinate2D, to:CLLocationCoordinate2D, waypoints:(WayPoints:[CLLocationCoordinate2D], Optimise:Bool)?, travel_Mode:GTravelMode,  alternatives:Bool, avoid:[String]?) {
        FromLocation = from
        ToLocation = to
        Points = waypoints
        Mode = travel_Mode
        Alternatives = alternatives
        Avoid = avoid
    }
    
}

