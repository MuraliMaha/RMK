//
//  GError.swift
//  GDirections
//
//  Created by Raja Bhuma on 16/09/17.
//  Copyright © 2017 MyFriends. All rights reserved.
//

import UIKit

public enum GError: Error {
    case null_key(error: String)
    case access_denied(error: String) // -> REQUEST_DENIED
    case not_found(error: String) // -> NOT_FOUND
    case zero_results(error: String) // -> ZERO_RESULTS
    case max_waypoints_exceeded(error: String) // -> MAX_WAYPOINTS_EXCEEDED
    case max_route_length_exceeded(error: String) // -> MAX_ROUTE_LENGTH_EXCEEDED
    case invalid_request(error: String) // -> INVALID_REQUEST
    case over_quiry_limit(error: String) // -> OVER_QUERY_LIMIT
    case unknown_error(error: String) // -> UNKNOWN_ERROR
}

struct AdaptError: Error {
    let error: Error
}

extension Error {
    var underlyingAdaptError: Error? { return (self as? AdaptError)?.error }
}

extension GError {
    public var isKeyAvailable: Bool {
        if case .null_key = self { return true }
        return false
    }
    public var isAccessDenied: Bool {
        if case .access_denied = self { return true }
        return false
    }
    public var isNotFound: Bool {
        if case .not_found = self { return true }
        return false
    }
    public var isZeroResults: Bool {
        if case .zero_results = self { return true }
        return false
    }
    public var isMaxWaypointsExceeded: Bool {
        if case .max_waypoints_exceeded = self { return true }
        return false
    }
    public var idMaxRouteLengthExceeded: Bool {
        if case .max_route_length_exceeded = self { return true }
        return false
    }
    public var isInvalidRequest: Bool {
        if case .invalid_request = self { return true }
        return false
    }
    public var isOverQuiryLimit: Bool {
        if case .over_quiry_limit = self { return true }
        return false
    }
    public var isUnknownError: Bool {
        if case .unknown_error = self { return true }
        return false
    }
}


extension GError {
    public var errorDescription: String {
        switch self {
        case .null_key(let error):
            return error
        case .access_denied(let error):
            return error + ". Api key is either invalid or expired"
        case .invalid_request(let error):
            return error
        case .max_route_length_exceeded(let error):
            return error
        case .max_waypoints_exceeded(let error):
            return error
        case .not_found(let error):
            return error
        case .over_quiry_limit(let error):
            return error
        case .unknown_error(let error):
            return error
        case .zero_results(let error):
            return error
        }
    }
}

extension GError {
    static func GetResponceError(errorMsg: String) -> GError {
        switch errorMsg {
        case "NULL": fallthrough
        case "nil":
            return .null_key(error: "No Data Available")
        case "REQUEST_DENIED":
            return .access_denied(error: "REQUEST_DENIED. Api key is either invalid or expired")
        case "NOT_FOUND":
            return .not_found(error: "NOT_FOUND")
        case "ZERO_RESULTS":
            return .zero_results(error: "ZERO_RESULTS")
        case "MAX_WAYPOINTS_EXCEEDED":
            return .max_waypoints_exceeded(error: "MAX_WAYPOINTS_EXCEEDED")
        case "MAX_ROUTE_LENGTH_EXCEEDED":
            return .max_route_length_exceeded(error: "MAX_ROUTE_LENGTH_EXCEEDED")
        case "INVALID_REQUEST":
            return .invalid_request(error: "INVALID_REQUEST")
        case "OVER_QUERY_LIMIT":
            return .over_quiry_limit(error: "OVER_QUERY_LIMIT")
        case "UNKNOWN_ERROR":
            return .unknown_error(error: "UNKNOWN_ERROR")
        default:
            return .unknown_error(error: "UNKNOWN_ERROR")
        }
    }
}
