//
//  Constants.swift
//  DriveBooking
//
//  Created by Raja Bhuma on 12/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit

struct GOOGLEKeys {
    
    
    
    static let DummyKey = "AIzaSyD24QZTEZF84MuM_IpVDASMd-chf-SWogE"

    
    //    static let MainKey = "AIzaSyD24QZTEZF84MuM_IpVDASMd-chf-SWogE"
    //    static let DirectionKey = "AIzaSyD1zadZ__YSJ0QovvhjqkRUF6y5Rts7E60"
    
    
//      New Key Created on 27 Mar 2018 - AIzaSyAgfD01pn2blWocp7zLTGtrAIciqTrXdsM
    static let MainKey = "AIzaSyAgfD01pn2blWocp7zLTGtrAIciqTrXdsM"
    static let DirectionKey = "AIzaSyC73pxDhCiBKwHRhAt6wO6wd5Yt5dCqudY"
}

struct Constants {
    static let NetErrorMsg = "please Check your Internet Connection. Turn on mobile data or use WiFi"
    static let InternalError = "Something went wrong..!"
    static let BookingType = "Meter Tariff"
}

struct WebServicesUrl
{
    //Tata Server
    static let DriveBookingBase = "https://www.drivee.in/BookingApp/bookingservice.svc"
    
    //not using i think so
    static let GetPlacesAPI = "http://aamchidrivebooking.in/googlelocations/googlelocation.asmx"
    static let DummySecurity = "A5F0E074-2A1E-4C39-84C4-0E28296BC54D"
    
    static let DriveLogin = "LoginUser"
    static let DriveGetOtp = "GetOtp"
    static let DriveRegisterUser = "RegisterUser"
    static let DriveGetUpdatedPassword = "GetUpdatedPassword"
    static let DriveSetUpdatedName = "GetProfileDetail"
    static let DriveSetFavouritePlaces = "SetFavouritePlaces"
    
    
    static let DriveBookingWithWallets = "BookingWithWallets"
    
//    static let DrivePackageTariffs = "GetPackageTariff"
    static let DrivePackageTariffs = "PackageTariffDetails"
    static let DriveVehicleModelDetails = "VehicleModelDetails"
    static let DriveEstimateRideForBooking = "EstimateRideForBooking"
    static let DriveCheckCouponCode = "CheckCouponCode"
    static let DriveBookingWithPayTm = "BookingWithPayTm"
    static let DriveGetOffers = "GetOffer"
    static let DriveBookingsHistory = "BookingsHistory"
    static let DrivePaytmAccessDetails = "PaytmAccessDetails"
    static let DriveCancellationReasons = "CancellationReasons"
    static let DriveCancelBooking = "CancelBooking"
    static let EmergencyContactDetails = "EmergencyContactDetails"
    
    // Ride Now
    
    static let DriveAvailableVehicles = "AvailableVehicles"
    static let DriveRateCard = "GetRateCard"
    
    static let CallgooglePlacesAPI = "GetGoogleLocation"
    
    // Track Page
    static let DriveGetBookingDetails = "GetBookingDetails"
    static let DriveRateYourRide = "RateYourRide"
    static let DriveContactCustomerCare = "ContactCustomerCare"
    static let DriveRequestInvoice = "GetInvoice"
    
    
    static let DriveReDispatch = "ReDispatch"
    static let DriveWalletAccessDetails = "WalletAccessDetails"
}

struct StaticCredentials {
    
    //Stpl Credential
//    static let VendorId = "1246"
//    static let CorporateId = "10620"
//    static let AppCustomerType = "2"

    //VendorTest Credential
//    static let VendorId = "1196"
//    static let CorporateId = "10490"
//    static let AppCustomerType = "2"
    
    //STPL Credential - 1224 10535
    static let VendorId = "1287"
    static let CorporateId = "10811"
    static let AppCustomerType = "2"
    
}
