//
//  GRoute.swift
//  GDirections
//
//  Created by Raja Bhuma on 16/09/17.
//  Copyright © 2017 MyFriends. All rights reserved.
//

import UIKit
import CoreLocation

public struct GRoute {
    
    public let bounds:GBounds!
    
    public let copyrights: String!
    
    public let legs: [GLeg]!
    
    public let polyline: String!
    
    public let summary: String!
    
    public let waypoint_order: [Int]!
    
    public init(value: [String:Any]) {
        
        bounds = GBounds.init(value: value["bounds"] as! [String:Any])
        
        copyrights = "\(value["copyrights"]!)"
        
        polyline = "\((value["overview_polyline"] as! [String:Any])["points"]!)"
        
        summary = "\(value["summary"]!)"
        
        waypoint_order = value["waypoint_order"] as! [Int]
        
        legs = [GLeg]()
        
        for leg in value["legs"] as! [[String:Any]] {
            legs.append(GLeg.init(value: leg))
        }
        
    }
}

// MARK: - CustomStringConvertible & CustomDebugStringConvertible

extension GRoute: CustomStringConvertible, CustomDebugStringConvertible {
    
    public var description: String {
        return self.debugDescription
    }
    
    public var debugDescription: String {
        
        var Debug = [String]()
        
        Debug.append("copyrights: \(copyrights!), summary: \(summary!)")
        Debug.append("polyline: \(polyline!), waypoint_order: \(waypoint_order!)")
        Debug.append("Bounds: \(bounds!)")
        Debug.append("[Legs]: \(legs!)")

        return Debug.joined(separator: "\n")
    }
}
