//
//  LocalStorage.swift
//  DriveBooking
//
//  Created by Raja Bhuma on 12/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit

// MARK: - Login Request Data Handling

func SaveDriveRequest(request:[String:String]) {
    let Defaults = UserDefaults.standard
    let data = try? JSONSerialization.data(withJSONObject: request, options: .prettyPrinted)
    Defaults.set(data, forKey: "DriveRequest")
    Defaults.synchronize()
}

func SaveDriveRequestStruct(Request:DriveLoginRequest) {
       let Dict =  ["UserName":Request.UserName!,
         "Password":Request.Password!,
         "VendorId":Request.LoginCreds.VendorId!,
         "CorporateId":Request.LoginCreds.CorporateId!,
         "AppCustomerType":Request.LoginCreds.AppCustomerType!,
         "Version":Request.Version!,
         "DeviceToken":Request.DeviceToken!,
         "DeviceIMEINO":Request.DeviceIMEINO!,
         "DeviceType":Request.DeviceType!]
    
    let Defaults = UserDefaults.standard
    let data = try? JSONSerialization.data(withJSONObject: Dict, options: .prettyPrinted)
    Defaults.set(data, forKey: "DriveRequest")
    Defaults.synchronize()
}

func FetchDriveRequest() -> DriveLoginRequest? {
    if UserDefaults.standard.value(forKey: "DriveRequest") != nil
    {
        
        if let RequestDict:[String:String] = try! JSONSerialization.jsonObject(with:UserDefaults.standard.value(forKey: "DriveRequest") as! Data, options: JSONSerialization.ReadingOptions.allowFragments) as? [String:String]
        {
            var Drive = DriveLoginRequest()
            
            var Creds = DriveCredentials()
            Creds.VendorId = "\(RequestDict["VendorId"]!)"
            Creds.CorporateId = "\(RequestDict["CorporateId"]!)"
//            Creds.CorporateId2 = "\(RequestDict["CorporateId2"]!)"
            Creds.AppCustomerType = "\(RequestDict["AppCustomerType"]!)"
            
            Drive.LoginCreds = Creds
            
            Drive.UserName = "\(RequestDict["UserName"]!)"
            Drive.Password = "\(RequestDict["Password"]!)"
            Drive.Version = "\(RequestDict["Version"]!)"
            Drive.DeviceToken = "\(RequestDict["DeviceToken"]!)"
            Drive.DeviceIMEINO = "\(RequestDict["DeviceIMEINO"]!)"
            Drive.DeviceType = "\(RequestDict["DeviceType"]!)"

            return Drive
        }
        else {
            return nil
        }
        
    }
    else {
        return nil
    }
}

// MARK: - Login Responce Data Handling

func FetchDriveResponce() -> DriveLoginResponce? {
    
    if UserDefaults.standard.value(forKey: "DriveResponce") != nil
    {
        
        if let ResponceDict:[String:AnyObject] = try! JSONSerialization.jsonObject(with:UserDefaults.standard.value(forKey: "DriveResponce") as! Data, options: JSONSerialization.ReadingOptions.allowFragments) as? [String:AnyObject]
        {
            
            var ResponceStruct = DriveLoginResponce()
            
            // CategoryType {
            
            var CatStrArr = [CategoryTypeStruct]()
            
            for CategoryTypeObj in ResponceDict["CategoryType"] as! [[String:AnyObject]] {
                var StructObj = CategoryTypeStruct()
                StructObj.CategoryId = "\(CategoryTypeObj["CategoryId"]!)"
 
                StructObj.CategoryImage1 = "\(CategoryTypeObj["CategoryImage1"]!)"
                StructObj.CategoryImage2 = "\(CategoryTypeObj["CategoryImage2"]!)"
                StructObj.CategoryName = "\(CategoryTypeObj["CategoryName"]!)"
                StructObj.SelectedImage = "\(CategoryTypeObj["SelectedImage"]!)"
                StructObj.PopupMessage = "\(CategoryTypeObj["PopupMessage"]!)"
                StructObj.MapIcon = "\(CategoryTypeObj["MapIcon"]!)"
                CatStrArr.append(StructObj)
            }
            
            ResponceStruct.CategoryType = CatStrArr
            
            //}
            
            // CityDetails {
            
            var CityDetailsStrArr = [CityDetailsStruct]()
            
            for CityDetailsObj in ResponceDict["CityDetails"] as! [[String:AnyObject]] {
                var StructObj = CityDetailsStruct()
                StructObj.CityId = "\(CityDetailsObj["CityId"]!)"
                StructObj.CityName = "\(CityDetailsObj["CityName"]!)"
                CityDetailsStrArr.append(StructObj)
            }
            
            ResponceStruct.CityDetails = CityDetailsStrArr
            
            //}
            
            // TripType {
            
            var TripTypeStrArr = [TripTypeStruct]()
            
            for TripTypeObj in ResponceDict["TripType"] as! [[String:AnyObject]] { // if not working "TripData"
                var StructObj = TripTypeStruct()
                StructObj.TripId = "\(TripTypeObj["TripId"]!)"
                StructObj.TripName = "\(TripTypeObj["TripName"]!)"
                StructObj.TripImage = "\(TripTypeObj["TripImage"]!)"
                StructObj.BookingDuration = TripTypeObj.keys.contains("BookingDuration") ? "\(TripTypeObj["BookingDuration"]!)" : "60"
                TripTypeStrArr.append(StructObj)
            }
            
            ResponceStruct.TripType = TripTypeStrArr
            
            // }
            
            //LocationImage {
            
            var LocationTypeStrArr = [LocationTypeStruct]()
            
            for LocationTypeObj in ResponceDict["LocationDetails"] as! [[String:AnyObject]] {
                var StructObj = LocationTypeStruct()
                StructObj.LocationImage = "\(LocationTypeObj["ImagePath"]!)"
                StructObj.LocationName = "\(LocationTypeObj["Name"]!)"
                LocationTypeStrArr.append(StructObj)
            }
            ResponceStruct.LocationType = LocationTypeStrArr
            
            
            
            //}
        
            ResponceStruct.AppCustomerType = "\(ResponceDict["AppCustomerType"]!)"
            ResponceStruct.CompanyId = "\(ResponceDict["CompanyId"]!)"
            ResponceStruct.CorpPaymentModes = "\(ResponceDict["CorpPaymentModes"]!)"
            ResponceStruct.PersonalPaymentModes = "\(ResponceDict["PersonalPaymentModes"]!)"
            ResponceStruct.CorporateId = "\(ResponceDict["CorporateId"]!)"
//            ResponceStruct.CorporateId2 = "\(ResponceDict["CorporateId2"]!)"
            ResponceStruct.CorporateId2 = ResponceDict.keys.contains("CorporateId2") ? "\(ResponceDict["CorporateId2"]!)" : "NA"

            ResponceStruct.CorporateName = "\(ResponceDict["CorporateName"]!)"
            ResponceStruct.CustomerCareNo = "\(ResponceDict["CustomerCareNo"]!)"
            ResponceStruct.CustomerTypeId = "\(ResponceDict["CustomerTypeId"]!)"
            ResponceStruct.Email = "\(ResponceDict["Email"]!)"
            ResponceStruct.EmergencyContacts = "\(ResponceDict["EmergencyContacts"]!)"
            ResponceStruct.EmpId = "\(ResponceDict["EmpId"]!)"
            ResponceStruct.Favourites = "\(ResponceDict["Favourites"]!)"
            ResponceStruct.Name = "\(ResponceDict["Name"]!)"
            ResponceStruct.PhoneNo = "\(ResponceDict["PhoneNo"]!)"
            ResponceStruct.RatingDetails = "\(ResponceDict["RatingDetails"]!)"
            ResponceStruct.Response = "\(ResponceDict["Response"]!)"
            ResponceStruct.Status = "\(ResponceDict["Status"]!)"
            ResponceStruct.VendorId = "\(ResponceDict["VendorId"]!)"
            
            ResponceStruct.AdvanceBookingTime = "\(ResponceDict["AdvanceBookingTime"]!)"
            
            ResponceStruct.MapApiKey = ResponceDict.keys.contains("AndroidMapApiKey") ? "\(ResponceDict["AndroidMapApiKey"]!)" : "AIzaSyAm8lypD6AjAlUKx0PIJAfVBDfaTEp7Pdo"
            
            ResponceStruct.AdvanceBookingDuration = "\(ResponceDict["AdvanceBookingDuration"]!)"
            ResponceStruct.PaymentType = "\(ResponceDict["PaymentType"]!)"
            ResponceStruct.PaymentStatus = "\(ResponceDict["PaymentStatus"]!)"
            ResponceStruct.WalletDialogueStatus = "\(ResponceDict["WalletDialogueStatus"]!)"
            
            ResponceStruct.AuthenticationToken = "\(ResponceDict["AuthenticationToken"]!)"
            
            ResponceStruct.ReferralCode = "\(ResponceDict["ReferralCode"]!)"
            ResponceStruct.ReferralHeader = "\(ResponceDict["ReferralHeader"]!)"
            ResponceStruct.ReferralMessage = "\(ResponceDict["ReferralMessage"]!)"
            
            ResponceStruct.PaytmWalletNo = ResponceDict.keys.contains("PaytmWalletNo") ? "\(ResponceDict["PaytmWalletNo"]!)" : "NA"
            ResponceStruct.IOSGoogleTranslatorKey = ResponceDict.keys.contains("IOSGoogleTranslatorKey") ? "\(ResponceDict["IOSGoogleTranslatorKey"]!)" : "AIzaSyBqvaCquYYN3kf2cOrhrY59AN8NCyxJcTg"
            ResponceStruct.SSOToken = ResponceDict.keys.contains("SSOToken") ? "\(ResponceDict["SSOToken"]!)" : "NA"
            ResponceStruct.ExpiryTime = ResponceDict.keys.contains("ExpiryTime") ? "\(ResponceDict["ExpiryTime"]!)" : "NA"
            ResponceStruct.TokenValidity = ResponceDict.keys.contains("TokenValidity") ? "\(ResponceDict["TokenValidity"]!)" : "NA"
            
            ResponceStruct.WalletToken = ResponceDict.keys.contains("WalletToken") ? "\(ResponceDict["WalletToken"]!)" : "NA"
            ResponceStruct.WalletMobileNo = ResponceDict.keys.contains("WalletMobileNo") ? "\(ResponceDict["WalletMobileNo"]!)" : "NA"
            
            
            
            
            
            ResponceStruct.ShowHideReferFriend = ResponceDict.keys.contains("ReferralStatus") ? "\(ResponceDict["ReferralStatus"]!)" : "NA"
            
            ResponceStruct.CustomerCareNumber = ResponceDict.keys.contains("CustomerCareNo") ? "\(ResponceDict["CustomerCareNo"]!)" : "NA"
            ResponceStruct.BiddingInterval = ResponceDict.keys.contains("BiddingInterval") ? "\(ResponceDict["BiddingInterval"]!)" : "60"
            ResponceStruct.NotificationsCount = ResponceDict.keys.contains("NotificationsCount") ? "\(ResponceDict["NotificationsCount"]!)" : "0"
            
            ResponceStruct.RetryInterval = ResponceDict.keys.contains("RetryInterval") ? "\(ResponceDict["RetryInterval"]!)" : "120"
            ResponceStruct.BiddingRetryMsg = ResponceDict.keys.contains("BiddingRetryMsg") ? "\(ResponceDict["BiddingRetryMsg"]!)" : "Please Give us 2 More Minutes to Search Cabs Around You"
            
            //            DefaultPaymentMode
            
            
            ResponceStruct.DefaultPaymentMode = ResponceDict.keys.contains("DefaultPaymentMode") ? "\(ResponceDict["DefaultPaymentMode"]!)" : "CASH"
            ResponceStruct.WalletMinBalance = ResponceDict.keys.contains("WalletMinBalance") ? "\(ResponceDict["WalletMinBalance"]!)" : "150.0"
            ResponceStruct.TranslationStatus = ResponceDict.keys.contains("TranslationStatus") ? "\(ResponceDict["TranslationStatus"]!)" : "true"
//            ResponceStruct.DummyVehStatus = ResponceDict.keys.contains("DummyVehStatus") ? "\(ResponceDict["DummyVehStatus"]!)" : "true"
            
            ResponceStruct.CorpBookingStatus = ResponceDict.keys.contains("CorpBookingStatus") ? "\(ResponceDict["CorpBookingStatus"]!)" : "false"
            ResponceStruct.RideNowStatus = ResponceDict.keys.contains("RideNowStatus") ? "\(ResponceDict["RideNowStatus"]!)" : "false"
            
            return ResponceStruct
            
        }
        else
        {
            return nil
            
        }
        
    }
    else
    {
        return nil
    }
    
}
func saveDriveResponceStuct(driveStruct:DriveLoginResponce) {
    
    if UserDefaults.standard.value(forKey: "DriveResponce") != nil
    {
        
        if let ResponceDict:[String:AnyObject] = try! JSONSerialization.jsonObject(with:UserDefaults.standard.value(forKey: "DriveResponce") as! Data, options: JSONSerialization.ReadingOptions.allowFragments) as? [String:AnyObject]
        {
            var Dict: [String:AnyObject] = ResponceDict
            
            Dict["SSOToken"] = driveStruct.SSOToken! as AnyObject
            Dict["ExpiryTime"] = driveStruct.ExpiryTime! as AnyObject
            Dict["PaytmWalletNo"] = driveStruct.PaytmWalletNo! as AnyObject
            
            Dict["Name"] = driveStruct.Name! as AnyObject
            
            Dict["WalletToken"] = driveStruct.WalletToken! as AnyObject
            Dict["WalletMobileNo"] = driveStruct.WalletMobileNo! as AnyObject
            
            Dict["RatingDetails"] = driveStruct.RatingDetails! as AnyObject
            
            SaveDriveResponce(DriveResponce: Dict)
        }
    }
}
func SaveDriveResponce(DriveResponce:[String:AnyObject]) {
    
    // Save Favourites {
    
    SaveFavouritesLocations(FavouritesStr: DriveResponce["Favourites"]! as? String)
    SaveEmergencyContacts(EmergencyStr: DriveResponce["EmergencyContacts"]! as? String)
    // }
    
    let Defaults = UserDefaults.standard
    
    let data = try? JSONSerialization.data(withJSONObject: DriveResponce, options: .prettyPrinted)
    Defaults.set(data, forKey: "DriveResponce")
    Defaults.synchronize()
}

// MARK: - Favorite Data Handling


func SaveFavouritesLocations(FavouritesStr:String?) {
    let Defaults = UserDefaults.standard
    Defaults.set("\(FavouritesStr!)", forKey: "FavorateLocData")
    Defaults.synchronize()
}
func SaveFavoritesAs(FavoritesStructArr:[FavouritesLocationsStruct]) {
    var StringObj = ""
    for FavStrObj in FavoritesStructArr {
        let Str = "\(FavStrObj.Latitude!)" + "|" + "\(FavStrObj.Longitude!)" + "|" + "\(FavStrObj.Location!)" + "~"
        StringObj.append(Str)
    }
    let Defaults = UserDefaults.standard
    Defaults.set("\(StringObj)", forKey: "FavorateLocData")
    Defaults.synchronize()
}
func FetchFavouritesLocation() -> [FavouritesLocationsStruct]? {
    
    if UserDefaults.standard.value(forKey: "FavorateLocData") != nil
    {
        let FavouritesStr:String = (UserDefaults.standard.value(forKey: "FavorateLocData") as? String)!
        
        let Str = "\(FavouritesStr)"
        
        let StrArr = Str.components(separatedBy: "~")
        
        var StructArr = [FavouritesLocationsStruct]()
        for i in 0..<StrArr.count-1 {
            let Sub = StrArr[i]
            let SubFilterArr = Sub.components(separatedBy: "|")
            
            var LocStr = FavouritesLocationsStruct()
            LocStr.Latitude = Double("\(SubFilterArr[0])")!
            LocStr.Longitude = Double("\(SubFilterArr[1])")!
            LocStr.Location = "\(SubFilterArr[2])"
            StructArr.append(LocStr)
            
        }
        return StructArr
        
    }
    else {
        return nil
    }
}
// emergency data handling
func SaveEmergencyContacts(EmergencyStr:String?) {
    let Defaults = UserDefaults.standard
    Defaults.set("\(EmergencyStr!)", forKey: "EmegencyContactUserDefaults")
    Defaults.synchronize()
}
func SaveEmergencyContactsAs(EmergencyStructArr:[EmergencyContactStruct]) {
    var StringObj = ""
    for EmrgStrObj in EmergencyStructArr {
        let Str = "\(EmrgStrObj.Name!)" + "|" + "\(EmrgStrObj.MobileNumber!)" + "~"
        StringObj.append(Str)
    }
    let Defaults = UserDefaults.standard
    Defaults.set("\(StringObj)", forKey: "EmegencyContactUserDefaults")
    Defaults.synchronize()
}

func GetEmergencyValue() -> [EmergencyContactStruct]?{
    if UserDefaults.standard.value(forKey: "EmegencyContactUserDefaults") != nil{
    
     let EmergencyStr:String = (UserDefaults.standard.value(forKey: "EmegencyContactUserDefaults") as? String)!
        
        let Str = "\(EmergencyStr)"
        
        let StrArr = Str.components(separatedBy: "~")
        
        var EmergStructArr = [EmergencyContactStruct]()
        for i in 0..<StrArr.count {
            
            let Sub = StrArr[i]
            
            if Sub != "" && Sub.contains("|") {
                let SubFilterArr = Sub.components(separatedBy: "|")
                var EmergencyArr = EmergencyContactStruct()
                EmergencyArr.Name  = "\(SubFilterArr[0])"
                EmergencyArr.MobileNumber = "\(SubFilterArr[1])"
                EmergStructArr.append(EmergencyArr)
            }
         }
        return EmergStructArr

    }
    else {
        return nil
    }
}

func SaveDriveCredentials(Credentails:DriveCredentials) {
    
    let dataDict = ["VendorId":Credentails.VendorId!,"CorporateId":Credentails.CorporateId!,"AppCustomerType":Credentails.AppCustomerType!]
    
    let Defaults = UserDefaults.standard
    let data = try? JSONSerialization.data(withJSONObject: dataDict, options: .prettyPrinted)
    Defaults.set(data, forKey: "DriveCredentials")
    Defaults.synchronize()
}

func FetchDriveCredentials() -> DriveCredentials? {
    
    if UserDefaults.standard.value(forKey: "DriveCredentials") != nil
    {
        if let CredDict:[String:String] = try! JSONSerialization.jsonObject(with:UserDefaults.standard.value(forKey: "DriveCredentials") as! Data, options: JSONSerialization.ReadingOptions.allowFragments) as? [String:String]
        {
            var DriveCred = DriveCredentials()
            DriveCred.VendorId = CredDict["VendorId"]!
            DriveCred.CorporateId = CredDict["CorporateId"]!
            DriveCred.AppCustomerType = CredDict["AppCustomerType"]!
            
            return DriveCred
        }
        else {
            return nil
        }
        
    }
    else {
        return nil
    }
}

