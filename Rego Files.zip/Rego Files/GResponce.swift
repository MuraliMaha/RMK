//
//  GResponce.swift
//  GDirections
//
//  Created by Raja Bhuma on 16/09/17.
//  Copyright © 2017 MyFriends. All rights reserved.
//

import UIKit
import CoreLocation

public struct GResponce<GDirectionsData> {
   
    public let result: GResult<GDirectionsData>
    
    public let data: Data?
    
    public var value: GDirectionsData? { return result.value }
    
    public var error: GError? { return result.error }
    
    public init(gResult: GResult<GDirectionsData>, gData: Data?) {
        result = gResult
        data = gData
    }
}

// MARK: - CustomStringConvertible & CustomDebugStringConvertible

extension GResponce: CustomStringConvertible, CustomDebugStringConvertible {
    
    public var description: String {
        return self.debugDescription
    }
    
    public var debugDescription: String {
        
        var Debug = [String]()
        
        Debug.append("Result: \(result)")
        
        return Debug.joined(separator: "\n")
    }
}



public enum GResult<GDirectionsData> {
    
    case success(GDirectionsData)
    case failure(GError)
    
   
    public var isSuccess: Bool {
        switch self {
        case .success:
            return true
        case .failure:
            return false
        }
    }
    
    public var isFailure: Bool {
        return !isSuccess
    }
    
    public var value: GDirectionsData? {
        switch self {
        case .success(let value):
            return value
        case .failure:
            return nil
        }
    }
   
    public var error: GError? {
        switch self {
        case .success:
            return nil
        case .failure(let error):
            return error
        }
    }
}

// MARK: - CustomStringConvertible, CustomDebugStringConvertible

extension GResult: CustomStringConvertible, CustomDebugStringConvertible {
    public var description: String {
        return self.debugDescription
    }

    public var debugDescription: String {
        switch self {
        case .success(let value):
            return "SUCCESS: \(value)"
        case .failure(let error):
            return "FAILURE: \(error)"
        }
    }
}
 

public struct GDirectionsData {
    
    public let routes: [GRoute]!
    
    public let geocoded_waypoints: [GGeocodedWaypoints]!
    
    public init(value: [String:Any]) {
        
        routes = [GRoute]()
        
        for route in (value["routes"] as! [[String:Any]]) {
           routes.append(GRoute.init(value: route))
        }
        
        geocoded_waypoints = [GGeocodedWaypoints]()
        
        for geocoded_waypoint in (value["geocoded_waypoints"] as! [[String:Any]]) {
            geocoded_waypoints.append(GGeocodedWaypoints.init(value: geocoded_waypoint))
        }
    }
}

// MARK: - CustomStringConvertible & CustomDebugStringConvertible

extension GDirectionsData: CustomStringConvertible, CustomDebugStringConvertible {
    
    public var description: String {
        return self.debugDescription
    }
    
    public var debugDescription: String {
        
        var Debug = [String]()
        
        Debug.append("[Routes]: \(routes!)")
        Debug.append("[Geocoded_waypoints]: \(geocoded_waypoints!)")
        
        return Debug.joined(separator: "\n")
    }
}


public struct GGeocodedWaypoints {
    
    public let geocoder_status: String!
    
    public let place_id: String!

    public let types: [String]!

    public init(value: [String:Any]) {
        
        geocoder_status = "\(value["geocoder_status"]!)"

        place_id = value["place_id",default:"No PlaceID"] as! String
        
//        place_id = value.keys.contains("place_id") ? "\(value["place_id"]!)" : "No PlaceID"

        types = value.keys.contains("types") ? value["types"] as! [String] : []
    }
}



public struct GBounds {
    
    public let northeast: CLLocationCoordinate2D!
    public let southwest: CLLocationCoordinate2D!
    
    public init(value: [String:Any]) {
        
        let NE = value["northeast"] as! [String:Any]
        let SW = value["southwest"] as! [String:Any]

        northeast = CLLocationCoordinate2DMake(Double("\(NE["lat"]!)")!, Double("\(NE["lng"]!)")!)
        southwest = CLLocationCoordinate2DMake(Double("\(SW["lat"]!)")!, Double("\(SW["lng"]!)")!)
    }
}



