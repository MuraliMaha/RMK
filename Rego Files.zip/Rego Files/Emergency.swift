//
//  EmergencyContactVC.swift
//  EmergencyContactVC
//
//  Created by Divya on 28/03/17.
//  Copyright © 2017 suntelematics. All rights reserved.
//

import UIKit

class EmergencyTBCell:UITableViewCell {
    @IBOutlet var NameLbl : UILabel!
    @IBOutlet var NumberLbl : UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }
}

class Emergency: UIViewController,UIPopoverPresentationControllerDelegate {

    @IBOutlet weak var addContactButton: UIButton!
    @IBOutlet weak var contactsLabel: UILabel!
    @IBOutlet var EmergencyTB : UITableView!
    
    @IBOutlet var AddContactPopView : UIView!
    @IBOutlet var AddNameTxt : UITextField!
    @IBOutlet var AddPhoneTxt : UITextField!
    
    @IBOutlet var AddNamePrompt : UILabel!
    @IBOutlet var AddPhonePrompt : UILabel!
    
    @IBOutlet var AddNameLine : UILabel!
    @IBOutlet var AddPhoneLine : UILabel!
    
    var AddContactVC : UIViewController!
    
    var EmergencyContactsArr = [EmergencyContactStruct]()
    
    var IsUpdateNumber : Bool = false
    var UpdateIndex : Int = 0

//    static let PhonoStat = "9866386697"
    
    var LoginRequest:DriveLoginRequest!
    var DriveBookingResponce:DriveLoginResponce!
//    override func viewWillDisappear(_ animated: Bool) {
//        
//        self.navigationController?.isNavigationBarHidden = false
//    }
    
       override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.black
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
        self.navigationItem.leftBarButtonItem = BackBtnItem
        self.navigationItem.title = "EMERGENCY CONTACTS"
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor : UIColor.black]
 
        self.LoginRequest = FetchDriveRequest()
        self.DriveBookingResponce = FetchDriveResponce()
//        var emegergency = DriveBookingResponce.EmergencyContacts!
//        
//        emegergency  = "Amar|8801152597~Akhil|9035821372~"
//       
//        if  emegergency.contains("~") {
//        let ratingDetailsArray = emegergency.components(separatedBy: "~")
//
//            let dummy  = ratingDetailsArray[0]
//            let dummyy = ratingDetailsArray[1]
//            
//            let ratingDetailsA = dummy.components(separatedBy: "|")
//            let ratingDetailsArray1 = dummyy.components(separatedBy: "|")
//
//            print(ratingDetailsA[0],ratingDetailsA[1], ratingDetailsArray1[0],ratingDetailsArray1[1])
//            
//        }else if emegergency.contains("|"){
//            
//         let ratingDetailsArray = emegergency.components(separatedBy: "|")
//            let x = ratingDetailsArray
//            print(x[0],x[1])
//        
//        }
        
        EmergencyTB.rowHeight = 70
        
        if GetEmergencyValue()?.count != 0 {
            EmergencyContactsArr = GetEmergencyValue()!
        }
        if EmergencyContactsArr.count >= 2{
            updateCount()
        }
    }
    func updateCount(){
       // UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Updated Successfully", Interval: 2)
        if EmergencyContactsArr.count >= 2{
            addContactButton.isHidden = true
            contactsLabel.text = "Delete Contact if you need to add"
        }else{
            addContactButton.isHidden = false
            contactsLabel.text = "You can add up to 2 contacts"
        }

    
    }
    
    func SaveEmergencyContacts(){
        
        if (Reachability()?.isReachable)! {
            
            //        self.view.StartLoading()
            
            var EStringObj = ""
            for emgStrObj in self.EmergencyContactsArr {
                let eStr = "\(emgStrObj.Name!)" + "|" + "\(emgStrObj.MobileNumber!)" + "~"
                EStringObj.append(eStr)
            }
        
            
            
            let DriveDict = ["EmpId":"\(DriveBookingResponce.EmpId!)",
                "EmergencyContacts":EStringObj]
            print(DriveDict)
            
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.EmergencyContactDetails, parameterDict: DriveDict, securityKey: DriveBookingResponce.AuthenticationToken!, completion: { (response, responceCode, success) in
                
                print("*******\(response)")
                //            hideLoading()
                self.view.StopLoading()
                if success{
                    let ResponceArr = (response as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
                    print(ResponceArr)
                    let data = ResponceArr[0]
                    print(data["Response"]!)
                    if (data["Status"]!) as! String == "true"{
                    
                    UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "\(data["Response"]!)", Interval: 2)
                   
                    SaveEmergencyContactsAs(EmergencyStructArr: self.EmergencyContactsArr)
                        }
                    else{
                        UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "\(data["Response"]!)", Interval: 2)
                    }
                    
                }else{
                    UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: Constants.InternalError, Interval: 2)

                }
            })
        }else{
            
            self.view.ShowBlackTostWithText(message: "please Check your Internet Connection", Interval: 3)
            return
            
        }

    }
            
        
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @objc func BackAction(_ sender: UIButton) {
//        self.navigationController?.popToRootViewController(animated: true)
        self.navigationController?.popViewController(animated: true)
    }
//    @IBAction func BackBtnClicked(_ sender:UIButton) {
//        self.navigationController?.popToRootViewController(animated: true)
//    }
    
    @IBAction func AddContactBtnClicked(_ sender:UIButton) {
        
        if EmergencyContactsArr.count == 2 {
            // alert for max emergency contact reached
            
 
            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Cannot Add More Than 2 Numbers", Interval: 2)
            return
        }
        else {
            
//            let window = UIApplication.shared.windows.last!
            
            AddContactVC = UIViewController.init()
            
            AddContactPopView.frame = CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.size.width-25, height: 180.0);
            AddContactVC.view = AddContactPopView;
            
            AddPhoneTxt.text = ""
            AddNameTxt.text = ""
            
            AddNamePrompt.isHidden = true
            AddPhonePrompt.isHidden = true
            AddNameLine.backgroundColor = UIColor.lightGray
            AddPhoneLine.backgroundColor = UIColor.lightGray
            
            AddContactVC.modalPresentationStyle = .popover
            AddContactVC.preferredContentSize = CGSize.init(width:UIScreen.main.bounds.size.width-25, height: 180.0)
            
            let popOverController = AddContactVC.popoverPresentationController
            popOverController?.permittedArrowDirections = .init(rawValue: 0)
            popOverController?.delegate = self
            popOverController?.sourceView = self.view
            popOverController?.sourceRect = CGRect.init(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
            self.present(AddContactVC, animated: true, completion: {
                self.view.alpha = 0.5
                self.AddContactVC.view.superview?.layer.cornerRadius = 5
            })
        }
        
    }
    
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }
    
    func popoverPresentationControllerDidDismissPopover(_ popoverPresentationController: UIPopoverPresentationController) {
        print("method called")
//        let window = UIApplication.shared.windows.last
//        window?.subviews.last?.removeFromSuperview()
        
        self.AddContactVC.dismiss(animated: true, completion: nil)
        self.view.alpha = 1
        IsUpdateNumber = false
    }
    
    @IBAction func SaveContactBtnClicked(_ sender:UIButton) {
        
//        let window = UIApplication.shared.windows.last
//        window?.subviews.last?.removeFromSuperview()
        AddContactPopView.endEditing(true)
        
        if AddPhoneTxt.text! == ""{
            
            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Please Enter Mobile Number", Interval: 2)
//            showAlertMessage(vc: self, titleStr: "Alert", messageStr: "Please Enter Mobile Number")
            return
        }
        
        if !(AddPhoneTxt.text?.isValidMobileNumber())! {
            UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Please Enter a Valid Mobile Number", Interval: 2)
            return
        }
        if self.AddPhoneTxt.text == (DriveBookingResponce.PhoneNo!) {
            
            // error alert for same number
            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Registerd Number cannot add as a Emergency Contact Number", Interval: 3)
            
            return
        }
        if AddNameTxt.text! == ""{
             UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Please Enter Name", Interval: 2)
//        showAlertMessage(vc: self, titleStr: "Alert", messageStr: "Please Enter Name")
            return
         }
        self.AddContactVC.dismiss(animated: true, completion: nil)
        self.view.alpha = 1
        
        AddContactVC.dismiss(animated: false, completion: nil)
        
        if IsUpdateNumber {
            
            IsUpdateNumber = false
            EmergencyTB.beginUpdates()
            
            var contactStr = EmergencyContactsArr[UpdateIndex]
            
            contactStr.MobileNumber = self.AddPhoneTxt.text!
            contactStr.Name = self.AddNameTxt.text!
            
            EmergencyContactsArr[UpdateIndex] = contactStr
            
//            SaveEmergencyContactsAs(Structarr: EmergencyContactsArr)
            SaveEmergencyContacts()
            
            
            EmergencyTB.reloadRows(at: [IndexPath.init(row: UpdateIndex, section: 0)], with: .automatic)
            
            EmergencyTB.endUpdates()
            
        
        }
        else {
            if self.AddPhoneTxt.text == (DriveBookingResponce.PhoneNo!) {
                
                // error alert for same number
                
                UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "Registerd Number cannot add as a Emergency Contact Number", Interval: 3)
                
                 return
            }
            else {
                
                if EmergencyContactsArr.count > 0 {
                    
                    if EmergencyContactsArr[0].MobileNumber == self.AddPhoneTxt.text! {
                        // already phone contains
         
                        
                        UIApplication.shared.keyWindow?.ShowWhiteTostWithText(message: "Number Already Exists", Interval: 2)
                        return
                        
                    }
                    
                    var contactStr = EmergencyContactStruct()
                    contactStr.MobileNumber = self.AddPhoneTxt.text!
                    contactStr.Name = self.AddNameTxt.text!
                    
                    EmergencyContactsArr.append(contactStr)
                    
//                    SetEmergencyValue(Structarr: EmergencyContactsArr)
//                    SaveEmergencyContactsAs(EmergencyStructArr: EmergencyContactsArr)
                    SaveEmergencyContacts()

                    
                    EmergencyTB.reloadData()
                    
                }
                else {
                    
                    var contactStr = EmergencyContactStruct()
                    contactStr.MobileNumber = self.AddPhoneTxt.text!
                    contactStr.Name = self.AddNameTxt.text!
                    
                    var Arr = [EmergencyContactStruct]()
                    Arr.append(contactStr)
                    
                    EmergencyContactsArr = Arr
                    
//                    SetEmergencyValue(Structarr: EmergencyContactsArr)
//                    SaveEmergencyContactsAs(EmergencyStructArr: EmergencyContactsArr)
                    SaveEmergencyContacts()
                    
                    EmergencyTB.reloadData()
                }
                
            }
            
        }
         updateCount()
    }
   
}

extension Emergency: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == self.AddPhoneTxt {
            AddPhonePrompt.isHidden = false
            AddPhoneLine.backgroundColor = UIColor.darkGray
        }
        else if textField == self.AddNameTxt {
            AddNamePrompt.isHidden = false
            AddNameLine.backgroundColor = UIColor.darkGray
        }
        
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        if self.AddNameTxt.text == "" {
            AddNamePrompt.isHidden = true
            AddNameLine.backgroundColor = UIColor.lightGray
        }
        else {
            AddNamePrompt.isHidden = false
            AddNameLine.backgroundColor = UIColor.darkGray
        }
        
        if self.AddPhoneTxt.text == "" {
            AddPhonePrompt.isHidden = true
            AddPhoneLine.backgroundColor = UIColor.lightGray
        }
        else {
            AddPhonePrompt.isHidden = false
            AddPhoneLine.backgroundColor = UIColor.darkGray
        }
        
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if textField == self.AddPhoneTxt {
            
            let objcString = string as NSString
            
            let characterSet = NSCharacterSet.decimalDigits.inverted
            
            if objcString.rangeOfCharacter(from: characterSet).location != NSNotFound {
                return false
            }
            
            return true
        }
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
     }
}

extension Emergency: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return EmergencyContactsArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EmergencyCell", for: indexPath) as! EmergencyTBCell
        cell.NameLbl?.text = EmergencyContactsArr[indexPath.row].Name!
        cell.NumberLbl?.text = EmergencyContactsArr[indexPath.row].MobileNumber!
        return cell
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let DeleteAction = UITableViewRowAction.init(style: .destructive, title: "Delete") { (action, Deleteindexpath) in
            self.EmergencyTB.beginUpdates()
            
            self.EmergencyContactsArr.remove(at: Deleteindexpath.row)
            
            self.EmergencyTB.deleteRows(at: [Deleteindexpath], with: .automatic)
//             SetEmergencyValue(Structarr: self.EmergencyContactsArr)
//            SaveEmergencyContactsAs(EmergencyStructArr: self.EmergencyContactsArr)
            self.SaveEmergencyContacts()
            self.EmergencyTB.endUpdates()
            self.updateCount()
            
        }
        
        let EditAction = UITableViewRowAction.init(style: .normal, title: "Edit") { (action, editindexpath) in
            
            self.UpdateIndex = editindexpath.row
            self.IsUpdateNumber = true
            
            self.AddContactVC = UIViewController.init()
            
            self.AddContactPopView.frame = CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.size.width-25, height: 180.0);
            self.AddContactVC.view = self.AddContactPopView;
            
            self.AddNameTxt.text = self.EmergencyContactsArr[editindexpath.row].Name!
            self.AddPhoneTxt.text = self.EmergencyContactsArr[editindexpath.row].MobileNumber!
            
            self.AddNamePrompt.isHidden = false
            self.AddPhonePrompt.isHidden = false
            self.AddNameLine.backgroundColor = UIColor.darkGray
            self.AddPhoneLine.backgroundColor = UIColor.darkGray
            
            self.AddContactVC.modalPresentationStyle = .popover
            self.AddContactVC.preferredContentSize = CGSize.init(width:UIScreen.main.bounds.size.width-25, height: 180.0)
            
            let popOverController = self.AddContactVC.popoverPresentationController
            popOverController?.permittedArrowDirections = .init(rawValue: 0)
            popOverController?.delegate = self
            popOverController?.sourceView = self.view
            popOverController?.sourceRect = CGRect.init(x:self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
            self.present(self.AddContactVC, animated: true, completion: {
                self.view.alpha = 0.5
                self.AddContactVC.view.superview?.layer.cornerRadius = 5
            })
        }
        return [EditAction,DeleteAction];
    }
    
}



struct EmergencyContactStruct {
    var MobileNumber:String!
    var Name:String!
}

//func SetEmergencyValue(Structarr:[EmergencyContactStruct]) {
//    var Array = [[String:String]]();
//    
//    for struc in Structarr {
//        var dict = [String:String]()
//        dict["Phone"] = struc.MobileNumber!
//        dict["Name"] = struc.Name!
//        Array.append(dict)
//        
//    }
//    
//    UserDefaults.standard.set(Array, forKey: "EmegencyContactUserDefaults")
//    UserDefaults.standard.synchronize()
//}
//func GetEmergencyValue() -> [EmergencyContactStruct] {
//    var Data = [EmergencyContactStruct]()
//    if (UserDefaults.standard.object(forKey: "EmegencyContactUserDefaults") as? [[String:String]]) != nil {
//        let arr = UserDefaults.standard.object(forKey: "EmegencyContactUserDefaults") as? [[String:String]]
//        for Dict in arr! {
//            var structobj = EmergencyContactStruct()
//            structobj.MobileNumber = Dict["Phone"]!
//            structobj.Name = Dict["Name"]!
//            Data.append(structobj)
//        }
//        return Data
//    }
//    else {
//        return Data
//    }
//}

// MARK: - Toast Make Black and White
 // MARK: -

//
//EmergencyContactDetails(EmergencyContactRequest EmergencyContact)
//    
//{
//    "EmpId":"132004",
//    "EmergencyContacts":"9123405678"
//    
//}
