//
//  UpdatePassVC.swift
//  DriveBooking
//
//  Created by Raja Bhuma on 17/05/17.
//  Copyright © 2017 Sun Telematics Pvt Ltd. All rights reserved.
//

import UIKit

class UpdatePassVC: UIViewController, UITextFieldDelegate {

    var EmpID: String!
    var Mobile: String!
    
    @IBOutlet weak var newPasswordLabel: UILabel!
    @IBOutlet weak var newPasswordTextField: UITextField!
    @IBOutlet weak var confirmPasswordLabel: UILabel!
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        newPasswordLabel.isHidden = true
        confirmPasswordLabel.isHidden = true
        
        self.title = "Update Password"
        
        let BackBtnItem = UIBarButtonItem.init(image: UtilitiesClassSub.reduceSizeOftheImage(UIImage.init(named: "BackActionBtn"), to: CGSize.init(width: 23, height: 23)), style: .done, target: self, action: #selector(BackAction))
        BackBtnItem.tintColor = UIColor.black
        BackBtnItem.imageInsets = UIEdgeInsetsMake(0, -15, 0, +5)
        self.navigationItem.leftBarButtonItem = BackBtnItem
        self.perform(#selector(updateTextFields), with: self, afterDelay: 0.1)
    }
    
    @objc func updateTextFields(){
        newPasswordTextField.BottomLine = UIColor.black
        confirmPasswordTextField.BottomLine = UIColor.black
    }

    @objc func BackAction() {
        let Login = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        self.navigationController?.pushViewController(Login, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func UpdateBtnPressed(_ sender:UIButton) {
        if newPasswordTextField.text! == "" && confirmPasswordTextField.text! == "" {
            Message.shared.Alert(Title: "Alert", Message: "Please Enter new and confirm password to update", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            return
        }
        if newPasswordTextField.text! == ""{
            Message.shared.Alert(Title: "Alert", Message: "Please Enter new password to update", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            return
        }
        if (newPasswordTextField.text!.characters.count<5){
            Message.shared.Alert(Title: "Alert", Message: "Password should be minimum 5 characters", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
            return
        }
        if confirmPasswordTextField.text! == ""{
            Message.shared.Alert(Title: "Alert", Message: "Please confirm your password to update", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)

            return
        }
        if newPasswordTextField.text! == confirmPasswordTextField.text! {

            self.view.StartLoading()
            
            let Cred = FetchDriveCredentials()!
            
            let ChangeDict = ["Password":self.newPasswordTextField.text!,
                              "MobileNo":self.Mobile!,
                              "EmpId":self.EmpID!,
                              "VendorId":Cred.VendorId!,
                              "CorporateId":Cred.CorporateId!,
                              "AppCustomerType":Cred.AppCustomerType!]
            
            WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveGetUpdatedPassword, parameterDict: ChangeDict, securityKey: WebServicesUrl.DummySecurity, completion: { (responce, responceCode, success) in
                self.view.StopLoading()
                if success {
                    let Table = (responce as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
                    
                    if Table.count > 0 {
                        if "\(Table[0]["Status"]!)".toBool()! {
                            
                            UIApplication.shared.keyWindow?.ShowBlackTostWithText(message: "\(Table[0]["Response"]!)", Interval: 4)
                            
                            DispatchQueue.main.async {
                                
                                self.view.StartLoading()

                                let Cred = FetchDriveCredentials()!
                                
                                let version = "\(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString")!)"
                                
                                let Dict = ["UserName":self.Mobile!,
                                            "Password":self.newPasswordTextField.text!,
                                            "VendorId":Cred.VendorId!,
                                            "CorporateId":Cred.CorporateId!,
                                            "AppCustomerType":Cred.AppCustomerType!,
                                            "Version":version,
                                            "DeviceToken":"323",
                                            "DeviceIMEINO":UIDevice.current.identifierForVendor!.uuidString,
                                            "DeviceType":UIDevice.current.systemName]
                                
                                WebService().callDriveBookingAPI(Suffix: WebServicesUrl.DriveLogin, parameterDict: Dict, securityKey: WebServicesUrl.DummySecurity) { (value, responcecode, success) in
                                    
                                    self.view.StopLoading()
                                    
                                    if success {
                                        let Table = (value as! [String:AnyObject])["Table"] as! [[String:AnyObject]]
                                        if "\(Table[0]["Status"]!)".toBool()! {
                                            SaveDriveRequest(request: Dict)
                                            SaveDriveResponce(DriveResponce: Table[0])
                                            
                                            let NavMain = self.storyboard?.instantiateViewController(withIdentifier: "LGSideMenu")
                                            self.present(NavMain!, animated: true, completion: nil)
                                        }
                                        else {
                                            self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                                        }
                                        
                                    }
                                    else {
                                        print(responcecode.GetResponceCode())
                                        self.view.ShowBlackTostWithText(message: Constants.InternalError, Interval: 3)
                                    }
                                }
                            }
                        }
                        else {
                            Message.shared.Alert(Title: "Alert", Message: "\(Table[0]["Response"]!)", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                        }
                    }
                    else {
                        Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
                else {
                    if responceCode == .NoInternet {
                        Message.shared.Alert(Title: "Alert", Message: "Check the Internet connection and try again", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                    else {
                        Message.shared.Alert(Title: "Alert", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
                    }
                }
            })
        }
        else{
            Message.shared.Alert(Title: "Alert", Message: "New password and confirm password should be same", TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithOutSelector(Title: "Ok")], Controller: self)
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == newPasswordTextField {
            newPasswordLabel.isHidden = false
            newPasswordTextField.placeholder = ""
        }
        else {
            confirmPasswordLabel.isHidden = false
            confirmPasswordTextField.placeholder = ""
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        CheckForLabels()
    }
    
    func CheckForLabels() {
        
        if !(newPasswordTextField.text?.isEmpty)! {
            newPasswordLabel.isHidden = false
        }
        else {
            newPasswordLabel.isHidden = true
        }
        
        if !(confirmPasswordTextField.text?.isEmpty)! {
            confirmPasswordLabel.isHidden = false
        }
        else {
            confirmPasswordLabel.isHidden = true
        }
        
        newPasswordTextField.placeholder = "New Password"
        confirmPasswordTextField.placeholder = "Update Password"
    }
}
